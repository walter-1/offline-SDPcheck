<# last edit by: waltere 2022-09-27
 File Name: check-rfl-csv_Tech_Path.ps1 [Net|Dom|Cluster|Core|VSS|HyperV|RDS|Print|HyCoClNe|Client|All_OS] [full-path-to-expanded-SDP-report] [2008|2008R2|2012|2012R2|2016] -RunAddonBitMask <Int32>
 Help: get-help \\emeacssdfs.europe.corp.microsoft.com\netpod\rfl\check-rfl-csv_Tech_Path.ps1 -detailed 
    call script with -Verbose or -Debug for add. output
 ToDo: adjust $ReleaseCU_B for B/C CUs
       #ToDo# once we reach EOS of 20H2 (?? 2022) replace 20H2 with 21H2
	   open xray_ISSUES-FOUND if exists
#>

<#
.SYNOPSIS
The script reads SDP report and displays list of missing detailed hotfix information that needs to be installed, compared to CSS RFL list.

SYNTAX: .\check-rfl-csv_Tech_Path.ps1 [Net|Dom|Cluster|Core|VSS|HyperV|RDS|Print|HyCoClNe|Client|All_OS] [full-path-to-expanded-SDP-report] [2008|2008R2|2012|2012R2|2016|2016RS1|2016RS5|201620H2|201621H1|201621H2|201622H2|2022|Win11|Win1122H2]
 All_OS  = combination of All OS components (all platform RFLs)
 Net    = Networking
 Dom    = Domains/ActiveDirectory
 Cluster  = Microsoft Failover Cluster
 Core   = Core Operating System
 VSS    = Volume Shadow Copy Service
 HyperV  = Microsoft Windows Hyper-V Hypervisor
 RDS    = Remote Desktop Services (Terminal Services)
 Print   = Printing
 HyCoClNe = combination of HyperV, Core, Cluster, Net
 Client  = PUAS for Client OS

If you experience PS error '...is not digitally signed.' run the command:
 Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force
 check if an ExecutionPolicy higher in precedence (Get-ExecutionPolicy -List) disallows script execution.

.DESCRIPTION
The script will check the binaries available in the most recent RFL list against the installed binaries seen in expanded SDP report.
It will generate an output file in the SDP folder named !%computername%_Engineer_RFL_list_<tech>_<SdpOSversion>.txt

 join DL for questions:
 WW CSS RFL-check User Discussion <ww-CSS-RFL-check@microsoft.com>

.PARAMETER OpenSummary
	 This switch will not open resulting summary file with Notepad/Favorite Editor if set to $False
	 Reg-key per user: HKEY_CURRENT_USER\Software\RFLcheck\shellExtension\OpenWithFavEditor - Value 1: open FavEditor
	 
.EXAMPLE
	\\emeacssdfs.europe.corp.microsoft.com\netpod\rfl\check-rfl-csv_Tech_Path.ps1 All_OS \\Server\SR\extracted-SDP\
	will create tables of installed/missing recommended hotfixes in file !%computername%_Engineer_RFL_list_All_OS_<SdpOSversion>.txt in the same extraced-SDP folder.
	In addition it will run all addons (RegistryCheck, PstatSummary, Pstat-Compare, PerfMonAnalyis, Events summary)

.EXAMPLE
	\\emeacssdfs.europe.corp.microsoft.com\netpod\rfl\check-rfl-csv_Tech_Path.ps1 Cluster \\Server\SR\extractedSDP\ -RunAddonBitMask 21
	 BitMask: 1=get-PStatSum, 2=check-RegistryKeyNames, 4=get-pma, 8=get-events, 16=Compare-PStatSummary
	 '-RunAddonBitMask 21' will run only three AddOns, 1+4+16, '-RunAddonBitMask 0' will not run any addon
	 Addon 1: get-PStatSum
	 Addon 2: check-RegistryKeyNames
	 Addon 4: get-pma
	 Addon 8: get-events
	 Addon 16: Compare-PStatSummary
	 Addon 32: Arrange-SDPFolders
	 Addon 64: ChaseEvents -tbd
	 Addon 128: get-version-RFLShellExt

 Reg-key per user: HKEY_CURRENT_USER\Software\RFLcheck\shellExtension\RunAddonBitMask - default Value: 255 (= run all AddOns)
 
.LINK
	 datapath: \\emeacssdfs.europe.corp.microsoft.com\netpod\rfl\check-rfl-csv_Tech_Path.ps1
	 email:  waltere@microsoft.com; ww-CSS-RFL-check@microsoft.com
	 KB: https://internal.support.services.microsoft.com/en-us/help/3070416

#>

[CmdletBinding()]
PARAM (
	[ValidateSet("net","dom","cluster","core","vss","hyperv","rds","print","All_OS","SCVMM2012R2","HyCoClNe","Exchange","Client","CM2007","CM2012RTM","CM2012SP1","CM2012SP2","CM2012R2","custom")]
	[Parameter(Mandatory=$True,Position=0,HelpMessage='Choose one technology from: Net|Dom|Cluster|Core|VSS|HyperV|RDS|Print|Custom|HyCoClNe|SCVMM|Client|Exchange|CM2007|CM2012RTM|CM2012SP1|CM2012SP2|CM2012R2|All_OS|CoDoNe')]
	[string]$RFLFixesTech
	,
	[ValidateScript({Test-Path -LiteralPath $_ -PathType 'Container'})]
	[Parameter(Mandatory=$True,Position=1,HelpMessage='Choose a writable SDP folder location, i.e. C:\SR\SDP-report\ ')]
	[string]$SDPPath
	,
	[ValidateSet("2008","2008R2","2012","2012R2","2016","2016RS1","2016RS2","2016RS3","2016RS4","2016RS5","201619H1","201619H2","20162004","201620H2","201621H1","201621H2","201622H2","2022","Win11","Win1122H2","help")]
	[Parameter(Mandatory=$False,Position=2,HelpMessage='optional: Choose one OS from list: [2008|2008R2|2012|2012R2|2016|2016RS1|2016RS4|2016RS5|201619H2|20162004|201620H2|201621H1|201621H2|201622H2|2022|Win11|Win1122H2]')]
	[string]$SdpOSversion
	,
	[Parameter(Mandatory=$False,Position=3,HelpMessage='optional: choose RunAddonBitMask value in decimal, 1=get-PStatSum, 2=check-RegistryKeyNames, 4=get-pma, 8=get-events, 16=Compare-PStatSummary, 32=Arrange-SDPFolders, 64=ChaseEvents 128=get-version-RFLShellExt')]
	[int]$RunAddonBitMask=255
	,
	[switch]$HostMode  = $false, 		#This tells the logging functions to show logging on the screen
	[switch]$ScriptMode = $false, 		#This tells the logging functions to show logging in log file
	[switch]$UseExitCode= $true,		#This will cause the script to close after the error is logged if an error occurs.
	[switch]$BuildRS5= $false, 			#This is used to build RS5/20H2+ ready latest list for master file
	[switch]$Global:OpenSummary= $true,	# open with Notepad/FavEditor
	[switch]$noVersionChk= $false,		# if True, don't check for new version
	[switch]$noUpdate= $false,			# if True, don't update this script
	[switch]$DbgOut= $false				# Debug Mode
	)

BEGIN {
	$verDateScript	= "2022.10.21.0"
	$ScriptFolder 	= Split-Path $MyInvocation.MyCommand.Path -Parent
	# Load Common Library / module
		Remove-Module Utils_RflUpd -ErrorAction Ignore
		Import-Module $ScriptFolder\Utils_RflUpd.psm1 -DisableNameChecking
	$error.clear()	# clear previous PS script errors
	# This saves the starting ErrorActionPreference and then sets it to 'Stop'.
	$startErrorActionPreference = $errorActionPreference
	$errorActionPreference = 'Stop'
	# This gets the current path and name of the script.
	$invocation = (Get-Variable MyInvocation).Value
	$scriptName = $invocation.MyCommand.Name
	$UserName  = ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name)

	Set-Variable -Name ErrorMsg -Scope Script -Force
	[string]$Script:ErrorMsg=""

	### Trail SDPPath with \ and allow path with space character
	if ($SDPPath.EndsWith("\")){$SDPPath="$SDPPath"}
	else {$SDPPath="$SDPPath" +"\"}

	If (-NOT (Test-Path $SDPPath -PathType 'Container')){
				$Script:ErrorMsg += "No-Valid-SDP-path "
				Throw "$($SDPPath) is not a valid folder"}

#region: ###### customization section of script, logging configuration ########################
	$SDPcheckINI = (Get-content -Path "$ScriptFolder\_SDPcheck.ini")
	$Script:verDateRFL = (($SDPcheckINI[0] -split " ")[2]).trim("""") #"2022.10.21.0"
	$InOfflineMode = (($SDPcheckINI[1] -split " ")[2]).trim("""")	# set $True for outsourcer or when not connected to MS network - offline-SDPcheck
	$DFSserverName = (($SDPcheckINI[7] -split " ")[2]).trim("""")
	$ReleaseCU = $ReleaseCU_B = (($SDPcheckINI[3] -split " ")[2]).trim("""")	# refine in section below
	$ReleaseCU_C = (($SDPcheckINI[5] -split " ")[2]).trim("""")
	if ($InOfflineMode -match "False") {
		$RFLroot = (($SDPcheckINI[2] -split " ")[2]).trim("""")	# "\\emeacssdfs.europe.corp.microsoft.com\netpod\rfl\"
		$StatsServer = (($SDPcheckINI[4] -split " ")[2]).trim("""")
		#Write-Host "Test-Connection -ComputerName $StatsServer -Quiet -Count 1"
		if (Test-Connection -ComputerName $StatsServer -Quiet -Count 1) {[bool]$Stats=$True} else {[bool]$Stats=$False}
	} else { 
		$RFLroot = "\\localhost\ToolsShare\rfl"
		$RflUpdLogfile = $ScriptFolder + "\_RFL_Update-Log.txt"
		$Stats = $False
	}
	$csvDelimiter=","
	$Report_Type="Engineer_RFL"
	[bool]$OmitFullList=1
	[bool]$check_MS17_010=1
#	[bool]$DbgOut=0				# used for verbose debug output		#we# 0
	[bool]$RunAddon=1			# used for running additonal checks #we# 1
	#$RunAddonBitMask=255		# used for running additonal checks 1=get-PStatSum, 2=check-RegistryKeyNames, 4=get-pma, 8=get-events, 16=Compare-PStatSummary, 32=Arrange-SDPFolders, 64=ChaseEvents, 128=get-version-RFLShellExt
	$OutFileChars=300			# max line length in outfile
	if ($Stats) {
		$StatsServerPath="\\$StatsServer\netpodW$\RFL\scripts\Stats\"
		[bool]$StatsErr=1			# used for PS last error stats
		[bool]$FeedHigherSDPver=1	# used for accurancy of RFL database
		$HigherSDPverBinExceptList = "repdrvfs.dll","tzres.dll","unires.dll","unidrv.dll","Xpsgdiconverter.dll"
		$ListOfHigherSDPverFile 	= $StatsServerPath +'ToDo_RFLupdates.csv'
		$CountInvFil = $StatsServerPath +'countRFL.dat'
		$CountInvFil2 = $CountInvFil +'.us'
		$CountInvFil4 = $CountInvFil +'.PSErrAddon.txt'
		 ($j=[int32](Get-Content $CountInvFil -TotalCount 1 -ErrorAction SilentlyContinue)) |out-null
		 (++$j) | Set-Content $CountInvFil -ErrorAction SilentlyContinue
	}
#endregion: ###### customization section
if ($DbgOut){
	Write-Host  "___InOfflineMode $InOfflineMode"
	Write-Host "___ReleaseCU B/C  $ReleaseCU_B / $ReleaseCU_C"
	Write-Host "___RFLroot       $RFLroot"
	Write-Host "___Stats         $Stats"
	Write-Host "___ScriptFolder  $ScriptFolder"
	Write-Host "___ RunAddonBitMask $RunAddonBitMask"
}
	$RFLpath = $RFLroot + "\RflLists\"
	$UsrOSVersion = [Environment]::OSVersion.Version.ToString(3)
	$CheckDate = (Get-Date).ToUniversalTime().ToString("yy-MM-dd_HH-mm-ss")
	$i=0	# used in $Title*
	
	#check User preferences for OpenWithFavEditor and RunAddonBitMask
	$registryPathHKCU = "HKCU:\Software\RFLcheck\shellExtension"
	if ($registryPathHKCU) {
		 $OpenSum = (Get-ItemProperty -Path $registryPathHKCU -Name OpenWithFavEditor).OpenWithFavEditor
		 if ($OpenSum -eq "1") {Set-Variable -scope Global -name OpenSummary -Value $true} else {if ($Global:OpenSummary) {Clear-Variable -scope Global -name OpenSummary}}
		 if (-not $RunAddonBitMask) {$RunAddonBitMask = (Get-ItemProperty -Path $registryPathHKCU -Name RunAddonBitMask).RunAddonBitMask}
	}

	$ScriptError = $null
	If ($PSBoundParameters['Debug']) { $DebugPreference='Continue'}

#region  ::::: [Functions] -----------------------------------------------------------#
Function global:RflEnterFunc([String]$FunctionName){
	Write-Verbose "---> Enter $FunctionName"
}

Function global:RflEndFunc([String]$FunctionName){
	Write-Verbose "<--- End $FunctionName"
}

Function CheckVersion ($verCurrent){	
	RflEnterFunc ($MyInvocation.MyCommand.Name + "(verCurrent: $verCurrent)")
  if (-Not $noVersionChk.IsPresent){
	# automated version checking. When launched, the script will warn if a newer version is available online and recommend to download it. 
	# Internet access is required and the repository to be reachable, for the version check to be successful. It will NOT automatically download the new version; this will be up to the user to do.
#	$RFLReleaseServer = "api.Github.com"
	$UpdateSource = "GitHub"
	Try{
		$checkConn = FwTestConnWebSite $RFLReleaseServer # FwTestConnWebSite could throw an exception
		if ( $checkConn -eq "True") {
			try	{
				Write-Debug "[$($MyInvocation.MyCommand.Name)] try Invoke-WebRequest "
				# GitHub: Get web content and convert from JSON
				[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
				try { $web_content = Invoke-WebRequest -Uri $RFL_release_url -UseBasicParsing | ConvertFrom-Json } catch { "`n$(Get-Date -UFormat "%D %R:%S")*** Failure during RFL update. Exception Message:`n $($_.Exception.Message)" | Out-File $RflUpdLogfile -Append }
				if ($web_content.tag_name) {
					[version]$expected_latest_RFL_version = $web_content.tag_name.replace("v","")
					$verNew = $expected_latest_RFL_version
					write-verbose "[$($MyInvocation.MyCommand.Name)] $UpdateSource Version of '$RFL_release_url': --> $verNew"
					
					$installedRFLver = New-Object System.Version($verCurrent)
					$expectedVersion = New-Object System.Version($expected_latest_RFL_version)
					if ($($($installedRFLver).CompareTo($($expectedVersion))) -eq 0) { 		# If versions match, display message
							"`n $(Get-Date -UFormat "%D %R:%S")[$($MyInvocation.MyCommand.Name)] [Info] Latest RFL version $expectedVersion is installed. " | Out-File $RflUpdLogfile -Append
							#Write-Host -ForegroundColor Cyan "[$($MyInvocation.MyCommand.Name)] [Info] Latest RFL version $expectedVersion is installed.`n"
					}
					elseif ($($installedRFLver.CompareTo($expectedVersion)) -lt 0) {	# if installed current version is lower than latest $UpdateSource Release version
							"`n $(Get-Date -UFormat "%D %R:%S")[Action: $RFL_action -[Warning] Actually installed RFL version $installedRFLver is outdated - please run $ScriptFolder\RFL_update-script.ps1] " | Out-File $RflUpdLogfile -Append
							Write-Host -ForegroundColor red "[$($MyInvocation.MyCommand.Name)] [Warning] Actually installed RFL version $installedRFLver is outdated!`n - please run $ScriptFolder\RFL_update-script.ps1"
							Write-Host -ForegroundColor cyan "[$($MyInvocation.MyCommand.Name)] [Info] Latest available version on Github is: $expectedVersion"
							Write-Host -ForegroundColor cyan "[$($MyInvocation.MyCommand.Name)] Trying AutoUpdate now... "
							Write-Host -ForegroundColor Magenta "*** Note: results will only be accurate at next run! ***"
							& $ScriptFolder\RFL_update-script.ps1
					}
					else{
						"`n $(Get-Date -UFormat "%D %R:%S")[[Info] installedRFLver $installedRFLver -newer than- expectedVersion $expectedVersion] " | Out-File $RflUpdLogfile -Append
						Write-host "[$($MyInvocation.MyCommand.Name)] installedRFLver $installedRFLver -newer than- expectedVersion $expectedVersion"
						}
					Write-verbose "[$($MyInvocation.MyCommand.Name)] installedRFLver $installedRFLver - expectedVersion $expectedVersion"

					if($expectedVersion -gt $installedRFLver) {
						WriteWarning (" A newer version is available: v"+$verNew+" (you are currently on v"+$verCurrent+"). For best results, download and use the latest version from https://aka.ms/getRFL")
						$Script:fUpToDate = $False
					}else {
						write-verbose " [$($MyInvocation.MyCommand.Name)] verNew $verNewt - verCurrent $verCurrent"
						Write-Host -ForegroundColor Green  ("[$($MyInvocation.MyCommand.Name)] You are running the latest version (v"+$verCurrent+")")
						$Script:fUpToDate = $True
					}
					#return $expected_latest_RFL_version
				}else { 
					Write-Host -ForegroundColor Red "[$($MyInvocation.MyCommand.Name)] [ERROR] cannot securely access $RflReleaseServer. Please download https://aka.ms/getRFL"
					"`n $(GGet-Date -UFormat "%D %R:%S") [ERROR] cannot securely access $RflReleaseServer. Please download https://aka.ms/getRFL" | Out-File $RflUpdLogfile -Append
					$script:ChkFailed=$TRUE
					return 2022.0.0.0
				}
			}catch{
					WriteWarning ("[$($MyInvocation.MyCommand.Name)] Unable to check RFL script version online... (local version: v"+$verCurrent+")" + $_)
					WriteInfo "[$($MyInvocation.MyCommand.Name)] For best results, always use the latest version from https://aka.ms/getRFL"
			}
		}Else{
			WriteWarning ("[$($MyInvocation.MyCommand.Name)] Unable to contact MS tools store: $RFLReleaseServer (local version: v" +$verCurrent+ ")")
			WriteInfo "[$($MyInvocation.MyCommand.Name)] For best results, always use the latest version from https://aka.ms/getRFL"
		}
	}Catch{	$checkConn = $False	}
  }
  RflEndFunc ($MyInvocation.MyCommand.Name + "(fUpToDate: $Script:fUpToDate)")
}

Function UpdateRFL{
	RflEnterFunc ($MyInvocation.MyCommand.Name)
	If(Test-Path -Path "$Scriptfolder\RFL_update-script.ps1"){
		WriteInfo "[update] RFL update starting..." green
		Try{
			.\RFL_update-script.ps1 -RFL_action update -UpdMode Full #-verOnline $Script:RFLVerOnline 
		}Catch{
			LogException "Exception happened in RFL_update-script.ps1" $_
		}
		WriteInfo "[update] RFL update procedure completed."
	}Else{
		WriteWarning "[update] unable to find RFL_update-script.ps1" 
	}
	RflEndFunc ($MyInvocation.MyCommand.Name)
}

function Using-Culture{
	# SYNOPSIS: avoid tr-TR issue with Turkish character 'i /I' in Select-String -Pattern calls
	param(
		[System.Globalization.CultureInfo]$culture = (throw "USAGE: Using-Culture -Culture culture -Script {scriptblock}"),
		[ScriptBlock]$script= (throw "USAGE: Using-Culture -Culture culture -Script {scriptblock}")
	)
	RflEnterFunc ($MyInvocation.MyCommand.Name)
	$OldCulture = [System.Threading.Thread]::CurrentThread.CurrentCulture
	trap
	{
		[System.Threading.Thread]::CurrentThread.CurrentCulture = $OldCulture
	}
	[System.Threading.Thread]::CurrentThread.CurrentCulture = $culture
	Invoke-Command $script
	[System.Threading.Thread]::CurrentThread.CurrentCulture = $OldCulture
	Write-Debug "OldCulture: $OldCulture culture: $culture"
	RflEndFunc ($MyInvocation.MyCommand.Name)
}

function check-MS17-010-version-Installed ($ComputerName,$SdpOSversion,$Binary,$SdpVer){
		# SYNOPSIS: This function compares srv.sys version of SDP report with the versions listed in chart of https://support.microsoft.com/en-us/help/4023262/how-to-verify-that-ms17-010-is-installed
		#      if higher or equal to the patched version, then return "Patched".
		 If (($SdpOSversion -match "2008R2|2012|2016TH2|2016RS1") -or ($SdpOSversion -eq "2016")) {
			write-host " running WannaCrypt/Petya MS17-10 check for: $ComputerName $SdpOSversion $Binary "
			If ($SdpVer)
				{
				Try
					{
					$versionString = $SdpVer
					$fileVersion = New-Object System.Version($versionString)
					}
				Catch
					{
					Write-Host "Unable to retrieve file version info, please verify vulnerability state manually." -ForegroundColor Yellow
					Return
					}
			}
			Else
				{
				Write-Host "Srv.sys does not exist, please verify vulnerability state manually." -ForegroundColor Yellow
				Return
				}
			switch($SdpOSversion)
				{
				"2008"		{
							if ($versionString.Split('.')[3][0] -eq "1")
								{
								$currentOS = "$SdpOSversion GDR"
								$expectedVersion = New-Object System.Version("6.0.6002.19743")
								}
							elseif ($versionString.Split('.')[3][0] -eq "2")
								{
								$currentOS = "$SdpOSversion LDR"
								$expectedVersion = New-Object System.Version("6.0.6002.24067")
								}
							}
				"2008R2"	{$currentOS = "$SdpOSversion LDR"; $expectedVersion = New-Object System.Version("6.1.7601.23689")}
				"2012"		{$currentOS = "$SdpOSversion LDR"; $expectedVersion = New-Object System.Version("6.2.9200.22099")}
				"2012R2"	{$currentOS = "$SdpOSversion LDR"; $expectedVersion = New-Object System.Version("6.3.9600.18604")}
				"2016"		{$currentOS = "$SdpOSversion TH1"; $expectedVersion = New-Object System.Version("6.2.10240.17319")}
				"2016TH2"	{$currentOS = "$SdpOSversion TH2"; $expectedVersion = New-Object System.Version("6.2.10586.839")}
				"2016RS1"	{$currentOS = "$SdpOSversion RS1"; $expectedVersion = New-Object System.Version("6.2.14393.953")}
				}
			#$expectedVersionString= $($expectedVersion.ToString())
			Write-Host "`n $currentOS Expected Version of srv.sys: $($expectedVersion.ToString())" -ForegroundColor Cyan
			Write-Host " $currentOS Actual Version of srv.sys:  $($fileVersion.ToString())" -ForegroundColor Cyan
			If ($($fileVersion.CompareTo($expectedVersion)) -lt 0)
			{
				Write-Host " $ComputerName is vulnerable for MS17-010 WannaCrypt/Petya Ransomware. Please make sure this machine gets patched." -ForegroundColor Red
				$Script:ErrorMsg += "No_MS17-10_Installed "
			}
			Else
			{
				Write-Host " $ComputerName is Patched with MS17-010" -ForegroundColor Green
			}
		 }
} #end function check-MS17-010-version-Installed

function GetOSfromMSinfo32 ($SDPPath,$NodeName,$SdpArray){
	# Return: $script:SdpOSversion of SDP report
	RflEnterFunc ($MyInvocation.MyCommand.Name + "(NodeName: $NodeName)")
	### Validate user input of expanded SDP report and identify the number of msinfo32.txt files and the names of the computers $NodeNames (in Cluster Report)
	$msinfo32 = $SDPPath + $NodeName + '*msinfo*.txt' # Try .txt
	If (-NOT (Test-Path $msinfo32)) {
	    Write-Verbose "** $SDPPath without *msinfo32.txt"
	    $msinfo32 = $SDPPath + $NodeName + '*msinfo*.nfo' # Try .nfo
	}

	### Get OS version of SDP report from msinfo.txt
	If ("$msinfo32" -match ".txt"){
	    Write-Verbose "Node: $NodeName Using msinfo32.txt: $msinfo32"
	    #Read-in content from Msinfo file
	    if ($msinfo32file = get-childitem $msinfo32) {
			Write-Debug "msinfo32file: $msinfo32file "
			$script:SDPdate = $msinfo32file.LastWriteTime
			Write-Debug "`nNode: $NodeName : SDP Date: $script:SDPdate"
			$msinfo32 = Get-Content $msinfo32 -TotalCount 13
			If ($msinfo32){
				$SdpOSbuild = 		($msinfo32[-7]).Replace("Version","")
				$script:SdpOSname = 		$msinfo32[-8];$script:SdpOSname=($SdpOSname).Split(" ",3)[2]
				$script:SdpComputerName = 	$msinfo32[1].Split("")[-1]
				$SystemModel = 		($msinfo32[-2]).Replace("System Model","") #.Split("")[1,2,3]
				$is_Virtual = 		$SystemModel| Select-String -Pattern ".*Virtual.*" -ErrorAction SilentlyContinue; if ($is_Virtual) {$Virtualized="VM"} else {$Virtualized=""}
				$is_VMware = 		$SystemModel| Select-String -Pattern ".*VMware.*" -ErrorAction SilentlyContinue; if ($is_VMware) {$Script:Virtualization="VMware"} else {$Script:Virtualization=""}
				$SystemArch = 		($msinfo32[-1]).Replace("System Type","") #.Split("")[-1,-2]
				$is_x64 = 			$SystemArch| Select-String -Pattern ".*x64.*" -ErrorAction SilentlyContinue; if ($is_x64) {$Architecture="x64"} else {$Architecture="x86"}
				Write-Output " Node: $SdpComputerName|$SdpOSbuild|$SdpOSname|$SystemModel|$SystemArch |-> $Virtualized|$Virtualization|$Architecture|"
			}else{$script:ErrorMsg += "No-Valid-MsI32_txt "}
		}
	}
	Else { # Get OS version of SDP report from msinfo.nfo / may not work for some localized OS
		Write-Verbose "Node: $NodeName Using msinfo32.nfo = $msinfo32 "
		if ($msinfo32file = get-childitem $msinfo32) {
			$script:SDPdate = $msinfo32file.LastWriteTime
			Write-Debug "`nNode: $NodeName : SDP Date: $script:SDPdate"
			[xml]$nfo = Get-Content $msinfo32file
			$summary = $nfo.MSInfo.Category.Data.value # German $nfo.MSInfo.Category.Data.Wert / Italian: Valore
			If ($summary.'#cdata-section') {
				$script:SdpOSbuild = 		($summary.'#cdata-section'[1]).Replace("Version","")
				$script:SdpOSname = 		($summary.'#cdata-section'[0]).Replace("OS Name","")
				$script:SdpComputerName = 	$summary.'#cdata-section'[4]
				$SystemModel = 	($summary.'#cdata-section'[6]).Replace("System Model","")
				$is_Virtual = 		$SystemModel| Select-String -Pattern ".*Virtual.*" -ErrorAction SilentlyContinue; if ($is_Virtual) {$Virtualized="VM"} else {$Virtualized=""}
				$is_VMware = 		$SystemModel| Select-String -Pattern ".*VMware.*" -ErrorAction SilentlyContinue; if ($is_VMware) {$Script:Virtualization="VMware"} else {$Virtualization=""}
				$SystemArch = 		($summary.'#cdata-section'[7]).Replace("System Type","")
				$is_x64 = 			$SystemArch| Select-String -Pattern ".*x64.*" -ErrorAction SilentlyContinue; if ($is_x64) {$Architecture="x64"} else {$Architecture="x86"}
				Write-Host " Node: $SdpOSbuild|$SdpOSname|$SdpComputerName|$SystemModel|$SystemArch |-> $Virtualized|$Virtualization|$Architecture|"
			}else{
				$script:ErrorMsg += "No-Valid-MsI32_nfo"
				Write-Host -BackgroundColor Black -ForegroundColor Yellow -Object "WARNING: SDP with no valid MSinfo32.txt or English .nfo files"
			}
		}
	}
	if ($SdpOSname -match "Windows 1|Windows 7|Windows 8") {$isClient = $True}
	$script:ErrorMsg += "$Architecture $Virtualized $Virtualization "
	
	### match Build number in SDP report with OS short name
	if("$SdpOSbuild" -match "2600"){$script:SdpOSversion="old-XP"; $script:SdpOSversion_old="Old_OS"}  		# Windows XP
	if("$SdpOSbuild" -match "3790"){$script:SdpOSversion="old-2003"; $script:SdpOSversion_old="Old_OS"}  	# Windows 2003
	if("$SdpOSbuild" -match "6001"){$script:SdpOSversion="old-2008-SP1"; $script:SdpOSversion_old="Old_OS"}	# Windows Vista/2008 SP1
	if("$SdpOSbuild" -match "6002|6003"){$script:SdpOSversion="2008";$ReleaseCU=$ReleaseCU_B}  		# Windows Vista/2008 SP2
	if("$SdpOSbuild" -match "7600"){$script:SdpOSversion="old-2008R2-RTM"; $script:SdpOSversion_old="Old_OS"} # Windows 7/2008R2 RTM
	if("$SdpOSbuild" -match "7601"){$script:SdpOSversion="2008R2";$ReleaseCU=$ReleaseCU_B} 			# Windows 7/2008R2
	if("$SdpOSbuild" -match "9200"){$script:SdpOSversion="2012";$ReleaseCU=$ReleaseCU_B}  			# Windows 8
	if("$SdpOSbuild" -match "9600"){$script:SdpOSversion="2012R2";$ReleaseCU=$ReleaseCU_B} 			# Windows 8.1
	if("$SdpOSbuild" -match "10240"){$script:SdpOSversion="2016";$ReleaseCU=$ReleaseCU_B} 		# Windows 10
	if("$SdpOSbuild" -match "14393"){$script:SdpOSversion="2016RS1";$ReleaseCU=$ReleaseCU_B} 	# Windows 10 RS1
	if("$SdpOSbuild" -match "17763"){$script:SdpOSversion="2016RS5";$ReleaseCU=$ReleaseCU_C} 	# Windows 10 RS5
	if("$SdpOSbuild" -match "18363"){$script:SdpOSversion="201619H2";$ReleaseCU=$ReleaseCU_C}	# Windows 10 19H2
	if("$SdpOSbuild" -match "19041"){$script:SdpOSversion="20162004";$ReleaseCU=$ReleaseCU_C} 	# Windows 10 2004 2020 April 2020 Update
	if("$SdpOSbuild" -match "19042"){$script:SdpOSversion="201620H2";$ReleaseCU=$ReleaseCU_C} 	# Windows 10 20H2 October 2020 Update
	if("$SdpOSbuild" -match "19043"){$script:SdpOSversion="201621H1";$ReleaseCU=$ReleaseCU_C} 	# Windows 10 21H1 April 2021 Update
	if("$SdpOSbuild" -match "19044"){$script:SdpOSversion="201621H2";$ReleaseCU=$ReleaseCU_C} 	# Windows 10 21H2 Oct 2021 Update
	if("$SdpOSbuild" -match "19045"){$script:SdpOSversion="201622H2";$ReleaseCU=$ReleaseCU_C} 	# Windows 10 22H2 Oct 2022 Update
	if("$SdpOSbuild" -match "20348"){$script:SdpOSversion="2022";$ReleaseCU=$ReleaseCU_C} 		# Windows Srv 2022
	if("$SdpOSbuild" -match "22000"){$script:SdpOSversion="Win11";$ReleaseCU=$ReleaseCU_C} 	# Windows 11
	if("$SdpOSbuild" -match "22621"){$script:SdpOSversion="Win1122H2";$ReleaseCU=$ReleaseCU_C}	# Windows 11 22H2 Oct 2022 Update
	Write-Verbose " OS build: $SdpOSbuild - $script:SdpOSversion $script:SdpOSversion_old"
	Write-Host " SDP Date:         $($script:SDPdate) / OS-Version: $($script:SdpOSversion) $($script:SdpOSversion_old)" #Write-Verbose
	Write-Host " SDP ComputerName: $SdpComputerName |Build: $SdpOSbuild |OS: $SdpOSname"

	$SdpArray.ComputerName = $script:SdpComputerName
	$SdpArray.SDPdate = 	$script:SDPdate
	$SdpArray.OSbuild = 	$SdpOSbuild
	$SdpArray.OSname = 		$script:SdpOSname
	$SdpArray.SystemModel = $SystemModel
	$SdpArray.Virtualized = $Virtualized
	$SdpArray.Virtualization = $Virtualization
	$SdpArray.Architecture = $Architecture
	$SdpArray.SystemArch = 	$SystemArch
	$SdpArray.SdpOSversion = $($script:SdpOSversion)
	$SdpArray.ReleaseCU = 	$ReleaseCU
	
	#$script:SdpOSversion
	RflEndFunc ($MyInvocation.MyCommand.Name + "(OS build: $SdpOSbuild - $script:SdpOSversion $script:SdpOSversion_old)")
}

Function GetUserInfputYN{
	#Get user input to continue:
	CHOICE.exe /T 20 /C yn /D n /M "Do you want to continue, Press key Y for Yes = continue, N for No = Exit."
	If($LASTEXITCODE -eq 2){ # 2=no
		Write-Host ".. ...ending RFL-check per User Input (or timeout)" -ForegroundColor Yellow
		CleanUpandExit	#	break
	}
}

function NoValidMsinfo32_askUser{
	# ask user for expected OS in SDP report
	Write-Host -BackgroundColor Black -ForegroundColor Red -Object " {335} WARNING: Sdp OSversion cannot be determined! This error happens for non-standard SDP reports, i.e. VSS, SCCM or some SQL SDP reports"
	Write-Host -BackgroundColor Black -ForegroundColor Red -Object " There are no *Msinfo*.* files in $SDPPath - Please double-check expanded SDP-path folder first!"
	Write-Host "Do you want to continue, type Y and in next step please type OS-Version"
	GetUserInfputYN
	$UserInputOS = Read-Host 'Sdp OSversion: [2008|2008R2|2012|2012R2|2016|2016RS1|2016RS5|201620H2|201621H1|201621H2|201622H2|2022|Win11|Win1122H2]'
	if ($UserInputOS -Notmatch '20|Win11') {
		Write-Host " ...ending RFL-check, wrong input for OS version: $UserInputOS "
		$Script:ErrorMsg += "No-Valid-OS-$($UserInputOS) "
		break
	}else {$SdpOSversion = $UserInputOS}
	$Script:ErrorMsg += "No-Valid-msinfo32: Usr_$($UserInputOS)"
	$MsinfoFiles = Get-Item -path ($SDPPath + '*evt_System.txt')
	Write-Host " Proceed with file: $MsinfoFiles "
	switch($UserInputOS)
		{
		"2008"		{$script:ReleaseCU=$ReleaseCU_B; $ExceptCUfileName=""}	# substituting with Date of current monthly Cumulative Updates; ToDo: add $exceptFile_OS_latest.csv
		"2008R2"	{$script:ReleaseCU=$ReleaseCU_B; $ExceptCUfileName=""}
		"2012"		{$script:ReleaseCU=$ReleaseCU_B; $ExceptCUfileName=""}
		"2012R2"	{$script:ReleaseCU=$ReleaseCU_B; $ExceptCUfileName=""}
		"2016"		{$script:ReleaseCU=$ReleaseCU_B; $ExceptCUfileName=""}
		"2016RS1"	{$script:ReleaseCU=$ReleaseCU_B; $ExceptCUfileName=""}
		"2016RS5"	{$script:ReleaseCU=$ReleaseCU_B; $ExceptCUfileName=""}
		"201620H2"	{$script:ReleaseCU=$ReleaseCU_C; $ExceptCUfileName=""}
		"201621H1"	{$script:ReleaseCU=$ReleaseCU_C; $ExceptCUfileName=""}
		"201621H2"	{$script:ReleaseCU=$ReleaseCU_C; $ExceptCUfileName=""}
		"201622H1"	{$script:ReleaseCU=$ReleaseCU_C; $ExceptCUfileName=""}
		"201622H2"	{$script:ReleaseCU=$ReleaseCU_C; $ExceptCUfileName=""}
		"2022"		{$script:ReleaseCU=$ReleaseCU_C; $ExceptCUfileName=""}
		"Win11"		{$script:ReleaseCU=$ReleaseCU_C; $ExceptCUfileName=""}
		"Win1122H2"	{$script:ReleaseCU=$ReleaseCU_C; $ExceptCUfileName=""}
		#default {write-host "____no SdpOSversion = '$SdpOSversion' found"}
		}	
}

Function CleanUpandExit{
	$CallStack = Get-PSCallStack
	$CallerInfo = $CallStack[1]
	If($CallerInfo.FunctionName -eq '<ScriptBlock>'){
		 $FuncName = 'Main'
	}Else{
		$FuncName = $CallerInfo.FunctionName
	}
	RflEnterFunc ("$($MyInvocation.MyCommand.Name)" + "(Caller - $($FuncName):$($CallerInfo.ScriptLineNumber))")
	WriteWarning "Exiting script..."
	RflEndFunc $MyInvocation.MyCommand.Name
	
	Exit
}
#endregion  ::::: [Functions] -----------------------------------------------------------#

#_# checking online for latest public version
if (-Not $noVersionChk.IsPresent){
	If (-Not $noUpdate.IsPresent){
		if ($InOfflineMode -match "True")  {
			Write-Host -ForegroundColor Gray "[InOfflineMode] Checking if a new version is available on https://aka.ms/getRFL"
			CheckVersion $script:verDateRFL
			Write-Verbose "[InOfflineMode] 'checking online for latest public version' done"
			}
	}
}
# for testing: CleanUpandExit

} #end BEGINN

PROCESS {
 try {
#region : MAIN :::::
	$Script:BeginTimeStamp = Get-Date
	if ($InOfflineMode -match "False")  {
		#Detect current serving node (NameHost) for Dfs server
		$NodeIP = (Test-Connection $DFSserverName -Count 1 -ErrorAction SilentlyContinue).IPV4Address.IPAddressToString 
		if ($NodeIP) { $NameHostObj = (Resolve-DnsName $NodeIP -ErrorAction SilentlyContinue) }
		if ($NameHostObj) { $NameHost = ($NameHostObj.NameHost.split('.')[0]) }
		Write-host -ForegroundColor Gray "___ Script v$verDateScript DFS-N currently served by Host: $NameHost ($NodeIP) - InOfflineMode: $InOfflineMode"
	}
	# Validate SDP folder for not having more than one consecutive space characters
	if (($SDPpath  -match '\s\s') -or ($SDPpath  -match '\)')) {write-host -fore red "SDP path contains more consecutive spaces or brackets. Please rename/correct the SDP path: '$SDPpath'"}
	"$Report_Type Report for Tech: '$RFLFixesTech'"
	$i++

	### Validate expanded SDP report and identify the number of msinfo32.txt files and the names of the computers $NodeNames (in Cluster Report)
	$MsinfoFiles = Get-Item -path ($SDPPath + "\*Msinfo*.txt")
	#Write-host "____ checking $($SDPPath)*Msinfo*.txt"
	if (!$MsinfoFiles) {
		Write-host "___ could not find any *Msinfo*.txt file in path $SDPPath!" 
		$MsinfoFiles = Get-Item -path ($SDPPath + "*Msinfo*.nfo")}
	if (!$MsinfoFiles) {
		NoValidMsinfo32_askUser
	}
	$NodeNames = foreach ($NodeName in $MsinfoFiles){($NodeName.name).split('_')[0]}
	Write-Host "$(Get-Date -UFormat "%D %R:%S") SDP NodeName(s): $NodeNames" # -- ReleaseCU $script:ReleaseCU

########################################################## 
# Run report for each $NodeName in Cluster
# and create separate output files per node
$NodeCnt=0
foreach ($NodeName in $NodeNames){
	$NodeCnt++
	Set-Variable -Name SdpArray -Scope Script
	$script:SdpArray = New-Object PSObject -Property @{
		ComputerName	= $Null
		SDPdate			= $Null
		OSbuild			= $Null
		OSname			= $Null
		SystemModel		= $Null
		Virtualized		= $Null
		Virtualization	= $Null
		Architecture	= $Null
		SystemArch		= $Null
	 	SdpOSversion	= $SdpOSversion
		ReleaseCU		= $Null
		}
	# Add new dynamic variable with the name SdpArray_$NodeName, for every Nodename
	# To access variable use: get-variable -Name "SdpArray_$NodeName"
	#new-variable -Name "SdpArrayNode" -Value $SdpArray -Force -Scope Global
	
	if ($($NodeNames.count) -gt 1) {
		Write-Host -BackgroundColor Blue -ForegroundColor Cyan -NoNewline -Object "$($NodeCnt) " -Separator .
		Write-Host "$(Get-Date -UFormat "%R:%S") ___Node $NodeCnt $NodeName"
	}
	$startTime_NodeName = Get-Date
	# fetch SdpOSversion from MSinfo files 
	GetOSfromMSinfo32 $SDPPath $NodeName $script:SdpArray

	Write-Verbose "___ script:SdpArray $script:SdpArray" 
	
	#Write-Host -BackgroundColor Black -ForegroundColor Red -Object "SdpOSversion $($SdpArray.SdpOSversion)"	
	if ($SdpOSversion -match "2008|RS2|RS3|RS4|19H|2004") {
			$wshell = New-Object -ComObject Wscript.Shell
			$wshell.Popup("SDP check: This OS version edition $SdpOSversion reached end of service - is out of support! Please verify with CSAM if customer has a valid CSA agreement signed for eligible OS.",0,$SdpOSversion,0x1)
	}
	If ($SdpOSversion_old) {
		Write-Host -BackgroundColor Black -ForegroundColor Red -Object "WARNING: $($SdpArray.Computername) with $SdpOSversion_old is outdated! apply latest Service Pack for: Vista/2008, Win7/2008R2
		to continue anyways, please retry using the optional parameter 3:
		.\check-rfl-csv_MultiTech_Path.ps1 [Net] [SDP-path] [2008|2008R2|2012|2012R2|2016|2016RS1|2016RS2|2016RS3|2016RS4|2016RS5|201619H1|201619H2|20162004|201620H2|201621H1|201621H2|201622H2|2022|Win11|Win1122H2] - no RFL for XP/2003 "
		#break
	}
	if("$SdpOSversion" -match "old"){Throw "$SdpOSversion is outdated! apply latest SP for: Vista/2008, Win7/2008R2, Win8/2012, or more recent Win10 version"}

	Write-Verbose "SDP ComputerName: $($SdpArray.Computername) |Build: $($SdpArray.OSbuild) |OS: $($SdpArray.OSname)"

	##########################################################
	### build $RFLFixesPath for ref__Tech+OS+latest.csv files
	# ToDo:  derive csvpath from All_OS csv with RegEX compare for POD... - see check-RegistryKeyNames.ps1 as example
	$csvpath = $RFLpath +'*'+$RFLFixesTech+'*'+$SdpOSversion+'*latest.csv'
	 If ("$RFLFixesTech" -match "CM") {$csvpath = $RFLpath +'*'+$RFLFixesTech+'_latest.csv'} # ConfigMgr
	 If ($SdpOSversion -match  "20H2|21H1|21H2|1622H2") {$csvpath = $RFLpath + 'ref__' + $RFLFixesTech +'_201620H2_latest.csv'} 	# 20H2,21H1,21H2 share same binaries and SSU as 2004 #ToDo# once we reach EOS of 20H2 ++ #ToDo#  for Win1122H2
	 #ToDo: If ($SdpOSversion -match  "Win11|Win1122H2) {$csvpath = $RFLpath + 'ref__' + $RFLFixesTech +'_Win11_latest.csv'}
	Write-Verbose "** Csv-Path: $csvpath "
	If (-NOT (Test-Path $csvpath)){Throw "$($csvpath) is not available on $RFLpath"}
	$RFLFixesPath = ((get-item $csvpath)[-1]).FullName
	$csvpathReleaseDate = ((get-item $csvpath)[-1]).LastWriteTime

	Write-Host -BackgroundColor Gray -ForegroundColor Black -Object "* Latest '$RFLFixesTech' RFL update: $csvpathReleaseDate *"

	$rfl = Import-Csv $RFLFixesPath
	$SDPpathSym = $SDPPath + $NodeName + '*sym*.csv'
	$SDPpathHotfix = $SDPPath + $NodeName + '*Hotfixes.csv'

	### inform user if SDP report is not suited, i.e. VSS, SCCM or SQL SDP reports (or if *sym or *hotfix files are missing) #2016-01-18
	$SDPpathSymFiles = get-childitem $SDPpathSym
	$SDPpathResultsFile = Get-Item -path ($SDPPath + "results.xml") -ErrorAction SilentlyContinue
	if (!$SDPpathResultsFile) {$Script:ErrorMsg += "No-Valid-resultsXml "}
	else {
		[xml]$Types = Get-Content $SDPpathResultsFile	#Select-Xml -Xml $Types -XPath "//ID"
		$SDPtype = $Types.SelectSingleNode("//ID")| ForEach-Object { $_.InnerText }
		Write-Host " SDP report type:  $SDPtype" 
	}

	if (!$SDPpathSymFiles) {
		Write-Host -BackgroundColor Black -ForegroundColor Red -Object "There are no '*sym*.csv' files in $SDPPath - Please double-check expanded SDP-path again!"
		Write-Host " Note: This error happens for non-standard SDP reports, i.e. VSS, SCCM or some SQL SDP reports [results.xml shows report-type] $SDPtype"
		Write-Host " RFL-check may show inconsistent results because of missing file versions in this report."
		GetUserInfputYN
		$Script:ErrorMsg += "No-Valid-sym_csv "
		Write-Host "***ErrorMsg: $Script:ErrorMsg "
		}

	####
	"Processing '$RFLFixesTech' RFL list for Windows $SdpOSversion (or Client OS) from SDP path:"
	"  $SDPPath"
	" SDP computer-name: $($SdpArray.Computername) with OS: $($SdpArray.OSbuild) $($SdpArray.OSname) OSshort: $($SdpArray.SdpOSversion)"
	If ($SdpOSversion -match "RS2|RS3|RS4|19H|2004") {Write-host -BackgroundColor Red -ForegroundColor Black "[EOS Note] Windows 10 $SdpOSversion reached end of service - This OS is no more supported, please update!"}
	"Please wait ... "
	if ("$SdpOSversion" -match "2012R2|2016|2022|Win11") {" - Yellow blocks mark missing fixes ... `n"}
	else 						{" - Yellow blocks mark missing fixes, - Cyan=lightBlue blocks mark GDR-fix only installed ... `n"}
	### Initialize
	[array]$myArrayMissingKB = $null
	[array]$myArrayInstalledKB = $null
	if ($FeedHigherSDPver){[array]$myArrayHigherSDPver = $null}
	$SdpVer=$null
	$sdpkb=$null
	$Cp3125574Installed=$false

	# v1.18 added for test if GDR version is installed
	$SDPpathHotfixFile = (get-childitem $SDPpathHotfix)
	write-debug "SDPpathHotfixFile: $SDPpathHotfixFile"
	if ($SDPpathHotfixFile) {
		$SDPpathHotfixFileContent = (Get-Content $SDPpathHotfixFile)
	}else{
		$Script:ErrorMsg += "No-Valid-hotfix_csv "
		Write-Host -BackgroundColor Black -ForegroundColor Red -Object "There is no '*hotfixes.csv' file in $SDPPath - Please double-check expanded SDP-path again!"
	}

	### processing RFL list for missing binaries and KB numbers
#Write-host "______ script:SdpOSversion $script:SdpOSversion - OSver $SdpOSversion - $($script:SdpOSversion)" -OK

	foreach ($line in $rfl){
		Write-Host -BackgroundColor Blue -ForegroundColor Cyan -NoNewline -Object "." -Separator .
		$Binary = 	$line.Binary
		#$Binary = ($line.Binary).ToUpper()	#2016-04-15 for Turkish character 'i /I'
		$RflVer = 	$line.Version
		$KB = 	((($line.Article).split("("))[0]).Replace(" ","") # 2015-10-04 replaced trailing blank
		$Title = 	$line.Title
		$Url = 		$line.Link
		$Release = 	$line.Published
		$Prio = 	$line.Prio
		$Branch = 	$line.Branch
		$Component = $line.Component
		$LDROnlyKB =$line.LDROnlyKB
		$LDROnlyTitle =$line.LDROnlyTitle
		$LDROnlyLink =$line.LDROnlyLink
		$IsInRollup=$line.RollupInfo

		if ($Binary -notmatch "[1-9][0-9][0-9][0-9][0-9]") { # processing binaries
			if ($SDPpathSym.count) {$SdpVer = Using-Culture en-US { Select-String -Pattern "\\$($Binary)" -Path $SDPpathSym -List -Encoding ascii -ErrorAction SilentlyContinue} } #2016-04-18
			
			if($SdpVer){
				# replace <INVALID DATE> with "Dummy 29, 2019 00:00:12"
				$SdpVerTmp=(($SdpVer[0]).ToString()).Replace("<INVALID DATE>","Dummy 29, 2019 00:00:12")
				if (-not $SdpVerTmp) {write-verbose "no verTmp @ $Binary"}
				
				$SdpVer=($SdpVerTmp).split(',')[15]
				$SdpVerFound=($SdpVerTmp).split(',')[15]
				Write-Verbose "___working on $Binary SdpVerFound: $SdpVerFound"
				$SdpVer = $SdpVer.Replace("(","");$SdpVer = $SdpVer.Replace(")","");$SdpVer = $SdpVer.Replace(":",".");$SdpVer = $SdpVer.Replace(".10585.",".10586.") ;$SdpVer = $SdpVer.Replace("10.0","6.2")
				Write-Verbose "working on $Binary SdpVer: $($SdpVer) - SdpVerTmp $SdpVerTmp"
				if (($SdpVer -ne "" -or $Null -ne $SdpVer) -and ($SdpVerFound)){
					# Compare versions and add telemetry feedback with binary + version if RflVer < SDPver
					#  ([version]$($V1)).CompareTo([version]$($V2)) // Result: if V1>V2 ->"1", if V1=V2 -> "0", if V1<V2 -> "-1"
					$VerExists = ([version]$($SDPver))
					if (([version]$($SDPver)).CompareTo([version]$($RFLver)) -eq 1){	#($RflVer -lt $SdpVer) -- now check for $SdpVer -gt $RflVer
						if ($FeedHigherSDPver){
							if ($HigherSDPverBinExceptList -NotContains $Binary){ ### (-NotContains ?) todo: -NotMatch seems not to work for multiple entries in list HigherSDPverBinExceptList --> use RegEX!
								if ($SdpVer -NotMatch ".7601.23403"){ # unless version matches Win7 Convenience pack version "6.1.7601.23403"
									write-verbose "non expected higher SDPver $SdpVer $Binary"
									Write-Host -BackgroundColor Gray -ForegroundColor Black -NoNewline -Object "." -Separator .
									if ($BuildRS5) {
										$obj2 = new-object PSObject -Property @{Prio=$Prio;Binary=$Binary;
											Branch=$Branch;RflVer=$SdpVer;SdpVer=$RflVer;Title=$Title;Release=$ReleaseCU;KB=$KB;Url=$Url;
											LDROnlyKB=$LDROnlyKB;LDROnlyTitle=$LDROnlyTitle;LDROnlyLink=$LDROnlyLink;Component=$Component;IsInRollup=$IsInRollup;Comment=" "
										}
									}else {
										$obj2 = new-object PSObject -Property @{CheckDate=$CheckDate;SdpOSversion=$($SdpArray.SdpOSversion);Architecture=$($SdpArray.Architecture);Prio=$Prio;Binary=$Binary;
											Branch=$Branch;RflVer=$SdpVer;SdpVer=$RflVer;Title=$Title;Release=$ReleaseCU;KB=$KB;Url=$Url; 
											LDROnlyKB=$LDROnlyKB;LDROnlyTitle=$LDROnlyTitle;LDROnlyLink=$LDROnlyLink;Component=$Component;IsInRollup=$IsInRollup;Comment="rEx"
										}
									}
									#"$obj2" #OK
									$myArrayHigherSDPver += $obj2
								}
							}
						}
					}
					# now do standard RFL check
					if (([version]$($RFLver)).CompareTo([version]$($SDPver)) -eq 1){ #($RflVer -gt $SdpVer)
						write-verbose "$KB $RFLver $SDPver $Binary"
							$KBgdrInstalled = $SDPpathHotfixFileContent | Select-String "$KB" #-quiet -ErrorAction SilentlyContinue
						Write-debug "KBgdrInstalled: $KB ? $KBgdrInstalled"
						if($KBgdrInstalled) { #GDR is IsInstalled="Yes"
							if ($KBgdrInstalled.Line -match "Completed successfully"){
								Write-Host -BackgroundColor Cyan -ForegroundColor Black -NoNewline -Object "." -Separator .
								$obj = new-object PSObject -Property @{Prio=$Prio;Binary=$Binary;
								Branch=$Branch;RflVer=$RflVer;SdpVer=$SdpVer;Title=$Title;Release=$Release;KB=$KB;Url=$Url;
								LDROnlyKB=$LDROnlyKB;LDROnlyTitle=$LDROnlyTitle;LDROnlyLink=$LDROnlyLink;Component=$Component;IsInRollup=$IsInRollup;IsInstalled="Yes"}
								$myArrayMissingKB += $obj
							}
						}
						else { #GDR is not installed
							Write-Host -BackgroundColor Yellow -ForegroundColor Cyan -NoNewline -Object "." -Separator .
							$obj = new-object PSObject -Property @{Prio=$Prio;Binary=$Binary;
							Branch=$Branch;RflVer=$RflVer;SdpVer=$SdpVer;Title=$Title;Release=$Release;KB=$KB;Url=$Url;
							LDROnlyKB=$LDROnlyKB;LDROnlyTitle=$LDROnlyTitle;LDROnlyLink=$LDROnlyLink;Component=$Component;IsInRollup=$IsInRollup;IsInstalled="No"}
							$myArrayMissingKB += $obj
						}
						# Do MS17-010 srv.sys version check: check-MS17-010-version-Installed
						if ($check_MS17_010) {
							if ($Binary -match "srv.sys") { # write-host " running WannaCrypt/Petya MS17-10 check for: $($SdpArray.Computername) $SdpOSversion $Binary "
								check-MS17-010-version-Installed $($SdpArray.Computername) $SdpOSversion $Binary $SdpVer
							}
						}
					}
					else{ #IsInstalled="Yes"
						$obj1 = new-object PSObject -Property @{Prio=$Prio;Binary=$Binary;
						Branch=$Branch;RflVer=$RflVer;SdpVer=$SdpVer;Title=$Title;Release=$Release;KB=$KB;Url=$Url;
						LDROnlyKB=$LDROnlyKB;LDROnlyTitle=$LDROnlyTitle;LDROnlyLink=$LDROnlyLink;Component=$Component;IsInRollup=$IsInRollup;IsInstalled="Yes"}
						$myArrayInstalledKB += $obj1
					}
				}else{Write-Host -BackgroundColor Red -ForegroundColor Black "SDP version not found for binary: $Binary"}
			}
		}
		else { # processing KB article numbers
		$sdpkb = Using-Culture en-US { Select-String -Pattern $Binary -Path $SDPpathHotfix -ErrorAction SilentlyContinue } #2016-04-18
		if(!($sdpkb))
			{
				Write-Host -BackgroundColor Yellow -ForegroundColor Cyan -NoNewline -Object "." -Separator .
				$obj = new-object PSObject -Property @{Prio=$Prio;Binary="";
				Branch=$Branch;RflVer="";SdpVer="";Title=$Title;Release=$Release;KB=$KB;Url=$Url;
				LDROnlyKB="";LDROnlyTitle="";LDROnlyLink="";Component=$Component;IsInRollup=$IsInRollup;IsInstalled="No"}
				$myArrayMissingKB += $obj
			}
		else{ #IsInstalled="Yes"
				$obj1 = new-object PSObject -Property @{Prio=$Prio;Binary="";
				Branch=$Branch;RflVer="";SdpVer="";Title=$Title;Release=$Release;KB=$KB;Url=$Url;
				LDROnlyKB="";LDROnlyTitle="";LDROnlyLink="";Component=$Component;IsInRollup=$IsInRollup;IsInstalled="Yes"}
				$myArrayInstalledKB += $obj1
				}
		} #end else - processing KB article numbers
	} #end foreach ($line in $rfl)

	### processing KBOnlyRollup_*_History.txt for installed cumulative KB numbers
	If ($SdpOSversion -match  "20H2|21H1|21H2|1622H2") {$KBOnlyRollupFileName = $RFLpath + "KBOnlyRollup_201620H2_History.txt"} 	# 20H2,21H1,21H1 share same History file as 2004 #ToDo# once we reach EOS of 2004
	else { $KBOnlyRollupFileName = $RFLpath + "KBOnlyRollup_" +$SdpOSversion+ "_History.txt"}
	$KBOnlyRollupFile   = Import-Csv $KBOnlyRollupFileName

	foreach ($line in $KBOnlyRollupFile){
		Write-Host -BackgroundColor Blue -ForegroundColor Cyan -NoNewline -Object "." -Separator .
		$Binary = $line.Binary
		$Component = $line.Component
		$Prio = $line.Prio
		$Release = $line.Published
		$Branch = $line.Branch
		$KB = ((($line.Article).split("("))[0]).Replace(" ","")
		$Title = $line.Title
		$Url = $line.Link
		$IsInRollup=$line.RollupInfo

		if ($Binary -match "[1-9][0-9][0-9][0-9][0-9]") #working on KB#s
		{
		 $CumulativeKBinstalled = $SDPpathHotfixFileContent | Select-String "$($Binary).*Completed successfully"
		 Write-Verbose "KB $Binary match $($CumulativeKBinstalled)"
		 if ($CumulativeKBinstalled) { #IsInstalled="Yes"
					$obj1 = new-object PSObject -Property @{Prio=$Prio;Binary="";
					Branch=$Branch;RflVer="";SdpVer="";Title=$Title;Release=$Release;KB=$KB;Url=$Url;
					LDROnlyKB="";LDROnlyTitle="";LDROnlyLink="";Component=$Component;IsInRollup=$IsInRollup;IsInstalled="Yes"}
					$myArrayInstalledKB += $obj1
					}
		}
	} #end foreach ($line in $KBOnlyRollupFile)

	### build list of missing binaries and KB numbers
	$ListOfMissingKB = @()
	if($myArrayMissingKB){ # build list of missing binaries
		$ListOfMissingKB = foreach ($EntryMissKB in $myArrayMissingKB ){ # working on Binary, no KB#
			if(($EntryMissKB.Binary -notmatch "[1-9][0-9][0-9][0-9][0-9]")){
				if($EntryMissKB.Branch -eq "LDRGDR" -and (($EntryMissKB).SdpVer).Substring(9).StartsWith(1)){ # only LDRGDR is installed, minor version starts with "1" like 6.1.7601.17725
					$EntryMissKB|
						Select-Object @{Label="Prio";Expression={$_.Prio}},
						@{Label="Component";Expression={$_.Component}},
						@{Label="Branch";Expression={$_.Branch}},
						@{Label="Binary";Expression={$_.Binary}},
						@{Label="RflVer";Expression={$_.RflVer}},
						@{Label="SdpVer";Expression={$_.SdpVer}},
						@{Label="Release Date";Expression={$_.Release}},
						@{Label="KB";Expression={$_.KB}},
						@{Label="Title";Expression={$_.Title}},
						@{Label="Url";Expression={$_.Url}},
						@{Label="LDROnlyKB";Expression={$_.LDROnlyKB}},
						@{Label="LDROnlyTitle";Expression={$_.LDROnlyTitle}},
						@{Label="LDROnlyLink";Expression={$_.LDROnlyLink}},
						@{Label="isInstalled";Expression={$_.isInstalled}},
						@{Label="IsInRollup";Expression={$_.IsInRollup}}
				}
				elseif(($EntryMissKB.Branch -eq "LDRGDR" -and (($EntryMissKB).SdpVer).Substring(9).StartsWith(2))){ # LDR is already installed, minor version starts with "2" like 6.1.7601.23153
					$EntryMissKB|
						Select-Object @{Label="Prio";Expression={$_.Prio}},
						@{Label="Component";Expression={$_.Component}},
						@{Label="Branch";Expression={$_.Branch}},
						@{Label="Binary";Expression={$_.Binary}},
						@{Label="RflVer";Expression={$_.RflVer}},
						@{Label="SdpVer";Expression={$_.SdpVer}},
						@{Label="Release Date";Expression={$_.Release}},
						@{Label="KB";Expression={$_.KB}},
						@{Label="Title";Expression={$_.Title}},
						@{Label="Url";Expression={$_.Url}},
						@{Label="isInstalled";Expression={$_.isInstalled}},
						@{Label="IsInRollup";Expression={$_.IsInRollup}}
				}
				else{ #Branch is LDR
					$EntryMissKB|
						Select-Object @{Label="Prio";Expression={$_.Prio}},
						@{Label="Component";Expression={$_.Component}},
						@{Label="Branch";Expression={$_.Branch}},
						@{Label="Binary";Expression={$_.Binary}},
						@{Label="RflVer";Expression={$_.RflVer}},
						@{Label="SdpVer";Expression={$_.SdpVer}},
						@{Label="Release Date";Expression={$_.Release}},
						@{Label="KB";Expression={$_.KB}},
						@{Label="Title";Expression={$_.Title}},
						@{Label="Url";Expression={$_.Url}},
						@{Label="isInstalled";Expression={$_.isInstalled}},
						@{Label="IsInRollup";Expression={$_.IsInRollup}}
				}
				Write-Debug "EntryMissKB: ($EntryMissKB | Select-Object KB,title,Url| Format-Table)"
			}
			else{ # KB# in Binary field - build list of missing KB#s
				$EntryMissKB|
					Select-Object @{Label="Prio";Expression={$_.Prio}},
					@{Label="Component";Expression={$_.Component}},
					@{Label="Branch";Expression={$_.Branch}},
					@{Label="Release Date";Expression={$_.Release}},
					@{Label="KB";Expression={$_.KB}},
					@{Label="Title";Expression={$_.Title}},
					@{Label="Url";Expression={$_.Url}},
					@{Label="isInstalled";Expression={$_.isInstalled}},
					@{Label="IsInRollup";Expression={$_.IsInRollup}}
			}
		}
	}
	else { # no matching binaries *or* KBs in SDP
		$ListOfMissingKB = "Up to date - or no binaries matched with given SDP report, i.e. no cluster binaries on Client OS"
		Write-Debug "ListOfMissingKB: $ListOfMissingKB"
	 }

	### build list of installed binaries and KB numbers
	$ListOfInstalledKB = @()
	if($myArrayInstalledKB){
		$ListOfInstalledKB = foreach ($EntryInstalledKB in $myArrayInstalledKB){ # build list of Installed binaries
			if(($EntryInstalledKB.Binary -notmatch "[1-9][0-9][0-9][0-9][0-9]")){ # working on Binary, no KB#
				$EntryInstalledKB|	Select-Object @{Label="Prio";Expression={$_.Prio}},
					@{Label="Component";Expression={$_.Component}},
					@{Label="Branch";Expression={$_.Branch}},
					@{Label="Binary";Expression={$_.Binary}},
					@{Label="RflVer";Expression={$_.RflVer}},
					@{Label="SdpVer";Expression={$_.SdpVer}},
					@{Label="Release Date";Expression={$_.Release}},
					@{Label="KB";Expression={$_.KB}}
					@{Label="Title";Expression={$_.Title}},
					@{Label="Url";Expression={$_.Url}},
					@{Label="isInstalled";Expression={$_.isInstalled}},
					@{Label="IsInRollup";Expression={$_.IsInRollup}}
			}else{ # build list of Installed KB#s
				$EntryInstalledKB|
					Select-Object @{Label="Prio";Expression={$_.Prio}},
					@{Label="Component";Expression={$_.Component}},
					@{Label="Branch";Expression={$_.Branch}},
					@{Label="Release Date";Expression={$_.Release}},
					@{Label="Binary";Expression={$_.Binary}},
					@{Label="KB";Expression={$_.KB}}
					@{Label="Title";Expression={$_.Title}},
					@{Label="Url";Expression={$_.Url}},
					@{Label="isInstalled";Expression={$_.isInstalled}},
					@{Label="IsInRollup";Expression={$_.IsInRollup}}
			}
		}
	}else { # no matching Installed binaries or KBs in SDP
		$ListOfInstalledKB = "No Hotfix from current '$RFLFixesTech $SdpOSversion' RFL list installed."
		Write-Verbose "$ListOfInstalledKB"
	}

	### Script Output in Debug mode
	if($DbgOut) {$myArrayMissingKB | Select-Object KB,Url,title|Sort-Object -Unique KB |Format-Table -auto}

	### RFL OUTPUT files: write detailed engineer and customer-ready unique KB
	$combinedListDSEcsv 		= $SDPPath + '!'+$($SdpArray.Computername)+'_'+$Report_Type+'_CombinedList_'+$RFLFixesTech+'_'+$SdpOSversion+'.csv'
	$savepathMissingKB_TxtFile 	= $SDPPath + '!'+$($SdpArray.Computername)+'_'+$Report_Type+'_list_'+$RFLFixesTech+'_'+$SdpOSversion+'.txt'
	#$ListOfHigherSDPverFile 	= $StatsServerPath +'ToDo_RFLupdates.csv'
	$ListOfHigherSDPverFileRS5 	= $StatsServerPath +'ref__Except_' + $SdpOSversion + '_latest.csv'
	[string[]]$savepathMissingKB_content = $Null
	if ($isClient -and ($SdpOSversion -match "2016RS2|2016RS3|2016RS4|2016RS5|201619H1|201619H2|20162004")) {$unsupportedOS = $True}

	## check for Win7/2008R2 Convenience Pack
	if ("$SdpOSversion" -match "2008R2") {
		$Cp3125574Installed = $myArrayInstalledKB | Select-Object KB,Binary,Component| Where-Object{$_.KB -match "3125574" -and $_.Component -match "2008R2.*rollup"}|Sort-Object -Unique KB
		Write-host "`n Is Cp 3125574 Installed?: '$($Cp3125574Installed.KB)' "
	}

	$Title = "____*** Disclaimer ***____
	!please reTHINK - before sending long hotfix/update lists to customer! Which Hotfixes are really necessary to solve this issue? i.e. for network connectivity issues, you should recommend only:
	 + Update NIC driver(s)
	 + Update Microsoft (stack/protocol) drivers involved in sending/receiving network packets, -> see category/components 'Net_Protocol'
	- The first section 1.1.1 below contains in 1.1.1.1 and/or 1.1.1.2 the actual hotfix recommendations for your customer, based on findings of received SDP Report.
	  Note: Cumulative updates for downlevel OS are only cumulative for downlevel OS since autumn 2016 and do not include earlier released hotfixes.
	  The 'Customer Ready' Consolidated List of [Missing LDR-only] and [Missing latest] Unique Hotfix-numbers for your chosen technology: '$RFLFixesTech' is in this section 1.1.1.
	- The second section 1.2 is FYI, it lists binaries up-to-date [already installed].
	- The third section 1.3 is aiming to give you more insights about the customer's system, like installed (SdpVer) and recommended (RflVer) binary versions.


	Quick Tip: If you set Notepad++ as your default text viewer, all of the results will open in tabs instead of opening a bunch of Notepad windows.
	BTW: Are you aware of troubleshooting TSS tool-set located on public  https://aka.ms/getTSS ? It helps to speed up troubleshooting/analysis for all Windows based issues a lot!
	(Questions, Feedback for improvements welcome mailto:ww-CSS-RFL-check@microsoft.com
		Please also report any inconsistency in RFL output, i.e. customer cannot install a recommended KB article, this will help the whole worldwide community using this service)

[SDPcheck Release: $Script:verDateRFL (Script version: $verDateScript)]
________________________
SDP date: $SDPdate - Missing '$RFLFixesTech' Hotfixes on: $($SdpArray.Computername) - $($SdpArray.OSname) - $($SdpArray.OSbuild)`n
 SDP report type: $SDPtype
 *** $Script:ErrorMsg 
 Expected monthly CU date: $ReleaseCU"
	 $EngNote = "Notes - for Computer/Server Administrator:
 Note#1: Please ignore the specific KB titles and content mentioned in required/missing KB#'s, we just make sure that the latest Hotfix for each module with all the previous fixes in that area is being installed.
	 (new cumulative updates for downlevel OS do not contain older hotfixes released before Oct 2016).
 Note#2: You can obtain multiple stand-alone update packages through the Microsoft Download Center on http://catalog.update.microsoft.com using the basket feature in IE.
 Note#3: You can install all the fixes in one run, requiring only one reboot. If a Servicing Stack SSU fix is missing, please start patching with this SSU hotfix first.`n`n"
 
	if ("$SdpOSversion" -match "2008R2") { $EngNote += "Note#4: KB 4472027: 2019 SHA-2 Code Signing Support requirement for Windows and WSUS. `n`n" }
 
	$Title += "`n $SdpArray"
	if ( $Script:ErrorMsg -match "No_MS17-10_Installed") {$Title += "`n`n *** $($SdpArray.Computername) is vulnerable for MS17-010 WannaCrypt/Petya Ransomware. Please make sure this machine gets patched! ***"}
	if (($is_VMware) -and ("$SdpOSversion" -match "2008R2") -and (-not $Cp3125574Installed)) {
	 $Title += "`n *** Attention: $($SdpArray.Computername) is virtualized on $Virtualization ! Apply latest 2008R2 monthly cum.update before installing KB3125574. Use CheckPCI script https://github.com/CSS-Windows/WindowsDiag/tree/master/NET/CheckPCI"}

	$Separator  = "====================================================================================="
	$SeparatorCP =     "--------* reduced KB list - after installation of Convenience roll-up update *-------"
	$newline_Separator2 = "-------------------------------------------------------------------------------------`n"
	$newline_Separator = "`n====================================================================================="

	if (Test-Path ($SDPPath + "xray_I*.*")) {
		$xrayFile = (Get-Item -path ($SDPPath + "xray_I*.*") -EA Ignore)
		$fXrayFound=$True
	}
	$SDPparentPath 	= Split-Path $SDPPath -Parent
	if (Test-Path ($SDPparentPath + "\xray_I*.*")) {
		$xrayFile = (Get-Item -path ($SDPparentPath + "\xray_I*.*") -EA Ignore)
		$fXrayFound=$True
	}
	if ($fXrayFound) {
		$xrayFileName = $xrayFile.Name
		$Title += $newline_Separator
		$Title += "`n !!! *** Attention: Read the $xrayFileName file! *** !!!"
		# opening the xray*Found file
		Write-Host -ForegroundColor Yellow	"`n[xray] Using favorite editor to try opening $xrayFileName Report "
		#Write-Output "___xray: $xrayFile"
		if ($xrayFile) {Invoke-Item $xrayFile}
	}	
	
	#This chapter contains the actual recommendations found based on your provided data representative sample system (SDP Report of $($SdpArray.Computername) - $($SdpArray.OSname) - dated $SDPdate)."
	$Title3111 = "$i.1.1.1 $RFLFixesTech :: `t [Missing LDR-only] Please install following LDR-Only KBs to switch included binaries to LDR Branch:"
	$Title3112 = "$i.1.1.2 $RFLFixesTech :: `t [Missing latest] Please install the following missing latest Hotfixes to update related binaries to the recommended version:"
	$Title32  = "$i.2   `tRFL � Binaries [already up-to-date], Hotfixes including Binary Information "
	$Title33  = "$i.3  `tRFL � Full List including Binary Information with installed and recommended version"
	$Header  = ""
	$Footer  = "$CheckDate - Data processed for this Report:
	Report generated with v$verDateScript $($RFLpath)check-rfl-csv_Tech_Path.ps1 $RFLFixesTech $SDPPath "

	#Add-Content $savepathMissingKB_TxtFile -Encoding String -Value $Title
	if ("$i" -eq "1") {
		Write-Debug "`nFilling: savepathMissingKB_content"
		$Header 	 > $savepathMissingKB_TxtFile
		$savepathMissingKB_content += 	"$Title "
		$savepathMissingKB_content += 	$newline_Separator }
	if (("$SdpOSversion" -match "2008R2") -and (-not $Cp3125574Installed))
		{$savepathMissingKB_content += "NEW: Sections, if 3125574 is not installed: -------* reduced KB list - after installation of Convenience roll-up update *---------`n"}
	if ($unsupportedOS) {$savepathMissingKB_content += 	"***** UNSUPPORTED OS version *****"}
	$savepathMissingKB_content += 	"$i.1.1  `tMissing Fixes (Unique KB numbers of all missing KBs) on the System: $($SdpArray.Computername) " #$Title311

	if ("$SdpOSversion" -notmatch "2012R2|2016|2022|Win11") { #no LDRonly for 2012R2, 2016*, 2022, win11
		$savepathMissingKB_content += 	$Title3111
		#v1.23#$UniqueShortListOfMissingKBLdr = $myArrayMissingKB |Where-Object{$_.Branch -eq 'LDRGDR'}|Where-Object{$_.LDROnlyKB -ne 'No LDR Only available'}| Select-Object LDROnlyKB,Binary,Component,LDROnlyLink,LDROnlyTitle |Sort-Object -Unique LDROnlyKB|Sort-Object Component |Format-Table -auto
		$UniqueShortListOfMissingKBLdr = $ListOfMissingKB |Where-Object{$_.branch -eq 'LDRGDR'}|Where-Object{$_.LDROnlyKB -ne 'No LDR Only available'}| Select-Object LDROnlyKB,Binary,Component,LDROnlyLink,LDROnlyTitle |Sort-Object -Unique LDROnlyKB|Sort-Object Component |Format-Table -auto
		$m1 = 				 			 $ListOfMissingKB |Where-Object{$_.branch -eq 'LDRGDR'}|Where-Object{$_.LDROnlyKB -ne 'No LDR Only available'}|Where-Object{$_.LDROnlyKB -ne 'KB only'} | Select-Object LDROnlyKB |Sort-Object -Unique LDROnlyKB |Measure-Object
		$savepathMissingKB_content += "`tNumber of Unique [Missing LDR-only] $RFLFixesTech : $($m1.Count)"
		$savepathMissingKB_content += $UniqueShortListOfMissingKBLdr |Out-String -Width $OutFileChars
		if (("$SdpOSversion" -match "2008R2") -and (-not $Cp3125574Installed)) {
			$savepathMissingKB_content += $SeparatorCP
			$savepathMissingKB_content += "*** NOTE: Convenience Pack KB3125574 is optional, but if you install KB3125574, the list of [Missing LDR-only] hotfixes typically reduces a lot!"
	# (gc file.txt) | Where-Object {$_.trim() -ne "" } | set-content file.txt
			$UniqueShortListOfMissingKBLdr_CP = $ListOfMissingKB |Where-Object{$_.branch -eq 'LDRGDR'}|Where-Object{$_.LDROnlyKB -ne 'No LDR Only available'}|Where-Object{$_.IsInRollup -ne '16-04Rollup'}| Select-Object LDROnlyKB,Binary,Component,LDROnlyLink,LDROnlyTitle |Sort-Object -Unique LDROnlyKB|Sort-Object Component |Format-Table -auto
			$m1_CP = 				 		  $ListOfMissingKB |Where-Object{$_.branch -eq 'LDRGDR'}|Where-Object{$_.LDROnlyKB -ne 'No LDR Only available'}|Where-Object{$_.IsInRollup -ne '16-04Rollup'}|Where-Object{$_.LDROnlyKB -ne 'KB only'} | Select-Object LDROnlyKB |Sort-Object -Unique LDROnlyKB |Measure-Object
			$savepathMissingKB_content += "  `tNumber of Unique [Missing LDR-only] $RFLFixesTech : $($m1_CP.Count)"
			if ($($m1_CP.Count) -eq 0) {$savepathMissingKB_content += "***`t=> No single LDR-only fix would need to be installed, with KB3125574 being installed"}
			$savepathMissingKB_content += $UniqueShortListOfMissingKBLdr_CP |Out-String -Width $OutFileChars
			$savepathMissingKB_content += $newline_Separator2
		}
	 }
	$savepathMissingKB_content += 	$Title3112
	if ("$SdpOSversion" -match "201|202|Win11") { #v1.23 "2012" ->"201" = 2012* 2016* # -or ("$($SdpArray.OSname)" -match "10")
		#v1.23#$UniqueShortListOfMissingKB = $myArrayMissingKB |Where-Object{$_.IsInstalled -eq 'No' -and ($_.Component -match 'rollup_KB' -or $_.IsInRollup -eq 'No Rollup')} | Select-Object KB,Binary,Component,Url,Title |Sort-Object -Unique KB |Sort-Object Component |Format-Table -auto
		$UniqueShortListOfMissingKB = $ListOfMissingKB |Where-Object{$_.IsInstalled -eq 'No' -and ($_.Component -match 'rollup_KB' -or $_.IsInRollup -eq 'No Rollup')} | Select-Object KB,Binary,Component,Url,Title |Sort-Object -Unique KB |Sort-Object Component |Format-Table -auto
		$curr_UniDiffMissingArray  = $ListOfMissingKB |Where-Object{$_.IsInstalled -eq 'No' -and ($_.Component -match 'rollup_KB' -or $_.IsInRollup -eq 'No Rollup')} | Select-Object KB,Binary,Component,RflVer,SdpVer,Release,isInstalled,Branch,IsInRollup |Sort-Object -Unique KB |Sort-Object Component
		}
	else { #for 2008,2008-R2
		$UniqueShortListOfMissingKB = $myArrayMissingKB |Where-Object{$_.Component -match 'rollup_KB' -or $_.IsInstalled -eq 'No'} | Select-Object KB,Binary,Component,Url,Title |Sort-Object -Unique KB |Sort-Object Component |Format-Table -auto
		## need to check next line $myArrayMissingKB or $ListOfMissingKB?
		$curr_UniDiffMissingArray  = $myArrayMissingKB |Where-Object{$_.IsInstalled -eq 'No'} | Select-Object KB,Binary,Component,RflVer,SdpVer,Release,isInstalled,Branch,IsInRollup |Sort-Object -Unique KB |Sort-Object Component
		if (("$SdpOSversion" -match "2008R2") -and (-not $Cp3125574Installed)) {
			$UniqueShortListOfMissingKB_CP = $myArrayMissingKB |Where-Object{$_.Component -match 'rollup_KB' -or $_.IsInstalled -eq 'No'}|Where-Object{$_.IsInRollup -ne '16-04Rollup' }|Where-Object{$_.KB -ne '2775511'}| Select-Object KB,Binary,Component,Url,Title |Sort-Object -Unique KB |Sort-Object Component |Format-Table -auto
			}
		} # end #for 2008,2008-R2
		$m2 = 						 $myArrayMissingKB |Where-Object{$_.Component -match 'rollup_KB' -or $_.IsInstalled -eq 'No'} | Select-Object KB |Sort-Object -Unique KB |Measure-Object
		$savepathMissingKB_content += "`tNumber of Unique [Missing latest] Hotfixes $RFLFixesTech : $($m2.Count)"
		$savepathMissingKB_content += 	$UniqueShortListOfMissingKB |Out-String -Width $OutFileChars
		if (("$SdpOSversion" -match "2008R2") -and (-not $Cp3125574Installed)) {
			$savepathMissingKB_content += $SeparatorCP
			$savepathMissingKB_content += "*** NOTE: Convenience Pack KB3125574 is optional, but if customer installs KB3125574, the list of [Missing latest] hotfixes typically reduces a lot! Below is this list: "
			if ($is_VMware) {$savepathMissingKB_content += "*** Attention: $($SdpArray.Computername) is virtualized on $Virtualization ! Apply latest 2008R2 monthly cum.update before installing KB3125574. Use CheckPCI script https://github.com/CSS-Windows/WindowsDiag/tree/master/NET/CheckPCI"} ## Run *.VBS script after installation of KB3125574 or Jan 2018 KB4088878 or KB4088875 or later cum.updates and BEFORE reboot!
			$m2_CP = 					$ListOfMissingKB |Where-Object{$_.Component -match 'rollup_KB' -or $_.Component -match 'PreRequ_KB' -or $_.isInRollup -eq 'No Rollup'}|Where-Object{$_.IsInRollup -ne '16-04Rollup'} | Select-Object KB |Sort-Object -Unique KB |Measure-Object
			$savepathMissingKB_content += "  `tNumber of Unique [Missing latest] Hotfixes $RFLFixesTech : $($m2_CP.Count)"
			if ($($m2_CP.Count) -eq 0) {$savepathMissingKB_content += "***`t=> No additional hotfix would need to be installed, with KB3125574 being installed"}
			$savepathMissingKB_content += 	$UniqueShortListOfMissingKB_CP |Where-Object{$_.KB -ne ''} |Out-String -Width $OutFileChars
			$savepathMissingKB_content += $newline_Separator2
			$Script:ErrorMsg += "No-w7CP "
		}
		
	if ($unsupportedOS) {$savepathMissingKB_content += 	"***** UNSUPPORTED OS version *****`n"}
	$savepathMissingKB_content += 	$EngNote
	$savepathMissingKB_content += 	$Title32
	$savepathMissingKB_content += 	$Separator
	$savepathMissingKB_content += 	"$i.2.1 `t$RFLFixesTech ::`t[Info] Installed Binaries on the System: $($SdpArray.Computername) " #$Title321
	if ($ListOfInstalledKB -match "No Hotfix from current") { $savepathMissingKB_content += $ListOfInstalledKB}
	# not sorted by |Sort-Object -Unique KB
	$ListOfInstalledKB = $myArrayInstalledKB | Select-Object KB,Binary,Component,RflVer,SdpVer,Release,isInstalled,Title |Sort-Object Component |Format-Table -auto
		$m3 = $myArrayInstalledKB | Select-Object KB |Sort-Object -Unique KB |Measure-Object
		$savepathMissingKB_content += "`tNumber of Unique Hotfixes [already installed] $RFLFixesTech : $($m3.Count) " #Title32
	$savepathMissingKB_content += $ListOfInstalledKB |Out-String -Width $OutFileChars
	$savepathMissingKB_content += $Title33
	$savepathMissingKB_content += $Separator
	$savepathMissingKB_content += "$i.3.1  $RFLFixesTech :: [Table] Missing Fixes on the System: $($SdpArray.Computername) - $($SdpArray.OSname) $($SdpArray.OSbuild) " #$Title331
	 $ListOfMissingKBtable = $myArrayMissingKB| Select-Object KB,Binary,Component,RflVer,SdpVer,Release,isInstalled,Branch,IsInRollup,Title |Where-Object{$_ -match '[0-9]'}|Sort-Object Component |Format-Table -auto
		$m4 = $myArrayMissingKB | Select-Object Component |Measure-Object
		$savepathMissingKB_content += "`tNumber of Binary-Updates $RFLFixesTech : $($m4.Count) "
	$savepathMissingKB_content += $ListOfMissingKBtable |Out-String -Width $OutFileChars
	If ($OmitFullList -eq 0) { $savepathMissingKB_content += "$i.3.2  $RFLFixesTech :: [Full List] Missing Fixes on the System: $($SdpArray.Computername) - $($SdpArray.OSname) $($SdpArray.OSbuild) " #$Title332
				 $savepathMissingKB_content += $Separator
				 $savepathMissingKB_content += $ListOfMissingKB |Out-String -Width $OutFileChars #|format-List -property *
				}
	$savepathMissingKB_content += $Separator
	$savepathMissingKB_content += "Release Date of RFL list for module '$RFLFixesTech' = $csvpathReleaseDate `n"
	$savepathMissingKB_content += $Footer

	#write _content to file
	$savepathMissingKB_content | Out-File $savepathMissingKB_TxtFile -Append -Encoding String

	### append EngineerInfo (if available) to Engineer RFL output
	If ("$Report_Type" -eq "Engineer_RFL") {
		$EngineerInfo1 = $RFLpath + 'KB_info_'+$SdpOSversion+'.txt'
		$EngineerInfo2 = $RFLpath + 'KB_info_'+$RFLFixesTech+'_'+$SdpOSversion+'.txt'
		If (Test-Path $EngineerInfo1){
			Write-Debug "`n** EngineerInfo1: '$EngineerInfo1'"
			"`n...appending EngineerInfo_1 for '$RFLFixesTech' $SdpOSversion "
			Get-Content $EngineerInfo1 -Encoding Ascii | Out-File $savepathMissingKB_TxtFile -Append -Encoding String
		}
		If (Test-Path $EngineerInfo2){
			Write-Debug "`n** EngineerInfo2: '$EngineerInfo2'"
			"`n...appending EngineerInfo_2 for '$RFLFixesTech' $SdpOSversion "
			Get-Content $EngineerInfo2 -Encoding Ascii | Out-File $savepathMissingKB_TxtFile -Append -Encoding String
		}
	}

	### Write Excel Csv file
	Write-Host "`n...Creating overview of missing/installed Hotfix KB articles, .txt and .csv file."
	"" > $combinedListDSEcsv
	$combinedList = $myArrayInstalledKB + $myArrayMissingKB
	$combinedList 	| Select-Object Prio,KB,Component,Binary,RflVer,SdpVer,Url,isInstalled,Branch,Published,LDROnlyKB,LDROnlyTitle,LDROnlyLink,IsInRollup `
					|Sort-Object Prio,Component|Export-Csv -Path $combinedListDSEcsv -NoTypeInformation -UseCulture #-Delimiter "$csvDelimiter"

	### END: Script PS output

	"...Processing $Report_Type report of '$RFLFixesTech' RFL list for Windows $SdpOSversion - Done"
	#"Overview of installed/missing Hotfix KB articles:`n => $combinedListDSEcsv " #`n
	"$Report_Type Report of missing unique Hotfix KB articles, installed KBs:`n => $savepathMissingKB_TxtFile "

	### Write/Append Excel Csv file for non-expected higher SDPver, unless user provided OSver
	 if (($FeedHigherSDPver) -and ($null -eq $UserInputOS)){
		if ($BuildRS5) {
			$myArrayHigherSDPver | Select-Object Binary,Component,RflVer,Prio,Release,Branch,KB,Title,Url,LDROnlyKB,LDROnlyTitle,LDROnlyLink,Comment,IsInRollup `
					|Sort-Object Component|Export-Csv -Path $ListOfHigherSDPverFileRS5 -NoTypeInformation -Append -Delimiter "$csvDelimiter" -Force -ErrorAction SilentlyContinue
					#_# ToDo: export to Except file $ExceptCUfileName
		} else { 
			$myArrayHigherSDPver | Select-Object CheckDate,SdpOSversion,Architecture,SdpVer,Binary,Component,RflVer,Prio,Release,Branch,KB,Title,Url,LDROnlyKB,LDROnlyTitle,LDROnlyLink,Comment,IsInRollup `
					|Sort-Object Component|Export-Csv -Path $ListOfHigherSDPverFile -NoTypeInformation -Append -Delimiter "$csvDelimiter" -Force -ErrorAction SilentlyContinue
		}
	 }
	 #####################################
	 # Save result of current Cluster node
	 #new-variable -Name "myglobal:SdpArray_$NodeName" -value $script:SdpArray -Force
	 $curr_DiffMissingArray = $curr_UniDiffMissingArray | Select-Object KB,Binary,Component,RflVer,SdpVer,Release,isInstalled,Branch,IsInRollup |Sort-Object KB -desc #|Where-Object{$_ -match '[0-9]'} #$ListOfMissingKBtable
	 #$curr_R = (get-variable -Name "myglobal:SdpArray_$NodeName")

	 if ($NodeCnt -gt 1) {
		#Write-host "...Running Cluster nodes consistency check"
		Write-verbose "$NodeName_Prev =Prev node; Count Missing: $($prev_DiffMissingArray.count)"
		$PrevArr = $prev_DiffMissingArray | Select-Object KB,Binary,Component,RflVer,SdpVer,Release,isInstalled,Branch,IsInRollup
		Write-verbose "$NodeName =Curr node; Count Missing: $($curr_DiffMissingArray.count)"
		$CurrArr = $curr_DiffMissingArray | Select-Object KB,Binary,Component,RflVer,SdpVer,Release,isInstalled,Branch,IsInRollup

		if (($prev_DiffMissingArray.count -eq 0) -and ($curr_DiffMissingArray.count -eq 0)) {$Diffs = $null; write-verbose "Prev node and Curr node are up-to-date"} 
		else {	$Diffs = (Compare-Object ($PrevArr | ConvertTo-CSV) ($CurrArr | ConvertTo-CSV) -SyncWindow 20) }	# compare up to 20 lines distance
		if ($null -eq $Diffs) {Write-Host -BackgroundColor Green -ForegroundColor Black -Object "$NodeName_Prev / $NodeName ClusterNode '[Table] Missing Fixes' are equal"
					"$newline_Separator" >> $savepathMissingKB_TxtFile
					" - Cluster nodes consistency check in Cluster nodes: $newline_Separator" >> $savepathMissingKB_TxtFile
					" $NodeName_Prev / $NodeName ClusterNode '[Table] Missing Fixes' are equal" >> $savepathMissingKB_TxtFile 
		}
		else {	##
			Write-host -BackgroundColor Red -ForegroundColor Black -Object "$NodeName_Prev / $NodeName Differences:"
			$Diffs |Format-Table -auto
			## append in current $savepathMissingKB_TxtFile
			"$newline_Separator" >> $savepathMissingKB_TxtFile
			" - Checking for different recommended versions in Cluster nodes: $newline_Separator" >> $savepathMissingKB_TxtFile
			"$NodeName_Prev / $NodeName Differences:" >> $savepathMissingKB_TxtFile
			$Diffs |Format-Table -auto | Out-file $savepathMissingKB_TxtFile -Append -Encoding String -Width $OutFileChars

			### open output file with FavEditor
			If ($Global:OpenSummary) {
				Write-Host "... open output Summary file with FavEditor, because inconsistencies or differences were found for $NodeName."
				Invoke-Item $savepathMissingKB_TxtFile
				}
			} #end else
		} #end if ($NodeCnt -gt 1)
	 # save previous NodeName and DiffMissingArray for next node loop
	 $NodeName_Prev = $NodeName
	 $prev_DiffMissingArray = $curr_DiffMissingArray

	 "`nUsing favorite editor to open $Report_Type Report "
	$NodeEndTime = Get-Date
	$Duration = $NodeEndTime - $Script:BeginTimeStamp
	Write-Host -BackgroundColor Gray -ForegroundColor Black -Object "$(Get-Date -UFormat "%R:%S") Done $Report_Type script version v$verDateScript took $Duration `n"

	### open output file with Notepad/FavEditor
	If (($Global:OpenSummary) -and ($NodeCnt -eq 1)) {Invoke-Item $savepathMissingKB_TxtFile }
} #end of foreach ($NodeName in $NodeNames): processing RFL list for missing binaries and KB numbers, per NodeName

	Write-verbose "***ErrorMsg: $Script:ErrorMsg"
	### Stats
	### Log last script error, i.e. #$a=0; $b=4; $b/$a
	If ($Stats) {
	 [string]$jj=$j.ToString()
	 $ScriptError = $Error[0]
	 "$jj ;$CheckDate; $SdpOSversion; $PSculture; $RFLFixesTech; $UserName; $env:computername; $Duration; $SDPPath; $SDPtype; $Script:ErrorMsg; $NodeCnt; $UsrOSversion; v$verDateScript; $ScriptError; $NameHost; $NodeIP" | Out-File $CountInvFil2 -Append -Encoding UTF8 -ErrorAction SilentlyContinue
	}
#region :: running additional SDPcheck scripts
	If ($RunAddon) {
		Write-verbose "... running AddOns"
		#Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned -Force
		Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force
		$PStatTXTfiles = Get-Item -path ($SDPPath + "*_PStat.txt")
		$NodeNames = foreach ($NodeName in $PStatTXTfiles){($NodeName.name).split('_')[0]}
	 switch ($RunAddonBitMask) {
		{$_ -band 1} {
			if ($PStatTXTfiles) {
				Write-host -ForegroundColor Green "`n [Addon 1:Pstat] $(Get-Date -UFormat "%R:%S") ...running PstatSum for NodeName(s): $NodeNames "
				Unblock-File -Path $RFLroot\get-PStatSum.ps1 -ErrorAction SilentlyContinue
				& "$($RFLroot)\get-PStatSum.ps1" -SDPPath $SDPPath -OSversion $SdpOSversion -OpenSummary:$Global:OpenSummary
			} else {Write-host -ForegroundColor Magenta "`n [Addon 1: PstartSum] PStat.TXT file not found "}
		}
		{$_ -band 2} {
			$RegistryFiles = Get-Item -path ($SDPPath + "*_reg*")
			if ($RegistryFiles) {
				Write-host -ForegroundColor Green "`n [Addon 2:RegChk] $(Get-Date -UFormat "%R:%S") ...Registry checks for leading or trailing blank/space characters in registry key names in all Reg files:"
				#PowerShell.exe -Command "'$($RFLpath)check-RegistryKeyNames.ps1 $($SDPPath)'; Exit $LASTEXITCODE" > "test.log" 2>&1
				Unblock-File -Path $RFLroot\check-RegistryKeyNames.ps1 -ErrorAction SilentlyContinue
				& "$($RFLroot)\check-RegistryKeyNames.ps1" -SDPPath $SDPPath -OSversion $SdpOSversion -OpenSummary:$Global:OpenSummary
			} else {Write-host -ForegroundColor Magenta "`n [Addon 2: RegCheck] Reg file(s) not found "}
		}
		{$_ -band 4}{
			$PerfCounterFiles = Get-Item -path ($SDPPath + "*_Performance Counter.blg")
			if ($PerfCounterFiles) {
				Write-host -ForegroundColor Green "`n [Addon 3:PMA] $(Get-Date -UFormat "%R:%S") ...running 'Performance Monitor Analyzer' for NodeName(s): $NodeNames "
				Unblock-File -Path $RFLroot\get-pma.ps1 -ErrorAction SilentlyContinue
				& "$($RFLroot)\get-pma.ps1" -SDPPath $SDPPath -OSversion $SdpOSversion -OpenSummary:$Global:OpenSummary
			}  else {Write-host -ForegroundColor Magenta "`n [Addon 3: PMA] PerfCounter (*.blg) file not found "}
		}
		{$_ -band 8}{
			$EvtCheckFiles = Get-Item -path ($SDPPath + "*.evtx")
			if ($EvtCheckFiles) {
				Write-host -ForegroundColor Green "`n [Addon 4:EvtLog] $(Get-Date -UFormat "%R:%S") ...running 'Eventlog provider entries for last 6h' for NodeName(s): $NodeNames "
				Unblock-File -Path $RFLroot\get-events.ps1 -ErrorAction SilentlyContinue
				& "$($RFLroot)\get-events.ps1" -SDPPath $SDPPath -OSversion $SdpOSversion -OpenSummary:$Global:OpenSummary -NrOfHours "6"
			} else {Write-host -ForegroundColor Magenta "`n [Addon 4: Eventlogs] Eventlog file(s) not found "}
		}
		{$_ -band 16} {
			if ($PStatTXTfiles.count -gt 1) {
				$startTime_PStat = Get-Date
				Write-host -ForegroundColor Green "`n [Addon 5:CmpPstat] $(Get-Date -UFormat "%R:%S") ...running Compare-PStatSummary for NodeName(s): $NodeNames "
				Unblock-File -Path $RFLroot\Compare-PStatSummary.ps1 -ErrorAction SilentlyContinue
				$PStatSumFiles = Get-Item -path ($SDPPath + "!PStatSum_*.txt")
				# wait until all corresponding !PStatSum_*.txt have been created
				do
				{
					$isDone = ($PStatTXTfiles.count -ne $PStatSumFiles.count)
					if ($isDone) {Start-Sleep -Seconds 3}
				} until (($isDone -eq $false) -or ((Get-Date) -gt $startTime_PStat.AddMinutes(2)))
				& "$($RFLroot)\Compare-PStatSummary.ps1" -SDPPath $SDPPath -OSversion $SdpOSversion -Hostmode:$false -OpenSummary:$Global:OpenSummary
			} else {Write-host -ForegroundColor Magenta "`n [Addon 5: Compare Pstat] Did not find multiple Pstat files, i.e. on Cluster-SDP "}
		}
		{$_ -band 32} {
			if ($PStatTXTfiles.count -gt 1) {
				Write-host -ForegroundColor Green "`n [Addon 6] $(Get-Date -UFormat "%R:%S") ...running Arrange-SDPFolders for NodeName(s): $NodeNames "
				Unblock-File -Path $RFLroot\Arrange-SDPFolders.ps1 -ErrorAction SilentlyContinue
				& "$($RFLroot)\Arrange-SDPFolders.ps1" -SDPPath $SDPPath -OSversion $SdpOSversion -Hostmode:$false
			}
		}
	    {$_ -band 64} {
			if ($True) {
	 #			Write-host -ForegroundColor Green "`n [Addon 6] $(Get-Date -UFormat "%R:%S") ...running ChaseEvents for NodeName(s): $NodeNames "
	 #			Unblock-File -Path $RFLroot\ChaseEvents.ps1 -ErrorAction SilentlyContinue
	 #			& "$($RFLroot)\ChaseEvents.ps1.ps1" -SDPPath $SDPPath -OSversion $SdpOSversion
			}
		}
		{$_ -band 128} {
				#"`n [Addon 7:RFLShellExt] $(Get-Date -UFormat "%R:%S") ...now running get-version-RFLShellExt; checking for Explorer shell plugin updates:"
				Unblock-File -Path $RFLroot\get-version-RFLShellExt.ps1 -ErrorAction SilentlyContinue
				Unblock-File -Path $RFLroot\get-update-RFLShellExt.ps1 -ErrorAction SilentlyContinue
				Unblock-File -Path $RFLroot\remove-RFLShellExt.ps1 -ErrorAction SilentlyContinue
				& "$($RFLroot)\get-version-RFLShellExt.ps1" -Hostmode:$false -InformUser:$true
		}
		{$_ -band 256} {
	#  		"`n [Addon 8:ResponseTime] $(Get-Date -UFormat "%R:%S") ...now performing internal check for AZURE response time in your region (performance test: http://Support.Microsoft.com):"
	#			Unblock-File -Path $RFLroot\get-KB-measure.ps1 -ErrorAction SilentlyContinue
	#  		& "$($RFLroot)\get-KB-measure.ps1" -SDPPath $SDPPath -OSversion $SdpOSversion
		}
	 } # end switch
	  Write-host -ForegroundColor Gray " [AddonBitMask $RunAddonBitMask] $(Get-Date -UFormat "%R:%S") ...checks done. Thx for using this service! Please verify above results. Q's?: ask on ww-CSS-RFL-check@microsoft.com or on TEAMS RFLcheck channel."
	  $ScriptEndTimeStamp = Get-Date
	  Write-host -ForegroundColor Gray " [Info:] Overall Duration: $(New-TimeSpan -Start $Script:BeginTimeStamp -End $ScriptEndTimeStamp) `n"
	} #end If ($RunAddon)
#endregion :: running additional SDPcheck scripts


	If ($xrayFile) {
		Write-host -BackgroundColor Yellow -ForegroundColor Black "*** Attention: Please read the $xrayFileName file!"
	}
	
	### Notes/Hints in PS window for engineer - EOL
	If ($SdpOSversion -eq "2016RS2") {Write-host -BackgroundColor Red -ForegroundColor Black "[EOS Note] Windows 10 RS2 v1703 reached end of service on October 8, 2019 (KB4520010) - This OS is no more supported, please update!"}
	If ($SdpOSversion -eq "2016RS3") {Write-host -BackgroundColor Red -ForegroundColor Black "[EOS Note] Windows 10 RS3 v1709 reached end of service on October 13, 2020 (KB4580328) - This OS is no more supported, please update!"}
	If ($SdpOSversion -eq "2016RS4") {Write-host -BackgroundColor Red -ForegroundColor Black "[EOS Note] Windows 10 RS4 v1803 reached end of service on May 11, 2021 (KB5001339) - This OS is no more supported, please update!"}
	# If ($SdpOSversion -eq "2016RS1") {Write-host -BackgroundColor yellow -ForegroundColor Black "[EOS Note] Srv2016 RS1 will reach end of service on Jan 11, 2022 - This OS will be no more supported, please update!"}
	If ($isClient -and ($SdpOSversion -eq "2016RS5")) {Write-host -BackgroundColor Red -ForegroundColor Black "[EOS Note] except LTSC, Windows 10 v1809 Enterprise, Education, and IoT Enterprise editions reached end of service on May 11, 2021 (KB5001384) - This OS is no more supported, please update!"}
	If ($SdpOSversion -eq "201619H1") {Write-host -BackgroundColor Red -ForegroundColor Black "[EOS Note] Windows 10 v1903 reached end of service on December 8, 2020 (KB4592449) - This OS is no more supported, please update!"}
	If ($SdpOSversion -eq "201619H2") {Write-host -BackgroundColor Red -ForegroundColor Black "[EOS Note] Windows 10 v1909 reached end of service on May 10, 2022 (KB5013945) - This OS is no more supported, please update!"}
	If ($SdpOSversion -eq "20162004") {Write-host -BackgroundColor Red -ForegroundColor Black "[EOS Note] Windows 10 2004/20H1 reached end of service on Dec 14, 2021 (Kb5008212) - This OS is no more supported, please update!"}
	If ($SdpOSversion -match "2008") {Write-host -BackgroundColor Red -ForegroundColor Black "[EOS Note] Windows 7,2008,2008R2 reached end of service on January 14, 2020 (https://support.microsoft.com/en-us/help/13853/windows-lifecycle-fact-sheet) - Unless in Azure or with valid 'ESU year 3', this OS will be no more supported, please update!"}

#endregion : MAIN :::::
 } # end try PROCESS
 catch {
	$errorMessage = "$scriptName caught an exception on $($ENV:COMPUTERNAME):"
	$errorMessage += "`n`n"
	$errorMessage += "Exception Type: $($_.Exception.GetType().FullName)"
	$errorMessage += "`n`n"
	$errorMessage += "Exception Message: $($_.Exception.Message)"

	Write-Error $errorMessage -ErrorAction Continue
	Start-Sleep -Seconds 3
	Write-Debug $errorMessage
	if ( $UseExitCode ) {
		$error.clear()	# clear script errors
		exit 1
    }
 } #end Catch PROCESS
	Finally	{ }
} #end PROCESS

END {
	$ScriptEndTimeStamp = Get-Date
	$Duration = $(New-TimeSpan -Start $Script:BeginTimeStamp -End $ScriptEndTimeStamp)

	# Log latest script Addon errors
	If ($StatsErr) {
		$ScriptErrorAddon = $Error
		If ($ScriptErrorAddon) {"$jj; $CheckDate; $SdpOSversion; $PSculture; $RFLFixesTech; $UserName; $env:computername; $Duration; $SDPPath; $SDPtype; $Script:ErrorMsg; $NodeCnt; $UsrOSVersion; $ScriptErrorAddon; v$verDateScript; $NameHost; $NodeIP" | Out-File $CountInvFil4 -Append -Encoding UTF8 -ErrorAction SilentlyContinue}
	 }
	# This resets the ErrorActionPreference to the value at script start.
	$errorActionPreference = $startErrorActionPreference
	if($ErrorThrown) {Throw $error[0].Exception.Message}
} #end END


#region :comments
<#
	The top section is comment based help so the Get-Help command will work with the script.
	The [CmdletBinding()] turns on advanced options like the common parameters.
	All sub functions are in the "BEGIN" section.
	My script code goes in the "PROCESS try" block.

VERSION and AUTHOR:
    Ver 1.07; 27 Feb. 2015;
    Ioan Corcodel / Walter Eder	- waltere@microsoft.com

HISTORY
				display hotfix detailed information that need to be installed, compared to reference list
				add logic mandatory parameters with validation
				add logic to check if installed hotfix is LDR and do not display last LDR if RFL hotfix is LDRGDR
				save report as \\<SDP_path>\!%computername%_Engineer_RFL_list_<tech>_<SdpOSversion>.txt and open it with Notepad
	2014-07-20	changed input files names, no more SPx, Derive SdpOSversion from SDP-report
		  		add logic to check for kb only entry in the rfl list, against the SDP
	2014-07-26 	add short customer ready kb list !%computername%_Customer_KB-list_RFL_, sorted by Prio
		  		check for '*msinfo32.txt' in extracted SDP folder
	2014-07-28 	pick up KB_info_<Tech>_<OS>.txt and append EngineerInfo (if available) to Engineer RFL output
	2014-08-07 	add HelpMessage for parameter input
	2014-09-08 	script is capable to parse automaticaly every computer in the sdp folder - Cluster SDP specific output
				add hotfixes to switch to LDR Branch to !<computername>_Customer_KB-list_RFL_<tech>_<SdpOSversion>
				"NO LDROnly hotfixes" will not be written to !<computername>_Customer_KB-list_RFL_<tech>_<SdpOSversion>
	2014-11-05 	optional parameter#3 is SdpOSversion, valid list: [2008|2008R2|2012|2012R2|2016] (needed for SDP of Russian System)
	2014-11-04	Add new file, with allready installed hotfixes
	2014-11-06	PUAS report with missing KBs, installed KBs, and full info for missing KBs
	2014-11-10	PUAS *.csv report with missing KBs and installed KBs
				Prio,KB,Component,Binary,RflVer,SdpVer,Url,isInstalled,Branch,Release,LDROnlyKB,LDROnlyTitle,LDROnlyLink,IsInRollup
	2014-12-11	fixed Cluster report
	2014-12-14	�space� character in �expanded SDP path� allowed
	2015-01-23	solved bug for srv.sys in line "$SdpVer = Select-String -Pattern $Binary -Path $SDPpathSym -ErrorAction SilentlyContinue", which takes Version# for wrong *srv.sys binary
	2015-02-03	- inform Engineer about last RFL update $csvpathReleaseDate (+ yellow block markers about missing Hotfixes)
	2015-02-06	included All_OS; Performance enhancement (avoid multiple >> file outputs)
	2015-02-27	changed '*msinfo32. to '*msinfo*., error handling for SDPs without msinfo etc.
	2015-03-06	temp. added: [Addon 3]...now performing internal check for AZURE response time in your region -- removed 3 days later
	2015-04-11 	- need to make sure, user pointed to correct extracted SDP folder - throw correct (informative/more descriptive ) error message! i.e. "are you sure this is the right SDP folder?" OnError --> "unexptected error: Please feedback WalterE when something goes wrong..."
			- save last PS error '$($_.Exception.Message)' for followup
	2015-09-11	v1.09 basic Win10 support
	2015-09-20	- for Win2012R2: in Check-rfl-csv scripts: if cumulative updates April+Nov are installed, omit 05-10-2014 updates (changed KBOnlyRollup_2012R2.csv)
	2015-10-04	v1.10 changes to suppress [Missing latest] GDR KBs in section 1.1.1.2 that are already installed
	2015-10-05	 (version jump to adjust and match Version-nr in related Multi-Tech script)
			- $FeedHigherSDPver=1 - add feedback/telemetry data with binary + version, if RflVer < SDPver, into Out-file
			 This telemetry data info will help to keep the RFL list up-to-date!
	2015-10-09	v1.19 run report for each $NodeName in Cluster
	2015-11-19	v1.20 adding support for Win10/2016TH2
	2016-01-18	v1.22 DCR EriqS inform user if SDP report is not suited, i.e. VSS, SCCM or SQL SDP reports (or if *sym or *hotfix files are missing)
	2016-02-04	v1.23 corrected bug for section	[Missing LDR-only]: Do not list LDRonly if same LDRGDR binary listed in section [Missing latest] is already installed as LDR
			   + 2016* fix for no LDRonly output
	2016-02-10	v1.24 using FQDN 
	2016-02-14	  - Done: for 2016TH2: binaries apear as installed if minor version starts with bigger first number, i.e. Rfl 6.2.10586.103 : Sdp 6.2.10586.3 (-> using CompareTo)
			  - 2016*: check for installed rollup fixes
	2016-02-15	v1.25 removing "KBOnlyVersion" "KB Only" info in output files for KB# entries, when processing KB articles
	2016-02-16	   recording $StatsErr
	2016-02-17	v1.26 DCR EriqS done: addition to compare MissingArrays of Cluster Nodes
	2016-03-06	v1.27 adding 'Performance Monitor Analyzer' check
	2016-03-14	v1.28 appending Cluster Nodes differences to Engineer output files.
	2016-04-15	v1.29 changed $Binary = ($line.Binary).ToUpper()	#2016-04-15 for Turkish character 'i /I'
				replace check for stdout.log with results.xml;
				add feedback/telemetry data only if OS had been determined by script (not entered by user)
	2016-04-17	v1.30 add Number of Unique ($m.count) fixes (like in MultiTech script
			   replaced '("$SdpOSversion" -notmatch "2012R2")' with (("$SdpOSversion" -notmatch "2012R2") -and ("$SdpOSversion" -notmatch "2016"))
	2016-04-18	for tr-TR Turkish character 'i /I': implemented function to choose culture -> $SdpVer = Using-Culture en-US
	2016-04-18	- check for outdated Explorer-Plugin 'Rfl-Check_ShellExtension.reg' - "Plugin_Version"="1.0"
	2016-06-20	changed $CheckDate to include seconds
	2016-07-13	v1.31 no telemetry for Win7 Conv pack: if ($SdpVer -NotMatch ".7601.23403")
	2016-07-27	v1.32 using your favorite editor (FavEditor instead of notepad) to open result file
	2016-08-03 	adding 2016RS1
	2016-08-07 	v1.33 adding DCR Evt-check (display last total 100 events of all providers)
	2016-09-23   ;$SdpVer = $SdpVer.Replace(".10585.",".10586.")
	2016-10-15 	v1.34 Config: $OmitFullList=1 - Omit duplicate long list output: "1.3.2  Net :: [Full List] Missing Fixes"
	2016-10-19 	v1.35 #2012 is cumulativ starting Oct 2016
	2017-04-01	adding 2016RS2, limited max line lenght in outfile
	2017-04-02	v1.36 adding comparison 2008R2 vs Convenience pack
	2017-04-04	v1.37 adding virtualization info, corrected false positive CP
	2017-04-20	v1.38 adjusting installed fixes for 2008R2, 2008
	2017-04-27	v1.39 DCR Eric: adding input parameter $RunAddonBitMask for choice of avoiding run of specific addon scripts;
				BitMask for running checks 1=get-PStatSum, 2=check-RegistryKeyNames, 4=get-pma, 8=get-events, 16=get-version-RFLShellExt, 32=Arrange-SDPFolders, 64=ChaseEvents
	2017-05-20	v1.40 adding WannaCrypt Ransomware check for missing MS17-010
	2017-10-08	v1.43 adding 2016RS3; added MS17-10 version check
	2017-11-03	v1.44 appending for 2016* version check: replace ;$SdpVer = $SdpVer.Replace("10.0","6.2")
	2018-04-05	adding 2016RS4
	2019-01-02	v1.45 adding Compare-PStatSummary for cluster nodes
	2019-06-05	v1.50 bail out if SDP patch contains more consecutive spaces or brackets
	2019-10-26  if -BuildRS5 : write new format in $ListOfHigherSDPverFile; verify if OS is supported: Popup
	

	Know issues:

	ToDo:
		2017-01-31 avoid two blank characters in Path to SDP, i.e. on OneDrive location - ( tested -LiteralPath)
		2016-03-10 prepend cluster-nodes comparison results to output, + Regcheck (today they are appended)
		2022-09-01 open xray_ISSUES-FOUND if exists
		2022-09-15 start a new PS session (with same parameters) if script is outdated (otherwise only next report would be up-to-date)
		2022-09-15 -> take only one ALL_OS database as input and do regEx compare with POD-specific Binary-list (RFLFixesTech) for $csvpath 
		
#>

