<# last edit by: waltere
  File Name: Compare-PStatSummary.ps1
  Objective: This script compares the resulting !PStatSum_NodeName.TXT created when running RFL check
  supplied by Willy Moselhy (IBS) <v-waalmo@microsoft.com>
#>

<#
.SYNOPSIS
The script compares the cluster !PStatSum_NodeName.TXT created when running RFL check.

SYNTAX: .\Compare-PStatSummary.ps1 -SDPPath [full-path-to-expanded-SDP-report]

.DESCRIPTION
The script compares the !PStatSum_NodeName.TXT created when running RFL and displays overview of Microsoft and 3rd party modules/drivers that were loaded in memory when the SDP report was created on cluster.
Note: Expand the SDP report cab file into folder and run '.\get-PStatSum.ps1 [full-path-to-expanded-SDP-report]' before running this script in standalone mode.
Output file with table of nodes will be located in same folder with name !PStat_Sum_Compared.txt

If you experience PS error '...is not digitally signed.' run the command:
 Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned

.PARAMETER OpenSummary
 This switch will not open resulting summary file with Notepad/Favorite Editor if set to $False
 
.EXAMPLE
 \\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\Compare-PStatSummary.ps1 -SDPPath \\MyPC\temp\SDPs\ClusterReports
 This command will compare all !PStatSum_*.TXT in folder \\MyPC\temp\SDPs\ClusterReports

.EXAMPLE
 \\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\Compare-PStatSummary.ps1 -SDPPath C:\SDPs\ClusterReports -HostMode
 This command will show logging on the screen

.EXAMPLE
 \\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\Compare-PStatSummary.ps1 -SDPPath C:\SDPs\ClusterReports -ScriptMode
 This command will show script processing in log file _PStat_Sum_Compared.log

.LINK
\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\Compare-PStatSummary.ps1
v-waalmo@microsoft.com ; waltere@microsoft.com
#>

[CmdletBinding()]
PARAM (
	[Parameter(Mandatory = $true,Position=0,HelpMessage='Choose a writable SDP folder location, i.e. C:\SR\SDP-report\ ')]
	[String] $SDPPath,				# Path to SDP result folder containing !PStatSum_*.txt files
	[switch]$HostMode  = $true,		# This tells the logging functions to show logging on the screen
	[switch]$ScriptMode = $false,	# This tells the logging functions to show logging in log file _PStat_Sum_Compared.log
	[switch]$UseExitCode= $true,	# This will cause the script to close after the error is logged if an error occurs.
	[String]$OSVersion,				# will be derived by parent/invoking RFLcheck script
	[switch]$OpenSummary= $true		# open with Notepad/FavEditor
	)

BEGIN {
	$verDateScript = "2023.02.09.0"
	$ScriptFolder = Split-Path $MyInvocation.MyCommand.Path -Parent
	# Load Common Library:
	. $ScriptFolder\Utils_RflShared.ps1

	# This saves the starting ErrorActionPreference and then sets it to 'Stop'.
	$startErrorActionPreference = $errorActionPreference
	$errorActionPreference = 'Stop'
	# This gets the current path and name of the script.
	$invocation = (Get-Variable MyInvocation).Value
	$invocationLine= $($MyInvocation.Line)
	$scriptPath = Split-Path $invocation.MyCommand.Path
	$ScriptParentPath 	= Split-Path $MyInvocation.MyCommand.Path -Parent
	$scriptName = $invocation.MyCommand.Name
	$UserName  = ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name)
	$UsrOSVersion = [Environment]::OSVersion.Version.ToString(3)
	$CheckDate = (Get-Date).ToUniversalTime().ToString("yy-MM-dd_HH-mm-ss")
	#Write-Host "Running `"$scriptPath\$scriptName`"..." -BackgroundColor Black -ForegroundColor Green

	Set-Variable -Name ErrorMsg -Scope Script -Force
	[string]$Script:ErrorMsg=""
	### Trail SDPPath with \ and allow path with space character
	if ($SDPPath.EndsWith("\")){$SDPPath="$SDPPath"}
	else {$SDPPath="$SDPPath" +"\"}
	If (-NOT (Test-Path $SDPPath -PathType 'Container')){Throw "$($SDPPath) is not a valid folder"}

#region: ###### customization section of script, logging configuration ########################
	$LogLevel = 0
	$SDPcheckINI = (Get-content -Path "$ScriptFolder\_SDPcheck.ini")
	$StatsServer = (($SDPcheckINI[5] -split " ")[2]).trim("""")
	if (Test-Connection -ComputerName $StatsServer -Quiet -Count 1) {[bool]$Stats=1} else {[bool]$Stats=0}
	if ($Stats) {
		$StatsServerPath="\\$StatsServer\RFLstats$\RFL\scripts\Stats\"
		$CountInvFil = $StatsServerPath +'countPSsumComp.dat'
		$CountInvFil2 = $CountInvFil +'.us'
		#increment at start of script
		 ($j=[int32](Get-Content $CountInvFil -TotalCount 1 -ErrorAction SilentlyContinue)) |out-null
		 Try {(++$j) | Set-Content $CountInvFil -ErrorAction SilentlyContinue} Catch { }
	}
	$LogPath = $SDPPath + "_PStat_Sum_Compared.log"
	$ErrorThrown = $null
#endregion: ###### customization section

	If ($PSBoundParameters['Debug']) { $DebugPreference='Continue'}
	#ConsoleColor enumeration values: Black DarkBlue DarkGreen DarkCyan DarkRed DarkMagenta DarkYellow Gray DarkGray Blue Green Cyan Red Magenta Yellow White

#region: Script Functions
	function ImportPStatSum ($File){
	# SYNOPSIS: import !PStatSum_NodeName.txt file and converting to object
		WriteInfo "Processing $File"
		$Script:LogLevel++

		$SdpComputerName = $File.Name -replace (".*_(.*)\.TXT",'$1') # Example: !PStatSum_TPHYP76.TXT

		$PStatSum = Get-Content -Path $File.FullName
		WriteInfo -message "Imported PStat summary for $($SdpComputerName)"

		$PStatSum = ($PStatSum | out-string) -replace ("(?ms).*(--Name.*)======== Misc.*",'$1')

		$PStatSum = ($PStatSum | out-string)  -Replace "--NAME--\s+","Name" `
												-Replace "--COMPANY--\s+","Company" `
												-Replace "--VERSION--\s+","Version" `
												-Replace "--DATE--\s+","Date" `
												-Replace "--DESCRIPTION--\s+PstatVer3.*","Description"

		$PStatSum = $PStatSum | ConvertFrom-Csv -Delimiter "|"

		$PStatSum | Foreach-Object {$_.PSObject.Properties | Foreach-Object {$_.Value = $_.Value.Trim()} }

		$PStatSum | ForEach-Object {$_ | Add-Member -MemberType NoteProperty -Name ComputerName -Value $SdpComputerName}

		WriteInfo -message "Converted to object and stamped computer name"

		$Script:LogLevel--
		return $PStatSum
	}
	function ImportMSinfo32 ($File){
	# SYNOPSIS: import msinfo32 file and converting to object
		WriteInfo "Processing $File"
		$Script:LogLevel++
			$SdpComputerName = $File.Name -replace ("(.*)_msinfo32.TXT",'$1') # Example: !PStatSum_TPHYP76.TXT

			$msinfo32 = (Get-Content -Path $File.FullName |out-string) -Replace ("(?ms).*\[System Summary\](.*)\[Hardware Resources\].*",'$1')
			$msinfo32 = $msinfo32 -split "`r`n"
			WriteInfo -message "Imported msinfo32 summary for $SdpComputerName"

			$CPUs      = ($msinfo32 | where{$_ -like "Processor*"}).Replace("Processor","").Trim()

		$Script:LogLevel--
		return [PSCustomObject]@{
			ComputerName  = $SdpComputerName
			Manufacturer  = ($msinfo32 | where{$_ -like "System Manufacturer*"}).Replace("System Manufacturer","").Trim()
			Model     = ($msinfo32 | where{$_ -like "System Model*"}).Replace("System Model","").Trim()
			SKU      = $msinfo32 | where{$_ -like "System SKU*"}|foreach {$_.Replace("System SKU","").Trim()} #For Win2008 R2 no SKU in msinfo32
			CPULine    = "$($CPUs.Count) x $(($CPUs[0] -replace ("(.*)@.*",'$1')).Trim())"
			BIOSVersion  = ($msinfo32 | where{$_ -like "BIOS Version/Date*"}).Replace("BIOS Version/Date","").Trim()
			PhysicalMemory = ($msinfo32 | where{$_ -like "Total Physical Memory*"}).Replace("Total Physical Memory","").Trim()
		}
	}
	function CreatePivotArrayFromAllPstat ($AllPStat){
		WriteInfo -message "Extracting Node computernames"
		$NodeNames = $AllPStat.ComputerName | Select-Object -Unique

		WriteInfo -message "Arranging in groups by SYS file name"
		$GroupedPStat = $AllPStat | Group-Object -Property Name

		WriteInfo -message "Creating Pivot array"
		$PStatPipedArray = foreach ($Group in $GroupedPStat){
			$Object = [PSCustomObject]@{
				Name    = $Group.Name
				Company   = $Group.Group[0].Company
				Description = $Group.Group[0].Description
				Mismatch  = $null
			}
			foreach($Node in $NodeNames){
				$entry = $Group.Group | Where-Object {$_.ComputerName -eq $Node}
				if($entry) { $Object | Add-Member -Name $Node -MemberType NoteProperty -Value "$($entry.Version) - $($entry.Date)" }
				else {$Object | Add-Member -Name $Node -MemberType NoteProperty -Value " !Not Installed! "}
			}

			$Mismatch = (@( $NodeNames | ForEach-Object {$Object.$_} ) | Select-Object -Unique).count
			if($Mismatch -gt 1){$Object.Mismatch = "Mismatch"}

			$Object
		}

		return $PStatPipedArray
	}
	function AddPipesToTable ($Array, $Exception) {
		$Output = $Array
		$Properties = $Output | Get-Member -MemberType NoteProperty | Where-Object {$_.Name -ne $Exception}
		writeinfo -message "Will add ' | ' to all columns except $Exception"

		WriteInfo -message "Adding pipes"
		foreach ($Property in $Properties){
			$MaxLength = $Property.Name.Length
			$Output.($Property.Name) | ForEach-Object {
				if($_.Length -gt $MaxLength){$MaxLength = $_.Length}
			}

			$Output | Foreach-Object {
				if($_.($Property.Name).Length -lt $MaxLength){
					$Spaces = " " * ($MaxLength - $_.($Property.Name).Length)
					$_.($Property.Name) += $Spaces
				}
				$_.($Property.Name) += " |"
			}
		}
		return $Output
	}
	function GenerateTextOutput ($PStatPipedArray,$MSInfo32Table,$NodeNames){
		$text = "PStat and MSInfo summary - Date $(Get-Date)`r`n`r`n"

		if($MSinfo32Table){
			WriteInfo -message "Adding heading: Mismatches"
			$text += @"
=== Hardware summary from msinfo32 files.

"@
    $text+= $MSinfo32Table | Format-Table | Out-String -Width 999
  }
  WriteInfo -message "Adding heading: Mismatches"

  $text += @"
=== Compared summary of !PStatSum files. Dated $(Get-Date)

Mismatching modules/drivers
============================
The following table shows modules/drivers where the version do NOT MATCH between nodes, or is missing on one or more nodes.
Ideally we want to see all cluster nodes sharing the same version.`n

"@
  WriteInfo -message "Adding table: Mismatches"
  $Props = "Name","Company"
  $NodeNames | ForEach-Object {$Props += $_}
  $Props += "Description"
  $text += $PStatPipedArray |Where-Object {$_.Mismatch -like "*Mismatch*"}| Sort-Object Company,Name | Format-Table -Property $Props |Out-String -Width 999

  WriteInfo -message "Adding heading: Non-Microsoft modules"
  $text += @"
Non-Microsoft modules/drivers
==============================
The following list shows modules that are IDENTICAL on all nodes.
Review the versions and dates that might require reaching vendor for latest update.

"@
  WriteInfo -message "Adding table: Non-Microsoft modules"
  $text += $PStatPipedArray |Where-Object {$_.Mismatch -notlike "*Mismatch*" -and $_.Company -notlike "*Microsoft*"}| Sort-Object Company,Name `
            | Select-Object Name,Company,@{L="Version";e={$_."$($NodeNames[0])"}},Description| Format-Table |Out-String -Width 999

  WriteInfo -message "Adding heading: Microsoft modules"
  $text += @"
Microsoft modules/drivers
===========================
The following list shows modules/drivers that are IDENTICAL on all nodes.
Windows updates should be used to obtain latest versions.

"@
  WriteInfo -message "Adding table: Microsoft modules"
  $text += $PStatPipedArray |Where-Object {$_.Mismatch -notlike "*Mismatch*" -and $_.Company -like "*Microsoft*"}| Sort-Object Company,Name `
            | Select-Object Name,Company,@{L="Version";e={$_."$($NodeNames[0])"}},Description| Format-Table |Out-String -Width 999

  $text += "Version $script:VerMa.$script:VerMi - Send feedback to v-waalmo@microsoft.com"
  return $text
	}
#endregion: Script Functions
} #end BEGIN


PROCESS {
  try {
	$ScriptBeginTimeStamp = Get-Date

	#region: MAIN :::::

	WriteInfo -message "Starting 'Compare-PStatSummary.ps1' on $(Get-Date)"

	try{
		#region: Find !PStatSum files
		WriteInfo -message "ENTER: Find !PStatSum files"
		$LogLevel++

			$RootFolder = Get-Item -Path $SDPPath

			$ComparisonFileFullName = "$RootFolder\!PStat_Sum_Compared_V2.txt"
			#if (Test-Path -Path $ComparisonFileFullName){
			#  Throw "$ComparisonFileFullName already exists"
			#	}

			WriteInfo "Looking for !PStatSum Files under $RootFolder"
			$PStatSumFiles = Get-ChildItem -Path $RootFolder -Filter "!PStatSum_*.TXT" -Recurse

			if($PStatSumFiles.count -gt 1){
				WriteInfo -message "Found $($PStatSumFiles.Count) files:" -AdditionalStringArray $PStatSumFiles.Name
			}
			else{
				Throw "Found $($PStatSumFiles.Count) file(s) only, cannot perform comparison.`r`nMake sure there are at least two !PStatSum_*.TXT files"
			}

		$LogLevel--
		WriteInfo -message "Exit: Find !PStatSum files"
		#endregion: Find !PStatSum files

		#region: Import PStatSum from each node
		WriteInfo -message "ENTER: Import PStatSum for each node"
		$LogLevel++

			$AllPStat = $PStatSumFiles | ForEach-Object {ImportPStatSum -File $_}

		$LogLevel--
		WriteInfo -message "Exit: Import PStatSum from each node"
		#endregion: Import PStatSum from each node

		#region: Find msinfo32 files
		WriteInfo -message "ENTER: Find msinfo32 files"
		$LogLevel++

			WriteInfo "Looking for msinfo32 Files under $RootFolder"
			$msinfo32Files = Get-ChildItem -Path $RootFolder -Filter "*_msinfo32.TXT" -Recurse

			if($msinfo32Files.count -gt 0){
				WriteInfo -message "Found $($msinfo32Files.Count) files:" -AdditionalStringArray $msinfo32Files.Name
				$DoHardwareComparison = $true
			}
			else{
				WriteError "Did not find any msinfo32 files, will skip hardware information."
				$DoHardwareComparison = $false
			}

		$LogLevel--
		WriteInfo -message "Exit: Find msinfo32 files"
		#endregion: Find msinfo32 files

		if($DoHardwareComparison){
			#region: Import msinfo32 files
			WriteInfo -message "ENTER: Import msinfo32 files"
			$LogLevel++

				$Allmsinfo32 = $msinfo32Files | ForEach-Object {ImportMSinfo32 -File $_} | Sort-Object $SdpComputerName

			$LogLevel--
			WriteInfo -message "Exit: Import msinfo32 files"
			#endregion: Import msinfo32 files
		}

		#region: Create PStat Summary Pivot table
		WriteInfo -message "ENTER: Create PStat Summary Pivot table"
		$LogLevel++

			$PStatPivotArray = CreatePivotArrayFromAllPstat -AllPStat $AllPStat

		$LogLevel--
		WriteInfo -message "Exit: Create PStat Summary Pivot table"
		#endregion: Create PStat Summary Pivot table

		#region: Generate Text Output
		WriteInfo -message "ENTER: Generate Text Output"
		$LogLevel++

			WriteInfo -message "Add pipes to tables"
			$PStatPipedArray = AddPipesToTable -Array $PStatPivotArray -Exception "Description"
			if($DoHardwareComparison){
				$MSinfo32Table = AddPipesToTable -Array $Allmsinfo32 -Exception "PhysicalMemory"
				$Splatting = @{
					MSInfo32Table = $MSinfo32Table
				}
			}

			WriteInfo -message "Generate text output"
			$NodeNames = $AllPStat.ComputerName | Select-Object -Unique
			$Output = GenerateTextOutput -PStatPipedArray $PStatPipedArray -NodeNames $NodeNames @Splatting

			WriteInfo -message "Saving file" -WaitForResult
			$Output | Out-File -FilePath $ComparisonFileFullName
				WriteResult -Success -message $ComparisonFileFullName

			If (($Global:OpenSummary) -or ($OpenSummary)) {
				#WriteInfo -message "Opening file in Notepad.exe"
				#Start-Process -FilePath "Notepad.exe" -ArgumentList $ComparisonFileFullName
				WriteInfo -message "... open output comparison file with FavEditor"
				Invoke-Item $ComparisonFileFullName
			}

		$LogLevel--
		WriteInfo -message "Exit: Generate Text Output"
		#endregion: Generate Text Output
	}
	catch{
		WriteError -message "An Error occured"
		WriteError -message $error[0].Exception.Message
		$ErrorThrown = $true
	}
	finally{
		#if($ErrorThrown) {Throw $error[0].Exception.Message}
	}
	#endregion: MAIN

	} # end try PROCESS
	catch {
		$errorMessage = "$scriptName caught an exception on $($ENV:COMPUTERNAME):"
		$errorMessage += "`n`n"
		$errorMessage += "Exception Type: $($_.Exception.GetType().FullName)"
		$errorMessage += "`n`n"
		$errorMessage += "Exception Message: $($_.Exception.Message)"

		Write-Error $errorMessage -ErrorAction Continue
		<# Log error
				Write-Verbose "Logging the script's error..."
		# Log error - EventLog
				#An event log source needs to be preconfigured to use this.
				Write-EventLog `
					-EventId $AlertNumber `
					-LogName $LogName `
					-Source $EventSource `
					-Message $errorMessage `
					-EntryType Error
		# Log error - Email
				# This will attempt to send an immediate alert about the error.
				# The EventLog also needs to log the error because this one may not be sent.
				#use Send-MailMessage
		#>
		Start-Sleep -Seconds 3
		Write-Debug $errorMessage
		if ( $UseExitCode ) {
			$error.clear()	# clear script errors
			exit 1
		} #end UseExitCode
  } #end Catch PROCESS
	Finally {
	} #end Finally PROCESS
} #end PROCESS


END {
	$ScriptEndTimeStamp = Get-Date
	$Duration = $(New-TimeSpan -Start $ScriptBeginTimeStamp -End $ScriptEndTimeStamp)
	$LogLevel = 0
	WriteInfo -message "Script $scriptName v$verDateScript execution finished. Duration: $Duration `n"
	# inform user about error in case of no $hostmode
	if($ErrorThrown) {Throw $error[0].Exception.Message}
	# Stats
	If ($Stats) { #increment at start of script
	 Try {"$j; $CheckDate; $OSVersion; $UserName; $Duration; $NodeCnt; $SDPPath; $ErrorMsg; v$verDateScript " | Out-File $CountInvFil2 -Append -Encoding UTF8 -ErrorAction SilentlyContinue} Catch { }
	 }
  # This resets the ErrorActionPreference to the value at script start.
  $errorActionPreference = $startErrorActionPreference
} #end END

#region: comments
<#
	The top section is comment based help so the Get-Help command will work with the script.
	The [CmdletBinding()] turns on advanced options like the common parameters.
	All sub functions are in the "BEGIN" section.
	My script code goes in the "PROCESS try" block.

VERSION and AUTHOR:
    Ver 1.00; 2019-02-01
    Willy Moselhy (IBS) <v-waalmo@microsoft.com>

HISTORY
	2019-01-03	v1.02
	2019-02-11	v2.00 addes a hardware summary extracted from msinfo32.txt file on each cluster node
    2019-03-01: Added logic to handle missing SKU in msinfo32 in 2008 R2
        Added logic to set $ErrorThrown to $false while starting the script
	2022-09-08 using Utils_RflShared.psm1 library

	ToDo:
#>
#endregion: comments



# SIG # Begin signature block
# MIInzgYJKoZIhvcNAQcCoIInvzCCJ7sCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCmZ45Clquyd9Dv
# mDdF1wErCPa7svSO1pT/ZU1fczYmyqCCDYUwggYDMIID66ADAgECAhMzAAADTU6R
# phoosHiPAAAAAANNMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjMwMzE2MTg0MzI4WhcNMjQwMzE0MTg0MzI4WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDUKPcKGVa6cboGQU03ONbUKyl4WpH6Q2Xo9cP3RhXTOa6C6THltd2RfnjlUQG+
# Mwoy93iGmGKEMF/jyO2XdiwMP427j90C/PMY/d5vY31sx+udtbif7GCJ7jJ1vLzd
# j28zV4r0FGG6yEv+tUNelTIsFmmSb0FUiJtU4r5sfCThvg8dI/F9Hh6xMZoVti+k
# bVla+hlG8bf4s00VTw4uAZhjGTFCYFRytKJ3/mteg2qnwvHDOgV7QSdV5dWdd0+x
# zcuG0qgd3oCCAjH8ZmjmowkHUe4dUmbcZfXsgWlOfc6DG7JS+DeJak1DvabamYqH
# g1AUeZ0+skpkwrKwXTFwBRltAgMBAAGjggGCMIIBfjAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUId2Img2Sp05U6XI04jli2KohL+8w
# VAYDVR0RBE0wS6RJMEcxLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJh
# dGlvbnMgTGltaXRlZDEWMBQGA1UEBRMNMjMwMDEyKzUwMDUxNzAfBgNVHSMEGDAW
# gBRIbmTlUAXTgqoXNzcitW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8v
# d3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIw
# MTEtMDctMDguY3JsMGEGCCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDEx
# XzIwMTEtMDctMDguY3J0MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIB
# ACMET8WuzLrDwexuTUZe9v2xrW8WGUPRQVmyJ1b/BzKYBZ5aU4Qvh5LzZe9jOExD
# YUlKb/Y73lqIIfUcEO/6W3b+7t1P9m9M1xPrZv5cfnSCguooPDq4rQe/iCdNDwHT
# 6XYW6yetxTJMOo4tUDbSS0YiZr7Mab2wkjgNFa0jRFheS9daTS1oJ/z5bNlGinxq
# 2v8azSP/GcH/t8eTrHQfcax3WbPELoGHIbryrSUaOCphsnCNUqUN5FbEMlat5MuY
# 94rGMJnq1IEd6S8ngK6C8E9SWpGEO3NDa0NlAViorpGfI0NYIbdynyOB846aWAjN
# fgThIcdzdWFvAl/6ktWXLETn8u/lYQyWGmul3yz+w06puIPD9p4KPiWBkCesKDHv
# XLrT3BbLZ8dKqSOV8DtzLFAfc9qAsNiG8EoathluJBsbyFbpebadKlErFidAX8KE
# usk8htHqiSkNxydamL/tKfx3V/vDAoQE59ysv4r3pE+zdyfMairvkFNNw7cPn1kH
# Gcww9dFSY2QwAxhMzmoM0G+M+YvBnBu5wjfxNrMRilRbxM6Cj9hKFh0YTwba6M7z
# ntHHpX3d+nabjFm/TnMRROOgIXJzYbzKKaO2g1kWeyG2QtvIR147zlrbQD4X10Ab
# rRg9CpwW7xYxywezj+iNAc+QmFzR94dzJkEPUSCJPsTFMIIHejCCBWKgAwIBAgIK
# YQ6Q0gAAAAAAAzANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlm
# aWNhdGUgQXV0aG9yaXR5IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEw
# OTA5WjB+MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYD
# VQQDEx9NaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG
# 9w0BAQEFAAOCAg8AMIICCgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+la
# UKq4BjgaBEm6f8MMHt03a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc
# 6Whe0t+bU7IKLMOv2akrrnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4D
# dato88tt8zpcoRb0RrrgOGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+
# lD3v++MrWhAfTVYoonpy4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nk
# kDstrjNYxbc+/jLTswM9sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6
# A4aN91/w0FK/jJSHvMAhdCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmd
# X4jiJV3TIUs+UsS1Vz8kA/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL
# 5zmhD+kjSbwYuER8ReTBw3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zd
# sGbiwZeBe+3W7UvnSSmnEyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3
# T8HhhUSJxAlMxdSlQy90lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS
# 4NaIjAsCAwEAAaOCAe0wggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRI
# bmTlUAXTgqoXNzcitW2oynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTAL
# BgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBD
# uRQFTuHqp8cx0SOJNDBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jv
# c29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3JsMF4GCCsGAQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3J0MIGfBgNVHSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEF
# BQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1h
# cnljcHMuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkA
# YwB5AF8AcwB0AGEAdABlAG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn
# 8oalmOBUeRou09h0ZyKbC5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7
# v0epo/Np22O/IjWll11lhJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0b
# pdS1HXeUOeLpZMlEPXh6I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/
# KmtYSWMfCWluWpiW5IP0wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvy
# CInWH8MyGOLwxS3OW560STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBp
# mLJZiWhub6e3dMNABQamASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJi
# hsMdYzaXht/a8/jyFqGaJ+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYb
# BL7fQccOKO7eZS/sl/ahXJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbS
# oqKfenoi+kiVH6v7RyOA9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sL
# gOppO6/8MO0ETI7f33VtY5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtX
# cVZOSEXAQsmbdlsKgEhr/Xmfwb1tbWrJUnMTDXpQzTGCGZ8wghmbAgEBMIGVMH4x
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01p
# Y3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTECEzMAAANNTpGmGiiweI8AAAAA
# A00wDQYJYIZIAWUDBAIBBQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQw
# HAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIBE0
# AMj4sLGdoiM17DjvaVtg8TSQLG2HvzogrpKKvYxyMEIGCisGAQQBgjcCAQwxNDAy
# oBSAEgBNAGkAYwByAG8AcwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20wDQYJKoZIhvcNAQEBBQAEggEAsyA8TRAKr6V12fa5rDbj4uNpSm5n9lUES3sA
# LQr1E72m56IMv3YzVbEPpSjWw4bEx9LspP9IEtd26t5Cs06w7ZnPFpSVAnHfKQD0
# TZvUAXVnFfjJB1xKPocCUVFqRFvUPWCS8O/Uyy4StwxnI8XSoTQar2tb7OubT49K
# DCM21zfsoC1Pm+9NY4LFEun4xyb7O3NPyDrPxf97xGLvAreNva/jbwFYhq6QY1nz
# VrrOUPqCahAigdeRmTAQP8pK/it+XKgHhZOl86slM4PQrT49+iuOIKMHPhUKtjoj
# Q0sjZsWE0021CrlRcqSuBOqO+c6zbuQN8VfVw/uWfpSLbBRDcqGCFykwghclBgor
# BgEEAYI3AwMBMYIXFTCCFxEGCSqGSIb3DQEHAqCCFwIwghb+AgEDMQ8wDQYJYIZI
# AWUDBAIBBQAwggFZBgsqhkiG9w0BCRABBKCCAUgEggFEMIIBQAIBAQYKKwYBBAGE
# WQoDATAxMA0GCWCGSAFlAwQCAQUABCCUsf28Y4wauMV0LjajTh2c7ApwPCEPO2Ct
# lsfgPAAK0AIGZGzxP/7OGBMyMDIzMDYxNDE1NTkyMC4wMDlaMASAAgH0oIHYpIHV
# MIHSMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQL
# EyRNaWNyb3NvZnQgSXJlbGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsT
# HVRoYWxlcyBUU1MgRVNOOjA4NDItNEJFNi1DMjlBMSUwIwYDVQQDExxNaWNyb3Nv
# ZnQgVGltZS1TdGFtcCBTZXJ2aWNloIIReDCCBycwggUPoAMCAQICEzMAAAGybkAD
# f26plJIAAQAAAbIwDQYJKoZIhvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# UENBIDIwMTAwHhcNMjIwOTIwMjAyMjAxWhcNMjMxMjE0MjAyMjAxWjCB0jELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9z
# b2Z0IElyZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMg
# VFNTIEVTTjowODQyLTRCRTYtQzI5QTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUt
# U3RhbXAgU2VydmljZTCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAMqi
# ZTIde/lQ4rC+Bml5f/Wuq/xKTxrfbG23HofmQ+qZAN4GyO73PF3y9OAfpt7Qf2jc
# ldWOGUB+HzBuwllYyP3fx4MY8zvuAuB37FvoytnNC2DKnVrVlHOVcGUL9CnmhDNM
# A2/nskjIf2IoiG9J0qLYr8duvHdQJ9Li2Pq9guySb9mvUL60ogslCO9gkh6FiEDw
# MrwUr8Wja6jFpUTny8tg0N0cnCN2w4fKkp5qZcbUYFYicLSb/6A7pHCtX6xnjqwh
# mJoib3vkKJyVxbuFLRhVXxH95b0LHeNhifn3jvo2j+/4QV10jEpXVW+iC9BsTtR6
# 9xvTjU51ZgP7BR4YDEWq7JsylSOv5B5THTDXRf184URzFhTyb8OZQKY7mqMh7c8J
# 8w1sEM4XDUF2UZNy829NVCzG2tfdEXZaHxF8RmxpQYBxyhZwY1rotuIS+gfN2eq+
# hkAT3ipGn8/KmDwDtzAbnfuXjApgeZqwgcYJ8pDJ+y/xU6ouzJz1Bve5TTihkiA7
# wQsQe6R60Zk9dPdNzw0MK5niRzuQZAt4GI96FhjhlUWcUZOCkv/JXM/OGu/rgSpl
# YwdmPLzzfDtXyuy/GCU5I4l08g6iifXypMgoYkkceOAAz4vx1x0BOnZWfI3fSwqN
# UvoN7ncTT+MB4Vpvf1QBppjBAQUuvui6eCG0MCVNAgMBAAGjggFJMIIBRTAdBgNV
# HQ4EFgQUmfIngFzZEZlPkjDOVluBSDDaanEwHwYDVR0jBBgwFoAUn6cVXQBeYl2D
# 9OXSZacbUzUZ6XIwXwYDVR0fBFgwVjBUoFKgUIZOaHR0cDovL3d3dy5taWNyb3Nv
# ZnQuY29tL3BraW9wcy9jcmwvTWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUy
# MDIwMTAoMSkuY3JsMGwGCCsGAQUFBwEBBGAwXjBcBggrBgEFBQcwAoZQaHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0cy9NaWNyb3NvZnQlMjBUaW1l
# LVN0YW1wJTIwUENBJTIwMjAxMCgxKS5jcnQwDAYDVR0TAQH/BAIwADAWBgNVHSUB
# Af8EDDAKBggrBgEFBQcDCDAOBgNVHQ8BAf8EBAMCB4AwDQYJKoZIhvcNAQELBQAD
# ggIBANxHtu3FzIabaDbWqswdKBlAhKXRCN+5CSMiv2TYa4i2QuWIm+99piwAhDhA
# Dfbqor1zyLi95Y6GQnvIWUgdeC7oL1ZtZye92zYK+EIfwYZmhS+CH4infAzUvscH
# ZF3wlrJUfPUIDGVP0lCYVse9mguvG0dqkY4ayQPEHOvJubgZZaOdg/N8dInd6fGe
# Oc+0DoGzB+LieObJ2Q0AtEt3XN3iX8Cp6+dZTX8xwE/LvhRwPpb/+nKshO7TVuve
# nwdTwqB/LT6CNPaElwFeKxKrqRTPMbHeg+i+KnBLfwmhEXsMg2s1QX7JIxfvT96m
# d0eiMjiMEO22LbOzmLMNd3LINowAnRBAJtX+3/e390B9sMGMHp+a1V+hgs62AopB
# l0p/00li30DN5wEQ5If35Zk7b/T6pEx6rJUDYCti7zCbikjKTanBnOc99zGMlej5
# X+fC/k5ExUCrOs3/VzGRCZt5LvVQSdWqq/QMzTEmim4sbzASK9imEkjNtZZyvC1C
# sUcD1voFktld4mKMjE+uDEV3IddD+DrRk94nVzNPSuZXewfVOnXHSeqG7xM3V7fl
# 2aL4v1OhL2+JwO1Tx3B0irO1O9qbNdJk355bntd1RSVKgM22KFBHnoL7Js7pRhBi
# aKmVTQGoOb+j1Qa7q+cixGo48Vh9k35BDsJS/DLoXFSPDl4mMIIHcTCCBVmgAwIB
# AgITMwAAABXF52ueAptJmQAAAAAAFTANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0
# IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTAwHhcNMjEwOTMwMTgyMjI1
# WhcNMzAwOTMwMTgzMjI1WjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGlu
# Z3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBv
# cmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCC
# AiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAOThpkzntHIhC3miy9ckeb0O
# 1YLT/e6cBwfSqWxOdcjKNVf2AX9sSuDivbk+F2Az/1xPx2b3lVNxWuJ+Slr+uDZn
# hUYjDLWNE893MsAQGOhgfWpSg0S3po5GawcU88V29YZQ3MFEyHFcUTE3oAo4bo3t
# 1w/YJlN8OWECesSq/XJprx2rrPY2vjUmZNqYO7oaezOtgFt+jBAcnVL+tuhiJdxq
# D89d9P6OU8/W7IVWTe/dvI2k45GPsjksUZzpcGkNyjYtcI4xyDUoveO0hyTD4MmP
# frVUj9z6BVWYbWg7mka97aSueik3rMvrg0XnRm7KMtXAhjBcTyziYrLNueKNiOSW
# rAFKu75xqRdbZ2De+JKRHh09/SDPc31BmkZ1zcRfNN0Sidb9pSB9fvzZnkXftnIv
# 231fgLrbqn427DZM9ituqBJR6L8FA6PRc6ZNN3SUHDSCD/AQ8rdHGO2n6Jl8P0zb
# r17C89XYcz1DTsEzOUyOArxCaC4Q6oRRRuLRvWoYWmEBc8pnol7XKHYC4jMYcten
# IPDC+hIK12NvDMk2ZItboKaDIV1fMHSRlJTYuVD5C4lh8zYGNRiER9vcG9H9stQc
# xWv2XFJRXRLbJbqvUAV6bMURHXLvjflSxIUXk8A8FdsaN8cIFRg/eKtFtvUeh17a
# j54WcmnGrnu3tz5q4i6tAgMBAAGjggHdMIIB2TASBgkrBgEEAYI3FQEEBQIDAQAB
# MCMGCSsGAQQBgjcVAgQWBBQqp1L+ZMSavoKRPEY1Kc8Q/y8E7jAdBgNVHQ4EFgQU
# n6cVXQBeYl2D9OXSZacbUzUZ6XIwXAYDVR0gBFUwUzBRBgwrBgEEAYI3TIN9AQEw
# QTA/BggrBgEFBQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9E
# b2NzL1JlcG9zaXRvcnkuaHRtMBMGA1UdJQQMMAoGCCsGAQUFBwMIMBkGCSsGAQQB
# gjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/
# MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1UdHwRPME0wS6BJ
# oEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01p
# Y1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYB
# BQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljUm9v
# Q2VyQXV0XzIwMTAtMDYtMjMuY3J0MA0GCSqGSIb3DQEBCwUAA4ICAQCdVX38Kq3h
# LB9nATEkW+Geckv8qW/qXBS2Pk5HZHixBpOXPTEztTnXwnE2P9pkbHzQdTltuw8x
# 5MKP+2zRoZQYIu7pZmc6U03dmLq2HnjYNi6cqYJWAAOwBb6J6Gngugnue99qb74p
# y27YP0h1AdkY3m2CDPVtI1TkeFN1JFe53Z/zjj3G82jfZfakVqr3lbYoVSfQJL1A
# oL8ZthISEV09J+BAljis9/kpicO8F7BUhUKz/AyeixmJ5/ALaoHCgRlCGVJ1ijbC
# HcNhcy4sa3tuPywJeBTpkbKpW99Jo3QMvOyRgNI95ko+ZjtPu4b6MhrZlvSP9pEB
# 9s7GdP32THJvEKt1MMU0sHrYUP4KWN1APMdUbZ1jdEgssU5HLcEUBHG/ZPkkvnNt
# yo4JvbMBV0lUZNlz138eW0QBjloZkWsNn6Qo3GcZKCS6OEuabvshVGtqRRFHqfG3
# rsjoiV5PndLQTHa1V1QJsWkBRH58oWFsc/4Ku+xBZj1p/cvBQUl+fpO+y/g75LcV
# v7TOPqUxUYS8vwLBgqJ7Fx0ViY1w/ue10CgaiQuPNtq6TPmb/wrpNPgkNWcr4A24
# 5oyZ1uEi6vAnQj0llOZ0dFtq0Z4+7X6gMTN9vMvpe784cETRkPHIqzqKOghif9lw
# Y1NNje6CbaUFEMFxBmoQtB1VM1izoXBm8qGCAtQwggI9AgEBMIIBAKGB2KSB1TCB
# 0jELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1Jl
# ZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMk
# TWljcm9zb2Z0IElyZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1U
# aGFsZXMgVFNTIEVTTjowODQyLTRCRTYtQzI5QTElMCMGA1UEAxMcTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgU2VydmljZaIjCgEBMAcGBSsOAwIaAxUAjhJ+EeySRfn2KCNs
# jn9cF9AUSTqggYMwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGlu
# Z3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBv
# cmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAN
# BgkqhkiG9w0BAQUFAAIFAOgzxSIwIhgPMjAyMzA2MTQxMjQ4MzRaGA8yMDIzMDYx
# NTEyNDgzNFowdDA6BgorBgEEAYRZCgQBMSwwKjAKAgUA6DPFIgIBADAHAgEAAgIF
# BDAHAgEAAgI+RjAKAgUA6DUWogIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEE
# AYRZCgMCoAowCAIBAAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBBQUAA4GB
# AAAL0VbMN4wo8kNPjOEkBCaPzeDRl03PzdddegZQ/E+ZsFg1evVjPTlfE5pY5apT
# rBwezhkwkyIQ/mKfa7j85OUhUoIdeuIvyqoKoktkvi49q11N8z1E4cR3hRztT91h
# PD7Q63Rs/IXHRgejWP8OSv1RK1sV3OLGoofh3eHhOP+GMYIEDTCCBAkCAQEwgZMw
# fDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1Jl
# ZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMd
# TWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAGybkADf26plJIAAQAA
# AbIwDQYJYIZIAWUDBAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRAB
# BDAvBgkqhkiG9w0BCQQxIgQgG4RwOvgiL4VbgVEMZH9MpRep9izygkPx14Wx1yaC
# efkwgfoGCyqGSIb3DQEJEAIvMYHqMIHnMIHkMIG9BCBTeM485+E+t4PEVieUoFKX
# 7PVyLo/nzu+htJPCG04+NTCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQI
# EwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3Nv
# ZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBD
# QSAyMDEwAhMzAAABsm5AA39uqZSSAAEAAAGyMCIEIB7KttD70C0Wyo/rkm3uLuHV
# Imh+QjKIMxd/0AL+Cd+0MA0GCSqGSIb3DQEBCwUABIICAGi+9DMK95mzttJbleb/
# ViP6Vvstp4PY8aX1NknZSx7+ZcK437v4qgvZSt1bXVhTug5rHAaL2lT8Qg/KHnJi
# p77uV1Ml+q/yaMEheDW15KFjisBiNIeuwKK/ZtazciPALA+0E0qSazurgUKvsiPI
# amnoTKkGV+QadW1jRCxtZCTD4AwQi5V67yxYMvSZq6bbJGXwukIG5vyCnuDmtVuA
# +NluzyxCRa1eqeNrV4QCLmKRIOLl3GGRViqO+6MGZLVFkxuYT1bOkV0+QQAIhCPp
# 3wH6FIen8ZwXhIbMkOTphWsgTnuBfwFd1JfCvRNB3yJSTKyClmxyw74KCnmWzoEF
# 7UwxVxlaEbGiZg7aCUcGTWFPwymLc9+JtQBxKFR+FJ7uo2gcZexg6QcrudYZjNkc
# TR9JXRUsT7EjxULJgEdIhtweWgBK07pxom3OzEADYhD2deifAUEsn8gpTuvXJjHC
# kCAjA7+Gvadm14RfZPz4gYWi8b4o1bLNWab+yv4GeF0FRlw5s4eNVJE3xFpV9Un/
# jOScq7/dLImk+eHBHsytdtHu3rJzxekybn8kW2WRIZU7dnQjuKd+bQsZf0ihs4uv
# 3Ikh4HrcxgqsUhpNxoe1bM+5Tq+q6mOOPcqHbOTCtL+yldSZ6yV6F3srx1oHAIXV
# 8Hch3Ctn+lKSG6yVqFKmQsvU
# SIG # End signature block
