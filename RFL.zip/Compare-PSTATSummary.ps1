<# last edit by: v-waalmo 2019-02-11 / waltere 2019-02-11
   File Name: Compare-PStatSummary.ps1
   Objective: This script compares the resulting !PStatSum_NodeName.TXT created when running RFL check 
   supplied by Willy Moselhy (IBS) <v-waalmo@microsoft.com>
#>

<#
.SYNOPSIS
The script compares the cluster !PStatSum_NodeName.TXT created when running RFL check.

SYNTAX: .\Compare-PStatSummary.ps1 -SDPPath [full-path-to-expanded-SDP-report]

.DESCRIPTION
The script compares the !PStatSum_NodeName.TXT created when running RFL and displays overview of Microsoft and 3rd party modules/drivers that were loaded in memory when the SDP report was created on cluster.
Note: Expand the SDP report cab file into folder and run '.\get-PStatSum.ps1 [full-path-to-expanded-SDP-report]' before running this script in standalone mode.
Output file with table of nodes will be located in same folder with name !PStat_Sum_Compared.txt

If you experience PS error '...is not digitally signed.' run the command:
 Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned

.EXAMPLE
 \\localhost\ToolsShare\rfl\Compare-PStatSummary.ps1 -SDPPath \\MyPC\temp\SDPs\ClusterReports
 This command will compare all !PStatSum_*.TXT in folder \\MyPC\temp\SDPs\ClusterReports

.EXAMPLE
 \\localhost\ToolsShare\rfl\Compare-PStatSummary.ps1 -SDPPath C:\SDPs\ClusterReports -HostMode
 This command will show logging on the screen

.EXAMPLE
 \\localhost\ToolsShare\rfl\Compare-PStatSummary.ps1 -SDPPath C:\SDPs\ClusterReports -ScriptMode
 This command will show script processing in log file _PStat_Sum_Compared.log
 
.LINK
\\localhost\ToolsShare\rfl\Compare-PStatSummary.ps1
v-waalmo@microsoft.com ; waltere@microsoft.com
#>

[CmdletBinding()]
PARAM (
	# Path to SDP result folder containing !PStatSum_*.txt files
	[Parameter(Mandatory = $true,Position=0,HelpMessage='Choose a writable SDP folder location, i.e. C:\SR\SDP-report\ ')]
	[String] $SDPPath
	,
	[switch]$HostMode   = $true,  # This tells the logging functions to show logging on the screen
	[switch]$ScriptMode = $false, # This tells the logging functions to show logging in log file _PStat_Sum_Compared.log
	[switch]$UseExitCode= $true,  # This will cause the script to close after the error is logged if an error occurs.
	[String]$OSVersion			  # will be derived by parent/invoking RFLcheck script 
	)

BEGIN {
	# This saves the starting ErrorActionPreference and then sets it to 'Stop'.
	$startErrorActionPreference = $errorActionPreference
	$errorActionPreference = 'Stop'
	# This gets the current path and name of the script.
	$invocation = (Get-Variable MyInvocation).Value
	$invocationLine= $($MyInvocation.Line)
	$scriptPath = Split-Path $invocation.MyCommand.Path
	$ScriptParentPath 	= Split-Path $MyInvocation.MyCommand.Path -Parent
	$scriptName = $invocation.MyCommand.Name
	$UserName   = ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name)
	$UsrOSVersion = [Environment]::OSVersion.Version.ToString(3)
	$CheckDate = (Get-Date -UFormat "%Y-%m-%d_%R-%S").Replace(":","-")
	#Write-Host "Running `"$scriptPath\$scriptName`"..." -BackgroundColor Black -ForegroundColor Green
	
	Set-Variable -Name ErrorMsg -Scope Script -Force
	[string]$Script:ErrorMsg=""
	### Trail SDPPath with \ and allow path with space character
		if ($SDPPath.EndsWith("\")){$SDPPath="$SDPPath"}
		else {$SDPPath="$SDPPath" +"\"}
		If (-NOT (Test-Path $SDPPath -PathType 'Container')){Throw "$($SDPPath) is not a valid folder"}

	#region: ###### customization section of script, logging configuration ########################
	$LogLevel = 0
	$VerMa="2"
	$VerMi="01"
	$Stats=0
	$StatsServerPath="\\waltere-vdi.europe.corp.microsoft.com\netpod\tools\RFL\"
	$CountInvFil = $StatsServerPath +'countPSsumComp.dat'
	$CountInvFil2 = $CountInvFil +'.us'
	$LogPath = $SDPPath + "_PStat_Sum_Compared.log"
	$ErrorThrown = $null
	#endregion: ###### customization section 
	
	If ($Stats) { #increment at start of script
	  ($j=[int32](Get-Content $CountInvFil -ErrorAction SilentlyContinue)) |out-null
	  (++$j) | Set-Content $CountInvFil -ErrorAction SilentlyContinue
	  }
	If ($PSBoundParameters['Debug']) { $DebugPreference='Continue'}
	#ConsoleColor enumeration values: Black DarkBlue DarkGreen DarkCyan DarkRed DarkMagenta DarkYellow Gray DarkGray Blue Green Cyan Red Magenta Yellow White
	
	#region: Script Functions
	#region: Logging Functions 
	function WriteLine ([string]$line,[string]$ForegroundColor, [switch]$NoNewLine){
	# SYNOPSIS:  writes the actual output - used by other functions
		if($Script:ScriptMode){
			if($NoNewLine) {
				$Script:Trace += "$line"
			}
			else {
				$Script:Trace += "$line`r`n"
			}
			Set-Content -Path $script:LogPath -Value $Script:Trace
		}
		if($Script:HostMode){
			$Params = @{
				NoNewLine       = $NoNewLine -eq $true
				ForegroundColor = if($ForegroundColor) {$ForegroundColor} else {"White"}
			}
			Write-Host $line @Params
		}
	}
	
	function WriteInfo([string]$message,[switch]$WaitForResult,[string[]]$AdditionalStringArray,[string]$AdditionalMultilineString){
	# SYNOPSIS:  handles informational logs
		if($WaitForResult){
			WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:    $("`t" * $script:LogLevel)$message" -NoNewline
		}
		else{
			WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:    $("`t" * $script:LogLevel)$message"  
		}
		if($AdditionalStringArray){
			foreach ($String in $AdditionalStringArray){
				WriteLine "                    $("`t" * $script:LogLevel)`t$String"     
			}       
		}
		if($AdditionalMultilineString){
			foreach ($String in ($AdditionalMultilineString -split "`r`n" | Where-Object {$_ -ne ""})){
				WriteLine "                    $("`t" * $script:LogLevel)`t$String"     
			}
		}
	}

	function WriteResult([string]$message,[switch]$Pass,[switch]$Success){
	# SYNOPSIS:  writes results - should be used after -WaitForResult in WriteInfo
		if($Pass){
			WriteLine " - Pass" -ForegroundColor Cyan
			if($message){
				WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:    $("`t" * $script:LogLevel)`t$message" -ForegroundColor Cyan
			}
		}
		if($Success){
			WriteLine " - Success" -ForegroundColor Green
			if($message){
				WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:    $("`t" * $script:LogLevel)`t$message" -ForegroundColor Green
			}
		} 
	}

	function WriteInfoHighlighted([string]$message,[string[]]$AdditionalStringArray,[string]$AdditionalMultilineString){
	# SYNOPSIS:  write highlighted info ## currently not used
		WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:    $("`t" * $script:LogLevel)$message"  -ForegroundColor Cyan
		if($AdditionalStringArray){
			foreach ($String in $AdditionalStringArray){
				WriteLine "[$(Get-Date -Format hh:mm:ss)]          $("`t" * $script:LogLevel)`t$String" -ForegroundColor Cyan
			}
		}
		if($AdditionalMultilineString){
			foreach ($String in ($AdditionalMultilineString -split "`r`n" | Where-Object {$_ -ne ""})){
				WriteLine "[$(Get-Date -Format hh:mm:ss)]          $("`t" * $script:LogLevel)`t$String" -ForegroundColor Cyan
			}
		}
	}

	function WriteWarning([string]$message,[string[]]$AdditionalStringArray,[string]$AdditionalMultilineString){ 
	# SYNOPSIS:  write warning logs ## currently not used
		WriteLine "[$(Get-Date -Format hh:mm:ss)] WARNING: $("`t" * $script:LogLevel)$message"  -ForegroundColor Yellow
		if($AdditionalStringArray){
			foreach ($String in $AdditionalStringArray){
				WriteLine "[$(Get-Date -Format hh:mm:ss)]          $("`t" * $script:LogLevel)`t$String" -ForegroundColor Yellow
			}
		}
		if($AdditionalMultilineString){
			foreach ($String in ($AdditionalMultilineString -split "`r`n" | Where-Object {$_ -ne ""})){
				WriteLine "[$(Get-Date -Format hh:mm:ss)]          $("`t" * $script:LogLevel)`t$String" -ForegroundColor Yellow
			}
		}
	}

	function WriteError([string]$message){
	# SYNOPSIS:  logs errors
		WriteLine ""
		WriteLine "[$(Get-Date -Format hh:mm:ss)] ERROR:   $("`t`t" * $script:LogLevel)$message" -ForegroundColor Red
	}

	function WriteErrorAndExit($message){
	# SYNOPSIS:  logs errors and terminates script ## currently not used
		WriteLine "[$(Get-Date -Format hh:mm:ss)] ERROR:   $("`t" * $script:LogLevel)$message"  -ForegroundColor Red
		Write-Host "Press any key to continue ..."
		$host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") | OUT-NULL
		$HOST.UI.RawUI.Flushinputbuffer()
		Throw "Terminating Error"
	}
	#endregion: Logging Functions

	#region: Script Functions
	function ImportPStatSum ($File){
	# SYNOPSIS:  import !PStatSum_NodeName.txt file and converting to object
		WriteInfo "Processing $File"
		$Script:LogLevel++

		$ComputerName = $File.Name -replace (".*_(.*)\.TXT",'$1') # Example: !PStatSum_TPHYP76.TXT
		
		$PStatSum = Get-Content -Path $File.FullName
		WriteInfo -message "Imported PStat summary for $($ComputerName)" 
		
		$PStatSum = ($PStatSum | out-string) -replace ("(?ms).*(--Name.*)======== Misc.*",'$1')
		
		$PStatSum = ($PStatSum | out-string)    -Replace "--NAME--\s+","Name" `
												-Replace "--COMPANY--\s+","Company" `
												-Replace "--VERSION--\s+","Version" `
												-Replace "--DATE--\s+","Date" `
												-Replace "--DESCRIPTION--\s+PstatVer3.*","Description"
		
		$PStatSum = $PStatSum | ConvertFrom-Csv -Delimiter "|" 
		
		$PStatSum | Foreach-Object {$_.PSObject.Properties | Foreach-Object {$_.Value = $_.Value.Trim()} }

		$PStatSum | ForEach-Object {$_ | Add-Member -MemberType NoteProperty -Name ComputerName -Value $ComputerName}
		
		WriteInfo -message "Converted to object and stamped computer name"
		
		$Script:LogLevel--
		return $PStatSum     
	}
	function ImportMSinfo32 ($File){
	# SYNOPSIS:  import msinfo32 file and converting to object
		WriteInfo "Processing $File"
		$Script:LogLevel++
			$ComputerName = $File.Name -replace ("(.*)_msinfo32.TXT",'$1') # Example: !PStatSum_TPHYP76.TXT

			$msinfo32 = (Get-Content -Path $File.FullName |out-string) -Replace ("(?ms).*\[System Summary\](.*)\[Hardware Resources\].*",'$1')
			$msinfo32 = $msinfo32 -split "`r`n"
			WriteInfo -message "Imported msinfo32 summary for $ComputerName"
			
			$CPUs           = ($msinfo32 | where{$_ -like "Processor*"}).Replace("Processor","").Trim()

		$Script:LogLevel--
		return [PSCustomObject]@{
			ComputerName   = $ComputerName
			Manufacturer   = ($msinfo32 | where{$_ -like "System Manufacturer*"}).Replace("System Manufacturer","").Trim()
			Model          = ($msinfo32 | where{$_ -like "System Model*"}).Replace("System Model","").Trim()
			SKU            = ($msinfo32 | where{$_ -like "System SKU*"}).Replace("System SKU","").Trim()        
			CPULine        = "$($CPUs.Count) x $(($CPUs[0] -replace ("(.*)@.*",'$1')).Trim())"
			BIOSVersion    = ($msinfo32 | where{$_ -like "BIOS Version/Date*"}).Replace("BIOS Version/Date","").Trim()
			PhysicalMemory = ($msinfo32 | where{$_ -like "Total Physical Memory*"}).Replace("Total Physical Memory","").Trim()
		}
	}
	function CreatePivotArrayFromAllPstat ($AllPStat){
		WriteInfo -message "Extracting Node computernames"
		$NodeNames = $AllPStat.ComputerName | Select-Object -Unique

		WriteInfo -message "Arranging in groups by SYS file name"
		$GroupedPStat = $AllPStat | Group-Object -Property Name
		
		WriteInfo -message "Creating Pivot array"
		$PStatPipedArray = foreach ($Group in $GroupedPStat){
			$Object = [PSCustomObject]@{
				Name        = $Group.Name
				Company     = $Group.Group[0].Company
				Description = $Group.Group[0].Description
				Mismatch    = $null
			}
			foreach($Node in $NodeNames){
				$entry = $Group.Group | Where-Object {$_.ComputerName -eq $Node}
				if($entry) { $Object | Add-Member -Name $Node -MemberType NoteProperty -Value "$($entry.Version) - $($entry.Date)" }
				else {$Object | Add-Member -Name $Node -MemberType NoteProperty -Value "  !Not Installed!  "}
			}
		   
			$Mismatch = (@( $NodeNames | ForEach-Object {$Object.$_} ) | Select-Object -Unique).count
			if($Mismatch -gt 1){$Object.Mismatch = "Mismatch"}
		
			$Object
		}
		
		return $PStatPipedArray
	}
	function AddPipesToTable ($Array, $Exception) {
		$Output = $Array
		$Properties = $Output | Get-Member -MemberType NoteProperty | Where-Object {$_.Name -ne $Exception}
		writeinfo -message "Will add ' | ' to all columns except $Exception"
		
		WriteInfo -message "Adding pipes"
		foreach ($Property in $Properties){
			$MaxLength = $Property.Name.Length
			$Output.($Property.Name) | ForEach-Object {
				if($_.Length -gt $MaxLength){$MaxLength = $_.Length}
			}
		
			$Output | Foreach-Object {
				if($_.($Property.Name).Length -lt $MaxLength){
					$Spaces = " " * ($MaxLength - $_.($Property.Name).Length)
					$_.($Property.Name) += $Spaces
				}
				$_.($Property.Name) += " |"
			}
		}
		return $Output
	}
	function GenerateTextOutput ($PStatPipedArray,$MSInfo32Table,$NodeNames){
		$text = "PStat and MSInfo summary - Date $(Get-Date)`r`n`r`n"
		
		if($MSinfo32Table){
			WriteInfo -message "Adding heading: Mismatches"
			$text += @"
=== Hardware summary from msinfo32 files.

"@
        $text+= $MSinfo32Table | Format-Table | Out-String -Width 999
    }
    WriteInfo -message "Adding heading: Mismatches"

    $text  += @"
=== Compared summary of !PStatSum files. Dated $(Get-Date)

Mismatching modules/drivers
============================
The following table shows modules/drivers where the version do NOT MATCH between nodes, or is missing on one or more nodes.
Ideally we want to see all cluster nodes sharing the same version.`n

"@
    WriteInfo -message "Adding table: Mismatches"
    $Props = "Name","Company"
    $NodeNames | ForEach-Object {$Props += $_}
    $Props += "Description"
    $text += $PStatPipedArray |Where-Object {$_.Mismatch -like "*Mismatch*"}| Sort-Object Company,Name | Format-Table -Property $Props |Out-String -Width 999 
    
    WriteInfo -message "Adding heading: Non-Microsoft modules"
    $text += @"
Non-Microsoft modules/drivers
==============================
The following list shows modules that are IDENTICAL on all nodes. 
Review the versions and dates that might require reaching vendor for latest update.

"@
    WriteInfo -message "Adding table: Non-Microsoft modules"
    $text += $PStatPipedArray |Where-Object {$_.Mismatch -notlike "*Mismatch*" -and $_.Company -notlike "*Microsoft*"}| Sort-Object Company,Name `
                        |Select-Object Name,Company,@{L="Version";e={$_."$($NodeNames[0])"}},Description| Format-Table |Out-String -Width 999
    
    WriteInfo -message "Adding heading: Microsoft modules"    
    $text += @"
Microsoft modules/drivers
===========================
The following list shows modules/drivers that are IDENTICAL on all nodes. 
Windows updates should be used to obtain latest versions.

"@
    WriteInfo -message "Adding table: Microsoft modules"
    $text += $PStatPipedArray |Where-Object {$_.Mismatch -notlike "*Mismatch*" -and $_.Company -like "*Microsoft*"}| Sort-Object Company,Name `
                        |Select-Object Name,Company,@{L="Version";e={$_."$($NodeNames[0])"}},Description| Format-Table |Out-String -Width 999

    $text += "Version $script:VerMa.$script:VerMi - Send feedback to v-waalmo@microsoft.com"
    return $text
	}
	#endregion: Script Functions
} #end BEGIN


PROCESS {
   try {
	$ScriptBeginTimeStamp = Get-Date
	
	#region: MAIN :::::

	WriteInfo -message "Starting 'Compare-PStatSummary.ps1' on $(Get-Date)"

	try{
		#region: Find !PStatSum files
		WriteInfo -message "ENTER: Find !PStatSum files"
		$LogLevel++

			$RootFolder = Get-Item -Path $SDPPath

			$ComparisonFileFullName = "$RootFolder\!PStat_Sum_Compared_V2.txt"
			#if (Test-Path -Path $ComparisonFileFullName){
			#   Throw "$ComparisonFileFullName already exists"
			#	}

			WriteInfo "Looking for !PStatSum Files under $RootFolder"
			$PStatSumFiles = Get-ChildItem -Path $RootFolder -Filter  "!PStatSum_*.TXT" -Recurse
			
			if($PStatSumFiles.count -gt 1){
				WriteInfo -message "Found $($PStatSumFiles.Count) files:" -AdditionalStringArray $PStatSumFiles.Name
			}
			else{
				Throw "Found $($PStatSumFiles.Count) file(s) only, cannot perform comparison.`r`nMake sure there are at least two !PStatSum_*.TXT files"
			}

		$LogLevel--
		WriteInfo -message "Exit: Find !PStatSum files"
		#endregion: Find !PStatSum files

		#region: Import PStatSum from each node
		WriteInfo -message "ENTER: Import PStatSum for each node"
		$LogLevel++

			$AllPStat = $PStatSumFiles | ForEach-Object {ImportPStatSum -File $_}
				
		$LogLevel--
		WriteInfo -message "Exit: Import PStatSum from each node"
		#endregion: Import PStatSum from each node

		#region: Find msinfo32 files
		WriteInfo -message "ENTER: Find msinfo32 files"
		$LogLevel++
		
			WriteInfo "Looking for msinfo32 Files under $RootFolder"
			$msinfo32Files = Get-ChildItem -Path $RootFolder -Filter  "*_msinfo32.TXT" -Recurse
			
			if($msinfo32Files.count -gt 0){
				WriteInfo -message "Found $($msinfo32Files.Count) files:" -AdditionalStringArray $msinfo32Files.Name
				$DoHardwareComparison = $true
			}
			else{
				WriteError "Did not find any msinfo32 files, will skip hardware information."
				$DoHardwareComparison = $false
			}        
		
		$LogLevel--
		WriteInfo -message "Exit:  Find msinfo32 files"
		#endregion: Find msinfo32 files

		if($DoHardwareComparison){
			#region: Import msinfo32 files
			WriteInfo -message "ENTER: Import msinfo32 files"
			$LogLevel++
			
				$Allmsinfo32 = $msinfo32Files | ForEach-Object {ImportMSinfo32 -File $_} | Sort-Object $ComputerName
			
			$LogLevel--
			WriteInfo -message "Exit:  Import msinfo32 files"
			#endregion: Import msinfo32 files
		}

		#region: Create PStat Summary Pivot table
		WriteInfo -message "ENTER: Create PStat Summary Pivot table"
		$LogLevel++

			$PStatPivotArray = CreatePivotArrayFromAllPstat -AllPStat $AllPStat

		$LogLevel--
		WriteInfo -message "Exit: Create PStat Summary Pivot table"
		#endregion: Create PStat Summary Pivot table
		   
		#region: Generate Text Output
		WriteInfo -message "ENTER: Generate Text Output"
		$LogLevel++

			WriteInfo -message "Add pipes to tables"
			$PStatPipedArray = AddPipesToTable -Array $PStatPivotArray -Exception "Description"
			if($DoHardwareComparison){
				$MSinfo32Table = AddPipesToTable -Array $Allmsinfo32 -Exception "PhysicalMemory"
				$Splatting = @{
					MSInfo32Table = $MSinfo32Table
				}
			}
			
			WriteInfo -message "Generate text output"
			$NodeNames = $AllPStat.ComputerName | Select-Object -Unique
			$Output = GenerateTextOutput -PStatPipedArray $PStatPipedArray -NodeNames $NodeNames @Splatting
			
			WriteInfo -message "Saving file" -WaitForResult
			$Output | Out-File -FilePath $ComparisonFileFullName
				WriteResult -Success -message $ComparisonFileFullName

			#WriteInfo -message "Opening file in Notepad.exe"
			#Start-Process -FilePath "Notepad.exe" -ArgumentList $ComparisonFileFullName
			WriteInfo -message "... open output comparison file with FavEditor"
				Invoke-Item $ComparisonFileFullName

		$LogLevel--
		WriteInfo -message "Exit: Generate Text Output"
		#endregion: Generate Text Output
	}
	catch{
		WriteError -message "An Error occured"
		WriteError -message $error[0].Exception.Message
		$ErrorThrown = $true
	}
	finally{
		#if($ErrorThrown) {Throw $error[0].Exception.Message}
	}
	#endregion: MAIN 

	} # end try PROCESS
	catch {
		$errorMessage = "$scriptName caught an exception on $($ENV:COMPUTERNAME):"
		$errorMessage += "`n`n"
		$errorMessage += "Exception Type: $($_.Exception.GetType().FullName)"
		$errorMessage += "`n`n"
		$errorMessage += "Exception Message: $($_.Exception.Message)"

		Write-Error $errorMessage -ErrorAction Continue
		<# Log error
				Write-Verbose "Logging the script's error..."
		# Log error - EventLog
				#An event log source needs to be preconfigured to use this.
				Write-EventLog `
					-EventId $AlertNumber `
					-LogName $LogName `
					-Source $EventSource `
					-Message $errorMessage `
					-EntryType Error
		# Log error - Email
				# This will attempt to send an immediate alert about the error.
				# The EventLog also needs to log the error because this one may not be sent.
				#use Send-MailMessage
		#>
		Start-Sleep -Seconds 3
		Write-Debug $errorMessage
		if ( $UseExitCode ) {
			$error.clear()	# clear script errors
			exit 1
		} #end UseExitCode
    } #end Catch PROCESS
	Finally {
	} #end Finally PROCESS
} #end PROCESS


END {
	$ScriptEndTimeStamp = Get-Date
	$Duration = $(New-TimeSpan -Start $ScriptBeginTimeStamp -End $ScriptEndTimeStamp)
	$LogLevel = 0
	WriteInfo -message "Script $scriptName v$VerMa.$VerMi execution finished. Duration: $Duration `n"
	# inform user about error in case of no $hostmode
	if($ErrorThrown) {Throw $error[0].Exception.Message}
	# Stats
	If ($Stats) { #increment at start of script
	  "$j; $CheckDate; $OSVersion; $UserName; $Duration; $NodeCnt; $SDPPath; $ErrorMsg; v$VerMa.$VerMi" | Out-File $CountInvFil2 -Append -Encoding UTF8 -ErrorAction SilentlyContinue
	  }
    # This resets the ErrorActionPreference to the value at script start.
    $errorActionPreference = $startErrorActionPreference
} #end END

#region: comments
<#
	The top section is comment based help so the Get-Help command will work with the script.
	The [CmdletBinding()] turns on advanced options like the common parameters.
	All sub functions are in the "BEGIN" section.
	My script code goes in the "PROCESS try" block.

VERSION and AUTHOR:
        Ver 1.00; 2019-02-01
        Willy Moselhy (IBS) <v-waalmo@microsoft.com>

HISTORY
	2019-01-03	v1.02
	2019-02-11	v2.00 addes a hardware summary extracted from msinfo32.txt file on each cluster node
	
	ToDo:
#>
#endregion: comments 


