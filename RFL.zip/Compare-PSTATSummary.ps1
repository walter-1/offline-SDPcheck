<# last edit by: waltere 2022-09-12
  File Name: Compare-PStatSummary.ps1
  Objective: This script compares the resulting !PStatSum_NodeName.TXT created when running RFL check
  supplied by Willy Moselhy (IBS) <v-waalmo@microsoft.com>
#>

<#
.SYNOPSIS
The script compares the cluster !PStatSum_NodeName.TXT created when running RFL check.

SYNTAX: .\Compare-PStatSummary.ps1 -SDPPath [full-path-to-expanded-SDP-report]

.DESCRIPTION
The script compares the !PStatSum_NodeName.TXT created when running RFL and displays overview of Microsoft and 3rd party modules/drivers that were loaded in memory when the SDP report was created on cluster.
Note: Expand the SDP report cab file into folder and run '.\get-PStatSum.ps1 [full-path-to-expanded-SDP-report]' before running this script in standalone mode.
Output file with table of nodes will be located in same folder with name !PStat_Sum_Compared.txt

If you experience PS error '...is not digitally signed.' run the command:
 Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned

.PARAMETER OpenSummary
 This switch will not open resulting summary file with Notepad/Favorite Editor if set to $False
 
.EXAMPLE
 \\emeacssdfs.europe.corp.microsoft.com\netpod\rfl\Compare-PStatSummary.ps1 -SDPPath \\MyPC\temp\SDPs\ClusterReports
 This command will compare all !PStatSum_*.TXT in folder \\MyPC\temp\SDPs\ClusterReports

.EXAMPLE
 \\emeacssdfs.europe.corp.microsoft.com\netpod\rfl\Compare-PStatSummary.ps1 -SDPPath C:\SDPs\ClusterReports -HostMode
 This command will show logging on the screen

.EXAMPLE
 \\emeacssdfs.europe.corp.microsoft.com\netpod\rfl\Compare-PStatSummary.ps1 -SDPPath C:\SDPs\ClusterReports -ScriptMode
 This command will show script processing in log file _PStat_Sum_Compared.log

.LINK
\\emeacssdfs.europe.corp.microsoft.com\netpod\rfl\Compare-PStatSummary.ps1
v-waalmo@microsoft.com ; waltere@microsoft.com
#>

[CmdletBinding()]
PARAM (
	[Parameter(Mandatory = $true,Position=0,HelpMessage='Choose a writable SDP folder location, i.e. C:\SR\SDP-report\ ')]
	[String] $SDPPath,				# Path to SDP result folder containing !PStatSum_*.txt files
	[switch]$HostMode  = $true,		# This tells the logging functions to show logging on the screen
	[switch]$ScriptMode = $false,	# This tells the logging functions to show logging in log file _PStat_Sum_Compared.log
	[switch]$UseExitCode= $true,	# This will cause the script to close after the error is logged if an error occurs.
	[String]$OSVersion,				# will be derived by parent/invoking RFLcheck script
	[switch]$OpenSummary= $true		# open with Notepad/FavEditor
	)

BEGIN {
	$verDateScript = "2022.09.12.0"
	$ScriptFolder = Split-Path $MyInvocation.MyCommand.Path -Parent
	# Load Common Library
	  Remove-Module Utils_RflShared -ErrorAction Ignore
	  Import-Module $ScriptFolder\Utils_RflShared.psm1 -DisableNameChecking
	# This saves the starting ErrorActionPreference and then sets it to 'Stop'.
	$startErrorActionPreference = $errorActionPreference
	$errorActionPreference = 'Stop'
	# This gets the current path and name of the script.
	$invocation = (Get-Variable MyInvocation).Value
	$invocationLine= $($MyInvocation.Line)
	$scriptPath = Split-Path $invocation.MyCommand.Path
	$ScriptParentPath 	= Split-Path $MyInvocation.MyCommand.Path -Parent
	$scriptName = $invocation.MyCommand.Name
	$UserName  = ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name)
	$UsrOSVersion = [Environment]::OSVersion.Version.ToString(3)
	$CheckDate = (Get-Date).ToUniversalTime().ToString("yy-MM-dd_HH-mm-ss")
	#Write-Host "Running `"$scriptPath\$scriptName`"..." -BackgroundColor Black -ForegroundColor Green

	Set-Variable -Name ErrorMsg -Scope Script -Force
	[string]$Script:ErrorMsg=""
	### Trail SDPPath with \ and allow path with space character
	if ($SDPPath.EndsWith("\")){$SDPPath="$SDPPath"}
	else {$SDPPath="$SDPPath" +"\"}
	If (-NOT (Test-Path $SDPPath -PathType 'Container')){Throw "$($SDPPath) is not a valid folder"}

#region: ###### customization section of script, logging configuration ########################
	$LogLevel = 0
	$StatsServer = "waltere-vdi.europe.corp.microsoft.com"
	if (Test-Connection -ComputerName $StatsServer -Quiet -Count 1) {[bool]$Stats=1} else {[bool]$Stats=0}
	if ($Stats) {
		$StatsServerPath="\\$StatsServer\netpod\tools\RFL\"
		$CountInvFil = $StatsServerPath +'countPSsumComp.dat'
		$CountInvFil2 = $CountInvFil +'.us'
		#increment at start of script
		 ($j=[int32](Get-Content $CountInvFil -TotalCount 1 -ErrorAction SilentlyContinue)) |out-null
		 (++$j) | Set-Content $CountInvFil -ErrorAction SilentlyContinue
	}
	$LogPath = $SDPPath + "_PStat_Sum_Compared.log"
	$ErrorThrown = $null
#endregion: ###### customization section

	If ($PSBoundParameters['Debug']) { $DebugPreference='Continue'}
	#ConsoleColor enumeration values: Black DarkBlue DarkGreen DarkCyan DarkRed DarkMagenta DarkYellow Gray DarkGray Blue Green Cyan Red Magenta Yellow White

#region: Script Functions
	function ImportPStatSum ($File){
	# SYNOPSIS: import !PStatSum_NodeName.txt file and converting to object
		WriteInfo "Processing $File"
		$Script:LogLevel++

		$SdpComputerName = $File.Name -replace (".*_(.*)\.TXT",'$1') # Example: !PStatSum_TPHYP76.TXT

		$PStatSum = Get-Content -Path $File.FullName
		WriteInfo -message "Imported PStat summary for $($SdpComputerName)"

		$PStatSum = ($PStatSum | out-string) -replace ("(?ms).*(--Name.*)======== Misc.*",'$1')

		$PStatSum = ($PStatSum | out-string)  -Replace "--NAME--\s+","Name" `
												-Replace "--COMPANY--\s+","Company" `
												-Replace "--VERSION--\s+","Version" `
												-Replace "--DATE--\s+","Date" `
												-Replace "--DESCRIPTION--\s+PstatVer3.*","Description"

		$PStatSum = $PStatSum | ConvertFrom-Csv -Delimiter "|"

		$PStatSum | Foreach-Object {$_.PSObject.Properties | Foreach-Object {$_.Value = $_.Value.Trim()} }

		$PStatSum | ForEach-Object {$_ | Add-Member -MemberType NoteProperty -Name ComputerName -Value $SdpComputerName}

		WriteInfo -message "Converted to object and stamped computer name"

		$Script:LogLevel--
		return $PStatSum
	}
	function ImportMSinfo32 ($File){
	# SYNOPSIS: import msinfo32 file and converting to object
		WriteInfo "Processing $File"
		$Script:LogLevel++
			$SdpComputerName = $File.Name -replace ("(.*)_msinfo32.TXT",'$1') # Example: !PStatSum_TPHYP76.TXT

			$msinfo32 = (Get-Content -Path $File.FullName |out-string) -Replace ("(?ms).*\[System Summary\](.*)\[Hardware Resources\].*",'$1')
			$msinfo32 = $msinfo32 -split "`r`n"
			WriteInfo -message "Imported msinfo32 summary for $SdpComputerName"

			$CPUs      = ($msinfo32 | where{$_ -like "Processor*"}).Replace("Processor","").Trim()

		$Script:LogLevel--
		return [PSCustomObject]@{
			ComputerName  = $SdpComputerName
			Manufacturer  = ($msinfo32 | where{$_ -like "System Manufacturer*"}).Replace("System Manufacturer","").Trim()
			Model     = ($msinfo32 | where{$_ -like "System Model*"}).Replace("System Model","").Trim()
			SKU      = $msinfo32 | where{$_ -like "System SKU*"}|foreach {$_.Replace("System SKU","").Trim()} #For Win2008 R2 no SKU in msinfo32
			CPULine    = "$($CPUs.Count) x $(($CPUs[0] -replace ("(.*)@.*",'$1')).Trim())"
			BIOSVersion  = ($msinfo32 | where{$_ -like "BIOS Version/Date*"}).Replace("BIOS Version/Date","").Trim()
			PhysicalMemory = ($msinfo32 | where{$_ -like "Total Physical Memory*"}).Replace("Total Physical Memory","").Trim()
		}
	}
	function CreatePivotArrayFromAllPstat ($AllPStat){
		WriteInfo -message "Extracting Node computernames"
		$NodeNames = $AllPStat.ComputerName | Select-Object -Unique

		WriteInfo -message "Arranging in groups by SYS file name"
		$GroupedPStat = $AllPStat | Group-Object -Property Name

		WriteInfo -message "Creating Pivot array"
		$PStatPipedArray = foreach ($Group in $GroupedPStat){
			$Object = [PSCustomObject]@{
				Name    = $Group.Name
				Company   = $Group.Group[0].Company
				Description = $Group.Group[0].Description
				Mismatch  = $null
			}
			foreach($Node in $NodeNames){
				$entry = $Group.Group | Where-Object {$_.ComputerName -eq $Node}
				if($entry) { $Object | Add-Member -Name $Node -MemberType NoteProperty -Value "$($entry.Version) - $($entry.Date)" }
				else {$Object | Add-Member -Name $Node -MemberType NoteProperty -Value " !Not Installed! "}
			}

			$Mismatch = (@( $NodeNames | ForEach-Object {$Object.$_} ) | Select-Object -Unique).count
			if($Mismatch -gt 1){$Object.Mismatch = "Mismatch"}

			$Object
		}

		return $PStatPipedArray
	}
	function AddPipesToTable ($Array, $Exception) {
		$Output = $Array
		$Properties = $Output | Get-Member -MemberType NoteProperty | Where-Object {$_.Name -ne $Exception}
		writeinfo -message "Will add ' | ' to all columns except $Exception"

		WriteInfo -message "Adding pipes"
		foreach ($Property in $Properties){
			$MaxLength = $Property.Name.Length
			$Output.($Property.Name) | ForEach-Object {
				if($_.Length -gt $MaxLength){$MaxLength = $_.Length}
			}

			$Output | Foreach-Object {
				if($_.($Property.Name).Length -lt $MaxLength){
					$Spaces = " " * ($MaxLength - $_.($Property.Name).Length)
					$_.($Property.Name) += $Spaces
				}
				$_.($Property.Name) += " |"
			}
		}
		return $Output
	}
	function GenerateTextOutput ($PStatPipedArray,$MSInfo32Table,$NodeNames){
		$text = "PStat and MSInfo summary - Date $(Get-Date)`r`n`r`n"

		if($MSinfo32Table){
			WriteInfo -message "Adding heading: Mismatches"
			$text += @"
=== Hardware summary from msinfo32 files.

"@
    $text+= $MSinfo32Table | Format-Table | Out-String -Width 999
  }
  WriteInfo -message "Adding heading: Mismatches"

  $text += @"
=== Compared summary of !PStatSum files. Dated $(Get-Date)

Mismatching modules/drivers
============================
The following table shows modules/drivers where the version do NOT MATCH between nodes, or is missing on one or more nodes.
Ideally we want to see all cluster nodes sharing the same version.`n

"@
  WriteInfo -message "Adding table: Mismatches"
  $Props = "Name","Company"
  $NodeNames | ForEach-Object {$Props += $_}
  $Props += "Description"
  $text += $PStatPipedArray |Where-Object {$_.Mismatch -like "*Mismatch*"}| Sort-Object Company,Name | Format-Table -Property $Props |Out-String -Width 999

  WriteInfo -message "Adding heading: Non-Microsoft modules"
  $text += @"
Non-Microsoft modules/drivers
==============================
The following list shows modules that are IDENTICAL on all nodes.
Review the versions and dates that might require reaching vendor for latest update.

"@
  WriteInfo -message "Adding table: Non-Microsoft modules"
  $text += $PStatPipedArray |Where-Object {$_.Mismatch -notlike "*Mismatch*" -and $_.Company -notlike "*Microsoft*"}| Sort-Object Company,Name `
            | Select-Object Name,Company,@{L="Version";e={$_."$($NodeNames[0])"}},Description| Format-Table |Out-String -Width 999

  WriteInfo -message "Adding heading: Microsoft modules"
  $text += @"
Microsoft modules/drivers
===========================
The following list shows modules/drivers that are IDENTICAL on all nodes.
Windows updates should be used to obtain latest versions.

"@
  WriteInfo -message "Adding table: Microsoft modules"
  $text += $PStatPipedArray |Where-Object {$_.Mismatch -notlike "*Mismatch*" -and $_.Company -like "*Microsoft*"}| Sort-Object Company,Name `
            | Select-Object Name,Company,@{L="Version";e={$_."$($NodeNames[0])"}},Description| Format-Table |Out-String -Width 999

  $text += "Version $script:VerMa.$script:VerMi - Send feedback to v-waalmo@microsoft.com"
  return $text
	}
#endregion: Script Functions
} #end BEGIN


PROCESS {
  try {
	$ScriptBeginTimeStamp = Get-Date

	#region: MAIN :::::

	WriteInfo -message "Starting 'Compare-PStatSummary.ps1' on $(Get-Date)"

	try{
		#region: Find !PStatSum files
		WriteInfo -message "ENTER: Find !PStatSum files"
		$LogLevel++

			$RootFolder = Get-Item -Path $SDPPath

			$ComparisonFileFullName = "$RootFolder\!PStat_Sum_Compared_V2.txt"
			#if (Test-Path -Path $ComparisonFileFullName){
			#  Throw "$ComparisonFileFullName already exists"
			#	}

			WriteInfo "Looking for !PStatSum Files under $RootFolder"
			$PStatSumFiles = Get-ChildItem -Path $RootFolder -Filter "!PStatSum_*.TXT" -Recurse

			if($PStatSumFiles.count -gt 1){
				WriteInfo -message "Found $($PStatSumFiles.Count) files:" -AdditionalStringArray $PStatSumFiles.Name
			}
			else{
				Throw "Found $($PStatSumFiles.Count) file(s) only, cannot perform comparison.`r`nMake sure there are at least two !PStatSum_*.TXT files"
			}

		$LogLevel--
		WriteInfo -message "Exit: Find !PStatSum files"
		#endregion: Find !PStatSum files

		#region: Import PStatSum from each node
		WriteInfo -message "ENTER: Import PStatSum for each node"
		$LogLevel++

			$AllPStat = $PStatSumFiles | ForEach-Object {ImportPStatSum -File $_}

		$LogLevel--
		WriteInfo -message "Exit: Import PStatSum from each node"
		#endregion: Import PStatSum from each node

		#region: Find msinfo32 files
		WriteInfo -message "ENTER: Find msinfo32 files"
		$LogLevel++

			WriteInfo "Looking for msinfo32 Files under $RootFolder"
			$msinfo32Files = Get-ChildItem -Path $RootFolder -Filter "*_msinfo32.TXT" -Recurse

			if($msinfo32Files.count -gt 0){
				WriteInfo -message "Found $($msinfo32Files.Count) files:" -AdditionalStringArray $msinfo32Files.Name
				$DoHardwareComparison = $true
			}
			else{
				WriteError "Did not find any msinfo32 files, will skip hardware information."
				$DoHardwareComparison = $false
			}

		$LogLevel--
		WriteInfo -message "Exit: Find msinfo32 files"
		#endregion: Find msinfo32 files

		if($DoHardwareComparison){
			#region: Import msinfo32 files
			WriteInfo -message "ENTER: Import msinfo32 files"
			$LogLevel++

				$Allmsinfo32 = $msinfo32Files | ForEach-Object {ImportMSinfo32 -File $_} | Sort-Object $SdpComputerName

			$LogLevel--
			WriteInfo -message "Exit: Import msinfo32 files"
			#endregion: Import msinfo32 files
		}

		#region: Create PStat Summary Pivot table
		WriteInfo -message "ENTER: Create PStat Summary Pivot table"
		$LogLevel++

			$PStatPivotArray = CreatePivotArrayFromAllPstat -AllPStat $AllPStat

		$LogLevel--
		WriteInfo -message "Exit: Create PStat Summary Pivot table"
		#endregion: Create PStat Summary Pivot table

		#region: Generate Text Output
		WriteInfo -message "ENTER: Generate Text Output"
		$LogLevel++

			WriteInfo -message "Add pipes to tables"
			$PStatPipedArray = AddPipesToTable -Array $PStatPivotArray -Exception "Description"
			if($DoHardwareComparison){
				$MSinfo32Table = AddPipesToTable -Array $Allmsinfo32 -Exception "PhysicalMemory"
				$Splatting = @{
					MSInfo32Table = $MSinfo32Table
				}
			}

			WriteInfo -message "Generate text output"
			$NodeNames = $AllPStat.ComputerName | Select-Object -Unique
			$Output = GenerateTextOutput -PStatPipedArray $PStatPipedArray -NodeNames $NodeNames @Splatting

			WriteInfo -message "Saving file" -WaitForResult
			$Output | Out-File -FilePath $ComparisonFileFullName
				WriteResult -Success -message $ComparisonFileFullName

			If (($Global:OpenSummary) -or ($OpenSummary)) {
				#WriteInfo -message "Opening file in Notepad.exe"
				#Start-Process -FilePath "Notepad.exe" -ArgumentList $ComparisonFileFullName
				WriteInfo -message "... open output comparison file with FavEditor"
				Invoke-Item $ComparisonFileFullName
			}

		$LogLevel--
		WriteInfo -message "Exit: Generate Text Output"
		#endregion: Generate Text Output
	}
	catch{
		WriteError -message "An Error occured"
		WriteError -message $error[0].Exception.Message
		$ErrorThrown = $true
	}
	finally{
		#if($ErrorThrown) {Throw $error[0].Exception.Message}
	}
	#endregion: MAIN

	} # end try PROCESS
	catch {
		$errorMessage = "$scriptName caught an exception on $($ENV:COMPUTERNAME):"
		$errorMessage += "`n`n"
		$errorMessage += "Exception Type: $($_.Exception.GetType().FullName)"
		$errorMessage += "`n`n"
		$errorMessage += "Exception Message: $($_.Exception.Message)"

		Write-Error $errorMessage -ErrorAction Continue
		<# Log error
				Write-Verbose "Logging the script's error..."
		# Log error - EventLog
				#An event log source needs to be preconfigured to use this.
				Write-EventLog `
					-EventId $AlertNumber `
					-LogName $LogName `
					-Source $EventSource `
					-Message $errorMessage `
					-EntryType Error
		# Log error - Email
				# This will attempt to send an immediate alert about the error.
				# The EventLog also needs to log the error because this one may not be sent.
				#use Send-MailMessage
		#>
		Start-Sleep -Seconds 3
		Write-Debug $errorMessage
		if ( $UseExitCode ) {
			$error.clear()	# clear script errors
			exit 1
		} #end UseExitCode
  } #end Catch PROCESS
	Finally {
	} #end Finally PROCESS
} #end PROCESS


END {
	$ScriptEndTimeStamp = Get-Date
	$Duration = $(New-TimeSpan -Start $ScriptBeginTimeStamp -End $ScriptEndTimeStamp)
	$LogLevel = 0
	WriteInfo -message "Script $scriptName v$verDateScript execution finished. Duration: $Duration `n"
	# inform user about error in case of no $hostmode
	if($ErrorThrown) {Throw $error[0].Exception.Message}
	# Stats
	If ($Stats) { #increment at start of script
	 "$j; $CheckDate; $OSVersion; $UserName; $Duration; $NodeCnt; $SDPPath; $ErrorMsg; v$verDateScript " | Out-File $CountInvFil2 -Append -Encoding UTF8 -ErrorAction SilentlyContinue
	 }
  # This resets the ErrorActionPreference to the value at script start.
  $errorActionPreference = $startErrorActionPreference
} #end END

#region: comments
<#
	The top section is comment based help so the Get-Help command will work with the script.
	The [CmdletBinding()] turns on advanced options like the common parameters.
	All sub functions are in the "BEGIN" section.
	My script code goes in the "PROCESS try" block.

VERSION and AUTHOR:
    Ver 1.00; 2019-02-01
    Willy Moselhy (IBS) <v-waalmo@microsoft.com>

HISTORY
	2019-01-03	v1.02
	2019-02-11	v2.00 addes a hardware summary extracted from msinfo32.txt file on each cluster node
    2019-03-01: Added logic to handle missing SKU in msinfo32 in 2008 R2
        Added logic to set $ErrorThrown to $false while starting the script
	2022-09-08 using Utils_RflShared.psm1 library

	ToDo:
#>
#endregion: comments


# SIG # Begin signature block
# MIInlQYJKoZIhvcNAQcCoIInhjCCJ4ICAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAh8eC9S0m6GIu6
# LhtBTwdTNv2BO367ePfZou/J40K6C6CCDXYwggX0MIID3KADAgECAhMzAAACy7d1
# OfsCcUI2AAAAAALLMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjIwNTEyMjA0NTU5WhcNMjMwNTExMjA0NTU5WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC3sN0WcdGpGXPZIb5iNfFB0xZ8rnJvYnxD6Uf2BHXglpbTEfoe+mO//oLWkRxA
# wppditsSVOD0oglKbtnh9Wp2DARLcxbGaW4YanOWSB1LyLRpHnnQ5POlh2U5trg4
# 3gQjvlNZlQB3lL+zrPtbNvMA7E0Wkmo+Z6YFnsf7aek+KGzaGboAeFO4uKZjQXY5
# RmMzE70Bwaz7hvA05jDURdRKH0i/1yK96TDuP7JyRFLOvA3UXNWz00R9w7ppMDcN
# lXtrmbPigv3xE9FfpfmJRtiOZQKd73K72Wujmj6/Su3+DBTpOq7NgdntW2lJfX3X
# a6oe4F9Pk9xRhkwHsk7Ju9E/AgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUrg/nt/gj+BBLd1jZWYhok7v5/w4w
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzQ3MDUyODAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAJL5t6pVjIRlQ8j4dAFJ
# ZnMke3rRHeQDOPFxswM47HRvgQa2E1jea2aYiMk1WmdqWnYw1bal4IzRlSVf4czf
# zx2vjOIOiaGllW2ByHkfKApngOzJmAQ8F15xSHPRvNMmvpC3PFLvKMf3y5SyPJxh
# 922TTq0q5epJv1SgZDWlUlHL/Ex1nX8kzBRhHvc6D6F5la+oAO4A3o/ZC05OOgm4
# EJxZP9MqUi5iid2dw4Jg/HvtDpCcLj1GLIhCDaebKegajCJlMhhxnDXrGFLJfX8j
# 7k7LUvrZDsQniJZ3D66K+3SZTLhvwK7dMGVFuUUJUfDifrlCTjKG9mxsPDllfyck
# 4zGnRZv8Jw9RgE1zAghnU14L0vVUNOzi/4bE7wIsiRyIcCcVoXRneBA3n/frLXvd
# jDsbb2lpGu78+s1zbO5N0bhHWq4j5WMutrspBxEhqG2PSBjC5Ypi+jhtfu3+x76N
# mBvsyKuxx9+Hm/ALnlzKxr4KyMR3/z4IRMzA1QyppNk65Ui+jB14g+w4vole33M1
# pVqVckrmSebUkmjnCshCiH12IFgHZF7gRwE4YZrJ7QjxZeoZqHaKsQLRMp653beB
# fHfeva9zJPhBSdVcCW7x9q0c2HVPLJHX9YCUU714I+qtLpDGrdbZxD9mikPqL/To
# /1lDZ0ch8FtePhME7houuoPcMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGXUwghlxAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAALLt3U5+wJxQjYAAAAAAsswDQYJYIZIAWUDBAIB
# BQCggbAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEINjdbc3MQt1//9Eibbp56LPV
# 0z+I2lQnwDlcavlw/t1hMEQGCisGAQQBgjcCAQwxNjA0oBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEcgBpodHRwczovL3d3dy5taWNyb3NvZnQuY29tIDANBgkqhkiG9w0B
# AQEFAASCAQABe1nrFmlHKLFrciy21nuLvlufz/irrvZw08BkwCdMfaihYnDA1VCZ
# OyWuiGHK/r9qXkstvj1E80Xbv+IEgpmHo17x/qHjuHa+VptW0XM0uMevULEsenaB
# wm3G1KWIfFoWuQommC9EMwkRK6lDaOrZX2wRe3eVN+MA0mJbuGsoH0GyyXWxrC+a
# jq5GaEqiOGSKYESKR50EEuxfWIlGupWYWlxZlhg5DEaEpRdz9wl7sXh2qnDmHuCB
# WjnU9CAujRqOATS+9kqGedJxDTWGdouLfpl7plepgbFd6Po6c9hUt7cJd/n6QCTO
# awImK22YunGYYfd6sf9qjnAbiwRiomPWoYIW/TCCFvkGCisGAQQBgjcDAwExghbp
# MIIW5QYJKoZIhvcNAQcCoIIW1jCCFtICAQMxDzANBglghkgBZQMEAgEFADCCAVEG
# CyqGSIb3DQEJEAEEoIIBQASCATwwggE4AgEBBgorBgEEAYRZCgMBMDEwDQYJYIZI
# AWUDBAIBBQAEIOspCqqVN+7CctcMkUecCn2P3kdy+e9dFRNbVgqX0xQ6AgZjEWUr
# 7q8YEzIwMjIwOTEyMTM0MDIzLjU4OFowBIACAfSggdCkgc0wgcoxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBB
# bWVyaWNhIE9wZXJhdGlvbnMxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjhBODIt
# RTM0Ri05RERBMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNl
# oIIRVDCCBwwwggT0oAMCAQICEzMAAAGZyI+vrbZ9vosAAQAAAZkwDQYJKoZIhvcN
# AQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQG
# A1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjExMjAyMTkw
# NTE2WhcNMjMwMjI4MTkwNTE2WjCByjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldh
# c2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBD
# b3Jwb3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0aW9u
# czEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046OEE4Mi1FMzRGLTlEREExJTAjBgNV
# BAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQC4E/lXXKMsy9rVa2a8bRb0Ar/Pj4+bKiAgMgKayvCM
# Fn3ddGof8eWFgJWp5JdKjWjrnmW1r9tHpcP2kFpjXp2Udrj55jt5NYi1MERcoIo+
# E29XuCwFAMJftGdvsWea/OTQPIFsZEWqEteXdRncyVwct5xFzBIC1JWCdmfc7R59
# RMIyvgWjIz8356mweowkOstN1fe53KIJ8flrYILIQWsNRMOT3znAGwIb9kyL54C6
# jZjFxOSusGYmVQ+Gr/qZQELw1ipx9s5jNP1LSpOpfTEBFu+y9KLNBmMBARkSPpTF
# kGEyGSwGGgSdOi6BU6FPK+6urZ830jrRemK4JkIJ9tQhlGcIhAjhcqZStn+38lRj
# VvrfbBI5EpI2NwlVIK2ibGW7sWeTAz/yNPNISUbQhGAJse/OgGj/1qz/Ha9mqfYZ
# 8BHchNxn08nWkqyrjrKicQyxuD8mCatTrVSbOJYfQyZdHR9a4vgyGeZEXBYQNAlI
# uB37QCOAgs/VeDU8M4dc/IlrTyC0uV1SS4Gk8zV+5X5eRu+XORN8FWqzI6k/9y6c
# WwOWMK6aUN1XqLcaF/sm9rX84eKW2lhDc3C31WLjp8UOfOHZfPuyy54xfilnhhCP
# y4QKJ9jggoqqeeEhCEfgDYjy+PByV/e5HDB2xHdtlL93wltAkI3aCxo84kVPBCa0
# OwIDAQABo4IBNjCCATIwHQYDVR0OBBYEFI26Vrg+nGWvrvIh0dQPEonENR0QMB8G
# A1UdIwQYMBaAFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMF8GA1UdHwRYMFYwVKBSoFCG
# Tmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY3Jvc29mdCUy
# MFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEpLmNybDBsBggrBgEFBQcBAQRgMF4w
# XAYIKwYBBQUHMAKGUGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY2Vy
# dHMvTWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3J0MAwG
# A1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZIhvcNAQELBQAD
# ggIBAHGzWh29ibBNro3ns8E3EOHGsLB1Gzk90SFYUKBilIu4jDbR7qbvXNd8nnl/
# z5D9LKgw3T81jqy5tMiWp+p4jYBBk3PRx1ySqLUfhF5ZMWolRzW+cQZGXV38iSmd
# AUG0CpR5x1rMdPIrTczVUFsOYGqmkoUQ/dRiVL4iAXJLCNTj4x3YwIQcCPt0ijJV
# inPIMAYzA8f99BbeiskyI0BHGAd0kGUX2I2/puYnlyS8toBnANjh21xgvEuaZ2dv
# RqvWk/i1XIlO67au/XCeMTvXhPOIUmq80U32Tifw3SSiBKTyir7moWH1i7H2q5QA
# nrBxuyy//ZsDfARDV/Atmj5jr6ATfRHDdUanQpeoBS+iylNU6RARu8g+TMCu/Znd
# Zmrs9w+8galUIGg+GmlNk07fXJ58Oc+qFqgNAsNkMi+dSzKkWGA4/klJFn0XichX
# L8+t7KOayXKGzQja6CdtCjisnyS8hbv4PKhaeMtf68wJWKKOs0tt2AJfYC5vSbH9
# ck8BGj2e/yQXEZEu88L5/fHK5XUk/IKXx3zaLkxXTSZ43Ea/WKXVBzMasHZ3Pmny
# 0moEekAXx1UhLNNYv4Vum33VirxSB6r/GKQxFSHu7yFfrWQpYyyDH119TmhAedS8
# T1VabqdtO5ZP2E14TK82Vyxy3xEPelOo4dRIlhm7XY6k9B68MIIHcTCCBVmgAwIB
# AgITMwAAABXF52ueAptJmQAAAAAAFTANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0
# IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTAwHhcNMjEwOTMwMTgyMjI1
# WhcNMzAwOTMwMTgzMjI1WjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGlu
# Z3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBv
# cmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCC
# AiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAOThpkzntHIhC3miy9ckeb0O
# 1YLT/e6cBwfSqWxOdcjKNVf2AX9sSuDivbk+F2Az/1xPx2b3lVNxWuJ+Slr+uDZn
# hUYjDLWNE893MsAQGOhgfWpSg0S3po5GawcU88V29YZQ3MFEyHFcUTE3oAo4bo3t
# 1w/YJlN8OWECesSq/XJprx2rrPY2vjUmZNqYO7oaezOtgFt+jBAcnVL+tuhiJdxq
# D89d9P6OU8/W7IVWTe/dvI2k45GPsjksUZzpcGkNyjYtcI4xyDUoveO0hyTD4MmP
# frVUj9z6BVWYbWg7mka97aSueik3rMvrg0XnRm7KMtXAhjBcTyziYrLNueKNiOSW
# rAFKu75xqRdbZ2De+JKRHh09/SDPc31BmkZ1zcRfNN0Sidb9pSB9fvzZnkXftnIv
# 231fgLrbqn427DZM9ituqBJR6L8FA6PRc6ZNN3SUHDSCD/AQ8rdHGO2n6Jl8P0zb
# r17C89XYcz1DTsEzOUyOArxCaC4Q6oRRRuLRvWoYWmEBc8pnol7XKHYC4jMYcten
# IPDC+hIK12NvDMk2ZItboKaDIV1fMHSRlJTYuVD5C4lh8zYGNRiER9vcG9H9stQc
# xWv2XFJRXRLbJbqvUAV6bMURHXLvjflSxIUXk8A8FdsaN8cIFRg/eKtFtvUeh17a
# j54WcmnGrnu3tz5q4i6tAgMBAAGjggHdMIIB2TASBgkrBgEEAYI3FQEEBQIDAQAB
# MCMGCSsGAQQBgjcVAgQWBBQqp1L+ZMSavoKRPEY1Kc8Q/y8E7jAdBgNVHQ4EFgQU
# n6cVXQBeYl2D9OXSZacbUzUZ6XIwXAYDVR0gBFUwUzBRBgwrBgEEAYI3TIN9AQEw
# QTA/BggrBgEFBQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9E
# b2NzL1JlcG9zaXRvcnkuaHRtMBMGA1UdJQQMMAoGCCsGAQUFBwMIMBkGCSsGAQQB
# gjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/
# MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1UdHwRPME0wS6BJ
# oEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01p
# Y1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYB
# BQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljUm9v
# Q2VyQXV0XzIwMTAtMDYtMjMuY3J0MA0GCSqGSIb3DQEBCwUAA4ICAQCdVX38Kq3h
# LB9nATEkW+Geckv8qW/qXBS2Pk5HZHixBpOXPTEztTnXwnE2P9pkbHzQdTltuw8x
# 5MKP+2zRoZQYIu7pZmc6U03dmLq2HnjYNi6cqYJWAAOwBb6J6Gngugnue99qb74p
# y27YP0h1AdkY3m2CDPVtI1TkeFN1JFe53Z/zjj3G82jfZfakVqr3lbYoVSfQJL1A
# oL8ZthISEV09J+BAljis9/kpicO8F7BUhUKz/AyeixmJ5/ALaoHCgRlCGVJ1ijbC
# HcNhcy4sa3tuPywJeBTpkbKpW99Jo3QMvOyRgNI95ko+ZjtPu4b6MhrZlvSP9pEB
# 9s7GdP32THJvEKt1MMU0sHrYUP4KWN1APMdUbZ1jdEgssU5HLcEUBHG/ZPkkvnNt
# yo4JvbMBV0lUZNlz138eW0QBjloZkWsNn6Qo3GcZKCS6OEuabvshVGtqRRFHqfG3
# rsjoiV5PndLQTHa1V1QJsWkBRH58oWFsc/4Ku+xBZj1p/cvBQUl+fpO+y/g75LcV
# v7TOPqUxUYS8vwLBgqJ7Fx0ViY1w/ue10CgaiQuPNtq6TPmb/wrpNPgkNWcr4A24
# 5oyZ1uEi6vAnQj0llOZ0dFtq0Z4+7X6gMTN9vMvpe784cETRkPHIqzqKOghif9lw
# Y1NNje6CbaUFEMFxBmoQtB1VM1izoXBm8qGCAsswggI0AgEBMIH4oYHQpIHNMIHK
# MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQLExxN
# aWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25zMSYwJAYDVQQLEx1UaGFsZXMgVFNT
# IEVTTjo4QTgyLUUzNEYtOUREQTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3Rh
# bXAgU2VydmljZaIjCgEBMAcGBSsOAwIaAxUAku/zYujnqapN6BJ9MJ5jtgDrlOug
# gYMwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYw
# JAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0B
# AQUFAAIFAObJEn8wIhgPMjAyMjA5MTIxMDA1NTFaGA8yMDIyMDkxMzEwMDU1MVow
# dDA6BgorBgEEAYRZCgQBMSwwKjAKAgUA5skSfwIBADAHAgEAAgIhxjAHAgEAAgIR
# /TAKAgUA5spj/wIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAow
# CAIBAAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBAJVz+G1MXrC3
# CNphk2BQBY45FhNj3qUMhq7aDYLDsHwMJ8eJf1nrGbpTJpkex3HPYwKoR0zi58pS
# RV7xCFN5i8UN/dQKOAyf2BxDP3KpU1VnBQb1R+1ph6x2gDXF1mtFzdryLxOatTQc
# C9wRnm+VDpu2iteVfGx1R874zoUh40LIMYIEDTCCBAkCAQEwgZMwfDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAGZyI+vrbZ9vosAAQAAAZkwDQYJYIZI
# AWUDBAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG
# 9w0BCQQxIgQgPadgEo2UISmeha2VnjeGoD43AdXz3gv8B7Xtt4AcfM0wgfoGCyqG
# SIb3DQEJEAIvMYHqMIHnMIHkMIG9BCBmfWn58qKN7WWpBTYOrUO1BSCSnKPLC/G7
# wCOIc2JsfjCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMz
# AAABmciPr622fb6LAAEAAAGZMCIEIBGbTn/SNzaeMYaWBTbJ30SQWMthzrnXoy0f
# u5aVCNtsMA0GCSqGSIb3DQEBCwUABIICAIloKmNlvcASRVzkmXw8MjVJM3QuCdv9
# joCIk56FkewJH+ut/KXiHkhB0JskqPwVL4oI8L7WJBo/ZAvXxhJDaE/A566vJmni
# kwmmTLAaskWU918LjYBbBHLkhOqMCFDA/lnU4RN/rmXOG0snHMPRJsE5G1Xwfvld
# 0VUXS9SgLO+MS5TP+HqDPClaH5aeS8jHLLgKONyNu4ELs5UEs+S++zu6w68GOVxu
# AXY6Dkb/N7X7/3sB6qqdKQII2DrjFfVchGE6tgMpidN5lblfvHjvwOfxHJeEjm2C
# UfBGbx3IyEAGfZpkQhkWRdDjQqCY2/6Pgx+V17l66yrfAbE93BouH/NJ4n+uJ9Ee
# wNxzEPfhfC4AX2nBv+jIMm3PLVC0R0WcZvpSWNJ4nqKz7TCmW/tzbEGJ2+5IBBSn
# 0T6NQ0MjLomq4Ee3WBaA0++BcvGXg7HU9yW+Uy1CyhWA88mlmMFy0f6wFxEW+PVs
# 8Rt1Q00s4p95hsPgkFbzw1F7Z1GmCWBqAHC5tGbpCmx+GFXf33dbT+2wIFcwY4M7
# bH6Z6rAXhYt8J5+m0VAFaxNx+nSsJigUPg7YNeaQR9mQNcGzlLszT/nQcM4DH3hM
# CWCxvAnQ9oGXOelcJ1YIIY8BvZWYEmob0c2Yeta2MKc57EUqGp2m/SOhHSuq/Byn
# SjSnqEBRg+Ew
# SIG # End signature block
