<# last edit by: waltere 2023-01-04
  File Name: get-DNSqueries.ps1 - KB5022810 DNS performance: how to review the top consuming queries in a packet capture
  Objective: This script is intended to provide a summary of top DNS queries in a pcap network trace, by leveraging Wireshark Tshark.exe and Log Parser 2.2
  Help: get-help \\emeacssdfs\netpod\rfl\get-DNSqueries.ps1 -detailed

VERSION and AUTHORs:
    Ver 1.00 
	Walter Eder	- waltere@microsoft.com (this PS script)

Details are found in internal KB 5022810 DNS performance: how to review the top consuming queries in a packet capture https://internal.evergreen.microsoft.com/en-us/topic/8e480846-e780-2519-7fb5-f6b3d68fe62c

HISTORY
	2023-01-04 v1.00 created get-DNSqueries.ps1 
#>

<#
.SYNOPSIS
  There are scenarios where we need the statistics of the incoming DNS queries in a packet capture, however this can be a slow task if it is done manually. Below are the steps found by EE Tony Gaston to automate the analysis of the packet capture using tshark.exe
The script  
	- converts a given network trace (pcap format) with Tshark.exe into output tsv file, 
	- inserts a first line with content: 'Query-name' into output tsv file
	- runs LogParser.exe to count each occurrence
	- displays result file in your favorite TXT Editor
	
PreRequisites: Installation of tools with default location
- install Wireshark (C:\Program Files\Wireshark\tshark.exe)
- install Log Parser 2.2(C:\Program Files (x86)\Log Parser 2.2\LogParser.exe)

SYNTAX: .\get-DNSqueries.ps1 [full-path-to-folder-with-pcap]

.DESCRIPTION
The script reads in the *_packetcapture*.pcap* file(s) from given folder and displays/provides a summary of top DNS queries in a pcap network trace
Note: make sure WireShark and LogParser is installed before running this script.


If you experience PS error '...is not digitally signed.' run the command:
 Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned

.PARAMETER OpenSummary
 This switch will not open resulting summary file with Notepad/Favorite Editor if set to $False
 
.EXAMPLE
\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\get-DNSqueries.ps1 \\waltere\temp\New_RFL\SDPs\DNSServer

.LINK
\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\get-DNSqueries.ps1
waltere@microsoft.com

#>

[CmdletBinding()]
PARAM (
	[ValidateScript({Test-Path $_ -PathType 'Container'})]
	[Parameter(Mandatory = $true,Position=0,HelpMessage='Choose the .pcap* folder location, i.e. C:\SR\TSS-Data-folder\ ')]
	[string]$FolderPath,			# Path to folder containing *.pcap* files
	[switch]$HostMode  = $true, 	# This tells the logging functions to show logging on the screen
	[switch]$ScriptMode = $false,	# This tells the logging functions to show logging in log file _get-DNSqueries.log
	[switch]$OpenSummary= $true		# open with Notepad/FavEditor
)

BEGIN {
	$verDateScript = "2023.01.04.0"
	$ScriptFolder = Split-Path $MyInvocation.MyCommand.Path -Parent
	# Load Common Library:
	. $ScriptFolder\Utils_RflShared.ps1

  # This saves the starting ErrorActionPreference and then sets it to 'Stop'.
	$startErrorActionPreference = $errorActionPreference
	$errorActionPreference = 'Stop'
  # This gets the current path and name of the script.
	$invocation = (Get-Variable MyInvocation).Value
	#$scriptPath = Split-Path $invocation.MyCommand.Path
	$scriptName = $invocation.MyCommand.Name
  #Write-Host "Running `"$scriptPath\$scriptName`"..." -BackgroundColor Black -ForegroundColor Green

	Set-Variable -Name ErrorMsg -Scope Script -Force
	[string]$Script:ErrorMsg=""
	### Trail FolderPath with \ and allow path with space character
		if ($FolderPath.EndsWith("\")){$FolderPath="$FolderPath"}
		else {$FolderPath="$FolderPath" +"\"}
		If (-NOT (Test-Path $FolderPath -PathType 'Container')){Throw "$($FolderPath) is not a valid folder"}

#region: ###### customization section of script, logging configuration ########################
	$SDPcheckINI = (Get-content -Path "$ScriptFolder\_SDPcheck.ini")
	$InOfflineMode 	= (($SDPcheckINI[1] -split " ")[2]).trim("""")	# set $True for outsourcer or when not connected to MS network - offline-SDPcheck
	$RFLroot = (($SDPcheckINI[2] -split " ")[2]).trim("""")	# "\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\" -or- "\\localhost\ToolsShare\rfl\"
	if ($InOfflineMode -match "False") {
		$RFLserver = "emea.europe.corp.microsoft.com"
		$StatsServer = (($SDPcheckINI[4] -split " ")[2]).trim("""")
		if (Test-Connection -ComputerName $StatsServer -Quiet -Count 1) {[bool]$Stats=$True} else {[bool]$Stats=$False}
	} else { 
		$RFLserver = "localhost"
		$Stats = $False
		Write-host "OfflineMode: $InOfflineMode"
	}
#endregion: ###### customization section

	$LogLevel = 0
	$CheckDate = (Get-Date).ToUniversalTime().ToString("yy-MM-dd_HH-mm-ss")
	##$LogPath = $FolderPath + "_" + $scriptName + ".log"
	$ErrorThrown = $null
	If ($Stats) {
		$StatsServerPath="\\$StatsServer\RFLstats$\RFL\scripts\Stats\"
		$CountInvFil = $StatsServerPath +'countDNS.dat'
		$CountInvFil2 = $CountInvFil +'.us'
		#increment at start of script
		 ($j=[int32](Get-Content $CountInvFil -TotalCount 1 -ErrorAction SilentlyContinue)) |out-null
		 (++$j) | Set-Content $CountInvFil -ErrorAction SilentlyContinue
	 }
	If ($PSBoundParameters['Debug']) { $DebugPreference='Continue'}
} #end BEGIN

PROCESS {
	function Set-FirstLine {
		param (
			[string]$FilePath,
			[string]$FirstLineContent
		)
		$oldContent = Get-Content $FilePath
		Set-Content -Path $FilePath -Value $FirstLineContent
		Add-Content -Path $FilePath -Value $oldContent
	}
	
	try {
		$ScriptBeginTimeStamp = Get-Date
		#region: MAIN :::::
		"`n$(Get-Date -UFormat "%R:%S") ==DNS performance==... runnning 'DNS performance: top consuming queries' based on .pcap* files in folder $FolderPath"
		# ToDo: allow more *.pcap* -or- Recurse subfolders?
		try {
			#$ListOfPcapFiles = Get-ChildItem -Path $FolderPath -File -Filter "*.pcap*"  -ErrorAction SilentlyContinue # -exclude *msdbg* #| ? { $_.Name -match "packetcapture|NetTrace|capture|NdisCap|sniff" }).FullName #_# get-childitem  -Recurse -Path ### -exclude *qryNames*
			$ListOfPcapFiles = Get-ChildItem -Path $FolderPath -File| Where-Object {$_.Extension -match "pcap*"}
			}
		catch [System.IO.IOException] {
			Write-Host "FAIL: errorRecord is: $error" # [System.IO.PathTooLongException]
			$ListOfPcapFiles = (Get-ChildItem -LiteralPath $FolderPath -File -Filter *.pcap*)
		}
		Write-Host -ForegroundColor Cyan "List of $($ListOfPcapFiles.count) .Pcap* files:"
		$ListOfPcapFiles
		
		#$PcapFiles = Get-Item -path ($FolderPath + "*.pcap*") # all *.pcap* files in given folder
		if ($ListOfPcapFiles.count -ge 1 ) {
			$NodeNames = foreach ($NodeName in $ListOfPcapFiles){($NodeName.name).split('_')[0]}
			Write-Host "$(Get-Date -UFormat "%R:%S") NodeName(s): $NodeNames"

			$NodeCnt=0
			foreach ($PcapFile in $ListOfPcapFiles){
				$ScripTaskStartTimeStamp = Get-Date
				$NodeCnt++
				Write-Host -BackgroundColor Blue -ForegroundColor Cyan -NoNewline -Object "$($NodeCnt) " -Separator .
				$NodeName = ($PcapFile.name).split('_')[0]
				if ($($NodeCnt) -lt 32) {
					if ($NodeNames.count -gt 1) {Write-Host "Node $NodeName $NodeCnt of $($NodeNames.count)"}
					$outFile = $FolderPath + ($PcapFile.name) + "_qryNames.tsv"
					$outDnsStats = $FolderPath + ($PcapFile.name) + "_qryNamesStats.txt"
					Write-Host  "$(Get-Date -UFormat "%R:%S") step#1: ... running tshark.exe .. Please be patient..."
					"   => Output .tsv file will be saved to: $outFile "
					Write-Verbose  "___Name: $PcapFile Fullname: $($PcapFile.Fullname)"
					& "C:\Program Files\Wireshark\tshark.exe" -r $($PcapFile.Fullname) -Y "dns.count.answers > 0" -T fields -e dns.qry.name > $outFile
					#& $RFLroot\tshark.exe -r $($PcapFile.Fullname) -Y "dns.count.answers > 0" -T fields -e dns.qry.name > $outFile
					Write-Host  "$(Get-Date -UFormat "%R:%S") step#2: ... adding header line 'Query-name' to $outFile"
					Set-FirstLine -FilePath $outFile -FirstLineContent 'Query-name'
					Write-Host  "$(Get-Date -UFormat "%R:%S") step#3: ... processing DNS Query stats to $outDnsStats"
					#& "C:\Program Files (x86)\Log Parser 2.2\LogParser.exe" -I:TSV "Select Query-name,COUNT(*) as query-count from $outFile group by Query-name order by query-count desc" -headerRow:ON  -q:ON | Out-File $outDnsStats #-Append
					& $RFLroot\LogParser.exe -I:TSV "Select Query-name,COUNT(*) as query-count from $outFile group by Query-name order by query-count desc" -headerRow:ON  -q:ON | Out-File $outDnsStats #-Append
					Set-FirstLine -FilePath $outDnsStats -FirstLineContent 'Query-name                                                         | Query-Count'
				}
				else {Write-Host "$(Get-Date -UFormat "%R:%S") ...checked only first 32 nodes" }

				If (($Global:OpenSummary) -or ($OpenSummary)) {
					"`nUsing favorite editor to open 'DNS Query stats file'..."
					Invoke-Item $outDnsStats 
				}
				$ScripTasktEndTimeStamp = Get-Date
				$Duration = $(New-TimeSpan -Start $ScripTaskStartTimeStamp -End $ScripTasktEndTimeStamp)
				Write-Host -BackgroundColor Gray -ForegroundColor Black -Object "$(Get-Date -UFormat "%R:%S") Done: Trace $PcapFile took $Duration `n"
			}
		}
		else { Write-Host -BackgroundColor Black -ForegroundColor Red -Object "There is no *_packetcapture*.pcap* file in $FolderPath - Double-check folder path! Or convert *.etl first to .pcap format"
					$ErrorMsg += "No-Valid-Pcap " }
		#endregion: MAIN
	} # end try PROCESS
	catch {
		WriteError -message "An Error occured"
		WriteError -message $error[0].Exception.Message
		$ErrorThrown = $true

		$errorMessage = "$scriptName caught an exception on $($ENV:COMPUTERNAME):"
		$errorMessage += "`n`n"
		$errorMessage += "Exception Type: $($_.Exception.GetType().FullName)"
		$errorMessage += "`n`n"
		$errorMessage += "Exception Message: $($_.Exception.Message)"
		Write-Host "Possible explanation of: Exception Message: Could not find a part of the path ...
		There are too many nested folders, i.e. expanded psSDP folder. Solution: move the psSDP folder up one level."
		Write-Error $errorMessage -ErrorAction Continue
		Start-Sleep -Seconds 3
		Write-Debug $errorMessage
		if ($UseExitCode){
			$error.clear()	# clear script errors
			exit 1
		} #end UseExitCode
	} #end Catch PROCESS
	Finally {
	}
} #end PROCESS

END {
	$ScriptEndTimeStamp = Get-Date
	$Duration = $(New-TimeSpan -Start $ScriptBeginTimeStamp -End $ScriptEndTimeStamp)
	$LogLevel = 0
	Write-Host -BackgroundColor Gray -ForegroundColor Black -Object "Script $scriptName v$verDateScript execution finished. Duration: $Duration"
	if($ErrorThrown) {Throw $error[0].Exception.Message
		}
	# Stats
	If ($Stats) { #increment at start of script
		"$j" + " ;$CheckDate" + "; " + ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name) + "; $($Duration)" + "; $NodeCnt" + "; $FolderPath" + "; $($ListOfPcapFiles.count); $ErrorMsg" + "; v$verDateScript" | Out-File $CountInvFil2 -Append -Encoding UTF8 -ErrorAction SilentlyContinue
	 }
  # This resets the ErrorActionPreference to the value at script start.
  $errorActionPreference = $startErrorActionPreference
} #end END


