<#
  File Name: Show-ClusterLogResourceMoveChart.ps1
  Objective: Draw cluster group movement Gantt chart using clusterlogs (Get-ClusterLog)
	supplied by Albert Lavrentev <v-allav@microsoft.com> - https://github.com/albertlav/Show-ClusterLogResourceMoveChart
  last edit by: waltere 2022-10-13
#>

<#
.SYNOPSIS
This script will draw cluster group movement Gantt chart using clusterlogs (Get-ClusterLog)

SYNTAX: .\Show-ClusterLogResourceMoveChart.ps1 -SDPPath [full-path-to-expanded-SDP-report]

.DESCRIPTION
The script will raw cluster group movement Gantt chart using clusterlogs (Get-ClusterLog)

Quick cluster resource placement overview from cluster logs (who was CSV coordinator, or where specific VM was placed at time Z, etc)
may be wrong if not all logs available, or not all logs consistent
unreliable for placement data before first move and after last move, charts -1 and +1 days for each resouce since first/last movement
chart is little bit interactive, can be zoomed in up to milliseconds scale, on NodeID axis – there is nodeIDs
It goes through 1 Gb of logs in 5-10 seconds on SSD, and caches parsed data in XML for reuse, so once logs parsed once it will not parse again by default
chart created based on “[RCM] move of group from to is about to succeed” events and may be inaccurate if not all logs from all nodes present

If you experience PS error '...is not digitally signed.' run the command:
 Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned

.EXAMPLE
\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\Show-ClusterLogResourceMoveChart -SDPPath \\MyPC\temp\SDPs\ClusterReports
Generate chart using *cluster.log files in SDP folder

.EXAMPLE
\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\Show-ClusterLogResourceMoveChart -SDPPath \\MyPC\temp\SDPs\ClusterReports -ForceRebuild
Force reparses and regenerates datasource even if _groupMovementData.xml exists. _groupMovementData.xml will be overwritten

.EXAMPLE
\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\Show-ClusterLogResourceMoveChart -SDPPath \\MyPC\temp\SDPs\ClusterReports -ClusterGroupsToChart "Available Storage", "Cluster Resources", "GROUP01"
Generate chart using *cluster.log files in SDP folder for "Available Storage", "Cluster Resources", "GROUP01" ClusterGroups only

.LINK
\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\Show-ClusterLogResourceMoveChart.ps1
v-allav@microsoft.com ; waltere@microsoft.com
 https://github.com/albertlav/Show-ClusterLogResourceMoveChart
#>
#>

[CmdletBinding()]
PARAM (
	[Parameter(Mandatory = $true,Position=0,HelpMessage='Choose a writable SDP folder location, i.e. C:\SR\SDP-report\ ')]
	[string]$SDPPath,			# Path to Cluster SDP result folder
	[switch]$HostMode  = $false, #This tells the logging functions to show logging on the screen
	[switch]$ScriptMode = $false #This tells the logging functions to show logging in log file _PStat_Sum_Compared.log
)

	$verDateScript = "2023.01.07.0"
	$ScriptFolder = Split-Path $MyInvocation.MyCommand.Path -Parent
	# Load Common Library:
	. $ScriptFolder\Utils_RflShared.ps1
	  
	### Trail SDPPath with \ and allow path with space character
	if ($SDPPath.EndsWith("\")){$SDPPath="$SDPPath"}
	else {$SDPPath="$SDPPath" +"\"}
	If (-NOT (Test-Path $SDPPath -PathType 'Container')){Throw "$($SDPPath) is not a valid folder"}

	$ScriptBeginTimeStamp = Get-Date

#region: ###### customization section of script, logging configuration ########################
	$SDPcheckINI = (Get-content -Path "$ScriptFolder\_SDPcheck.ini")
	$InOfflineMode 	= (($SDPcheckINI[1] -split " ")[2]).trim("""")	# set $True for outsourcer or when not connected to MS network - offline-SDPcheck
	if ($InOfflineMode -match "False") {
		$StatsServer = (($SDPcheckINI[4] -split " ")[2]).trim("""")
		if (Test-Connection -ComputerName $StatsServer -Quiet -Count 1) {[bool]$Stats=$True} else {[bool]$Stats=$False}
	} else { 
		$Stats = $False
	}
	$ErrorActionPreference = "Continue" #"Stop"
	$LogLevel = 0
	$CheckDate = (Get-Date).ToUniversalTime().ToString("yy-MM-dd_HH-mm-ss")
	if ($Stats) {
		$StatsServerPath="\\$StatsServer\RFLstats$\RFL\scripts\Stats\"
		$CountInvFil = $StatsServerPath +'countClResChart.dat'
		$CountInvFil2 = $CountInvFil +'.us'
		#increment at start of script
		 ($j=[int32](Get-Content $CountInvFil -TotalCount 1 -ErrorAction SilentlyContinue)) |out-null
		 (++$j) | Set-Content $CountInvFil -ErrorAction SilentlyContinue
	}	
	$LogPath = $SDPPath + "_ClusterLogResourceMoveChart.log"
	$ErrorThrown = $null
#endregion: ###### customization section

	Set-Variable -Name ErrorMsgPS -Scope Script -Force
	If ($PSBoundParameters['Debug']) { $DebugPreference='Continue'}

#region: Script Functions
function Show-ClusterLogResourceMoveChart {
	<#
	.Synopsis
	  Draw cluster group movement Gantt chart using clusterlogs (Get-ClusterLog)
	.DESCRIPTION
	  Draw cluster group movement Gantt chart using clusterlogs (Get-ClusterLog)
	  may be wrong if not all logs available, or not all logs consistent
	  unreliable for placement data before first move and after last move, charts -1 and +1 days for each resouce since first/last movement
	.EXAMPLE
	  Show-ClusterLogResourceMoveChart
	  Generate chart using *cluster.log files in current folder
	.EXAMPLE
	  Show-ClusterLogResourceMoveChart -Path c:\clusterlogs
	  Generate chart using *cluster.log files in c:\clusterlogs folder
	.EXAMPLE
	  Show-ClusterLogResourceMoveChart -Path c:\clusterlogs -ForceRebuild
	  Force reparses and regenerates datasource even if _groupMovementData.xml exists. _groupMovementData.xml will be overwritten
	.EXAMPLE
	  Show-ClusterLogResourceMoveChart -ClusterGroupsToChart "Available Storage", "Cluster Resources", "GROUP01"
	  Generate chart using *cluster.log files in current folder for "Available Storage", "Cluster Resources", "GROUP01" ClusterGroups only
	#>
  [CmdletBinding(DefaultParameterSetName = 'Parameter Set 1',
    SupportsShouldProcess = $true,
    PositionalBinding = $false,
    HelpUri = 'http://www.microsoft.com/',
    ConfirmImpact = 'Medium')]
  [Alias()]
  [OutputType([String])]
  Param
  (
    # Path to folder with clusterlogs
    [Parameter(
      ParameterSetName = 'Parameter Set 1')]
    [ValidateNotNull()]
    [ValidateNotNullOrEmpty()]
    $Path = ".",

    # Cluster Groups to Draw
    [Parameter(ParameterSetName = 'Parameter Set 1')]
    [String[]]
    [AllowNull()]
    [AllowEmptyCollection()]
    [AllowEmptyString()]
    $ClusterGroupsToChart = @(),

    # Force reprocess *cluster.log files even if _groupMovementData.xml exists. Existing file _groupMovementData.xml will be overwritten
    [Parameter(ParameterSetName = 'Parameter Set 1')]
    [switch] $ForceRebuild
  )

  Begin {
  }
  Process {
	function AddDataToChartAndRedraw () {
	#region Add data to chart
	$Chart.Series.Clear()
	$logselector="*"
	if ($DropDownLogs.SelectedIndex -ne 0) {$logselector=$DropDownLogs.SelectedItem}
	if ($DropDownGroups.SelectedIndex -ne 0) {$ClusterGroupsToChart=$DropDownGroups.SelectedItem}
	foreach ($keyGroup in $groupMovementData.Keys) {
	  if ($ClusterGroupsToChart.Contains($keyGroup) -or $ClusterGroupsToChart.Count -eq 0) {
	    [void]$Chart.Series.Add($keyGroup)
	    $Chart.Series["$keyGroup"].ChartType = [System.Windows.Forms.DataVisualization.Charting.SeriesChartType]::RangeBar;

	    #unreliable - before first move, chart 1 day before it
	    $Chart.Series[$keyGroup].Points.AddXY([int]$groupMovementData[$keyGroup][0][3].Split('()')[1], $groupMovementData[$keyGroup][0][0].AddDays(-1),$groupMovementData[$keyGroup][0][0])| Out-Null

	    for ($i = 0; $i -lt $groupMovementData[$keyGroup].count; $i++) {
	      if ($groupMovementData[$keyGroup][$i][2] -like $logselector) {
	        if ($i + 1 -ge $groupMovementData[$keyGroup].count) {
	          #unreliable - after last move, chart 1 days after it
	          $Chart.Series[$keyGroup].Points.AddXY([int]$groupMovementData[$keyGroup][$i][1].Split('()')[1], $groupMovementData[$keyGroup][$i][0], $groupMovementData[$keyGroup][$i][0].AddDays(1))| Out-Null
	        }
	        else {
	          $Chart.Series[$keyGroup].Points.AddXY([int]$groupMovementData[$keyGroup][$i][1].Split('()')[1], $groupMovementData[$keyGroup][$i][0], $groupMovementData[$keyGroup][$i + 1][0]) | Out-Null
	        }
	      }
	    }
       }
	}
      $Chart.Refresh()
	#endregion Add data to chart
    }

#region parse logs and build dataset, or reload if available
	$logfiles = Get-ChildItem -Path $Path -Filter *cluster.log
	if ((Test-Path "$Path\_groupMovementData.xml") -and !$ForceRebuild) {
	  $groupMovementData = Import-Clixml "$Path\_groupMovementData.xml"
	}
	else {
	  $groupMoveSeparators = @("::", " INFO  [RCM] move of group "," INFO [RCM] move of group ", " from ", " to ", " of type ", " is about to succeed")
      $groupMovementData = @{ }
      foreach ($logfile in $logfiles) {
        $logfile.Name
        $lineEnumerator = [System.IO.File]::ReadLines($logfile.FullName)
        foreach ($line in $lineEnumerator) {
          if ($line.Contains("[RCM] move of group") -and $line.Contains("is about to succeed")) {
            $data = $line.Split($groupMoveSeparators, 0)
            $timestamp = [datetime]::parseexact($data[1], 'yyyy/MM/dd-HH:mm:ss.fff', $null)
            $groupName = $data[2]
            $nodeFrom = $data[3]
            $nodeTo = $data[4]

            if (!$groupMovementData.ContainsKey($groupName)) {$groupMovementData.Add($groupName, $(New-Object System.Collections.ArrayList))}
            [void]$groupMovementData[$groupName].Add(@($timestamp, $nodeTo, $logfile.Name, $nodeFrom))
          }
        }
      }
      #sort resulting arraylists by timestamps
      [string[]]$keysTemp=$groupMovementData.Keys
      foreach ($key in $keysTemp){$groupMovementData[$key]=$groupMovementData[$key]|Sort-Object -Property {$_[0]}}
      $groupMovementData | Export-Clixml "$Path\_groupMovementData.xml" -Force
    }
#endregion parse logs

    [void][Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
    [void][Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms.DataVisualization")
    $Form = New-Object Windows.Forms.Form
    $Form.Text = "ClusterLog Chart"
    $Form.Width = 600
    $Form.Height = 600

#region drop down selectors
    $DropDownLogs = new-object System.Windows.Forms.ComboBox
    $DropDownLogs.Location = new-object System.Drawing.Size(40, 40)
    $DropDownLogs.Size = new-object System.Drawing.Size(330, 30)
    $DropDownLogs.Items.Add("All logs combined")
    $DropDownLogs.SelectedItem = $DropDownLogs.Items[0]
    $DropDownLogs.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Left
    ForEach ($Item in $logfiles) {
      [void] $DropDownLogs.Items.Add($Item)
    }
    $DropDownLogs.add_SelectedIndexChanged( {AddDataToChartAndRedraw})
    $Form.Controls.Add($DropDownLogs)

    $DropDownGroups = new-object System.Windows.Forms.ComboBox
    $DropDownGroups.Location = new-object System.Drawing.Size(40, 10)
    $DropDownGroups.Size = new-object System.Drawing.Size(330, 30)
    $DropDownGroups.Items.Add("All groups combined")
    $DropDownGroups.SelectedItem = $DropDownGroups.Items[0]
    $DropDownGroups.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Left
    ForEach ($Item in $groupMovementData.Keys) {
      [void] $DropDownGroups.Items.Add($Item)
    }
    $DropDownGroups.add_SelectedIndexChanged( {AddDataToChartAndRedraw})
    $Form.Controls.Add($DropDownGroups)
#endregion drop down selectors

#region Create Chart object and tune it
    # create chart object
    $Chart = New-object System.Windows.Forms.DataVisualization.Charting.Chart
    $Chart.Width = 500
    $Chart.Height = 400
    $Chart.Left = 40
    $Chart.Top = 80
    #$Chart.Cursor
    # create a chartarea to draw on and add to chart
    $ChartArea = New-Object System.Windows.Forms.DataVisualization.Charting.ChartArea
    $Legend = New-Object System.Windows.Forms.DataVisualization.Charting.Legend

    $ChartArea.CursorY.IsUserEnabled = $true
    $ChartArea.CursorY.IsUserSelectionEnabled = $true
    $ChartArea.CursorY.Autoscroll = $false
    $ChartArea.CursorX.IsUserEnabled = $true
    $ChartArea.CursorX.IsUserSelectionEnabled = $true
    $ChartArea.CursorX.Autoscroll = $false
    $ChartArea.CursorY.IntervalType = 9
    
    $Chart.add_CursorPositionChanged( { try {$tooltip.show("NodeID=$($ChartArea.CursorX.Position), Y=$([datetime]::FromOADate($ChartArea.CursorY.Position).ToString('yyyy/MM/dd-HH:mm:ss.fff'))", $chart, 0, 0)}catch{$tooltip.show("select point to show nodeID and time", $chart, 0, 0)} })
    #$ChartArea.AxisY.IntervalAutoMode = 1
    $ChartArea.AxisY.ScaleView.SmallScrollSizeType  = 8
    $ChartArea.AxisX.ScaleView.SmallScrollSize = 1
    $ChartArea.AxisY.ScaleView.SmallScrollSize = 1

    $ChartArea.AxisY.IntervalType = 9
    $ChartArea.AxisY.LabelStyle.Format = "yyyy/MM/dd-HH:mm:ss"
    $ChartArea.AxisX.Title = "NodeID"
    $ChartArea.AxisX.IsMarginVisible = $true
    $ChartArea.AxisX.LineWidth = 0

    $ChartArea.CursorY.IntervalType = 9
    $Legend.Title="Cluster Groups"
    $Legend.Enabled = $true
    $Chart.Legends.Add($Legend)
    $Chart.ChartAreas.Add($ChartArea)
#endregion  Create Chart object

    AddDataToChartAndRedraw

    # display the chart on a form
    $Chart.Anchor = [System.Windows.Forms.AnchorStyles]::Bottom -bor [System.Windows.Forms.AnchorStyles]::Right -bor
    [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Left
    $Form.Controls.Add($Chart)

    #region save button
    $SaveFileDialog = New-Object Windows.Forms.SaveFileDialog
    $SaveFileDialog.initialDirectory = $env:HOMEDRIVE+$env:HOMEPATH
    $SaveFileDialog.title = "Save current graph to disk"
    $SaveFileDialog.filter = "PNG files|*.PNG"

    $SaveButton = New-Object Windows.Forms.Button
    $SaveButton.Text = "Save Current View to File"
    $SaveButton.Top = 40
    $SaveButton.Left = 465
    $SaveButton.AutoSize=$true
    $SaveButton.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Right
    $SaveButton.add_click( {
        $result = $SaveFileDialog.ShowDialog()
    $result
    if($result -eq "OK")  {
        $Chart.SaveImage($SaveFileDialog.filename, "PNG")
    }
    })
    $Form.controls.add($SaveButton)
    #endregion save button

    $tooltip = New-Object System.Windows.Forms.ToolTip

    $Form.Add_Shown( {$Form.Activate()})
    $Form.ShowDialog()
  }
  End {
  }
}
#endregion: Script Functions

#region: MAIN
WriteInfo -message "...Starting 'Arrange-SDPFolders.ps1' on $(Get-Date)"

try{
  WriteInfo -message "ENTER: Collect and segregate all child items"
	Show-ClusterLogResourceMoveChart -Path $SDPPath
}
catch{
  WriteError -message "An Error occured"
  WriteError -message $error[0].Exception.Message
  $ErrorThrown = $true
}
finally{
  $ScriptEndTimeStamp = Get-Date
  $LogLevel = 0
  WriteInfo -message "Script Show-ClusterLogResourceMoveChart v$verDateScript execution finished. Duration interaction: $(New-TimeSpan -Start $ScriptBeginTimeStamp -End $ScriptEndTimeStamp)"

  if($ErrorThrown) {Throw $error[0].Exception.Message}
}
#endregion: MAIN

### Stats
$Duration = $ScriptEndTimeStamp - $ScriptBeginTimeStamp
If ($Stats) { #increment at start of script
 "$j" + " ;$CheckDate" + "; $OSVersion; " + ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name) + "; $($Duration)" + "; $NodeCnt" + "; $SDPPath" + "; $ErrorMsgPS" + "; v$verDateScript" | Out-File $CountInvFil2 -Append -Encoding UTF8 -ErrorAction SilentlyContinue
 }



# SIG # Begin signature block
# MIInpAYJKoZIhvcNAQcCoIInlTCCJ5ECAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDZhKUzw4C0y27B
# daax/FzjwESvGK7Xz0Z1M+KRv0MEzaCCDXYwggX0MIID3KADAgECAhMzAAACy7d1
# OfsCcUI2AAAAAALLMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjIwNTEyMjA0NTU5WhcNMjMwNTExMjA0NTU5WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC3sN0WcdGpGXPZIb5iNfFB0xZ8rnJvYnxD6Uf2BHXglpbTEfoe+mO//oLWkRxA
# wppditsSVOD0oglKbtnh9Wp2DARLcxbGaW4YanOWSB1LyLRpHnnQ5POlh2U5trg4
# 3gQjvlNZlQB3lL+zrPtbNvMA7E0Wkmo+Z6YFnsf7aek+KGzaGboAeFO4uKZjQXY5
# RmMzE70Bwaz7hvA05jDURdRKH0i/1yK96TDuP7JyRFLOvA3UXNWz00R9w7ppMDcN
# lXtrmbPigv3xE9FfpfmJRtiOZQKd73K72Wujmj6/Su3+DBTpOq7NgdntW2lJfX3X
# a6oe4F9Pk9xRhkwHsk7Ju9E/AgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUrg/nt/gj+BBLd1jZWYhok7v5/w4w
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzQ3MDUyODAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAJL5t6pVjIRlQ8j4dAFJ
# ZnMke3rRHeQDOPFxswM47HRvgQa2E1jea2aYiMk1WmdqWnYw1bal4IzRlSVf4czf
# zx2vjOIOiaGllW2ByHkfKApngOzJmAQ8F15xSHPRvNMmvpC3PFLvKMf3y5SyPJxh
# 922TTq0q5epJv1SgZDWlUlHL/Ex1nX8kzBRhHvc6D6F5la+oAO4A3o/ZC05OOgm4
# EJxZP9MqUi5iid2dw4Jg/HvtDpCcLj1GLIhCDaebKegajCJlMhhxnDXrGFLJfX8j
# 7k7LUvrZDsQniJZ3D66K+3SZTLhvwK7dMGVFuUUJUfDifrlCTjKG9mxsPDllfyck
# 4zGnRZv8Jw9RgE1zAghnU14L0vVUNOzi/4bE7wIsiRyIcCcVoXRneBA3n/frLXvd
# jDsbb2lpGu78+s1zbO5N0bhHWq4j5WMutrspBxEhqG2PSBjC5Ypi+jhtfu3+x76N
# mBvsyKuxx9+Hm/ALnlzKxr4KyMR3/z4IRMzA1QyppNk65Ui+jB14g+w4vole33M1
# pVqVckrmSebUkmjnCshCiH12IFgHZF7gRwE4YZrJ7QjxZeoZqHaKsQLRMp653beB
# fHfeva9zJPhBSdVcCW7x9q0c2HVPLJHX9YCUU714I+qtLpDGrdbZxD9mikPqL/To
# /1lDZ0ch8FtePhME7houuoPcMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGYQwghmAAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAALLt3U5+wJxQjYAAAAAAsswDQYJYIZIAWUDBAIB
# BQCggbAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIJ7Ht8NE2aq9fxBpySFqLAZe
# M5ESFzSHe6yY0pteRVm6MEQGCisGAQQBgjcCAQwxNjA0oBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEcgBpodHRwczovL3d3dy5taWNyb3NvZnQuY29tIDANBgkqhkiG9w0B
# AQEFAASCAQBZw31b4hf9nPTRtzTYzyf0cCvueLNOvDGwG495kvzZ5MeTI4Ktt6ne
# fzZDR8DYrbMaXXWx8xpROIvKYgm/oyh/U6XWN/2lqPuwXyeTF+SSZdz4CtFJJ19y
# LCih3xgyze2EGW9lrY3JbL9bD4/h7z0Kvo6tHbzk1PMAGeFMg3Vk7jZPGSB7fOVx
# poN5YRisp8i1hOrAd0zdDnB4o05dO/udp7HZViO+z8kS7ckqRsGNq+bw0OL2pFWa
# eRahVKo+wOyBzFKw/RiKZFwoKsqjyL/IBjUUNH1odP637tL3mLQNwA5D6kUD9/v7
# tvYrJ+pPvIhVQ3FhhS5O1o+fHdWwE9c4oYIXDDCCFwgGCisGAQQBgjcDAwExghb4
# MIIW9AYJKoZIhvcNAQcCoIIW5TCCFuECAQMxDzANBglghkgBZQMEAgEFADCCAVUG
# CyqGSIb3DQEJEAEEoIIBRASCAUAwggE8AgEBBgorBgEEAYRZCgMBMDEwDQYJYIZI
# AWUDBAIBBQAEIPmLSh54OC0K/73Sw3wsB7ZSVDTHzrB8d8oQFhpxsiq5AgZjoaBC
# XsoYEzIwMjMwMTEwMTM0NTIxLjM1M1owBIACAfSggdSkgdEwgc4xCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1pY3Jvc29mdCBP
# cGVyYXRpb25zIFB1ZXJ0byBSaWNvMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjpE
# OURFLUUzOUEtNDNGRTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2Vy
# dmljZaCCEV8wggcQMIIE+KADAgECAhMzAAABrGa8hyJd3j17AAEAAAGsMA0GCSqG
# SIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAw
# DgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24x
# JjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTIyMDMw
# MjE4NTEyOVoXDTIzMDUxMTE4NTEyOVowgc4xCzAJBgNVBAYTAlVTMRMwEQYDVQQI
# EwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3Nv
# ZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjpEOURFLUUzOUEtNDNG
# RTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZTCCAiIwDQYJ
# KoZIhvcNAQEBBQADggIPADCCAgoCggIBAMd4C1DFF2Lux3HMK8AElMdTF4iG9ROy
# KQWFehTXe+EX1QOrTBFnhMAKNHIQWoxkK1W62/oQQQmtIHo8sphMt1WpkLNvCm3L
# a8sdVL3t/BAx7UWkmfvujJ3KDaSgt3clc5uNPUj7e32U4n/Ep9oOc+Pv/EHc7XGH
# 1fGRvLRYzwoxP1xkKleusbIzT/aKn6WC2BggPzjHXin9KE7kriCuqA+JNhskkedT
# HJQIotblR+rZcsexTSmjO+Z7R0mfeHiU8DntvZvZ/9ad9XUhDwUJFKZ8ZZvxnqnZ
# XwFYkDKNagY8g06BF1vDulblAs6A4huP1e7ptKFppB1VZkLUAmIW1xxJGs3keidA
# TWIVx22sGVyemaT29NftDp/jRsDw/ahwv1Nkv6WvykovK0kDPIY9TCW9cRbvUeEl
# k++CVM7cIqrl8QY3mgEQ8oi45VzEBXuY04Y1KijbGLYRFNUypXMRDApV+kcjG8uS
# T13mSCf2iMhWRRLz9/jyIwe7lmXz4zUyYckr+2Nm8GrSq5fVAPshIO8Ab/aOo6/o
# e3G3Y+cil8iyRJLJNxbMYxiQJKZvbxlCIp+pGInaD1373M7KPPF/yXeT4hG0LqXK
# velkgtlpzefPrmUVupjYTgeGfupUwFzymSk4JRNO1thRB0bDKDIyNMVqEuvV1Uxd
# cricV0ojgeJHAgMBAAGjggE2MIIBMjAdBgNVHQ4EFgQUWBGfdwTLH0BnSjx8SVqY
# WsBAjk0wHwYDVR0jBBgwFoAUn6cVXQBeYl2D9OXSZacbUzUZ6XIwXwYDVR0fBFgw
# VjBUoFKgUIZOaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jcmwvTWlj
# cm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3JsMGwGCCsGAQUF
# BwEBBGAwXjBcBggrBgEFBQcwAoZQaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3Br
# aW9wcy9jZXJ0cy9NaWNyb3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIwMjAxMCgx
# KS5jcnQwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEFBQcDCDANBgkqhkiG
# 9w0BAQsFAAOCAgEAedC1AlhVXHCldk8toIzAW9QyITcReyhUps1uD67zCC308fRz
# YFES/2vMX7o0ObJgzCxT1ni0vkcs8WG2MUIsk91RCPIeDzTQItIpj9ZTz9h0tufc
# KGm3ahknRs1hoV12jRFkcaqXJo1fsyuoKgD+FTT2lOvrEsNjJh5wEsi+PB/mVmh/
# Ja0Vu8jhUJc1hrBUQ5YisQ4N00snZwhOoCePXbdD6HGs1cmsXZbrkT8vNPYV8LnI
# 4lxuJ/YaYS20qQr6Y9DIHFDNYxZbTlsQeXs/KjnhRNdFiCGoAcLHWweWeRszh2iU
# hMfY1/79d7somfjx6ZyJPZOr4fE0UT2l/rBaBTroPpDOvpaOsY6E/teLLMfynr6U
# OQeE4lRiw59siVGyAGqpTBTbdzAFLBFH40ubr7VEldmjiHa14EkZxYvcgzKxKqub
# 4yrKafo/j9aUbwLrL2VMHWcpa18Jhv6zIjd01IGkUdj3UJ+JKQNAz5eyPyQSZPt9
# ws8bynodGlM5nYkHBy7rPvj45y+Zz7jrLgjgvZIixGszwqKyKJ47APHxrH8GjCQu
# sbvW9NF4LAYKoZZGj7PwmQA+XmwD5tfUQ0KuzMRFmMpOUztiTAgJjQf9TMuc3pYm
# pFWEr8ksYdwrjrdWYALCXA/IQXEdAisQwj5YzTsh4QxTUq+vRSxs93yB3nIwggdx
# MIIFWaADAgECAhMzAAAAFcXna54Cm0mZAAAAAAAVMA0GCSqGSIb3DQEBCwUAMIGI
# MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylN
# aWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0yMTA5
# MzAxODIyMjVaFw0zMDA5MzAxODMyMjVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQI
# EwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3Nv
# ZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBD
# QSAyMDEwMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA5OGmTOe0ciEL
# eaLL1yR5vQ7VgtP97pwHB9KpbE51yMo1V/YBf2xK4OK9uT4XYDP/XE/HZveVU3Fa
# 4n5KWv64NmeFRiMMtY0Tz3cywBAY6GB9alKDRLemjkZrBxTzxXb1hlDcwUTIcVxR
# MTegCjhuje3XD9gmU3w5YQJ6xKr9cmmvHaus9ja+NSZk2pg7uhp7M62AW36MEByd
# Uv626GIl3GoPz130/o5Tz9bshVZN7928jaTjkY+yOSxRnOlwaQ3KNi1wjjHINSi9
# 47SHJMPgyY9+tVSP3PoFVZhtaDuaRr3tpK56KTesy+uDRedGbsoy1cCGMFxPLOJi
# ss254o2I5JasAUq7vnGpF1tnYN74kpEeHT39IM9zfUGaRnXNxF803RKJ1v2lIH1+
# /NmeRd+2ci/bfV+AutuqfjbsNkz2K26oElHovwUDo9Fzpk03dJQcNIIP8BDyt0cY
# 7afomXw/TNuvXsLz1dhzPUNOwTM5TI4CvEJoLhDqhFFG4tG9ahhaYQFzymeiXtco
# dgLiMxhy16cg8ML6EgrXY28MyTZki1ugpoMhXV8wdJGUlNi5UPkLiWHzNgY1GIRH
# 29wb0f2y1BzFa/ZcUlFdEtsluq9QBXpsxREdcu+N+VLEhReTwDwV2xo3xwgVGD94
# q0W29R6HXtqPnhZyacaue7e3PmriLq0CAwEAAaOCAd0wggHZMBIGCSsGAQQBgjcV
# AQQFAgMBAAEwIwYJKwYBBAGCNxUCBBYEFCqnUv5kxJq+gpE8RjUpzxD/LwTuMB0G
# A1UdDgQWBBSfpxVdAF5iXYP05dJlpxtTNRnpcjBcBgNVHSAEVTBTMFEGDCsGAQQB
# gjdMg30BATBBMD8GCCsGAQUFBwIBFjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20v
# cGtpb3BzL0RvY3MvUmVwb3NpdG9yeS5odG0wEwYDVR0lBAwwCgYIKwYBBQUHAwgw
# GQYJKwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB
# /wQFMAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186aGMQwVgYDVR0f
# BE8wTTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJv
# ZHVjdHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEBBE4w
# TDBKBggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0
# cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwDQYJKoZIhvcNAQELBQADggIB
# AJ1VffwqreEsH2cBMSRb4Z5yS/ypb+pcFLY+TkdkeLEGk5c9MTO1OdfCcTY/2mRs
# fNB1OW27DzHkwo/7bNGhlBgi7ulmZzpTTd2YurYeeNg2LpypglYAA7AFvonoaeC6
# Ce5732pvvinLbtg/SHUB2RjebYIM9W0jVOR4U3UkV7ndn/OOPcbzaN9l9qRWqveV
# tihVJ9AkvUCgvxm2EhIRXT0n4ECWOKz3+SmJw7wXsFSFQrP8DJ6LGYnn8AtqgcKB
# GUIZUnWKNsIdw2FzLixre24/LAl4FOmRsqlb30mjdAy87JGA0j3mSj5mO0+7hvoy
# GtmW9I/2kQH2zsZ0/fZMcm8Qq3UwxTSwethQ/gpY3UA8x1RtnWN0SCyxTkctwRQE
# cb9k+SS+c23Kjgm9swFXSVRk2XPXfx5bRAGOWhmRaw2fpCjcZxkoJLo4S5pu+yFU
# a2pFEUep8beuyOiJXk+d0tBMdrVXVAmxaQFEfnyhYWxz/gq77EFmPWn9y8FBSX5+
# k77L+DvktxW/tM4+pTFRhLy/AsGConsXHRWJjXD+57XQKBqJC4822rpM+Zv/Cuk0
# +CQ1ZyvgDbjmjJnW4SLq8CdCPSWU5nR0W2rRnj7tfqAxM328y+l7vzhwRNGQ8cir
# Ooo6CGJ/2XBjU02N7oJtpQUQwXEGahC0HVUzWLOhcGbyoYIC0jCCAjsCAQEwgfyh
# gdSkgdEwgc4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAn
# BgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1ZXJ0byBSaWNvMSYwJAYDVQQL
# Ex1UaGFsZXMgVFNTIEVTTjpEOURFLUUzOUEtNDNGRTElMCMGA1UEAxMcTWljcm9z
# b2Z0IFRpbWUtU3RhbXAgU2VydmljZaIjCgEBMAcGBSsOAwIaAxUAsRrSE7C4sEn9
# 6AMhjNkXZ0Y1iqCggYMwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAx
# MDANBgkqhkiG9w0BAQUFAAIFAOdnzcwwIhgPMjAyMzAxMTAxNTQzMDhaGA8yMDIz
# MDExMTE1NDMwOFowdzA9BgorBgEEAYRZCgQBMS8wLTAKAgUA52fNzAIBADAKAgEA
# AgItlgIB/zAHAgEAAgIRDDAKAgUA52kfTAIBADA2BgorBgEEAYRZCgQCMSgwJjAM
# BgorBgEEAYRZCgMCoAowCAIBAAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEB
# BQUAA4GBAAvINxa0cxMCW8zymkmcppc0CMzwLpK/znLmpdfRmplyz3YzJ146aTMH
# f2qn2E5vHqlXTeuZ7C2R8ikhZ00halld5h5Iv9Wdpep6JZ3cT/czqvMG3M3KB8pD
# LyvsbdWXNjPHXcqmlIitSMF9daL5jLZOhLhqppPs4N8MZno9ZgpdMYIEDTCCBAkC
# AQEwgZMwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQG
# A1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAGsZryHIl3e
# PXsAAQAAAawwDQYJYIZIAWUDBAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG
# 9w0BCRABBDAvBgkqhkiG9w0BCQQxIgQgtdevpmha0AKoUDSkalLBeglWUfJyfgkE
# lIZGeXeQvmwwgfoGCyqGSIb3DQEJEAIvMYHqMIHnMIHkMIG9BCD5twGSgzgvCXEA
# crVz56m79Pp+bQJf+0+Lg2faBCzC9TCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0
# YW1wIFBDQSAyMDEwAhMzAAABrGa8hyJd3j17AAEAAAGsMCIEIBQbgNqpxvXeWfvF
# KWrtF/ZyrzgMOYM7fmKlKnoVK6nqMA0GCSqGSIb3DQEBCwUABIICAA1htJcjikVF
# c9Lmq6qnRjPPaS66wYgHeo/2LqvNbUgMDa4aWX1zihAGto2oh2Ml4eUcT88jW+5z
# ZdhaCJNL1yP8lSKws0M7L3RxCJYI8HitTMFIlBoUT8DvKnbCzatcg6GV7ez6MnKq
# QPZ6hsF+ywruKGOrhKOmAglpjobuIw/5fsZeXVuffTBaINyUpCzU9sPRWollTdII
# kAmQca7pu+lj/jY3p/Xj1RK160WRRhUs+0LV7trfavdrl2IrtcTDhIqApMbQ+bMB
# MhXFBBrT+lWxiK8SLiy2ftwUC0gmtc3+iQB5qSVjJXXvTi3oBG/p8q//9APBPUO6
# cMBdaSKsIu6xMy0sUPSqI+fK//DAo5ZG8YtRtFfTFAgUrN5i0gPsM9FKBoQpZ755
# FAALh0cr7W2CJv6U4pkxf6maQdTGKxDV1RQ02kmWYKQ/L0RXLPotVP77fCHs7glm
# vNtgFOPPk0viWVXAkqxJ0Z7kXcYliqMi3cOGWPQ5OPUL+cyhZBfK2bVfZsN11cI/
# J/xgJL5dBC51uFvaEk+K/Nkk1jcsTXFimMfGWkRdfj5lwcyRXhFGpHnOEH5aLAJt
# vUARAPp2bcQNJfx+t+j8x9OJugFuGx8ug3Onmiv6vrs7GwSTF6qiA4bPtBpv9rZe
# N7iCAKfs51DWgnlhlD4QeIOdvzZ0PpmM
# SIG # End signature block
