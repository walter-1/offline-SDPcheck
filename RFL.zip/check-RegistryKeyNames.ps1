<# last edit by: waltere
  File Name: check-RegistryKeyNames.ps1 [full-path-to-expanded-SDP-report]
  Objective: 	1. check for accidently blanks/spaces in reg export files of SDP report
  		2. Compare SDP reg settings with given list of important reg.keys with default values
  call script with -Verbose or -Debug for add. console output
  Note: If you want to use the Explorer plug in, doubleclick the Registry file \\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\Rfl-Check_ShellExtension.reg
        - in Offline-version, the path would be \\localhost\ToolsShare\rfl\Rfl-Check_ShellExtension.reg
VERSION and AUTHORs:
    Ver 1.04 - 27.02.2015
    Ioan Corcodel 	- ioanc@microsoft.com
	Walter Eder	- waltere@microsoft.com

HISTORY
	2015-02-02	V1.00 adjusted RegEx matching, excluded _reg*.HIV files, introduced $exceptionRegNameList
	2015-02-02	V1.01 summary output of findings
	2015-02-08	V1.02 added function Compare-RegName-Value-vs-DefaultValue
	2015-02-10	V1.03 added more output found in reg file, tables for Reg entries
	2015-03-13	V1.05 corrected function Compare-RegName-Value-vs-DefaultValue (all previous checks were done only for last reg_file in SDP folder
	2015-08-26	V1.06 check in stdout.log if Registry outputs are enabled. -> "ERROR: Registry editing has been disabled by your administrator."
	2015-10-08	v1.07 triple performance of function Compare-RegName-Value-vs-DefaultValue
				+ write to file
	2015-10-09	v1.08 again, double performance of function Compare-RegName-Value-vs-DefaultValue
	2015-10-10	v1.09 - run script with NodeNames of Cluster report, again, double performance
			- corrected false positive FileNotFoundCacheLifeTimeInSec\ FileNotFoundCacheLifetime\ (-> use trailing Space in Reg_Reference)
	2015-10-13	v1.10 - corrected possible false positive for Reg.keys with same name in diff. HKLM-path, i.e. EnableSecuritySignature
			- now including "*_reg_Print*.txt" in investigation
	2015-10-14	v1.11 - including UNC hardening settings
	2015-10-20	- excluding big *_reg_print* again
	2015-11-19	v1.12 Win10/2016TH2 addition
	2015-11-26	check if '*stdout*.log' exists in function CheckRegistryEditingDisabledSDP
	2015-03-24	Finding: Leading "_" seems to be a false positive! - let's correct in script
	2016-01-18	v1.13 DCR from TomAu: false positive in regkeys ending with trailing backslash '\' '+' '-' '#'; add '_' '/' characters to Leading
	2016-02-10	v1.14 using FQDN emeacssdfs.europe.corp.microsoft.com
	2016-02-20	v1.15 ErrMsg to ErrMsgRG
	2016-02-17	v1.16 DCR EriqS done: addition to compare RegArrays of Cluster Nodes
	2016-03-14	v1.17 appending Cluster Nodes differences to R-E-G output files.
			- don't open Notepad window, if Cluster report for additional nodes is the same
	2016-03-23	   check:	 if ($CurrArr)
	2016-04-17	v1.18 replace check for stdout.log with results.xml;
	2016-05-01	v1.19 $UsingCulture="en-US"
	2016-07-27	v1.20 using your favorite editor (FavEditor instead of notepad) to open result file
	2016-08-03 	adding 2016RS1
	2017-04-01	adding 2016RS2
	2017-10-06 	v1.21 adding 2016RS3
	2018-04-05 	adding 2016RS4
	2020-01-09  excluding more (cluster) Reg files: ignored Reg Files: *_reg_*.hiv, *_reg_Print*,*_reg_CurrentVersion*,*_reg_Component_Based*,*_reg_SideBySide*,*_reg_DriverDatabase*,*_reg_services*,*reg_Winevt*,*reg_Enum*
	2022-09-08 using Utils_RflShared.psm1 library
	
	ToDo: 	/known issue:
		- combine issues found in PS output (trailing space, only show once in SUMMARY
			RegName               REG_type   RegValue  HKEY
			ex: P:\Sample_SDPs\2012R2\2012R2_clu-7node_CTSHyperV
		 perhaps: do a Cluster summary output)
		- adjustment for localized language SDP reports (like Russian with cyrillic characters in Registry)
		- integrate script functionality into SDP / UDE rules
		- correct missing colums, if one entry i.e. AuthForwardServerlist exceeds certain amount of max characters
#>

<#
.SYNOPSIS
The script reads SDP report and checks for accidently Registry key names containing a leading or trailing Space character.
The script compares all the listed registry settings against default values

SYNTAX: .\check-RegistryKeyNames.ps1 [full-path-to-expanded-SDP-report]

.DESCRIPTION
Step#1: The script reads in all *_reg_*.txt files from SDP report and checks for accidently Registry key names containing a leading or trailing Space character.
You can configure to omit some known fals positive RegNames in the scripts paramter $exceptionRegNameList, see customization section.
Step#2: The script compares all the registry settings against default values (only given RegNames in ref__RegistryReference.csv are compared)

If you experience PS error '...is not digitally signed.' run the command:
 Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned

.PARAMETER OpenSummary
 This switch will not open resulting summary file with Notepad/Favorite Editor if set to $False
 
.EXAMPLE
Example 1
do the reg check on UNC path
\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\check-RegistryKeyNames.ps1 \\ioanc00\temp\New_RFL\SDPs\FileServer

Example 2
do the reg check on local disk path
\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\check-RegistryKeyNames.ps1 C:\SRdata\SDPs\FileServer

.LINK
\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\check-RegistryKeyNames.ps1
ioanc@microsoft.com ; waltere@microsoft.com ;

#>

[CmdletBinding()]
PARAM (
	[ValidateScript({Test-Path $_ -PathType 'Container'})]
	[Parameter(Mandatory=$True,Position=0,HelpMessage='Choose a writable SDP folder location, i.e. C:\SR\SDP-report\ ')]
	[string]$SDPPath
	,
	[ValidateSet("2008","2008R2","2012","2012R2","2016","2016RS1","2016RS2","2016RS3","2016RS4","2016RS5","201619H1","201619H2","20162004","201620H2","201621H1","201621H2","201622H2","2022","Win11","Win1122H2","Win1123H1","help","")]
	[Parameter(Mandatory=$False,Position=1,HelpMessage='optional: Choose one OS from list: [2008|2008R2|2012|2012R2|2016|2016RS1|2016RS2|2016RS3|2016RS4|2016RS5|201619H1|201619H2|20162004|201620H2|201621H1|201621H2|201622H2|2022|Win11|Win1122H2|Win1123H1]')]
	[string]$OSversion = "undefined"
	,
	[switch]$OpenSummary= $true		# open with Notepad/FavEditor
	)

Process
{
	$verDateScript = "2023.06.07.0"
	$ScriptFolder = Split-Path $MyInvocation.MyCommand.Path -Parent
	# Load Common Library:
	. $ScriptFolder\Utils_RflShared.ps1

	$scriptName = $invocation.MyCommand.Name

#region: ###### customization section of script, logging configuration ########################
	$SDPcheckINI = (Get-content -Path "$ScriptFolder\_SDPcheck.ini")
	$InOfflineMode 	= (($SDPcheckINI[1] -split " ")[2]).trim("""")	# set $True for outsourcer or when not connected to MS network - offline-SDPcheck
	$RFLroot = (($SDPcheckINI[2] -split " ")[2]).trim("""")	# "\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\" -or- "\\localhost\ToolsShare\rfl\"
	if ($InOfflineMode -match "False") {
		$StatsServer = (($SDPcheckINI[5] -split " ")[2]).trim("""")
		if (Test-Connection -ComputerName $StatsServer -Quiet -Count 1) {[bool]$Stats=$True} else {[bool]$Stats=$False}
	} else { 
		$Stats = $False
	}
	$RFdBLpath = $RFLroot + "\RflLists\"
	$RegReferenceCsvFile = $RFdBLpath + 'ref__RegistryReference.csv'
	[string[]]$exceptionRegNameList = "Cardinality",".*http.*" # Whitelist note: "Cardinality " has FalsePositive trailing Space
	#$Global:OpenSummary=1		# with Notepad/FavEditor
	$DbgOut=0		# used for verbose debug output
	$OutFileChars=300		# max line lenght in outfile
#endregion: ###### customization section

if ($Stats) {
	$StatsServerPath="\\$StatsServer\RFLstats$\RFL\scripts\Stats\"
	$CountInvFil = $StatsServerPath +'countReg.dat'
	$CountInvFil2 = $CountInvFil +'.us'
	 ($j=[int32](Get-Content $CountInvFil -TotalCount 1 -ErrorAction SilentlyContinue)) |Out-Null
	 Try {(++$j) | Set-Content $CountInvFil -ErrorAction SilentlyContinue} Catch { }
}

$UsingCulture="en-US"	# for Select-String
$ActualCulture = Get-Culture
Write-verbose "Note: UsingCulture = $UsingCulture - your Culture setting: $ActualCulture "
$ScriptBeginTimeStamp = Get-Date
$CheckDate = (Get-Date).ToUniversalTime().ToString("yy-MM-dd_HH-mm-ss")

$newline_Seperator = "
==========================================================="
Set-Variable -Name ErrorMsgScript -Scope Script -Force
Set-Variable -Name ComputerName -value "" -Scope Script
$RegReferenceCsvFileReleaseDate = ((get-item $RegReferenceCsvFile)[-1]).LastWriteTime

If ($PSBoundParameters['Debug']) { $DebugPreference='Continue'}

#region: Script Functions
########################################################### 2016-04-18
## avoid tr-TR issue with Turkish character 'i /I' in Select-String -Pattern calls
Function Using-Culture (
[System.Globalization.CultureInfo]$culture = (throw "USAGE: Using-Culture -Culture culture -Script {scriptblock}"),
[ScriptBlock]$script= (throw "USAGE: Using-Culture -Culture culture -Script {scriptblock}"))
{
  $OldCulture = [System.Threading.Thread]::CurrentThread.CurrentCulture
  trap
  {
    [System.Threading.Thread]::CurrentThread.CurrentCulture = $OldCulture
  }
  [System.Threading.Thread]::CurrentThread.CurrentCulture = $culture
  Invoke-Command $script
  [System.Threading.Thread]::CurrentThread.CurrentCulture = $OldCulture
}

function GetOSfromMSinfo32_Ex ($SDPPath,$NodeName){
###########################################################
### Step#1: function GetOSfromMSinfo32_Ex* files
# Return: $OSVersion

	write-debug "__enter GetOSfromMSinfo32_Ex($SDPPath,$NodeName)"
	### Validate user input of expanded SDP report and identify the number of msinfo32.txt files and the names of the computers $NodeNames (in Cluster Report)
	$msinfo32 = $SDPPath + $NodeName + '*msinfo*.txt' # Try .txt
	If (-NOT (Test-Path $msinfo32)) {
	 Write-Verbose "** $SDPPath without *msinfo32.txt"
	 $msinfo32 = $SDPPath + $NodeName + '*msinfo*.nfo' # Try .nfo
	 }
	 ### Get OS version from SDP report from msinfo.txt
	 If ("$msinfo32" -match ".txt"){
	  Write-Debug "...$NodeName Using msinfo32.txt = $msinfo32 "
	  #Read-in content from Msinfo file
	  if ($msinfo32file = get-childitem $msinfo32) {
	     Write-Debug "msinfo32file: $msinfo32file "
		 $SDPdate = $msinfo32file.LastWriteTime
		 Write-Debug "`Node: $NodeName : SDP Date: $SDPdate"
		 $msinfo32 = Get-Content $msinfo32 -TotalCount 7
		 If ($msinfo32) {
			$SdpOSbuild = $msinfo32[-1]
		 	$SdpOSname = $msinfo32[-2];$SdpOSname=$SdpOSname.Split(" ",3)[2]
		 	$SdpComputerName = $msinfo32[1].Split("")[-1]
		}
   		Else {$ErrorMsgScript += "No-Valid-MsI32txt "}
	 }
	}
	Else { # Get OS version from SDP report from msinfo.nfo / seems not to work for some localized OS
	  Write-Debug "...$NodeName Using msinfo32.nfo = $msinfo32 "
	  if ($msinfo32file = get-childitem $msinfo32) {
		$SDPdate = $msinfo32file.LastWriteTime
		Write-Debug "`nNode: $NodeName : SDP Date: $SDPdate"
		[xml]$nfo = Get-Content $msinfo32file
		$summary = $nfo.MSInfo.Category.Data.value
		If ($summary.'#cdata-section') {$SdpOSbuild = $summary.'#cdata-section'[1]
		   				$SdpOSname = $summary.'#cdata-section'[0]
		   				$SdpComputerName = $summary.'#cdata-section'[4] }
   		Else {$ErrorMsgScript += "No-Valid-MsI32nfo "}
	 }
	} #end Else
	### match Build number in SDP report with OS short name
	$RegistryArray.ComputerName = $SdpComputerName
	$RegistryArray.SDPdate = $SDPdate
	$RegistryArray.OSversion = $OSversion
	if("$SdpOSbuild" -match "2600"){$RegistryArray.OSVersion_old="old-XP"}  # Windows XP
	if("$SdpOSbuild" -match "3790"){$RegistryArray.OSVersion_old="old-2003"}  # Windows 2003
	if("$SdpOSbuild" -match "6001"){$RegistryArray.OSVersion_old="old-2008-SP1"}  # Windows Vista SP1
	if(("$SdpOSbuild" -match "6002") -or ("$SdpOSbuild" -match "6003") ){$RegistryArray.OSVersion="2008"}  # Windows Vista SP2
	if("$SdpOSbuild" -match "7600"){$RegistryArray.OSVersion_old="old-2008R2-RTM"} # Windows 7 RTM
	if("$SdpOSbuild" -match "7601"){$RegistryArray.OSVersion="2008R2"} # Windows 7
	if("$SdpOSbuild" -match "9200"){$RegistryArray.OSVersion="2012"}  # Windows 8
	if("$SdpOSbuild" -match "9600"){$RegistryArray.OSVersion="2012R2"} # Windows 8.1
	if("$SdpOSbuild" -match "10.0.10240"){$RegistryArray.OSVersion="2016"} 	# Windows 10
	if("$SdpOSbuild" -match "10.0.14393"){$RegistryArray.OSVersion="2016RS1"} 	# Windows 10 RS1
	if("$SdpOSbuild" -match "10.0.17763"){$RegistryArray.OSVersion="2016RS5"} 	# Windows 10 1809 RS5 October 2018 Update
	if("$SdpOSbuild" -match "10.0.18363"){$RegistryArray.OSVersion="201619H2"} # Windows 10 1909 19H2 October 2019 Update
	if("$SdpOSbuild" -match "10.0.19041"){$RegistryArray.OSVersion="20162004"} # Windows 10 2004 2020 April 2020 Update
	if("$SdpOSbuild" -match "10.0.19042"){$RegistryArray.OSVersion="201620H2"} # Windows 10 20H2 October 2020 Update
	if("$SdpOSbuild" -match "10.0.19043"){$RegistryArray.OSVersion="201621H1"} # Windows 10 21H1 April 2021 Update
	if("$SdpOSbuild" -match "10.0.19044"){$RegistryArray.OSVersion="201621H2"} # Windows 10 21H2 October 2021 Update
	if("$SdpOSbuild" -match "10.0.19045"){$RegistryArray.OSVersion="201622H2"} # Windows 10 22H2 October 2022 Update
	if("$SdpOSbuild" -match "10.0.20348"){$RegistryArray.OSVersion="2022"} 	# Windows Srv 2022
	if("$SdpOSbuild" -match "10.0.20349"){$RegistryArray.OSVersion="2022"} 	# Windows Srv 2022AZ HCI
	if("$SdpOSbuild" -match "10.0.22000"){$RegistryArray.OSVersion="Win11"} 	# Windows 11
	if("$SdpOSbuild" -match "10.0.22621"){$RegistryArray.OSVersion="Win1122H2"} # Windows 11 May 2022 Update
	if("$SdpOSbuild" -match "10.0.22622"){$RegistryArray.OSVersion="Win1123H1"} # Windows 11 

	Write-host " SDP Date:         $($RegistryArray.SDPdate) / OS-Version: $($RegistryArray.OSVersion) $($RegistryArray.OSVersion_old)"
	Write-host " SDP ComputerName: $SdpComputerName |Build: $SdpOSbuild |OS: $SdpOSname"
}

function CheckRegistryEditingDisabledSDP ($SDPPath,$Nodename){
##########################################################
### Step#2: function CheckRegistryEditingDisabledSDP
# Return: xxx if line is present: ERROR: Registry editing has been disabled by your administrator.
  $SDPoutFile = $SDPPath + '*stdout*.log'
  If (Test-Path $SDPoutFile) {
	$SDPoutFileContent = Get-Content $SDPoutFile
	$RegEdDisabled = Using-Culture $UsingCulture {$SDPoutFileContent | Select-String "Registry editing has been disabled"} #-quiet -ErrorAction SilentlyContinue
	#$RegEdDisabled = $SDPoutFileContent | Select-String "Registry editing has been disabled" #-quiet -ErrorAction SilentlyContinue
	Write-verbose "**SDPoutFile: $SDPoutFile - RegEdDisabled: $RegEdDisabled"
	Write-debug "**SDPoutFile: $SDPoutFile - RegEdDisabled: $RegEdDisabled"
	if ($RegEdDisabled)
 	 {
	  $ErrorMsgScript += "Reg-Edit_disabled "
	  $RegistryArray.WARNmsg = "***WARNING for this customer SDP report: Registry editing has been disabled at SDP runtime! see stdout*.log`n"
	  Write-Host -BackgroundColor Blue -ForegroundColor Red -NoNewline -Object $RegistryArray.WARNmsg -Separator .
	 }
  }
  else {Write-Host "[Informational]: $SDPoutFile does not exist in this report."}
} # end function CheckRegistryEditingDisabledSDP

function get-Reg-Check-Blank ($SDPPath,$Nodename){
###########################################################
### Step#3: get-Reg-Check-Blank: function to check for Registry key names containing incorrect 'leading or trailing Space' characters
# Return:
write-debug "__enter get-Reg-Check-Blank ($SDPPath,$Nodename)"
Write-Host "...Checking Registry files for incorrect RegKey names with leading or trailing Space character - Please wait ... "
## read files with $Nodename*_reg_* in their names
#$regfiles = dir $SDPPath|?{$_.name -match "_reg_*.txt"} # changed from "_reg_" to "_reg*.txt"
#$RegistryArray.regFiles = Get-Item -path ($SDPPath + $NodeName + "*_reg*") -Exclude "*.hiv","*_reg_Print*" #Why _print? These are pretty big!
$RegistryArray.regFiles = Get-Item -path ($SDPPath + $NodeName + "*_reg*") -Exclude "*.hiv","*_reg_Print*","*_reg_CurrentVersion*","*_reg_Component_Based*","*_reg_SideBySide*","*_reg_DriverDatabase*","*_reg_services*","*reg_Winevt*","*reg_Enum*"  #Why _print, etc.? These are pretty big, esp. all the Cluster Regs...!
$startReg = Get-Date

## don't scan reg entries with known false positives
#$exceptionRegStrings = $exceptionRegNameList -join "|"
$exceptionRegStrings = (($exceptionRegNameList |ForEach-Object{[regex]::escape($_)}) -join "|")
Write-Debug "Exception List: '$exceptionRegNameList' - Match_string: '$exceptionRegStrings'"

foreach ($Reg_file in $RegistryArray.regFiles){
   Write-Host -BackgroundColor Blue -ForegroundColor Cyan -NoNewline -Object "." -Separator .
   $HkeyPathTable=@()
   $content = Get-Content($Reg_file.pspath)
   ## Build Table of RegKeyPath with list of RegKeyNames
   # $HkeyPath example: HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\services\Dhcp
   # $HkeyPathTable row example: HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\services\Dhcp\  Group  REG_SZ  TDI
   foreach ($line in $content)
   {
      if ($line -match "^HKEY"){
       $HkeyPath = $line #.Replace('\','\\') #.Replace('\','-')
      }
      else { # accumulate RegNames
#       	if ($line -match "[0-9a-zA-Z_\)\}\*\/\$\%\?\.\:]") {
       	if ($line -match "^  ") {
        	$line = $HkeyPath + "\" + $line
#        	$line = $HkeyPath + "\\" + $line
        $HkeyPathTable += $line
        }
      }
   }
# Note: no perf gain here
#	Write-verbose "HkeyPathTable Before: $($HkeyPathTable.count)"
#	$HkeyPathTable= $HkeyPathTable | Sort-Object | Get-Unique #v1.07 - 2015-10-08
#	Write-verbose "HkeyPathTable After : $($HkeyPathTable.count)"
 #  $RegistryArray.RegNamesArray = $HkeyPathTable #foreach ($line in $HkeyPathTable { $_ -NotMatch "\[HK" }
   $RegistryArray.RegNamesArray = $HkeyPathTable | Sort-Object | Get-Unique #foreach ($line in $HkeyPathTable { $_ -NotMatch "\[HK" }
   # Build complete list of all registry names
   $RegistryArray.AllRegNamesArray += $RegistryArray.RegNamesArray	# used later in function Compare-RegName-Value-vs-DefaultValue
   $RegistryArray.AllRegNamesArray = $RegistryArray.AllRegNamesArray | Sort-Object -unique # 14.10.2015
   #Write-debug "_ Table: $($HkeyPathTable)"
   Write-debug "__[get-Reg-Check-Blank] done filling RegNamesArray:`n$($RegistryArray.RegNamesArray)"
   ## Check for leading or trailing Space characters
   foreach ($entry in $HkeyPathTable){
    #?# [string]$entry = $entry
   	# if (($entry -match "(REG_DWORD)") -or ($entry -match "(REG_SZ)") -or ($entry -match "(REG_MULTI_SZ)")) {
   	if (($entry -match "(REG_)") -and ($entry -Notmatch $exceptionRegStrings)) {
 #     if ($entry -notmatch "[0-9a-zA-Z_\)\}\*\/\$\%\?\.\:](\s){4,4}REG_")		# trailing space at the end of the KeyName
      if ($entry -notmatch "[0-9a-zA-Z_\(\)\{\}\*\/\$\%\?\.\:\+\-\#\\](\s){4,4}REG_")		# trailing space at the end of the KeyName #2016-01-18
       {	Write-Host -BackgroundColor Red -ForegroundColor Cyan -NoNewline -Object "." -Separator .
        #Add_RegNameEntryToArray $RegistryArray.TrailingIncorrectArray $entry 	 #call function
		#$pattern = "(?<HKEY>^HKEY_.*)(\s){4,}(?<RegName>\w.*(\s){4,})\s*(?<REG_type>REG_.*)(\s){4,4}(?<RegValue>.*)" ## 4 spaces or more before or after RegName !
		$pattern = Using-Culture $UsingCulture {"(?<HKEY>^HKEY_.*)(\s){4,}(?<RegName>\w.*(\s){4,})\s*(?<REG_type>REG_.*)(\s){4,4}(?<RegValue>.*)"} ## 4 spaces or more before or after RegName !
		Write-debug "Trail pattern: $pattern"
		if ($entry -match $pattern)
		 {
		 $SDPentry = New-Object PSObject -Property @{
		 	  HKEY 	= ($Matches.HKEY).Replace("HKEY_LOCAL_MACHINE","HKLM")
		 	  RegName 	= ($Matches.RegName).Replace("  ","~")
		 	  REG_type 	= $Matches.REG_type
		 	  RegValue 	= $Matches.RegValue
		 	  }
		 Write-Verbose "... adding SDP_RegKey: $($SDPentry.RegName) to Trailing-List"
		 $RegistryArray.TrailingIncorrectArray += $SDPentry
		 }

        	Write-Verbose "reg-File: $($Reg_file.name)"
        	Write-Debug "Trailing_Space: $entry "
        	## make note of filename to output
        	$RegistryArray.TrailingIncorrectFileArray += $Reg_file
       }
 #     if ($entry -notmatch "\\(\s){4,4}[/(a-zA-Z0-9/{/*/./@/#/$/%/?/./:/\\]")	# leading space at the start of the KeyName
      if ($entry -notmatch "\\(\s){4,4}[/(a-zA-Z0-9_/{/*/./@/#/$/%/?/./:///\\]")	# leading space at the start of the KeyName #2016-01-18
       {	Write-Host -BackgroundColor DarkRed -ForegroundColor Cyan -NoNewline -Object "." -Separator .
		#$pattern = "(?<HKEY>^HKEY_.*)(\s){4,}(?<RegName>\w.*(\s){4,})\s*(?<REG_type>REG_.*)(\s){4,4}(?<RegValue>.*)" ## 4 spaces or more before or after RegName !
		$pattern = Using-Culture $UsingCulture {"(?<HKEY>^HKEY_.*)(\s){4,}(?<RegName>\w.*(\s){4,})\s*(?<REG_type>REG_.*)(\s){4,4}(?<RegValue>.*)"} ## 4 spaces or more before or after RegName !
		Write-debug "Lead pattern: $pattern"
		if ($entry -match $pattern)
		 {
		 $SDPentry = New-Object PSObject -Property @{
		 	  HKEY 	= ($Matches.HKEY).Replace("HKEY_LOCAL_MACHINE","HKLM")
		 	  RegName 	= ($Matches.RegName).Replace("  "," ")
		 	  REG_type 	= $Matches.REG_type
		 	  RegValue 	= $Matches.RegValue
		 	  }
		 Write-Verbose "... adding SDP_RegKey: $($SDPentry.RegName) to Leading-List"
		 $RegistryArray.LeadingIncorrectArray += $SDPentry
		 }
        	Write-Verbose "reg-File: $($Reg_file.name)"
        	Write-Debug "Leading_Space: $entry "
        	$RegistryArray.LeadingIncorrectFileArray += $Reg_file
       }
      }
   }
  Write-Verbose "Reg-File $($Reg_file.name) done"
  }

if ($RegistryArray.TrailingIncorrectArray -or $RegistryArray.LeadingIncorrectArray) {
 if ($RegistryArray.TrailingIncorrectArray) {
   Write-Host -BackgroundColor Magenta -ForegroundColor Black -Object "`n__Reg-Files-Blank-Check: $($RegistryArray.TrailingIncorrectArray.count) Registry key name(s) containing 'trailing Space' character"
   $RegistryArray.TrailingIncorrectArray | Select-Object RegName,REG_type,RegValue,HKEY | Sort-Object HKEY,RegName| Format-Table -auto
   }
 if ($RegistryArray.LeadingIncorrectArray) {
   Write-Host -BackgroundColor Magenta -ForegroundColor Black -Object "`n__Reg-Files-Blank-Check: $($RegistryArray.LeadingIncorrectArray.count) Registry key name(s) containing 'leading blank' character"
   $RegistryArray.LeadingIncorrectArray | Select-Object RegName,REG_type,RegValue,HKEY | Sort-Object HKEY,RegName| Format-Table -auto
   }
}
else {Write-Host -BackgroundColor Green -ForegroundColor Black -Object "`n$(Get-Date -UFormat "%R:%S") Reg-Files-Blank-Check OK: No Registry key name contains leading or trailing Space character."}


$RegistryArray.ignoredFiles = Get-Item -path ($SDPPath + $NodeName + "*_reg*") -Include "*.hiv" #,"*_reg_Print*"
Write-Verbose "..ignored Reg Files: "
Write-Verbose "$($RegistryArray.ignoredFiles)"
#Write-Host "`nTotal $($RegistryArray.regFiles.count) _reg_*.txt files checked, $($RegistryArray.ignoredFiles.count) *_reg_*.Hiv or big *_reg_Print.txt ignored."
Write-Host "`nTotal $($RegistryArray.regFiles.count) _reg_*.txt files checked, $($RegistryArray.ignoredFiles.count) *_reg_*.Hiv + *_reg_Print*,*_reg_CurrentVersion*,*_reg_Component_Based*,*_reg_SideBySide*,*_reg_DriverDatabase*,*_reg_services*,*reg_Winevt*,*reg_Enum* ignored."
$endReg = Get-Date
Write-Host -BackgroundColor Black -ForegroundColor Gray -Object "$(Get-Date -UFormat "%R:%S") Reg-Files-Blank-Check: v$verDateScript  took $($endReg - $startReg)"
write-debug "___leaving [get-Reg-Check-Blank]"
} #end function get-Reg-Check-Blank

function Compare-RegName-Value-vs-DefaultValue ($RegNamesArray,$NodeName){
###########################################################
### Step#4: function Compare-RegName-Value-vs-DefaultValue
# compare all RegKeyNames in given SDP _reg_ files with Standard settings
# Return:
#http://blogs.technet.com/b/heyscriptingguy/archive/2011/02/18/speed-up-array-comparisons-in-powershell-with-a-runtime-regex.aspx
# $a = �red.�,�blue.�,�yellow.�,�green.�,�orange.�,�purple.�
# $b = �blue.�,�green.�,�orange.�,"white.","gray."
# [regex] $a_regex = �(?i)^(� + (($a |foreach {[regex]::escape($_)}) -join �|�) + �)$�
# $b -match $a_regex
#$RegistryArray.regFiles = Get-Item -path ($SDPPath + $NodeName + "*WebClient_reg_output*") -Exclude "*.hiv","*_reg_Print*" #*_reg*

	write-debug "__entering Compare-RegName-Value-vs-DefaultValue($RegName, )"
	Write-Host "...Checking for differences in Registry settings "
	Write-Host " - Yellow blocks mark non default settings ..."
	# lookup RegName and default value in reg reference list $RegReferenceCsvFile
	Write-Verbose "_Fetch reg reference List: $RegReferenceCsvFile"
	$DefaultRegValuesCsvFile = import-csv $RegReferenceCsvFile

	#[regex] $DefRegKeys_regex = �(?i)^(� + (($DefaultRegValuesCsvFile |foreach {[regex]::escape($_.RegName)}) -join �|�) + �)$�
	#$DefRegKeys_regex = (($DefaultRegValuesCsvFile |ForEach-Object{[regex]::escape($_.RegName)}) -join �| �)
	$DefRegKeys_regex = Using-Culture $UsingCulture {(($DefaultRegValuesCsvFile |ForEach-Object{[regex]::escape($_.RegName)}) -join "| ") }
	Write-Host " ..Note: checks can only be done on available *_reg* files from SDP report"
	Write-Verbose " ..Checking: $DefRegKeys_regex"
#$UniqueAllRegNamesArray = $UniqueAllRegNamesArray | Sort-Object -Unique ### http://blogs.technet.com/b/heyscriptingguy/archive/2012/01/15/use-powershell-to-choose-unique-objects-from-a-sorted-list.aspx

	#$SDPRegNamesMatchList = $RegistryArray.AllRegNamesArray | Select-String "$DefRegKeys_regex"	#may need Function Using-Culture for Turkish TR-TR?
	$SDPRegNamesMatchList = Using-Culture $UsingCulture {$RegistryArray.AllRegNamesArray | Select-String "$DefRegKeys_regex" }
	Write-debug "SDPRegNamesMatchList: $SDPRegNamesMatchList"
	if ($SDPRegNamesMatchList) {
	foreach ($line in $DefaultRegValuesCsvFile) {
	  Write-Host -BackgroundColor Blue -ForegroundColor Cyan -NoNewline -Object "." -Separator .
	  $Component 		= $line.Component
	  $HKEY 		= $line.HKEY
	  $RegName 		= $line.RegName
	  #$REG_type 		= $line.REG_type
	  $DefaultValue 	= $line.DefaultValue
	  $KBref 		= $line.KBref
	  $Comment 		= $line.Comment

	#write-host "....checking $($RegistryArray.AllRegNamesArray)"
	#$RegStringFile = "c:\temp\RegStringFileKB.txt"
    #$RegistryArray.AllRegNamesArray | Out-File -FilePath $RegStringFile

	#  $regMatch= $SDPRegNamesMatchList | Select-String "$RegName" #-quiet
		$HKEY_regex = ($HKEY.replace("\","\\"))
$RegName_regex = ([regex]::escape($RegName))
#		$RegName_regex = ($RegName.replace("\\*\","\\\\\*\\")) #^\\\\\w+ for UNC hardening #[regex]::escape($_)
#		$RegName_regex = ($RegName.replace("\\*\","^\\\\\w+\\\w+")) #^\\\\\w+ for UNC hardening
#	  $regMatch_regex = "$($HKEY_regex)\s{4,5}$($RegName).*\s{4,5}.*"
	  $regMatch_regex = "$($HKEY_regex)\s{4,6}$($RegName_regex)\s{4,6}.*"
	  Write-debug "regMatch_regex: $regMatch_regex"
	  #$regMatch= $SDPRegNamesMatchList | Select-String "$regMatch_regex" #-quiet
	  $regMatch= Using-Culture $UsingCulture {$SDPRegNamesMatchList | Select-String "$regMatch_regex"} #-quiet
	  Write-debug "regMatch: $regMatch"
	  if ($regMatch) { # example: HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters\  SMB2  REG_DWORD  0x1
	 	$regMatch | ForEach-Object {
	## 	 $pattern = "(?<HKEY>^HKEY_.*)(\s){4,4}(?<RegName>\w.*(\s){4,4})\s*(?<REG_type>REG_.*)(\s){4,4}(?<RegValue>.*)"
	 	 $pattern = "(?<HKEY>^HKEY_.*)(\s){4,6}(?<RegName>\S.*(\s){4,6})\s*(?<REG_type>REG_.*)(\s){4,4}(?<RegValue>.*)"
	 	 if ($_ -match $pattern)
	 	  {
			#Write-host "$RegName : $($SDPvalue)"
			$SDPentry = New-Object PSObject -Property @{
	 	     HKEY 		= $Matches.HKEY
	 	     RegName 	= ($Matches.RegName).Replace("  ","")
	 	     REG_type 	= $Matches.REG_type
	 	     RegValue 	= $Matches.RegValue
	 	     Component	= $Component
	 	     DefaultValue	= $DefaultValue
	 	     KBref		= $KBref
	 	     Comment	= $Comment
	 	   	}
	 	   	Write-debug "SDPentry: $($SDPentry.RegName)"
	 	   	Write-debug "Reference: $($RegName)"
	## 	 	If (($SDPentry.RegName -match $RegName) -and ($DefaultValue -ne $SDPentry.RegValue))
	 	 	If ($DefaultValue -ne $SDPentry.RegValue)
	 	 	{ 	Write-Host -BackgroundColor Yellow -ForegroundColor Cyan -NoNewline -Object "." -Separator .
	 	 		Write-Verbose "Found difference: $($RegKeyNameDiffValueArray)
	 	 		 	=> Default Value: $RegName $DefaultValue `n"
	 	 		$RegistryArray.RegKeyNameDiffValueArray += $SDPentry
				Write-Verbose " Component: $($line.component) RegName: $($line.RegName) DefValue: $($line.DefaultValue) -differs to- SDP: $($SDPentry.RegValue) "
			}
	 	  } # end if ($_ -match $pattern)
	 	} # end ForEach-Object
	  }#end if ($regMatch)
	} # end foreach ($line in $DefaultRegValuesCsvFile)
	} # end if ($SDPRegNamesMatchList)
	else { Write-Host "[Informational] No match of given registry names to compare"}

	# ToDo: inform engineer about discrepancy (report in file)
	#    store the regkeyname (hopefully unique) while scanning all reg files and do the comparison only once at end of script
	
	Write-Host -BackgroundColor Black -ForegroundColor Gray -Object "`n$(Get-Date -UFormat "%R:%S") Reg-Names-Compare script v$verDateScript  took: $($endTimeRegCompare - $startRegCompare)"
	write-debug "___leaving [get-Reg-Check-Blank]"
} #end function Compare-RegName-Value-vs-DefaultValue

function Add_RegNameEntryToArray ($RegNamesArray,$RegNameEntry){
###########################################################
### function Add_RegNameEntryToArray --- currently not used!
# Return:
# 	$RegNameEntry | ForEach-Object {
 	 $pattern = "(?<HKEY>^HKEY_.*)(\s){4,}(?<RegName>\w.*(\s){4,})\s*(?<REG_type>REG_.*)(\s){4,4}(?<RegValue>.*)" ## 4 spaces or more before or after RegName !
 	 if ($RegNameEntry -match $pattern)
 	 {
  	   	 $SDPentry = New-Object PSObject -Property @{
 	     HKEY 		= $Matches.HKEY
 	     RegName 	= ($Matches.RegName).Replace("  ","")
 	     REG_type 	= $Matches.REG_type
 	     RegValue 	= $Matches.RegValue
 	   	}
 	   	Write-Verbose "... adding SDP_RegKey: $($SDPentry.RegName) to Array $($RegNamesArray.name)"
 	   	$RegNamesArray += $SDPentry
 	 }
#	}
} # end function Add_RegNameEntryToArray

#endregion: Script Functions

### Trail SDPPath with '\' and allow path with space character
if ($SDPPath.EndsWith("\")){$SDPPath="$SDPPath"}
else {$SDPPath="$SDPPath" +"\"}
If (-NOT (Test-Path $SDPPath -PathType 'Container')){Throw "$($SDPPath) is not a valid folder"}


#region ### ::main ##################################################################################
#if (-Not $OSversion) {
	$MsinfoFiles = Get-Item -path ($SDPPath + "*Msinfo*.txt")

	 if (!$MsinfoFiles) {
		$MsinfoFiles = Get-Item -path ($SDPPath + "*Msinfo*.nfo")
		Write-Host -BackgroundColor Black -ForegroundColor Red -Object "There are no *Msinfo*.* files in $SDPPath - Please double-check SDP-path again!"
		Write-Host " This error happens for non-standard SDP reports, i.e. VSS, SCCM or SQL SDP reports"
		$ErrorMsgScript += "No-Valid-msinfo32 "
		#Get user input for OS:
		Write-Verbose " To run this script, you can input the OS as third parameter, i.e. 2008,2008R2,2012,2012R2"
		#  continue to allow parameter #3 as OSversion, workaround for no MsInfo32 file in SDP, plus manual optional 3rd parameter OSversion
		if (!$MsinfoFiles) {$MsinfoFiles = Get-Item -path ($SDPPath + '*evt_System.txt')}
		if (!$MsinfoFiles) {$MsinfoFiles = Get-Item -path ($SDPPath + '*evt_System.evtx')}
		Write-Verbose " Proceed with Files: $MsinfoFiles "
		}

	Write-Host "$(Get-Date -UFormat "%R:%S") ==Registry Check==... running checks for incorrect entries and check against different/non-standard key values... "
	$NodeNames = foreach ($NodeName in $MsinfoFiles) {($NodeName.name).split('_')[0]}
	Write-Host "$(Get-Date -UFormat "%R:%S") NodeName(s): $NodeNames"

	### Get SDP report type, i.e. VSS, SCCM or SQL SDP reports) #2016-01-18
	 #$SDPpathStdoutFile = Get-Item -path ($SDPPath + "stdout.log") -ErrorAction SilentlyContinue
	 #if (!$SDPpathStdoutFile) {$ErrorMsg += "No-Valid-stdout "}
	 #else { $stdout = Get-Content $SDPpathStdoutFile -TotalCount 3
	 #	$SDPtype = $stdout[-1];$SDPtype=$SDPtype.Split(" ",2)[0] }
	 $SDPpathResultsFile = Get-Item -path ($SDPPath + "results.xml") -ErrorAction SilentlyContinue
	 if (!$SDPpathResultsFile) {$ErrorMsg += "No-Valid-resultsXml "}
	 else { [xml]$Types = Get-Content $SDPpathResultsFile	#Select-Xml -Xml $Types -XPath "//ID"
		$SDPtype = $Types.SelectSingleNode("//ID")| ForEach-Object { $_.InnerText }
	 }
## foreach loop: processing per NodeName in Cluster report
$NodeCnt=0
foreach ($NodeName in $NodeNames) {
	$NodeCnt++
	if ($($NodeNames.count) -gt 1) {Write-Host -BackgroundColor Blue -ForegroundColor Cyan -NoNewline -Object "$($NodeCnt) " -Separator .
					Write-Host "$(Get-Date -UFormat "%R:%S") ___Node $NodeCnt $NodeName"}
	$DiffValKeys = ""
	Set-Variable -Name RegistryArray -Scope Script
	Set-Variable -Name prev_DiffRegistryArray -Scope Script
	Set-Variable -Name curr_DiffRegistryArray -Scope Script

	$RegistryArray = New-Object PSObject -Property @{
		ComputerName			= $Null
		SDPdate				= @()
		WARNmsg				= @()
		regFiles			= @()
		ignoredFiles			= @()
	 	TrailingIncorrectArray		= @()
	 	TrailingIncorrectFileArray	= @()
	 	LeadingIncorrectArray	 	= @()
	 	LeadingIncorrectFileArray	= @()
	 	RegNamesArray			= @()
	 	AllRegNamesArray		= @()
	 	RegKeyNameDiffValueArray 	= @()
	 	OSVersion			= $Null
	 	OSVersion_old			= $Null
		}

	# Add new dynamic variable with the name RegistryArray_$NodeName, for every Nodename
	# To access variable use: get-variable -Name "RegistryArray_$NodeName"
	new-variable -Name "RegistryArray_$NodeName" -Value $RegistryArray -Force
	#initialize

	### 1. Get OSversion (if not supplied by parent script)
	$result1 = GetOSfromMSinfo32_Ex $SDPPath $NodeName			# Call function
	if ($OSversion -NotMatch "undefined") {Write-Verbose "OSVersion in SDP report: $($RegistryArray.OSVersion) - ComputerName: $($NodeName)"}

	$regCheckFile = $SDPPath + '!'+$NodeName+'_R-E-G-Check_'+$RegistryArray.OSVersion+'.txt'

	### 2. Check if _reg_ files are relevant (Administrator has not disabled Registry editing )
	$result1a = CheckRegistryEditingDisabledSDP $SDPPath $NodeName		# Call function

	### 3. run the registry checks for keys with blank characters
	$BeginTimeBlankChar = Get-Date
		get-Reg-Check-Blank $SDPPath $NodeName			# Call function
	$endTimeBlankChar = Get-Date
	$DurationRegBlank=$(New-TimeSpan -Start $BeginTimeBlankChar -End $endTimeBlankChar)
	Write-debug "RegNamesArray: $($RegistryArray.RegNamesArray)"

	### 4. Compare-RegName-Value-vs-DefaultValue
	$BeginTimeRegCompare = Get-Date
		Write-Debug "..in main"
		#reduce nr of AllRegNamesArray by sorting unique
		Write-verbose "AllRegNamesArray Before: $($RegistryArray.AllRegNamesArray.count)"
		$RegistryArray.AllRegNamesArray = $RegistryArray.AllRegNamesArray | Sort-Object | Get-Unique
		Write-verbose "AllRegNamesArray After : $($RegistryArray.AllRegNamesArray.count)"
		Compare-RegName-Value-vs-DefaultValue $RegistryArray.AllRegNamesArray $NodeName	# Call function
	$endTimeRegCompare = Get-Date
	$DurationRegCompare =$(New-TimeSpan -Start $BeginTimeRegCompare -End $endTimeRegCompare)
	Write-Output "... see details in output file: $regCheckFile "

	### write onscreen summary
	Write-Output " => Table of different Registry settings:"
	if ($($NodeNames.count) -gt 1) { Write-Output "SUMMARY Node_#$($NodeCnt): $NodeName "}
	else { Write-Output "SUMMARY: $NodeName "}
	foreach ($Regkey in $RegistryArray.TrailingIncorrectArray) { $TrailingKeys += ($Regkey.RegName) }
	$TrailFileList = $RegistryArray.TrailingIncorrectFileArray -split (" ")
	Write-Debug "Trail: $($RegistryArray.TrailingIncorrectArray)"
	Write-Verbose "Trail: $($TrailingKeys)"
	$TrailingCnt = ($RegistryArray.TrailingIncorrectArray).count
	foreach ($Regkey in $RegistryArray.LeadingIncorrectArray) { $LeadingKeys += ($Regkey.RegName) }
	$LeadFileList= $RegistryArray.LeadingIncorrectFileArray -split (" ")
	Write-Debug "Lead : $($RegistryArray.LeadingIncorrectArray)"
	Write-Verbose "Lead : $($LeadingKeys)"
	$LeadingCnt = ($RegistryArray.LeadingIncorrectArray).count
	foreach ($Regkey in $RegistryArray.RegKeyNameDiffValueArray) { $DiffValKeys += " " + ($Regkey.RegName) }
	Write-Debug "Diff: $($RegistryArray.RegKeyNameDiffValueArray)"
	Write-Verbose "Diff: $($DiffValKeys)"
	$DiffValCnt = ($RegistryArray.RegKeyNameDiffValueArray).count
	If (($TrailingCnt) -or ($LeadingCnt))
		{ Write-Host -BackgroundColor Magenta -ForegroundColor Black -Object "- Found $($TrailingCnt + $LeadingCnt) inconsistent Registry Name entries with 'Trailing Space': $TrailingCnt - 'Leading Space': $LeadingCnt"
		 Write-Output " in ($($RegistryArray.TrailingIncorrectFileArray.count) + $($RegistryArray.LeadingIncorrectFileArray.count)) Registry File(s): `n"
		 Write-Output "- Trailing space (~): $TrailFileList "
		 $RegistryArray.TrailingIncorrectArray | Select-Object RegName,REG_type,RegValue,HKEY |Sort-Object HKEY,RegName| Format-Table -auto
		 Write-Output "- Leading space: $LeadFileList "
		 $RegistryArray.LeadingIncorrectArray | Select-Object RegName,REG_type,RegValue,HKEY |Sort-Object HKEY,RegName| Format-Table -auto
		 Write-Output "...check this inconsistency right away! `n => And if this is a false positive, inform script author WalterE for script enhancement. Thx!"
		}
	If ($DiffValCnt)
		{ Write-Host -BackgroundColor Yellow -ForegroundColor Black -Object "`n- Found $($DiffValCnt) registry key values different to default setting (compared only known keys):`n '$($DiffValKeys)'"
		}

	#If (($TrailingCnt) -or ($LeadingCnt) -or ($DiffValCnt)) {}#Write-Output "...open summary file with FavEditor"}
	#$RegistryArray | measure-object -property RegKeyNameDiffValueArray
	If (-not (($TrailingCnt) -or ($LeadingCnt) -or ($DiffValCnt))) {Write-Host -BackgroundColor Green -ForegroundColor Black -Object "$(Get-Date -UFormat "%R:%S") Reg-Compare: ...no issues found"}
	####################
	#Create Output file, Write to file
	"Registry Check Summary:" > $regCheckFile
	" SDP-date: $($RegistryArray.SDPdate) - OS-Version: $($RegistryArray.OSVersion) - Name: $($RegistryArray.ComputerName) $SdpOSbuild $SdpOSname" >> $regCheckFile
	" SDP-path: $SDPPath " >> $regCheckFile
	" SDP-type: $SDPtype $newline_Seperator" >> $regCheckFile
	" $CheckDate Found $($DiffValCnt) registry key values different to default setting (compared only known keys, see Appendix table below; listed in existing *reg* files of SDP report):" >> $regCheckFile
	" ** @engineer: if you are misssing any registry key in the Appendix table, please report to WalterE  **"
	" $($DiffValKeys) $newline_Seperator" >> $regCheckFile
	$RegistryArray.RegKeyNameDiffValueArray | Select-Object Component,RegName,REG_type,RegValue,DefaultValue,KBref,Comment |Sort-Object Component,RegName | Format-Table -auto| Out-file $regCheckFile -Append -Width $OutFileChars #Tee-Object -file $regCheckFile
	"Note:" +$RegistryArray.WARNmsg+ "$newline_Seperator" >> $regCheckFile

	## Write Registry Blank test
	if ($RegistryArray.TrailingIncorrectArray) {
		"- Trailing space (~): $newline_Seperator" >> $regCheckFile
		$RegistryArray.TrailingIncorrectFileArray >> $regCheckFile
	  $RegistryArray.TrailingIncorrectArray | Select-Object RegName,REG_type,RegValue,HKEY |Sort-Object HKEY,RegName| Format-Table -auto |Out-file $regCheckFile -Append -Encoding String -Width $OutFileChars
	  }
	if ($RegistryArray.LeadingIncorrectArray) {
		"- Leading space: $newline_Seperator" >> $regCheckFile
		$RegistryArray.LeadingIncorrectFileArray >> $regCheckFile
	  $RegistryArray.LeadingIncorrectArray | Select-Object RegName,REG_type,RegValue,HKEY |Sort-Object HKEY,RegName| Format-Table -auto |Out-file $regCheckFile -Append -Encoding String -Width $OutFileChars
	  }
	if ($RegistryArray.ignoredFiles) {
	#	"- ignored Reg Files (*.hiv or big *_reg_Print.txt): $newline_Seperator" >> $regCheckFile
		"- ignored Reg Files (*_reg_*.hiv, *_reg_Print*,*_reg_CurrentVersion*,*_reg_Component_Based*,*_reg_SideBySide*,*_reg_DriverDatabase*,*_reg_services*,*reg_Winevt*,*reg_Enum*): $newline_Seperator" >> $regCheckFile
		$RegistryArray.ignoredFiles >> $regCheckFile
	  }
	#Write-Output "Table of Registry settings (known keys), which are compared to def.value (last update: $($RegReferenceCsvFileReleaseDate)):"
	 "$newline_Seperator
	 APPENDIX: Table of Registry settings (known keys), which are compared to def.value (last update: $($RegReferenceCsvFileReleaseDate)):
	 Note: Registry key values different to default setting can only be detected if the key is listed in the collection of the SDP speciality report. $newline_Seperator" >> $regCheckFile
	 $DefaultRegValuesCsvFile1 = import-csv $RegReferenceCsvFile
	 $DefaultRegValuesCsvFile1 | Select-Object Component,RegName,REG_type,DefaultValue,KBref,Comment |Sort-Object Component,RegName | Format-Table -auto | Out-file $regCheckFile -Append -Encoding String -Width $OutFileChars

	$endTimeDurBlank = get-date

	#$DurNode = $endNode - $startNode
	Write-Host -BackgroundColor Blue -ForegroundColor Red -NoNewline -Object $RegistryArray.WARNmsg -Separator .
	Write-Host "Summary stored in file: $regCheckFile"

	#####################################
	# Save result of current Cluster node
	#new-variable -Name "myRegistryArray_$NodeName" -value $RegistryArray -Force
	$curr_DiffRegistryArray = $RegistryArray.RegKeyNameDiffValueArray
	#$curr_R = (get-variable -Name "myRegistryArray_$NodeName")

	if ($NodeCnt -gt 1) {
		Write-host "...Running Cluster nodes consistency check"
		if ($DbgOut) {	Write-host "$NodeName_Prev Prev:"
				$prev_DiffRegistryArray | Select-Object Component,RegName,RegValue,DefaultValue | Format-Table -auto}
		$PrevArr = $prev_DiffRegistryArray | Select-Object Component,RegName,RegValue,DefaultValue
		if ($DbgOut) {	Write-host "$NodeName Curr:"
				$curr_DiffRegistryArray | Select-Object Component,RegName,RegValue,DefaultValue | Format-Table -auto}
		$CurrArr = $curr_DiffRegistryArray | Select-Object Component,RegName,RegValue,DefaultValue
		 if ($CurrArr) {
			$Diffs = (Compare-Object ($PrevArr | ConvertTo-CSV) ($CurrArr | ConvertTo-CSV) -SyncWindow 20)
			if ($null -eq $Diffs) {Write-Host -BackgroundColor Green -ForegroundColor Black -Object "$(Get-Date -UFormat "%R:%S") $NodeName_Prev / $NodeName ClusterNode Reg-Compare-Arrays are equal"
				"- Checking for different reg settings in Cluster nodes: $newline_Seperator" >> $regCheckFile
				" $NodeName_Prev / $NodeName ClusterNode Reg-Compare-Arrays are equal" >> $regCheckFile }
			else {	##ToDo - also open FavEditor, if TrailingCnt or LeadingCnt
				Write-host -BackgroundColor Black -ForegroundColor Red -Object "$NodeName_Prev / $NodeName Differences:"
				$Diffs | Format-Table -auto
				## append in current $regCheckFile
				"- Checking for different reg settings in Cluster nodes: $newline_Seperator" >> $regCheckFile
				"$NodeName_Prev / $NodeName Differences:" >> $regCheckFile
				$Diffs | Format-Table -auto | Out-file $regCheckFile -Append -Encoding String -Width $OutFileChars
				### open output file with FavEditor
				If ((($Global:OpenSummary) -or ($OpenSummary)) -and (($TrailingCnt) -or ($LeadingCnt) -or ($DiffValCnt) -or ($RegistryArray.WARNmsg))) {
					Write-Host "... open output Summary file with FavEditor, because inconsistencies or differences were found for $NodeName."
					Invoke-Item $regCheckFile
				}
			}
		} #end if ($CurrArr)
	} #end if ($NodeCnt -gt 1)
	# save previous NodeName and DiffRegistryArray for next node loop
	$NodeName_Prev = $NodeName
	$prev_DiffRegistryArray = $curr_DiffRegistryArray

	### open output file with FavEditor
	If ((($Global:OpenSummary) -or ($OpenSummary)) -and ($NodeCnt -eq 1) -and (($TrailingCnt) -or ($LeadingCnt) -or ($DiffValCnt) -or ($RegistryArray.WARNmsg))) {
		Write-Host "... open output Summary file with FavEditor, because inconsistencies or differences were found."
		Invoke-Item $regCheckFile
	}
	#Write-Host -BackgroundColor Gray -ForegroundColor Black -Object "$(Get-Date -UFormat "%R:%S") $($NodeName) Done SDP Registry-check Script version v$verDateScript  took $DurNode"

} #end of foreach ($NodeName in $NodeNames) loop: processing per NodeName

$ScriptEndTimeStamp = Get-Date
$Duration = $(New-TimeSpan -Start $ScriptBeginTimeStamp -End $ScriptEndTimeStamp)

Write-Host -BackgroundColor Gray -ForegroundColor Black -Object "$(Get-Date -UFormat "%R:%S") Name(s): '$NodeNames' Done $scriptName version v$verDateScript took $Duration"
Write-output "`n"
#endregion ### ::main ##################################################################################

If ($Stats) {
 Try {"$j" + " ;$CheckDate; $($RegistryArray.OSVersion); $PSculture; " + ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name) + "; $($Duration)" + "; Trail: $TrailingCnt '$($TrailingKeys)' Lead: $LeadingCnt '$($LeadingKeys)' Diff: $DiffValCnt '$($DiffValKeys)'" + "; RegBlank: $($DurationRegBlank)" + "; RegComp: $($DurationRegCompare)" + "; Type: $($SDPtype)" + "; Err: $($ErrorMsgScript)" + "; $NodeCnt" + "; $SDPPath" + "; v$verDateScript " | Out-File $CountInvFil2 -Append -Encoding UTF8 -ErrorAction SilentlyContinue} Catch { }
 }
} #end Process


#http://blogs.technet.com/b/heyscriptingguy/archive/2011/02/18/speed-up-array-comparisons-in-powershell-with-a-runtime-regex.aspx
# $a = �red.�,�blue.�,�yellow.�,�green.�,�orange.�,�purple.�
# $b = �blue.�,�green.�,�orange.�,"white.","gray."
# [regex] $a_regex = �(?i)^(� + (($a |ForEach-Object{[regex]::escape($_)}) -join �|�) + �)$�
# $b -match $a_regex



# SIG # Begin signature block
# MIInvwYJKoZIhvcNAQcCoIInsDCCJ6wCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCC+zwjqelghUsi0
# CrEty/Cj5OhRRaDdnZQQ8iJBHnSWIaCCDXYwggX0MIID3KADAgECAhMzAAADTrU8
# esGEb+srAAAAAANOMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjMwMzE2MTg0MzI5WhcNMjQwMzE0MTg0MzI5WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDdCKiNI6IBFWuvJUmf6WdOJqZmIwYs5G7AJD5UbcL6tsC+EBPDbr36pFGo1bsU
# p53nRyFYnncoMg8FK0d8jLlw0lgexDDr7gicf2zOBFWqfv/nSLwzJFNP5W03DF/1
# 1oZ12rSFqGlm+O46cRjTDFBpMRCZZGddZlRBjivby0eI1VgTD1TvAdfBYQe82fhm
# WQkYR/lWmAK+vW/1+bO7jHaxXTNCxLIBW07F8PBjUcwFxxyfbe2mHB4h1L4U0Ofa
# +HX/aREQ7SqYZz59sXM2ySOfvYyIjnqSO80NGBaz5DvzIG88J0+BNhOu2jl6Dfcq
# jYQs1H/PMSQIK6E7lXDXSpXzAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUnMc7Zn/ukKBsBiWkwdNfsN5pdwAw
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzUwMDUxNjAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAD21v9pHoLdBSNlFAjmk
# mx4XxOZAPsVxxXbDyQv1+kGDe9XpgBnT1lXnx7JDpFMKBwAyIwdInmvhK9pGBa31
# TyeL3p7R2s0L8SABPPRJHAEk4NHpBXxHjm4TKjezAbSqqbgsy10Y7KApy+9UrKa2
# kGmsuASsk95PVm5vem7OmTs42vm0BJUU+JPQLg8Y/sdj3TtSfLYYZAaJwTAIgi7d
# hzn5hatLo7Dhz+4T+MrFd+6LUa2U3zr97QwzDthx+RP9/RZnur4inzSQsG5DCVIM
# pA1l2NWEA3KAca0tI2l6hQNYsaKL1kefdfHCrPxEry8onJjyGGv9YKoLv6AOO7Oh
# JEmbQlz/xksYG2N/JSOJ+QqYpGTEuYFYVWain7He6jgb41JbpOGKDdE/b+V2q/gX
# UgFe2gdwTpCDsvh8SMRoq1/BNXcr7iTAU38Vgr83iVtPYmFhZOVM0ULp/kKTVoir
# IpP2KCxT4OekOctt8grYnhJ16QMjmMv5o53hjNFXOxigkQWYzUO+6w50g0FAeFa8
# 5ugCCB6lXEk21FFB1FdIHpjSQf+LP/W2OV/HfhC3uTPgKbRtXo83TZYEudooyZ/A
# Vu08sibZ3MkGOJORLERNwKm2G7oqdOv4Qj8Z0JrGgMzj46NFKAxkLSpE5oHQYP1H
# tPx1lPfD7iNSbJsP6LiUHXH1MIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGZ8wghmbAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAANOtTx6wYRv6ysAAAAAA04wDQYJYIZIAWUDBAIB
# BQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIJv7LfNyNUkSYnttTjHUfdNg
# F9bJiNYkfyvLHQwZzCVsMEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEB
# BQAEggEASO0bcu09DEqTMKeQb9NLk/P2uJAm3o63oGeUJ4IMd2hVvg7KA0U6MvE6
# ryIE74a3XlocANwRU410uWKsUMlqzYPq97pobT5mRtCCwP71A1e1LpLl0rK8VqT1
# Cwbe+K/qZFrN3yphB3lCwvDaLHwMLrsscghAjazdGVrMYm5ey5qANmb4lLVcCMT9
# 2n64cu2sTb4G8qRs6ISmuOlOFcQuj8LN8kFmMIt9gU34rrXeQLUEEiuAS0nSofDy
# ind3Zpc5BMBNHVl3gNOo9mflp3eskonlaxcK7+CnIaAodIjgOSxVlafS1RU9hFM+
# bDs6P6zohL3EdkI6V143hbFTuO1UPKGCFykwghclBgorBgEEAYI3AwMBMYIXFTCC
# FxEGCSqGSIb3DQEHAqCCFwIwghb+AgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFZBgsq
# hkiG9w0BCRABBKCCAUgEggFEMIIBQAIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFl
# AwQCAQUABCAPox+HJnkkKDhV3m3Y6yAcGNqd3LOyQWzjOFlBVRQqWAIGZGzw6qvc
# GBMyMDIzMDYxNDE1NTkyNy4xODFaMASAAgH0oIHYpIHVMIHSMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJl
# bGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNO
# OjhENDEtNEJGNy1CM0I3MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNloIIReDCCBycwggUPoAMCAQICEzMAAAGz/iXOKRsbihwAAQAAAbMwDQYJ
# KoZIhvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjIw
# OTIwMjAyMjAzWhcNMjMxMjE0MjAyMjAzWjCB0jELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IElyZWxhbmQgT3Bl
# cmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjo4RDQxLTRC
# RjctQjNCNzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZTCC
# AiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBALR8D7rmGICuLLBggrK9je3h
# JSpc9CTwbra/4Kb2eu5DZR6oCgFtCbigMuMcY31QlHr/3kuWhHJ05n4+t377PHon
# dDDbz/dU+q/NfXSKr1pwU2OLylY0sw531VZ1sWAdyD2EQCEzTdLD4KJbC6wmACon
# iJBAqvhDyXxJ0Nuvlk74rdVEvribsDZxzClWEa4v62ENj/HyiCUX3MZGnY/AhDya
# zfpchDWoP6cJgNCSXmHV9XsJgXJ4l+AYAgaqAvN8N+EpN+0TErCgFOfwZV21cg7v
# genOV48gmG/EMf0LvRAeirxPUu+jNB3JSFbW1WU8Z5xsLEoNle35icdET+G3wDNm
# cSXlQYs4t94IWR541+PsUTkq0kmdP4/1O4GD54ZsJ5eUnLaawXOxxT1fgbWb9VRg
# 1Z4aspWpuL5gFwHa8UNMRxsKffor6qrXVVQ1OdJOS1JlevhpZlssSCVDodMc30I3
# fWezny6tNOofpfaPrtwJ0ukXcLD1yT+89u4uQB/rqUK6J7HpkNu0fR5M5xGtOch9
# nyncO9alorxDfiEdb6zeqtCfcbo46u+/rfsslcGSuJFzlwENnU+vQ+JJ6jJRUrB+
# mr51zWUMiWTLDVmhLd66//Da/YBjA0Bi0hcYuO/WctfWk/3x87ALbtqHAbk6i1cJ
# 8a2coieuj+9BASSjuXkBAgMBAAGjggFJMIIBRTAdBgNVHQ4EFgQU0BpdwlFnUgwY
# izhIIf9eBdyfw40wHwYDVR0jBBgwFoAUn6cVXQBeYl2D9OXSZacbUzUZ6XIwXwYD
# VR0fBFgwVjBUoFKgUIZOaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9j
# cmwvTWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3JsMGwG
# CCsGAQUFBwEBBGAwXjBcBggrBgEFBQcwAoZQaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNyb3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIw
# MjAxMCgxKS5jcnQwDAYDVR0TAQH/BAIwADAWBgNVHSUBAf8EDDAKBggrBgEFBQcD
# CDAOBgNVHQ8BAf8EBAMCB4AwDQYJKoZIhvcNAQELBQADggIBAFqGuzfOsAm4wAJf
# ERmJgWW0tNLLPk6VYj53+hBmUICsqGgj9oXNNatgCq+jHt03EiTzVhxteKWOLoTM
# x39cCcUJgDOQIH+GjuyjYVVdOCa9Fx6lI690/OBZFlz2DDuLpUBuo//v3e4Kns41
# 2mO3A6mDQkndxeJSsdBSbkKqccB7TC/muFOhzg39mfijGICc1kZziJE/6HdKCF8p
# 9+vs1yGUR5uzkIo+68q/n5kNt33hdaQ234VEh0wPSE+dCgpKRqfxgYsBT/5tXa3e
# 8TXyJlVoG9jwXBrKnSQb4+k19jHVB3wVUflnuANJRI9azWwqYFKDbZWkfQ8tpNoF
# fKKFRHbWomcodP1bVn7kKWUCTA8YG2RlTBtvrs3CqY3mADTJUig4ckN/MG6AIr8Q
# +ACmKBEm4OFpOcZMX0cxasopdgxM9aSdBusaJfZ3Itl3vC5C3RE97uURsVB2pvC+
# CnjFtt/PkY71l9UTHzUCO++M4hSGSzkfu+yBhXMGeBZqLXl9cffgYPcnRFjQT97G
# b/bg4ssLIFuNJNNAJub+IvxhomRrtWuB4SN935oMfvG5cEeZ7eyYpBZ4DbkvN44Z
# vER0EHRakL2xb1rrsj7c8I+auEqYztUpDnuq6BxpBIUAlF3UDJ0SMG5xqW/9hLMW
# naJCvIerEWTFm64jthAi0BDMwnCwMIIHcTCCBVmgAwIBAgITMwAAABXF52ueAptJ
# mQAAAAAAFTANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNh
# dGUgQXV0aG9yaXR5IDIwMTAwHhcNMjEwOTMwMTgyMjI1WhcNMzAwOTMwMTgzMjI1
# WjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQD
# Ex1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCCAiIwDQYJKoZIhvcNAQEB
# BQADggIPADCCAgoCggIBAOThpkzntHIhC3miy9ckeb0O1YLT/e6cBwfSqWxOdcjK
# NVf2AX9sSuDivbk+F2Az/1xPx2b3lVNxWuJ+Slr+uDZnhUYjDLWNE893MsAQGOhg
# fWpSg0S3po5GawcU88V29YZQ3MFEyHFcUTE3oAo4bo3t1w/YJlN8OWECesSq/XJp
# rx2rrPY2vjUmZNqYO7oaezOtgFt+jBAcnVL+tuhiJdxqD89d9P6OU8/W7IVWTe/d
# vI2k45GPsjksUZzpcGkNyjYtcI4xyDUoveO0hyTD4MmPfrVUj9z6BVWYbWg7mka9
# 7aSueik3rMvrg0XnRm7KMtXAhjBcTyziYrLNueKNiOSWrAFKu75xqRdbZ2De+JKR
# Hh09/SDPc31BmkZ1zcRfNN0Sidb9pSB9fvzZnkXftnIv231fgLrbqn427DZM9itu
# qBJR6L8FA6PRc6ZNN3SUHDSCD/AQ8rdHGO2n6Jl8P0zbr17C89XYcz1DTsEzOUyO
# ArxCaC4Q6oRRRuLRvWoYWmEBc8pnol7XKHYC4jMYctenIPDC+hIK12NvDMk2ZItb
# oKaDIV1fMHSRlJTYuVD5C4lh8zYGNRiER9vcG9H9stQcxWv2XFJRXRLbJbqvUAV6
# bMURHXLvjflSxIUXk8A8FdsaN8cIFRg/eKtFtvUeh17aj54WcmnGrnu3tz5q4i6t
# AgMBAAGjggHdMIIB2TASBgkrBgEEAYI3FQEEBQIDAQABMCMGCSsGAQQBgjcVAgQW
# BBQqp1L+ZMSavoKRPEY1Kc8Q/y8E7jAdBgNVHQ4EFgQUn6cVXQBeYl2D9OXSZacb
# UzUZ6XIwXAYDVR0gBFUwUzBRBgwrBgEEAYI3TIN9AQEwQTA/BggrBgEFBQcCARYz
# aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9Eb2NzL1JlcG9zaXRvcnku
# aHRtMBMGA1UdJQQMMAoGCCsGAQUFBwMIMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIA
# QwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFNX2
# VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwu
# bWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEw
# LTA2LTIzLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93
# d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYt
# MjMuY3J0MA0GCSqGSIb3DQEBCwUAA4ICAQCdVX38Kq3hLB9nATEkW+Geckv8qW/q
# XBS2Pk5HZHixBpOXPTEztTnXwnE2P9pkbHzQdTltuw8x5MKP+2zRoZQYIu7pZmc6
# U03dmLq2HnjYNi6cqYJWAAOwBb6J6Gngugnue99qb74py27YP0h1AdkY3m2CDPVt
# I1TkeFN1JFe53Z/zjj3G82jfZfakVqr3lbYoVSfQJL1AoL8ZthISEV09J+BAljis
# 9/kpicO8F7BUhUKz/AyeixmJ5/ALaoHCgRlCGVJ1ijbCHcNhcy4sa3tuPywJeBTp
# kbKpW99Jo3QMvOyRgNI95ko+ZjtPu4b6MhrZlvSP9pEB9s7GdP32THJvEKt1MMU0
# sHrYUP4KWN1APMdUbZ1jdEgssU5HLcEUBHG/ZPkkvnNtyo4JvbMBV0lUZNlz138e
# W0QBjloZkWsNn6Qo3GcZKCS6OEuabvshVGtqRRFHqfG3rsjoiV5PndLQTHa1V1QJ
# sWkBRH58oWFsc/4Ku+xBZj1p/cvBQUl+fpO+y/g75LcVv7TOPqUxUYS8vwLBgqJ7
# Fx0ViY1w/ue10CgaiQuPNtq6TPmb/wrpNPgkNWcr4A245oyZ1uEi6vAnQj0llOZ0
# dFtq0Z4+7X6gMTN9vMvpe784cETRkPHIqzqKOghif9lwY1NNje6CbaUFEMFxBmoQ
# tB1VM1izoXBm8qGCAtQwggI9AgEBMIIBAKGB2KSB1TCB0jELMAkGA1UEBhMCVVMx
# EzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoT
# FU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IElyZWxh
# bmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjo4
# RDQxLTRCRjctQjNCNzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2Vy
# dmljZaIjCgEBMAcGBSsOAwIaAxUAcYtE6JbdHhKlwkJeKoCV1JIkDmGggYMwgYCk
# fjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQD
# Ex1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUFAAIF
# AOgzxTAwIhgPMjAyMzA2MTQxMjQ4NDhaGA8yMDIzMDYxNTEyNDg0OFowdDA6Bgor
# BgEEAYRZCgQBMSwwKjAKAgUA6DPFMAIBADAHAgEAAgIFHjAHAgEAAgIU3jAKAgUA
# 6DUWsAIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAowCAIBAAID
# B6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBAEofLgEX7oaNu0mRSHfp
# FbDZi0sgmCJkr26dZcqybQFwDVgq5P3zKsesULxMyoeb3fF+5/v4gLrLRZjRCo+a
# QpTKhktVInNwTDP014+wa6iPHanURv2s/r9ogyL8R3Urn2vGrtjTctaCi+Up9sQx
# bw8hVrrZZpMq+BJStXRjCkyEMYIEDTCCBAkCAQEwgZMwfDELMAkGA1UEBhMCVVMx
# EzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoT
# FU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUt
# U3RhbXAgUENBIDIwMTACEzMAAAGz/iXOKRsbihwAAQAAAbMwDQYJYIZIAWUDBAIB
# BQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0BCQQx
# IgQgF26PvwrykTJ5xo6IL0cVmq44Wk0mi3dVbPly1mhjXOcwgfoGCyqGSIb3DQEJ
# EAIvMYHqMIHnMIHkMIG9BCCGoTPVKhDSB7ZG0zJQZUM2jk/ll1zJGh6KOhn76k+/
# QjCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAw
# DgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24x
# JjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAABs/4l
# zikbG4ocAAEAAAGzMCIEIOx5HDco6S041/+giRN96XU7fPKC1pu3hg6nwoknF3hP
# MA0GCSqGSIb3DQEBCwUABIICAAp0jzxPZiWvBhZGoSYR9MfoxZ9O7LVZ7GeBBmh+
# irU7+h97TuY1OqjI/VoYHDJ949+0wghbfY9ijEZNujacPf0jUOqMLrG439fRRXvW
# ItG+r0nm5R43C9YPpwFQk024K6WfAyjT1/m5FmaJobtD1jZbPgi8giHkB5pZXdis
# /P+wVzo3psVsTrV1BZZqcPRESkNcuJ8HEzCH2ESIicbb2RmTU1N841N/5EbUoDzk
# m3aTr473Ayz3yiGVhEN7/BaJIremVZs8/6VDah5alDneG+eoMAx80QY3WyLXRDCz
# J0JP2fTgYk+Q8UunBOihY+yx6hJfaCqYRaNApcznspmrnzGvpdB0EXxavvls6kz6
# dHv0o3/nNQpwnhmH9Al2LYAS0pjGkesXX0OTe6SXf6vDsQvrG+XGqov384hKAYXy
# yRdSwGiDXDLOZyNG1JQ8s+9YWgrLyKgY2gw7kFPqFZLOEvfqAXHeCAnpQlMtEVHF
# LvA8tHsIetqp9uemjwVhbvL95Aqnpn5TmnylisdvcTp5nm9TlHFGmpQdVtd5MnfO
# DQKgMynv9awh9/RJ8rW8WU4hgHwobNL/teA/3HkQ4IFjzvYYVQt5/yfw3Eq7GCGl
# FlYrvQpKjEgB1EKsdH/fXNNFmPkyyxUqnVa6Y0ABBq670JYlz6Pw0F78A5mO8n1s
# Ivh7
# SIG # End signature block
