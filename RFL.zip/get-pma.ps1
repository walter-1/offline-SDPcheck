<# last edit by: waltere 2020-01-10
  File Name: get-pma.ps1 - Performance Monitor Analyzer
  Objective: This script is intended to provide a high level summary of key counters utilized by the Performance team.
  Leveraging the pma.vbs script created by AustinM
  call script with -Verbose or -Debug for add. console output
  Help: get-help \\emeacssdfs\netpod\rfl\get-pma.ps1 -detailed

VERSION and AUTHORs:
    Ver 1.00 - 06.03.2016
	Walter Eder	- waltere@microsoft.com (this PS script, invoking pma.vbs)
	Austin Mack	- AustinM@microsoft.com (pma.vbs script Created by AustinM and StevePar)
	Steve Parr	- StevePar@microsoft.com (pma.vbs script Created by AustinM and StevePar)

#pma.vbs origin: http://toolbox/PMAVBS
'==========================================================================
Performance Monitor Analyzer v1.00
Analyzes a performance monitor log to provide a generic high level analysis

Author: Jeff Fanjoy, VMC Consulting (v-11jfan / JeffreyFan@vmc.com)

Many thanks to Austin Mack (austinm@microsoft.com) and Yong Rhee (yongrhee@microsoft.com)
for their assistance testing and making recommendations.

Purpose:
========
This script is intended to provide a high level summary of key counters utilized by the
Performance team. Reviewing Perfmons has long been time consuming in attempting to collect
data on items such as which process is the reason for a handle leak. In addition it has
always been time consuming to generate a report that is meaningful to both customers and
other individuals reviewing a case.

***** THIS SCRIPT IS NOT INTENDED TO REPLACE ANALYSIS OF A PERFORMANCE MONITOR LOG *****

My hope is that this script will alleviate the time consuming aspects of analyzing a perfmon
log and quickly identifying areas that should be have focus when performing the analysis.
'==========================================================================

HISTORY
	2015-02-07 v1.00 Note: running the pma.vbs script requires to ChangeDirectory into SDPpath
	2016-02-10 v1.00 using FQDN emeacssdfs.europe.corp.microsoft.com
	2016-03-23 v1.01 prepared to allow *.blg files in SDP folder (previously: "*_Performance Counter.blg", DCR by Eriq Stern)
	2016-03-24 	 fixed missing leading "!" of resulting out-file in vbs script
	2016-04-17 v1.02 adding OSversion
	2016-08-03 adding 2016RS1
	ToDo:

#>

<#
.SYNOPSIS
The script reads SDP report and displays Performance Monitor Analysis when the SDP report was created.

SYNTAX: .\get-pma.ps1 [full-path-to-expanded-SDP-report]

.DESCRIPTION
The script reads in the *_Performance Counter.blg file(s) from the SDP report and displays overview of Microsoft and 3rd party modules/drivers that were loaded in memory when the SDP report was created.
Note: Expand the SDP report cab file into folder before running this script.

'== HOW IT WORKS:
'==  Reads all the .TXT files created by CHECKSYM that are in the folder
'==  with the PSTAT file to get file version information. It then reads
'==  the modules loaded in memory listed at the bottom of the PSTAT.TXT
'==  file.

If you experience PS error '...is not digitally signed.' run the command:
 Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned

.PARAMETER OpenSummary
 This switch will not open resulting summary file with Notepad/Favorite Editor if set to $False
 
.EXAMPLE
\\emeacssdfs.europe.corp.microsoft.com\netpod\rfl\get-pma.ps1 \\ioanc00\temp\New_RFL\SDPs\FileServer

.LINK
\\emeacssdfs.europe.corp.microsoft.com\netpod\rfl\get-pma.ps1
ioanc@microsoft.com ; waltere@microsoft.com ;

#>

Param(
	[ValidateScript({Test-Path $_ -PathType 'Container'})]
	[Parameter(Mandatory=$True,Position=0,HelpMessage='Choose a writable SDP folder location, i.e. C:\SR\SDP-report\ ')]
	[string]$SDPPath,
	[ValidateSet("2008","2008R2","2012","2012R2","2016","2016RS1","2016RS2","2016RS3","2016RS4","2016RS5","201619H1","201619H2","20162004","201620H2","201621H1","201621H2","201622H2","2022","Win11","Win1122H2","help","")]
	[Parameter(Mandatory=$False,Position=1,HelpMessage='optional: Choose one OS from list: [2008|2008R2|2012|2012R2|2016|2016RS1|2016RS2|2016RS3|2016RS4|2016RS5|201619H1|201619H2|20162004|201620H2|201621H1|201621H2|201622H2|2022|Win11|Win1122H2]')]
	[string]$OSversion,
	[ValidateSet("Q","-q","-Q")]
	[Parameter(Mandatory=$False,Position=2,HelpMessage='optional: Choose -Q = quiet')]
	[string]$quiet = "-Q",	#NoPrompt
	[switch]$OpenSummary= $true		# open with Notepad/FavEditor
	)
	
Process
{
############################################################
## customization section of script
$InOfflineMode = $True		# for outsourcer or when not connected to MS network - offline-SDPcheck
	if (-Not $InOfflineMode) {
		$RFLpath = "\\emeacssdfs.europe.corp.microsoft.com\netpod\rfl\"
		if (Test-Connection -ComputerName waltere-vdi.europe.corp.microsoft.com -Quiet -Count 1) {[bool]$Stats=$True} else {[bool]$Stats=$False}
	} else { 
		$RFLpath = "\\localhost\ToolsShare\rfl\"
		$Stats = $False
	}
$pmaScript = $RFLpath + "pma.vbs"
############################################################

#$StatsServerPath="\\netpod.europe.corp.microsoft.com\upload\RFL\"
$StatsServerPath="\\waltere-vdi.europe.corp.microsoft.com\netpod\tools\RFL\"
$VerMa="1"
$VerMi="04"
$start = Get-Date
$CheckDate = (Get-Date).ToUniversalTime().ToString("yy-MM-dd_HH-mm-ss")
$CountInvFil = $StatsServerPath +'countPMA.dat'
$CountInvFil2 = $CountInvFil +'.us'
Set-Variable -Name ErrorMsgPMA -Scope Script -Force
#Set-Variable -Name OSVersion -value "" -Scope Script
If ($Stats) { #increment at start of script
 ($j=[int32](Get-Content $CountInvFil -TotalCount 1 -ErrorAction SilentlyContinue)) |out-null
 (++$j) | Set-Content $CountInvFil -ErrorAction SilentlyContinue
 }
If ($PSBoundParameters['Debug']) { $DebugPreference='Continue'}

### Trail SDPPath with \ and allow path with space character
if ($SDPPath.EndsWith("\")){$SDPPath="$SDPPath"}
else {$SDPPath="$SDPPath" +"\"}
If (-NOT (Test-Path $SDPPath -PathType 'Container')){Throw "$($SDPPath) is not a valid folder"}

###########################################################
### function Get-OS-from-MSinfo32* files
# Return: $OSVersion
function Get-OS-from-MSinfo32 ($SDPPath,$NodeName)
{
	write-debug "__enter Get-OS-from-MSinfo32($SDPPath,$NodeName)"
	### Validate user input of expanded SDP report and identify the number of msinfo32.txt files and the names of the computers $NodeNames (in Cluster Report)
	$msinfo32 = $SDPPath + $NodeName + '*msinfo*.txt' # Try .txt
	If (-NOT (Test-Path $msinfo32)) {
	 Write-Verbose "** $SDPPath without *msinfo32.txt"
	 $msinfo32 = $SDPPath + $NodeName + '*msinfo*.nfo' # Try .nfo
	 }
	 ### Get OS version from SDP report from msinfo.txt
	 If ("$msinfo32" -match ".txt"){
	  Write-Debug "...$NodeName Using msinfo32.txt = $msinfo32 "
	  #Read-in content from Msinfo file
	  if ($msinfo32file = get-childitem $msinfo32) {
	     Write-Debug "msinfo32file: $msinfo32file "
		 $SDPdate = $msinfo32file.LastWriteTime
		 Write-Verbose "`n$NodeName : SDP Date: $SDPdate"
		 $msinfo32 = Get-Content $msinfo32 -TotalCount 7
		 If ($msinfo32) {$OSbuild = $msinfo32[-1]
		 		$OSName = $msinfo32[-2];$OSName=$OSName.Split(" ",3)[2]
		 		$ComputerName = $msinfo32[1].Split("")[-1] }
   		 Else {$ErrorMsgRG += "No-Valid-MsI32txt "}
		 }
	 }
	 Else { # Get OS version from SDP report from msinfo.nfo / seems not to work for some localized OS
	  Write-Debug "...$NodeName Using msinfo32.nfo = $msinfo32 "
	  if ($msinfo32file = get-childitem $msinfo32) {
		$SDPdate = $msinfo32file.LastWriteTime
		Write-Verbose "`n$NodeName : SDP Date: $SDPdate"
		[xml]$nfo = Get-Content $msinfo32file
		$summary = $nfo.MSInfo.Category.Data.value
		If ($summary.'#cdata-section') {$OSbuild = $summary.'#cdata-section'[1]
		   				$OSName = $summary.'#cdata-section'[0]
		   				$computername = $summary.'#cdata-section'[4] }
   		Else {$ErrorMsgRG += "No-Valid-MsI32nfo "}
		}
	 } #end Else
	### match Build number in SDP report with OS short name
	if("$OSbuild" -match "2600"){$OSVersion_old="old-XP"}  		# Windows XP
	if("$OSbuild" -match "3790"){$OSVersion_old="old-2003"}  	# Windows 2003
	if("$OSbuild" -match "6001"){$OSVersion_old="old-2008-SP1"}  	# Windows Vista SP1
	if("$OSbuild" -match "6002|6003"){$OSVersion="2008"}  		# Windows Vista SP2
	if("$OSbuild" -match "7600"){$OSVersion_old="old-2008R2-RTM"} 	# Windows 7 RTM
	if("$OSbuild" -match "7601"){$OSVersion="2008R2"} 		# Windows 7
	if("$OSbuild" -match "9200"){$OSVersion="2012"}  		# Windows 8
	if("$OSbuild" -match "9600"){$OSVersion="2012R2"} 		# Windows 8.1
	if("$OSbuild" -match "10.0.10240"){$OSVersion="2016"} 		# Windows 10
	if("$OSbuild" -match "10.0.14393"){$OSVersion="2016RS1"} 	# Windows 10 RS1
	if("$OSbuild" -match "10.0.17763"){$OSVersion="2016RS5"} 	# Windows 10 RS5
	if("$OSbuild" -match "10.0.18363"){$OSVersion="201619H2"}	# Windows 10 19H2
	if("$OSbuild" -match "10.0.19041"){$OSVersion="20162004"} 	# Windows 10 2004 2020 April 2020 Update
	if("$OSbuild" -match "10.0.19042"){$OSVersion="201620H2"} 	# Windows 10 20H2 October 2020 Update
	if("$OSbuild" -match "10.0.19043"){$OSVersion="201621H1"} 	# Windows 10 21H1 April 2021 Update
	if("$OSbuild" -match "10.0.19044"){$OSVersion="201621H2"} 	# Windows 10 21H2 Oct 2021 Update
	if("$OSbuild" -match "10.0.19045"){$OSVersion="201622H2"} 	# Windows 10 22H2 Oct 2022 Update
	if("$OSbuild" -match "10.0.20348"){$OSVersion="2022"} 		# Windows Srv 2022
	if("$OSbuild" -match "10.0.22000"){$OSVersion="Win11"} 		# Windows 11
	if("$OSbuild" -match "10.0.22621"){$OSVersion="Win1122H2"}	# Windows 11 May 2022 Update

	Write-Verbose " SDP Date: $($SDPdate) / OS-Version: $($OSVersion) $($OSVersion_old)"
	Write-Verbose " SDP computer name: $ComputerName $OSbuild $OSName"
	$OSVersion
} # end function Get-OS-from-MSinfo32

### === main
"`n$(Get-Date -UFormat "%R:%S") ==PMA check==... runnning 'Performance Monitor Analyzer' based on data collected at time of the SDP report was created."
## change directory to $SDPPath as required by pma.vbs script
Push-Location
Set-Location $SDPPath


#$PerfCounterFiles = Get-Item -path ($SDPPath + "*_Performance Counter.blg") #_Performance Counter.blg
# allow more *.blg ?
$PerfCounterFiles = Get-Item -path ($SDPPath + "*.blg") # all *.blg files in given folder
$NodeNames = foreach ($NodeName in $PerfCounterFiles){($NodeName.name).split('_')[0]}
Write-Host "$(Get-Date -UFormat "%R:%S") ...NodeName(s): $NodeNames"

if (!$PerfCounterFiles) { Write-Host -BackgroundColor Black -ForegroundColor Red -Object "There is no *_Performance Counter.blg file in $SDPPath - Double-check SDP path again!"
			$ErrorMsgPMA += "No-Valid-PMA " }
$NodeCnt=0
foreach ($PerfCounterFile in $PerfCounterFiles){
	$NodeCnt++
	Write-Host -BackgroundColor Blue -ForegroundColor Cyan -NoNewline -Object "$($NodeCnt) " -Separator .
	$NodeName = ($PerfCounterFile.name).split('_')[0]
	Write-Verbose "OSVersion in script param1: $($OSVersion) "
	if (!$OSversion) {$OSVersion = Get-OS-from-MSinfo32 $SDPPath $NodeName}			# Call function
	Write-Verbose "OSVersion in SDP report: $($OSVersion) - ComputerName: $($NodeName)"
	if ($($NodeCnt) -lt 32) {
		if ($NodeNames.count -gt 1) {Write-Host "Node $NodeName $NodeCnt of $($NodeNames.count)"}
		& wscript.exe $pmaScript $PerfCounterFile $quiet
		"$NodeName => Output file will be saved to: $($SDPPath)!$($Nodename)_Performance Counter-PMA-Summary.TXT "
	}
	else {Write-Host "$(Get-Date -UFormat "%R:%S") ...checked only first 32 nodes" }
}

If (($Global:OpenSummary) -or ($OpenSummary)) {
	"`nUsing favorite editor to open PMA Report(s) - this could take a few seconds until your Text Editor opens with results ..."
	#" => Output file saved to: $($SDPPath)!$Nodename_Performance Counter-PMA-Summary.TXT"
	}
$end = Get-Date
Write-Host -BackgroundColor Gray -ForegroundColor Black -Object "$(Get-Date -UFormat "%R:%S") Done Get-pma script version v$VerMa.$VerMi took $($end - $start) `n"

Pop-Location

### Stats
$Duration = $end - $start
If ($Stats) { #increment at start of script
 "$j" + " ;$CheckDate" + "; $OSVersion; " + ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name) + "; $($Duration)" + "; $NodeCnt" + "; $SDPPath" + "; $ErrorMsgPMA" + "; v$VerMa.$VerMi" | Out-File $CountInvFil2 -Append -Encoding UTF8 -ErrorAction SilentlyContinue
 }
}

