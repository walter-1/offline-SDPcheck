<# last edit by: waltere
  File Name: get-pma.ps1 - Performance Monitor Analyzer
  Objective: This script is intended to provide a high level summary of key counters utilized by the Performance team.
  Leveraging the pma.vbs script created by AustinM
  call script with -Verbose or -Debug for add. console output
  Help: get-help \\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\get-pma.ps1 -detailed

VERSION and AUTHORs:
    Ver 1.00 - 06.03.2016
	Walter Eder	- waltere@microsoft.com (this PS script, invoking pma.vbs)
	Austin Mack	- AustinM@microsoft.com (pma.vbs script Created by AustinM and StevePar)
	Steve Parr	- StevePar@microsoft.com (pma.vbs script Created by AustinM and StevePar)

#pma.vbs origin: https://dev.azure.com/mscodehub/Codebox/_git/PMAVBS?version=GBmaster
'==========================================================================
Performance Monitor Analyzer v1.00
Analyzes a performance monitor log to provide a generic high level analysis

Author: Jeff Fanjoy, VMC Consulting (v-11jfan / JeffreyFan@vmc.com)
Current Owner:   Steve Parr, Microsoft Corp. (stevepar@microsoft.com)

Many thanks to Austin Mack (austinm@microsoft.com) and Yong Rhee (yongrhee@microsoft.com)
for their assistance testing and making recommendations.

Purpose:
========
This script is intended to provide a high level summary of key counters utilized by the
Performance team. Reviewing Perfmons has long been time consuming in attempting to collect
data on items such as which process is the reason for a handle leak. In addition it has
always been time consuming to generate a report that is meaningful to both customers and
other individuals reviewing a case.

***** THIS SCRIPT IS NOT INTENDED TO REPLACE ANALYSIS OF A PERFORMANCE MONITOR LOG *****

My hope is that this script will alleviate the time consuming aspects of analyzing a perfmon
log and quickly identifying areas that should be have focus when performing the analysis.
'==========================================================================

HISTORY
	2015-02-07 v1.00 Note: running the pma.vbs script requires to ChangeDirectory into SDPpath
	2016-03-23 v1.01 prepared to allow *.blg files in SDP folder (previously: "*_Performance Counter.blg", DCR by Eriq Stern)
	2016-03-24 	 fixed missing leading "!" of resulting out-file in vbs script
	2016-04-17 v1.02 adding OSversion
	2016-08-03 adding 2016RS1
	2022-09-08 using Utils_RflShared.psm1 library
	2023-01-07 fix OSversion short name
	ToDo:

#>

<#
.SYNOPSIS
The script reads a .blg file from a given folder and is intended to provide a high level summary of key counters utilized by the Performance team.

SYNTAX: .\get-pma.ps1 [full-path-to-expanded-SDP-report]

.DESCRIPTION
The script reads in the Performance Counter *.blg file(s) from a folder and displays a high level summary of key counters utilized by the Performance team. 


If you experience PS error '...is not digitally signed.' run the command:
 Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned

.PARAMETER OpenSummary
 This switch will not open resulting summary file with Notepad/Favorite Editor if set to $False
 
.EXAMPLE
\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\get-pma.ps1 \\waltere-ws10\data\Folder-with-Blg

.LINK
\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\get-pma.ps1
waltere@microsoft.com ;

#>

[CmdletBinding()]
PARAM (
	[ValidateScript({Test-Path $_ -PathType 'Container'})]
	[Parameter(Mandatory=$True,Position=0,HelpMessage='Choose a writable SDP folder location, i.e. C:\SR\SDP-report\ ')]
	[string]$SDPPath,				# Folder path to *.blg file(s)
	[ValidateSet("2008","2008R2","2012","2012R2","2016","2016RS1","2016RS2","2016RS3","2016RS4","2016RS5","201619H1","201619H2","20162004","201620H2","201621H1","201621H2","201622H2","2022","Win11","Win1122H2","Win1123H1","help","unknown")]
	[Parameter(Mandatory=$False,Position=1,HelpMessage='optional: Choose one OS from list: [2008|2008R2|2012|2012R2|2016|2016RS1|2016RS2|2016RS3|2016RS4|2016RS5|201619H1|201619H2|20162004|201620H2|201621H1|201621H2|201622H2|2022|Win11|Win1122H2|Win1123H1]')]
	[string]$OSversion,				# optional, if not supplied script will try to get OS version from MSinfo
	[ValidateSet("Q","-q","-Q")]
	[Parameter(Mandatory=$False,Position=2,HelpMessage='optional: Choose -Q = quiet')]
	[string]$quiet = "-Q",	#NoPrompt
	[switch]$OpenSummary= $true		# open with Notepad/FavEditor
	)
	
Process
{
	$verDateScript = "2023.02.09.0"
	$ScriptFolder = Split-Path $MyInvocation.MyCommand.Path -Parent
	# Load Common Library:
	. $ScriptFolder\Utils_RflShared.ps1

	$scriptName = $invocation.MyCommand.Name
	
#region: ###### customization section of script, logging configuration ########################
	$SDPcheckINI = (Get-content -Path "$ScriptFolder\_SDPcheck.ini")
	$InOfflineMode 	= (($SDPcheckINI[1] -split " ")[2]).trim("""")	# set $True for outsourcer or when not connected to MS network - offline-SDPcheck
	$RFLroot = (($SDPcheckINI[2] -split " ")[2]).trim("""")	# "\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\" -or- "\\localhost\ToolsShare\rfl\"
	if ($InOfflineMode -match "False") {
		$StatsServer = (($SDPcheckINI[5] -split " ")[2]).trim("""")
		if (Test-Connection -ComputerName $StatsServer -Quiet -Count 1) {[bool]$Stats=$True} else {[bool]$Stats=$False}
	} else { 
		$Stats = $False
	}
	$pmaScript = $RFLroot + "\pma.vbs"
#endregion: ###### customization section

	$ScriptBeginTimeStamp = Get-Date
	$CheckDate = (Get-Date).ToUniversalTime().ToString("yy-MM-dd_HH-mm-ss")
	if ($Stats) {
		$StatsServerPath="\\$StatsServer\RFLstats$\RFL\scripts\Stats\"
		$CountInvFil = $StatsServerPath +'countPMA.dat'
		$CountInvFil2 = $CountInvFil +'.us'
		#increment at start of script
		 ($j=[int32](Get-Content $CountInvFil -TotalCount 1 -ErrorAction SilentlyContinue)) |out-null
		 Try {(++$j) | Set-Content $CountInvFil -ErrorAction SilentlyContinue} Catch { }
	}
	Set-Variable -Name ErrorMsgScript -Scope Script -Force
	If ($PSBoundParameters['Debug']) { $DebugPreference='Continue'}

	### Trail SDPPath with \ and allow path with space character
	if ($SDPPath.EndsWith("\")){$SDPPath="$SDPPath"}
	else {$SDPPath="$SDPPath" +"\"}
	If (-NOT (Test-Path $SDPPath -PathType 'Container')){Throw "$($SDPPath) is not a valid folder"}


	### === main
	"`n$(Get-Date -UFormat "%R:%S") ==PMA check==... runnning 'Performance Monitor Analyzer' for *.blg in folder $SDPPath"
	## change directory to $SDPPath as required by pma.vbs script
	Push-Location
	Set-Location $SDPPath

	$PerfCounterFiles = Get-Item -path ($SDPPath + "*.blg") # all *.blg files in given folder, i.e. *_Performance Counter.blg
	$NodeNames = foreach ($NodeName in $PerfCounterFiles){($NodeName.name).split('_')[0]}
	Write-Host "$(Get-Date -UFormat "%R:%S") NodeName(s): $NodeNames"

	if (!$PerfCounterFiles) { Write-Host -BackgroundColor Black -ForegroundColor Red -Object "There is no *_Performance Counter.blg file in $SDPPath - Double-check SDP path again!"
				$ErrorMsgScript += "No-Valid-PMA " }
	$NodeCnt=0
	foreach ($PerfCounterFile in $PerfCounterFiles){
		$NodeCnt++
		Write-Host -BackgroundColor Blue -ForegroundColor Cyan -NoNewline -Object "$($NodeCnt) " -Separator .
		$NodeName = ($PerfCounterFile.name).split('_')[0]
		Write-Verbose "OSVersion in script param1: $($OSVersion) "

		if ($($NodeCnt) -lt 32) {
			if ($NodeNames.count -gt 1) {Write-Host "Node $NodeName $NodeCnt of $($NodeNames.count)"}
			if (!$OSversion) {
				try {
					$OSVersion = GetOSfromMSinfo32 $SDPPath $NodeName			# Call function
				}
				catch {
					if ([String]::IsNullOrEmpty($OSversion)) {$OSVersion="unknown"}
				}
			}
			#Write-Host "OSVersion in SDP report: $($OSVersion) - ComputerName: $($NodeName)"
			Write-Verbose "OSVersion in SDP report: $($OSVersion) - ComputerName: $($NodeName)"			
			& wscript.exe $pmaScript $PerfCounterFile $quiet
			"=> Output file will be saved to: $($SDPPath)!$($Nodename)_Performance Counter-PMA-Summary.TXT "
		}
		else {Write-Host "$(Get-Date -UFormat "%R:%S") ...checked only first 32 nodes" }
	}

	If (($Global:OpenSummary) -or ($OpenSummary)) {
		"`nUsing favorite editor to open PMA Report(s) - this could take a few seconds until your Text Editor opens with results ..."
	}
	$ScriptEndTimeStamp = Get-Date
	$Duration = $(New-TimeSpan -Start $ScriptBeginTimeStamp -End $ScriptEndTimeStamp)
	Write-Host -BackgroundColor Gray -ForegroundColor Black -Object "$(Get-Date -UFormat "%R:%S") Done $scriptName version v$verDateScript took $Duration `n"

	Pop-Location

	### Stats
	If ($Stats) { #increment at start of script
	 Try {"$j" + " ;$CheckDate" + "; $OSVersion; " + ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name) + "; $($Duration)" + "; $NodeCnt" + "; $SDPPath" + "; $ErrorMsgScript" + "; v$verDateScript " | Out-File $CountInvFil2 -Append -Encoding UTF8 -ErrorAction SilentlyContinue} Catch { }
	}
}



# SIG # Begin signature block
# MIIn0QYJKoZIhvcNAQcCoIInwjCCJ74CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAYHNLuYHmsIf5z
# 5ggvs7FkAI/38M8G96IMoLSYeAnWGaCCDYUwggYDMIID66ADAgECAhMzAAADTU6R
# phoosHiPAAAAAANNMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjMwMzE2MTg0MzI4WhcNMjQwMzE0MTg0MzI4WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDUKPcKGVa6cboGQU03ONbUKyl4WpH6Q2Xo9cP3RhXTOa6C6THltd2RfnjlUQG+
# Mwoy93iGmGKEMF/jyO2XdiwMP427j90C/PMY/d5vY31sx+udtbif7GCJ7jJ1vLzd
# j28zV4r0FGG6yEv+tUNelTIsFmmSb0FUiJtU4r5sfCThvg8dI/F9Hh6xMZoVti+k
# bVla+hlG8bf4s00VTw4uAZhjGTFCYFRytKJ3/mteg2qnwvHDOgV7QSdV5dWdd0+x
# zcuG0qgd3oCCAjH8ZmjmowkHUe4dUmbcZfXsgWlOfc6DG7JS+DeJak1DvabamYqH
# g1AUeZ0+skpkwrKwXTFwBRltAgMBAAGjggGCMIIBfjAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUId2Img2Sp05U6XI04jli2KohL+8w
# VAYDVR0RBE0wS6RJMEcxLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJh
# dGlvbnMgTGltaXRlZDEWMBQGA1UEBRMNMjMwMDEyKzUwMDUxNzAfBgNVHSMEGDAW
# gBRIbmTlUAXTgqoXNzcitW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8v
# d3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIw
# MTEtMDctMDguY3JsMGEGCCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDEx
# XzIwMTEtMDctMDguY3J0MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIB
# ACMET8WuzLrDwexuTUZe9v2xrW8WGUPRQVmyJ1b/BzKYBZ5aU4Qvh5LzZe9jOExD
# YUlKb/Y73lqIIfUcEO/6W3b+7t1P9m9M1xPrZv5cfnSCguooPDq4rQe/iCdNDwHT
# 6XYW6yetxTJMOo4tUDbSS0YiZr7Mab2wkjgNFa0jRFheS9daTS1oJ/z5bNlGinxq
# 2v8azSP/GcH/t8eTrHQfcax3WbPELoGHIbryrSUaOCphsnCNUqUN5FbEMlat5MuY
# 94rGMJnq1IEd6S8ngK6C8E9SWpGEO3NDa0NlAViorpGfI0NYIbdynyOB846aWAjN
# fgThIcdzdWFvAl/6ktWXLETn8u/lYQyWGmul3yz+w06puIPD9p4KPiWBkCesKDHv
# XLrT3BbLZ8dKqSOV8DtzLFAfc9qAsNiG8EoathluJBsbyFbpebadKlErFidAX8KE
# usk8htHqiSkNxydamL/tKfx3V/vDAoQE59ysv4r3pE+zdyfMairvkFNNw7cPn1kH
# Gcww9dFSY2QwAxhMzmoM0G+M+YvBnBu5wjfxNrMRilRbxM6Cj9hKFh0YTwba6M7z
# ntHHpX3d+nabjFm/TnMRROOgIXJzYbzKKaO2g1kWeyG2QtvIR147zlrbQD4X10Ab
# rRg9CpwW7xYxywezj+iNAc+QmFzR94dzJkEPUSCJPsTFMIIHejCCBWKgAwIBAgIK
# YQ6Q0gAAAAAAAzANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlm
# aWNhdGUgQXV0aG9yaXR5IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEw
# OTA5WjB+MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYD
# VQQDEx9NaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG
# 9w0BAQEFAAOCAg8AMIICCgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+la
# UKq4BjgaBEm6f8MMHt03a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc
# 6Whe0t+bU7IKLMOv2akrrnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4D
# dato88tt8zpcoRb0RrrgOGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+
# lD3v++MrWhAfTVYoonpy4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nk
# kDstrjNYxbc+/jLTswM9sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6
# A4aN91/w0FK/jJSHvMAhdCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmd
# X4jiJV3TIUs+UsS1Vz8kA/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL
# 5zmhD+kjSbwYuER8ReTBw3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zd
# sGbiwZeBe+3W7UvnSSmnEyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3
# T8HhhUSJxAlMxdSlQy90lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS
# 4NaIjAsCAwEAAaOCAe0wggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRI
# bmTlUAXTgqoXNzcitW2oynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTAL
# BgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBD
# uRQFTuHqp8cx0SOJNDBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jv
# c29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3JsMF4GCCsGAQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3J0MIGfBgNVHSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEF
# BQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1h
# cnljcHMuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkA
# YwB5AF8AcwB0AGEAdABlAG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn
# 8oalmOBUeRou09h0ZyKbC5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7
# v0epo/Np22O/IjWll11lhJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0b
# pdS1HXeUOeLpZMlEPXh6I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/
# KmtYSWMfCWluWpiW5IP0wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvy
# CInWH8MyGOLwxS3OW560STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBp
# mLJZiWhub6e3dMNABQamASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJi
# hsMdYzaXht/a8/jyFqGaJ+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYb
# BL7fQccOKO7eZS/sl/ahXJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbS
# oqKfenoi+kiVH6v7RyOA9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sL
# gOppO6/8MO0ETI7f33VtY5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtX
# cVZOSEXAQsmbdlsKgEhr/Xmfwb1tbWrJUnMTDXpQzTGCGaIwghmeAgEBMIGVMH4x
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01p
# Y3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTECEzMAAANNTpGmGiiweI8AAAAA
# A00wDQYJYIZIAWUDBAIBBQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQw
# HAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIEFm
# DRpeDF8iusBACjG9i1EcldS27pjytRWZW70I/kySMEIGCisGAQQBgjcCAQwxNDAy
# oBSAEgBNAGkAYwByAG8AcwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20wDQYJKoZIhvcNAQEBBQAEggEAKqPj9qYlOsSx8+ylddiTNJOz7nZRCXysD3cg
# Pm2GXI0aujKoLTvw2XKWOLtESJEqQplWNh8sb+7dwDMcxB3wh1Z2KHkDHG552oz8
# aa92pcThp2XUUpbS97R9PAe1mHHPZye+jGKrlaauy7Tl54SNWYcdiBwJf+NR8jg0
# NiJhnoWD69ZCN+vmTKhopS02wOHm8agJPV7kXgO8akvqOtcNzJYQYjtOMqJ/2gkp
# VJ6zJgXs5M0v9xr7v1D+ChxjOE7LdOTlgGcuN9sZ5LVFCWph7WOdo/sSdHaZG2s6
# JKet5NsQqBtYAS4+pp/AZSFDs6Cg1sUfCPbLFx1TX7VEML1OuaGCFywwghcoBgor
# BgEEAYI3AwMBMYIXGDCCFxQGCSqGSIb3DQEHAqCCFwUwghcBAgEDMQ8wDQYJYIZI
# AWUDBAIBBQAwggFZBgsqhkiG9w0BCRABBKCCAUgEggFEMIIBQAIBAQYKKwYBBAGE
# WQoDATAxMA0GCWCGSAFlAwQCAQUABCDfr6QXY94KKCmn4CSP64UVzX/fSpnqwQ7D
# dZBDrpfm1gIGZHdGGPtdGBMyMDIzMDYxNDE1NTkxNy42MTJaMASAAgH0oIHYpIHV
# MIHSMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQL
# EyRNaWNyb3NvZnQgSXJlbGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsT
# HVRoYWxlcyBUU1MgRVNOOjNCRDQtNEI4MC02OUMzMSUwIwYDVQQDExxNaWNyb3Nv
# ZnQgVGltZS1TdGFtcCBTZXJ2aWNloIIRezCCBycwggUPoAMCAQICEzMAAAG0+4AI
# RAXSLfoAAQAAAbQwDQYJKoZIhvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# UENBIDIwMTAwHhcNMjIwOTIwMjAyMjA5WhcNMjMxMjE0MjAyMjA5WjCB0jELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9z
# b2Z0IElyZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMg
# VFNTIEVTTjozQkQ0LTRCODAtNjlDMzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUt
# U3RhbXAgU2VydmljZTCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBALRH
# pp5lBzJCH7zortuyvOmW8FoZLBsFe9g5dbhnaq9qSpvpn86E/mJ4JKvWixH/lw7Q
# A8gPtiiGVNIjvFhu/XiY889vX5WaQSmyoPMZdj9zvXa5XrkMN05zXzTePkCIIzF6
# RN7cTxezOyESymTIjrdxX5BVlZolyQAOxNziMCYKYYNPbYd0786fDE/PhzrRt23a
# 0Xf8trvFa0LEEy2YlcE2eqg2CjU/D0GZe8Ra0kjt0M12vdS4qWZ2Dpd7IhiQwnnt
# QWu19Ytd3UBR8SpeRX+Ccw3bjgWfOXtla6chctWt2shlMwayMOfY4TG4yMPWFXEL
# fZFFp7cgpjZNeVsmwkvoV6RAwy1Y9V+VvbJ5qFtartN/rp6a0I1kGlbjuwX3L0HT
# VXcikqgHistXk9h3HOZ9WgFXlxZurG1SZmcz0BEEdya+1vGHE45KguYU9qq2LiHG
# Bjn9z4+DqnV5tUKobsLbJMb4r+8st2fj8SacSsftnusxkWqEJiJS34P2uNlzVR03
# +ls6+ZO0NcO79LgP7BbIMipiOx8yh19PMQw0piaKFwOW7Q+gdJcfy6rOkG+CrYZw
# OzdiBHSebIzCIch2cAa+38w7JFP/koKdlJ36qzdVXWv4G/qZpWycIvDKYbxJWM40
# +z2Stg5uHqK3I8e09kFXtxCHpS7hm8c8m25WaEU5AgMBAAGjggFJMIIBRTAdBgNV
# HQ4EFgQUy0SF5fGUuDqcuxIot07eOMwy2X4wHwYDVR0jBBgwFoAUn6cVXQBeYl2D
# 9OXSZacbUzUZ6XIwXwYDVR0fBFgwVjBUoFKgUIZOaHR0cDovL3d3dy5taWNyb3Nv
# ZnQuY29tL3BraW9wcy9jcmwvTWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUy
# MDIwMTAoMSkuY3JsMGwGCCsGAQUFBwEBBGAwXjBcBggrBgEFBQcwAoZQaHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0cy9NaWNyb3NvZnQlMjBUaW1l
# LVN0YW1wJTIwUENBJTIwMjAxMCgxKS5jcnQwDAYDVR0TAQH/BAIwADAWBgNVHSUB
# Af8EDDAKBggrBgEFBQcDCDAOBgNVHQ8BAf8EBAMCB4AwDQYJKoZIhvcNAQELBQAD
# ggIBABLRDwWMKbeCYqEqtI6Bs8KmF+kqDR+2G6qYAK3ZZ63bert7pCkRJbihFakt
# l2o18cdFJFxnOF4vXadm0sabskJ05KviEMJIO6dXSq8AGtr3Zmjc895q0mnlBLuN
# Mgk4R8KrkJMHqBuHqkUWXtfTrVUpgwzQt2UOiINKs+/b4r14MuXRVpOJ6cQOS8Uh
# keMAWl2iLlYaBGtOr3f/f9mLEPfWwoke0sSUbdV60OZCRh1ItBYYM9efKr14H5qu
# 6jan6n00prEEa7W3uGb/1/qj6P5emnvkqy5HI0X69DjVdLxVbjSsegm/dA+S4DaX
# PcfFf6iBxK/iV21l1upgEVVajUApl5VR40wY4XF8EpmnUdTqLXDf7CqdhDjPST2K
# /OjvWPyQGQvc7oPapYyk66GU32AOyyHXJj6+vbtRUg/+ory+h0R2Xf5NhC+xbWcM
# zXEUXRRf1YKZDsRyH6r412pm8KDKE/r7Rk7aoKK7oYUpNGzNRf6QaYv5z2bVTSxk
# zWivFrepLHGwvRun9PYM/8AQSTgZr0yzzjk/97WghkqCaAwAVpyvg3uaYnuCl/Ac
# cSkGyb8c+70bFSeUephsfgb2r+QI7Mb2WcOnkJpCNLz0XJMS/UwlQn1ktLsiCpsq
# Ok3aLJ2wTv6LK3u69I0vQB/LKRKlZYRXKUDXzoPwr3UtsTVTMIIHcTCCBVmgAwIB
# AgITMwAAABXF52ueAptJmQAAAAAAFTANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0
# IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTAwHhcNMjEwOTMwMTgyMjI1
# WhcNMzAwOTMwMTgzMjI1WjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGlu
# Z3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBv
# cmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCC
# AiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAOThpkzntHIhC3miy9ckeb0O
# 1YLT/e6cBwfSqWxOdcjKNVf2AX9sSuDivbk+F2Az/1xPx2b3lVNxWuJ+Slr+uDZn
# hUYjDLWNE893MsAQGOhgfWpSg0S3po5GawcU88V29YZQ3MFEyHFcUTE3oAo4bo3t
# 1w/YJlN8OWECesSq/XJprx2rrPY2vjUmZNqYO7oaezOtgFt+jBAcnVL+tuhiJdxq
# D89d9P6OU8/W7IVWTe/dvI2k45GPsjksUZzpcGkNyjYtcI4xyDUoveO0hyTD4MmP
# frVUj9z6BVWYbWg7mka97aSueik3rMvrg0XnRm7KMtXAhjBcTyziYrLNueKNiOSW
# rAFKu75xqRdbZ2De+JKRHh09/SDPc31BmkZ1zcRfNN0Sidb9pSB9fvzZnkXftnIv
# 231fgLrbqn427DZM9ituqBJR6L8FA6PRc6ZNN3SUHDSCD/AQ8rdHGO2n6Jl8P0zb
# r17C89XYcz1DTsEzOUyOArxCaC4Q6oRRRuLRvWoYWmEBc8pnol7XKHYC4jMYcten
# IPDC+hIK12NvDMk2ZItboKaDIV1fMHSRlJTYuVD5C4lh8zYGNRiER9vcG9H9stQc
# xWv2XFJRXRLbJbqvUAV6bMURHXLvjflSxIUXk8A8FdsaN8cIFRg/eKtFtvUeh17a
# j54WcmnGrnu3tz5q4i6tAgMBAAGjggHdMIIB2TASBgkrBgEEAYI3FQEEBQIDAQAB
# MCMGCSsGAQQBgjcVAgQWBBQqp1L+ZMSavoKRPEY1Kc8Q/y8E7jAdBgNVHQ4EFgQU
# n6cVXQBeYl2D9OXSZacbUzUZ6XIwXAYDVR0gBFUwUzBRBgwrBgEEAYI3TIN9AQEw
# QTA/BggrBgEFBQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9E
# b2NzL1JlcG9zaXRvcnkuaHRtMBMGA1UdJQQMMAoGCCsGAQUFBwMIMBkGCSsGAQQB
# gjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/
# MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1UdHwRPME0wS6BJ
# oEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01p
# Y1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYB
# BQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljUm9v
# Q2VyQXV0XzIwMTAtMDYtMjMuY3J0MA0GCSqGSIb3DQEBCwUAA4ICAQCdVX38Kq3h
# LB9nATEkW+Geckv8qW/qXBS2Pk5HZHixBpOXPTEztTnXwnE2P9pkbHzQdTltuw8x
# 5MKP+2zRoZQYIu7pZmc6U03dmLq2HnjYNi6cqYJWAAOwBb6J6Gngugnue99qb74p
# y27YP0h1AdkY3m2CDPVtI1TkeFN1JFe53Z/zjj3G82jfZfakVqr3lbYoVSfQJL1A
# oL8ZthISEV09J+BAljis9/kpicO8F7BUhUKz/AyeixmJ5/ALaoHCgRlCGVJ1ijbC
# HcNhcy4sa3tuPywJeBTpkbKpW99Jo3QMvOyRgNI95ko+ZjtPu4b6MhrZlvSP9pEB
# 9s7GdP32THJvEKt1MMU0sHrYUP4KWN1APMdUbZ1jdEgssU5HLcEUBHG/ZPkkvnNt
# yo4JvbMBV0lUZNlz138eW0QBjloZkWsNn6Qo3GcZKCS6OEuabvshVGtqRRFHqfG3
# rsjoiV5PndLQTHa1V1QJsWkBRH58oWFsc/4Ku+xBZj1p/cvBQUl+fpO+y/g75LcV
# v7TOPqUxUYS8vwLBgqJ7Fx0ViY1w/ue10CgaiQuPNtq6TPmb/wrpNPgkNWcr4A24
# 5oyZ1uEi6vAnQj0llOZ0dFtq0Z4+7X6gMTN9vMvpe784cETRkPHIqzqKOghif9lw
# Y1NNje6CbaUFEMFxBmoQtB1VM1izoXBm8qGCAtcwggJAAgEBMIIBAKGB2KSB1TCB
# 0jELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1Jl
# ZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMk
# TWljcm9zb2Z0IElyZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1U
# aGFsZXMgVFNTIEVTTjozQkQ0LTRCODAtNjlDMzElMCMGA1UEAxMcTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgU2VydmljZaIjCgEBMAcGBSsOAwIaAxUAZZzYkPObl/ZzeCkS
# bf4B5CceCQiggYMwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGlu
# Z3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBv
# cmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAN
# BgkqhkiG9w0BAQUFAAIFAOg0ORIwIhgPMjAyMzA2MTQyMTAzMTRaGA8yMDIzMDYx
# NTIxMDMxNFowdzA9BgorBgEEAYRZCgQBMS8wLTAKAgUA6DQ5EgIBADAKAgEAAgIL
# YAIB/zAHAgEAAgIR3TAKAgUA6DWKkgIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgor
# BgEEAYRZCgMCoAowCAIBAAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBBQUA
# A4GBAH2Gsij61Fdwr+S4Z8DZi5itfCjDPM3lNJ/zbCRgDkS6rgCOO0xkIWieCShu
# vO02x2cOAXZY9750d9DleIj0SXvGnAJCwIeYikAxSRXymyNyOl6wFxpXIa6Tw547
# 6U+6EGP3gyB/lR7S/HKU9NP4HuTVt9m4fsj3XI6EWldGHxegMYIEDTCCBAkCAQEw
# gZMwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UE
# AxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAG0+4AIRAXSLfoA
# AQAAAbQwDQYJYIZIAWUDBAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0B
# CRABBDAvBgkqhkiG9w0BCQQxIgQghBMdcasjvzDnMW+81HAj1PTZoWgqsgw3miCE
# ndgknRQwgfoGCyqGSIb3DQEJEAIvMYHqMIHnMIHkMIG9BCDTyPd75qMwcAZRcb36
# /6xJa3hT0eLse71ysdp4twH3BjCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1w
# IFBDQSAyMDEwAhMzAAABtPuACEQF0i36AAEAAAG0MCIEIH7mP48gnBu9ij/QwNnm
# Zv5T/1xEdWHFi2Wfq/o8W2hVMA0GCSqGSIb3DQEBCwUABIICAAHS1/3HK82HB1mM
# o3AHWPk/W215u3/gQ6ohkzKIsLyyvkmS80SRHGrN7cncBlIze7j/9Od3bc8oJo8V
# PuSF3Q4Jjd73EKiNWd5ny9mqkxJKQxh57V78HJyPjsgKBeDyEHMiLt4JrakuX5Vu
# KDm0OA+yShJWUy6P4rSFtXnkyoJj9dfGk5IRux8Pm/jaZKNdkb3lq5SRHjzCs4VW
# QqtqzzqsG8beG6v1QBJscfU3KzN9xlsIWDNOvrK1q9yKZNvrDrJgtKdQZm8CHw2l
# xci5Mc9C1jnCPUpcUwbW/BEkmaui6cwbzHwLb7CLwvFrM1TCA9aT9PTPSh1ZIw/A
# 3saNdNp13Ri7DwHPLIK6fyv11O0hMu/cx9fs5W+xj2gLtWq+Ar1o3KMZZ5HZxAFR
# /OR0+KyPi8niwY5vL2ZWi8j7JN7fIogOJr8t5IjRpxQSsCFFVBy8ugRBDpdOZmZ0
# gtkVkxyY2F7I1b7Vzwlick8Ml3F6uO7u6/Ps/VMIOSbk+YOvwqH5eCnC+7zSdYhl
# 0N6wO3TlXDJg+lrs0ve4DPy/78VJApEPsdsBjEPLGr9fyxgIBLD9RyMwqCXTrImj
# QJJC8cFpn+Tlch3z0kHadn2ok3VMwOYZb7hh0j/vJf06TkDwGuwKxRaLDArsuXoQ
# suTVQToJAnxXQq4DdANwEfm65eCg
# SIG # End signature block
