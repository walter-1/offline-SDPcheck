<# last edit by: waltere 2023-01-07
  File Name: get-pma.ps1 - Performance Monitor Analyzer
  Objective: This script is intended to provide a high level summary of key counters utilized by the Performance team.
  Leveraging the pma.vbs script created by AustinM
  call script with -Verbose or -Debug for add. console output
  Help: get-help \\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\get-pma.ps1 -detailed

VERSION and AUTHORs:
    Ver 1.00 - 06.03.2016
	Walter Eder	- waltere@microsoft.com (this PS script, invoking pma.vbs)
	Austin Mack	- AustinM@microsoft.com (pma.vbs script Created by AustinM and StevePar)
	Steve Parr	- StevePar@microsoft.com (pma.vbs script Created by AustinM and StevePar)

#pma.vbs origin: https://dev.azure.com/mscodehub/Codebox/_git/PMAVBS?version=GBmaster
'==========================================================================
Performance Monitor Analyzer v1.00
Analyzes a performance monitor log to provide a generic high level analysis

Author: Jeff Fanjoy, VMC Consulting (v-11jfan / JeffreyFan@vmc.com)
Current Owner:   Steve Parr, Microsoft Corp. (stevepar@microsoft.com)

Many thanks to Austin Mack (austinm@microsoft.com) and Yong Rhee (yongrhee@microsoft.com)
for their assistance testing and making recommendations.

Purpose:
========
This script is intended to provide a high level summary of key counters utilized by the
Performance team. Reviewing Perfmons has long been time consuming in attempting to collect
data on items such as which process is the reason for a handle leak. In addition it has
always been time consuming to generate a report that is meaningful to both customers and
other individuals reviewing a case.

***** THIS SCRIPT IS NOT INTENDED TO REPLACE ANALYSIS OF A PERFORMANCE MONITOR LOG *****

My hope is that this script will alleviate the time consuming aspects of analyzing a perfmon
log and quickly identifying areas that should be have focus when performing the analysis.
'==========================================================================

HISTORY
	2015-02-07 v1.00 Note: running the pma.vbs script requires to ChangeDirectory into SDPpath
	2016-03-23 v1.01 prepared to allow *.blg files in SDP folder (previously: "*_Performance Counter.blg", DCR by Eriq Stern)
	2016-03-24 	 fixed missing leading "!" of resulting out-file in vbs script
	2016-04-17 v1.02 adding OSversion
	2016-08-03 adding 2016RS1
	2022-09-08 using Utils_RflShared.psm1 library
	2023-01-07 fix OSversion short name
	ToDo:

#>

<#
.SYNOPSIS
The script reads a .blg file from a given folder and is intended to provide a high level summary of key counters utilized by the Performance team.

SYNTAX: .\get-pma.ps1 [full-path-to-expanded-SDP-report]

.DESCRIPTION
The script reads in the Performance Counter *.blg file(s) from a folder and displays a high level summary of key counters utilized by the Performance team. 


If you experience PS error '...is not digitally signed.' run the command:
 Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned

.PARAMETER OpenSummary
 This switch will not open resulting summary file with Notepad/Favorite Editor if set to $False
 
.EXAMPLE
\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\get-pma.ps1 \\waltere-ws10\data\Folder-with-Blg

.LINK
\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\get-pma.ps1
waltere@microsoft.com ;

#>

[CmdletBinding()]
PARAM (
	[ValidateScript({Test-Path $_ -PathType 'Container'})]
	[Parameter(Mandatory=$True,Position=0,HelpMessage='Choose a writable SDP folder location, i.e. C:\SR\SDP-report\ ')]
	[string]$SDPPath,				# Folder path to *.blg file(s)
	[ValidateSet("2008","2008R2","2012","2012R2","2016","2016RS1","2016RS2","2016RS3","2016RS4","2016RS5","201619H1","201619H2","20162004","201620H2","201621H1","201621H2","201622H2","2022","Win11","Win1122H2","Win1123H1","help","unknown")]
	[Parameter(Mandatory=$False,Position=1,HelpMessage='optional: Choose one OS from list: [2008|2008R2|2012|2012R2|2016|2016RS1|2016RS2|2016RS3|2016RS4|2016RS5|201619H1|201619H2|20162004|201620H2|201621H1|201621H2|201622H2|2022|Win11|Win1122H2|Win1123H1]')]
	[string]$OSversion,				# optional, if not supplied script will try to get OS version from MSinfo
	[ValidateSet("Q","-q","-Q")]
	[Parameter(Mandatory=$False,Position=2,HelpMessage='optional: Choose -Q = quiet')]
	[string]$quiet = "-Q",	#NoPrompt
	[switch]$OpenSummary= $true		# open with Notepad/FavEditor
	)
	
Process
{
	$verDateScript = "2023.01.07.0"
	$ScriptFolder = Split-Path $MyInvocation.MyCommand.Path -Parent
	# Load Common Library:
	. $ScriptFolder\Utils_RflShared.ps1

	$scriptName = $invocation.MyCommand.Name
	
#region: ###### customization section of script, logging configuration ########################
	$SDPcheckINI = (Get-content -Path "$ScriptFolder\_SDPcheck.ini")
	$InOfflineMode 	= (($SDPcheckINI[1] -split " ")[2]).trim("""")	# set $True for outsourcer or when not connected to MS network - offline-SDPcheck
	$RFLroot = (($SDPcheckINI[2] -split " ")[2]).trim("""")	# "\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\" -or- "\\localhost\ToolsShare\rfl\"
	if ($InOfflineMode -match "False") {
		$StatsServer = (($SDPcheckINI[4] -split " ")[2]).trim("""")
		if (Test-Connection -ComputerName $StatsServer -Quiet -Count 1) {[bool]$Stats=$True} else {[bool]$Stats=$False}
	} else { 
		$Stats = $False
	}
	$pmaScript = $RFLroot + "\pma.vbs"
#endregion: ###### customization section

	$ScriptBeginTimeStamp = Get-Date
	$CheckDate = (Get-Date).ToUniversalTime().ToString("yy-MM-dd_HH-mm-ss")
	if ($Stats) {
		$StatsServerPath="\\$StatsServer\RFLstats$\RFL\scripts\Stats\"
		$CountInvFil = $StatsServerPath +'countPMA.dat'
		$CountInvFil2 = $CountInvFil +'.us'
		#increment at start of script
		 ($j=[int32](Get-Content $CountInvFil -TotalCount 1 -ErrorAction SilentlyContinue)) |out-null
		 (++$j) | Set-Content $CountInvFil -ErrorAction SilentlyContinue
	}
	Set-Variable -Name ErrorMsgScript -Scope Script -Force
	If ($PSBoundParameters['Debug']) { $DebugPreference='Continue'}

	### Trail SDPPath with \ and allow path with space character
	if ($SDPPath.EndsWith("\")){$SDPPath="$SDPPath"}
	else {$SDPPath="$SDPPath" +"\"}
	If (-NOT (Test-Path $SDPPath -PathType 'Container')){Throw "$($SDPPath) is not a valid folder"}


	### === main
	"`n$(Get-Date -UFormat "%R:%S") ==PMA check==... runnning 'Performance Monitor Analyzer' for *.blg in folder $SDPPath"
	## change directory to $SDPPath as required by pma.vbs script
	Push-Location
	Set-Location $SDPPath

	$PerfCounterFiles = Get-Item -path ($SDPPath + "*.blg") # all *.blg files in given folder, i.e. *_Performance Counter.blg
	$NodeNames = foreach ($NodeName in $PerfCounterFiles){($NodeName.name).split('_')[0]}
	Write-Host "$(Get-Date -UFormat "%R:%S") NodeName(s): $NodeNames"

	if (!$PerfCounterFiles) { Write-Host -BackgroundColor Black -ForegroundColor Red -Object "There is no *_Performance Counter.blg file in $SDPPath - Double-check SDP path again!"
				$ErrorMsgScript += "No-Valid-PMA " }
	$NodeCnt=0
	foreach ($PerfCounterFile in $PerfCounterFiles){
		$NodeCnt++
		Write-Host -BackgroundColor Blue -ForegroundColor Cyan -NoNewline -Object "$($NodeCnt) " -Separator .
		$NodeName = ($PerfCounterFile.name).split('_')[0]
		Write-Verbose "OSVersion in script param1: $($OSVersion) "

		if ($($NodeCnt) -lt 32) {
			if ($NodeNames.count -gt 1) {Write-Host "Node $NodeName $NodeCnt of $($NodeNames.count)"}
			if (!$OSversion) {
				try {
					$OSVersion = GetOSfromMSinfo32 $SDPPath $NodeName			# Call function
				}
				catch {
					if ([String]::IsNullOrEmpty($OSversion)) {$OSVersion="unknown"}
				}
			}
			#Write-Host "OSVersion in SDP report: $($OSVersion) - ComputerName: $($NodeName)"
			Write-Verbose "OSVersion in SDP report: $($OSVersion) - ComputerName: $($NodeName)"			
			& wscript.exe $pmaScript $PerfCounterFile $quiet
			"=> Output file will be saved to: $($SDPPath)!$($Nodename)_Performance Counter-PMA-Summary.TXT "
		}
		else {Write-Host "$(Get-Date -UFormat "%R:%S") ...checked only first 32 nodes" }
	}

	If (($Global:OpenSummary) -or ($OpenSummary)) {
		"`nUsing favorite editor to open PMA Report(s) - this could take a few seconds until your Text Editor opens with results ..."
	}
	$ScriptEndTimeStamp = Get-Date
	$Duration = $(New-TimeSpan -Start $ScriptBeginTimeStamp -End $ScriptEndTimeStamp)
	Write-Host -BackgroundColor Gray -ForegroundColor Black -Object "$(Get-Date -UFormat "%R:%S") Done $scriptName version v$verDateScript took $Duration `n"

	Pop-Location

	### Stats
	If ($Stats) { #increment at start of script
	 "$j" + " ;$CheckDate" + "; $OSVersion; " + ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name) + "; $($Duration)" + "; $NodeCnt" + "; $SDPPath" + "; $ErrorMsgScript" + "; v$verDateScript " | Out-File $CountInvFil2 -Append -Encoding UTF8 -ErrorAction SilentlyContinue
	}
}


