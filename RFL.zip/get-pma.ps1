<# last edit by: waltere 2023-01-07
  File Name: get-pma.ps1 - Performance Monitor Analyzer
  Objective: This script is intended to provide a high level summary of key counters utilized by the Performance team.
  Leveraging the pma.vbs script created by AustinM
  call script with -Verbose or -Debug for add. console output
  Help: get-help \\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\get-pma.ps1 -detailed

VERSION and AUTHORs:
    Ver 1.00 - 06.03.2016
	Walter Eder	- waltere@microsoft.com (this PS script, invoking pma.vbs)
	Austin Mack	- AustinM@microsoft.com (pma.vbs script Created by AustinM and StevePar)
	Steve Parr	- StevePar@microsoft.com (pma.vbs script Created by AustinM and StevePar)

#pma.vbs origin: https://dev.azure.com/mscodehub/Codebox/_git/PMAVBS?version=GBmaster
'==========================================================================
Performance Monitor Analyzer v1.00
Analyzes a performance monitor log to provide a generic high level analysis

Author: Jeff Fanjoy, VMC Consulting (v-11jfan / JeffreyFan@vmc.com)
Current Owner:   Steve Parr, Microsoft Corp. (stevepar@microsoft.com)

Many thanks to Austin Mack (austinm@microsoft.com) and Yong Rhee (yongrhee@microsoft.com)
for their assistance testing and making recommendations.

Purpose:
========
This script is intended to provide a high level summary of key counters utilized by the
Performance team. Reviewing Perfmons has long been time consuming in attempting to collect
data on items such as which process is the reason for a handle leak. In addition it has
always been time consuming to generate a report that is meaningful to both customers and
other individuals reviewing a case.

***** THIS SCRIPT IS NOT INTENDED TO REPLACE ANALYSIS OF A PERFORMANCE MONITOR LOG *****

My hope is that this script will alleviate the time consuming aspects of analyzing a perfmon
log and quickly identifying areas that should be have focus when performing the analysis.
'==========================================================================

HISTORY
	2015-02-07 v1.00 Note: running the pma.vbs script requires to ChangeDirectory into SDPpath
	2016-03-23 v1.01 prepared to allow *.blg files in SDP folder (previously: "*_Performance Counter.blg", DCR by Eriq Stern)
	2016-03-24 	 fixed missing leading "!" of resulting out-file in vbs script
	2016-04-17 v1.02 adding OSversion
	2016-08-03 adding 2016RS1
	2022-09-08 using Utils_RflShared.psm1 library
	2023-01-07 fix OSversion short name
	ToDo:

#>

<#
.SYNOPSIS
The script reads a .blg file from a given folder and is intended to provide a high level summary of key counters utilized by the Performance team.

SYNTAX: .\get-pma.ps1 [full-path-to-expanded-SDP-report]

.DESCRIPTION
The script reads in the Performance Counter *.blg file(s) from a folder and displays a high level summary of key counters utilized by the Performance team. 


If you experience PS error '...is not digitally signed.' run the command:
 Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned

.PARAMETER OpenSummary
 This switch will not open resulting summary file with Notepad/Favorite Editor if set to $False
 
.EXAMPLE
\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\get-pma.ps1 \\waltere-ws10\data\Folder-with-Blg

.LINK
\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\get-pma.ps1
waltere@microsoft.com ;

#>

[CmdletBinding()]
PARAM (
	[ValidateScript({Test-Path $_ -PathType 'Container'})]
	[Parameter(Mandatory=$True,Position=0,HelpMessage='Choose a writable SDP folder location, i.e. C:\SR\SDP-report\ ')]
	[string]$SDPPath,				# Folder path to *.blg file(s)
	[ValidateSet("2008","2008R2","2012","2012R2","2016","2016RS1","2016RS2","2016RS3","2016RS4","2016RS5","201619H1","201619H2","20162004","201620H2","201621H1","201621H2","201622H2","2022","Win11","Win1122H2","Win1123H1","help","unknown")]
	[Parameter(Mandatory=$False,Position=1,HelpMessage='optional: Choose one OS from list: [2008|2008R2|2012|2012R2|2016|2016RS1|2016RS2|2016RS3|2016RS4|2016RS5|201619H1|201619H2|20162004|201620H2|201621H1|201621H2|201622H2|2022|Win11|Win1122H2|Win1123H1]')]
	[string]$OSversion,				# optional, if not supplied script will try to get OS version from MSinfo
	[ValidateSet("Q","-q","-Q")]
	[Parameter(Mandatory=$False,Position=2,HelpMessage='optional: Choose -Q = quiet')]
	[string]$quiet = "-Q",	#NoPrompt
	[switch]$OpenSummary= $true		# open with Notepad/FavEditor
	)
	
Process
{
	$verDateScript = "2023.02.09.0"
	$ScriptFolder = Split-Path $MyInvocation.MyCommand.Path -Parent
	# Load Common Library:
	. $ScriptFolder\Utils_RflShared.ps1

	$scriptName = $invocation.MyCommand.Name
	
#region: ###### customization section of script, logging configuration ########################
	$SDPcheckINI = (Get-content -Path "$ScriptFolder\_SDPcheck.ini")
	$InOfflineMode 	= (($SDPcheckINI[1] -split " ")[2]).trim("""")	# set $True for outsourcer or when not connected to MS network - offline-SDPcheck
	$RFLroot = (($SDPcheckINI[2] -split " ")[2]).trim("""")	# "\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\" -or- "\\localhost\ToolsShare\rfl\"
	if ($InOfflineMode -match "False") {
		$StatsServer = (($SDPcheckINI[5] -split " ")[2]).trim("""")
		if (Test-Connection -ComputerName $StatsServer -Quiet -Count 1) {[bool]$Stats=$True} else {[bool]$Stats=$False}
	} else { 
		$Stats = $False
	}
	$pmaScript = $RFLroot + "\pma.vbs"
#endregion: ###### customization section

	$ScriptBeginTimeStamp = Get-Date
	$CheckDate = (Get-Date).ToUniversalTime().ToString("yy-MM-dd_HH-mm-ss")
	if ($Stats) {
		$StatsServerPath="\\$StatsServer\RFLstats$\RFL\scripts\Stats\"
		$CountInvFil = $StatsServerPath +'countPMA.dat'
		$CountInvFil2 = $CountInvFil +'.us'
		#increment at start of script
		 ($j=[int32](Get-Content $CountInvFil -TotalCount 1 -ErrorAction SilentlyContinue)) |out-null
		 Try {(++$j) | Set-Content $CountInvFil -ErrorAction SilentlyContinue} Catch { }
	}
	Set-Variable -Name ErrorMsgScript -Scope Script -Force
	If ($PSBoundParameters['Debug']) { $DebugPreference='Continue'}

	### Trail SDPPath with \ and allow path with space character
	if ($SDPPath.EndsWith("\")){$SDPPath="$SDPPath"}
	else {$SDPPath="$SDPPath" +"\"}
	If (-NOT (Test-Path $SDPPath -PathType 'Container')){Throw "$($SDPPath) is not a valid folder"}


	### === main
	"`n$(Get-Date -UFormat "%R:%S") ==PMA check==... runnning 'Performance Monitor Analyzer' for *.blg in folder $SDPPath"
	## change directory to $SDPPath as required by pma.vbs script
	Push-Location
	Set-Location $SDPPath

	$PerfCounterFiles = Get-Item -path ($SDPPath + "*.blg") # all *.blg files in given folder, i.e. *_Performance Counter.blg
	$NodeNames = foreach ($NodeName in $PerfCounterFiles){($NodeName.name).split('_')[0]}
	Write-Host "$(Get-Date -UFormat "%R:%S") NodeName(s): $NodeNames"

	if (!$PerfCounterFiles) { Write-Host -BackgroundColor Black -ForegroundColor Red -Object "There is no *_Performance Counter.blg file in $SDPPath - Double-check SDP path again!"
				$ErrorMsgScript += "No-Valid-PMA " }
	$NodeCnt=0
	foreach ($PerfCounterFile in $PerfCounterFiles){
		$NodeCnt++
		Write-Host -BackgroundColor Blue -ForegroundColor Cyan -NoNewline -Object "$($NodeCnt) " -Separator .
		$NodeName = ($PerfCounterFile.name).split('_')[0]
		Write-Verbose "OSVersion in script param1: $($OSVersion) "

		if ($($NodeCnt) -lt 32) {
			if ($NodeNames.count -gt 1) {Write-Host "Node $NodeName $NodeCnt of $($NodeNames.count)"}
			if (!$OSversion) {
				try {
					$OSVersion = GetOSfromMSinfo32 $SDPPath $NodeName			# Call function
				}
				catch {
					if ([String]::IsNullOrEmpty($OSversion)) {$OSVersion="unknown"}
				}
			}
			#Write-Host "OSVersion in SDP report: $($OSVersion) - ComputerName: $($NodeName)"
			Write-Verbose "OSVersion in SDP report: $($OSVersion) - ComputerName: $($NodeName)"			
			& wscript.exe $pmaScript $PerfCounterFile $quiet
			"=> Output file will be saved to: $($SDPPath)!$($Nodename)_Performance Counter-PMA-Summary.TXT "
		}
		else {Write-Host "$(Get-Date -UFormat "%R:%S") ...checked only first 32 nodes" }
	}

	If (($Global:OpenSummary) -or ($OpenSummary)) {
		"`nUsing favorite editor to open PMA Report(s) - this could take a few seconds until your Text Editor opens with results ..."
	}
	$ScriptEndTimeStamp = Get-Date
	$Duration = $(New-TimeSpan -Start $ScriptBeginTimeStamp -End $ScriptEndTimeStamp)
	Write-Host -BackgroundColor Gray -ForegroundColor Black -Object "$(Get-Date -UFormat "%R:%S") Done $scriptName version v$verDateScript took $Duration `n"

	Pop-Location

	### Stats
	If ($Stats) { #increment at start of script
	 Try {"$j" + " ;$CheckDate" + "; $OSVersion; " + ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name) + "; $($Duration)" + "; $NodeCnt" + "; $SDPPath" + "; $ErrorMsgScript" + "; v$verDateScript " | Out-File $CountInvFil2 -Append -Encoding UTF8 -ErrorAction SilentlyContinue} Catch { }
	}
}



# SIG # Begin signature block
# MIInwQYJKoZIhvcNAQcCoIInsjCCJ64CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBX7FRLxbeYOzMB
# deadWoDF02T04a6USn2mV7hTwUs5W6CCDXYwggX0MIID3KADAgECAhMzAAADTrU8
# esGEb+srAAAAAANOMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjMwMzE2MTg0MzI5WhcNMjQwMzE0MTg0MzI5WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDdCKiNI6IBFWuvJUmf6WdOJqZmIwYs5G7AJD5UbcL6tsC+EBPDbr36pFGo1bsU
# p53nRyFYnncoMg8FK0d8jLlw0lgexDDr7gicf2zOBFWqfv/nSLwzJFNP5W03DF/1
# 1oZ12rSFqGlm+O46cRjTDFBpMRCZZGddZlRBjivby0eI1VgTD1TvAdfBYQe82fhm
# WQkYR/lWmAK+vW/1+bO7jHaxXTNCxLIBW07F8PBjUcwFxxyfbe2mHB4h1L4U0Ofa
# +HX/aREQ7SqYZz59sXM2ySOfvYyIjnqSO80NGBaz5DvzIG88J0+BNhOu2jl6Dfcq
# jYQs1H/PMSQIK6E7lXDXSpXzAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUnMc7Zn/ukKBsBiWkwdNfsN5pdwAw
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzUwMDUxNjAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAD21v9pHoLdBSNlFAjmk
# mx4XxOZAPsVxxXbDyQv1+kGDe9XpgBnT1lXnx7JDpFMKBwAyIwdInmvhK9pGBa31
# TyeL3p7R2s0L8SABPPRJHAEk4NHpBXxHjm4TKjezAbSqqbgsy10Y7KApy+9UrKa2
# kGmsuASsk95PVm5vem7OmTs42vm0BJUU+JPQLg8Y/sdj3TtSfLYYZAaJwTAIgi7d
# hzn5hatLo7Dhz+4T+MrFd+6LUa2U3zr97QwzDthx+RP9/RZnur4inzSQsG5DCVIM
# pA1l2NWEA3KAca0tI2l6hQNYsaKL1kefdfHCrPxEry8onJjyGGv9YKoLv6AOO7Oh
# JEmbQlz/xksYG2N/JSOJ+QqYpGTEuYFYVWain7He6jgb41JbpOGKDdE/b+V2q/gX
# UgFe2gdwTpCDsvh8SMRoq1/BNXcr7iTAU38Vgr83iVtPYmFhZOVM0ULp/kKTVoir
# IpP2KCxT4OekOctt8grYnhJ16QMjmMv5o53hjNFXOxigkQWYzUO+6w50g0FAeFa8
# 5ugCCB6lXEk21FFB1FdIHpjSQf+LP/W2OV/HfhC3uTPgKbRtXo83TZYEudooyZ/A
# Vu08sibZ3MkGOJORLERNwKm2G7oqdOv4Qj8Z0JrGgMzj46NFKAxkLSpE5oHQYP1H
# tPx1lPfD7iNSbJsP6LiUHXH1MIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGaEwghmdAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAANOtTx6wYRv6ysAAAAAA04wDQYJYIZIAWUDBAIB
# BQCggbAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIEmUutMJICiaJ+JgKb7k4Fpc
# lNNHcXT9lEITkk84UWlTMEQGCisGAQQBgjcCAQwxNjA0oBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEcgBpodHRwczovL3d3dy5taWNyb3NvZnQuY29tIDANBgkqhkiG9w0B
# AQEFAASCAQBliQUZrjrCkvJQzBhVdOynQqBtf8NKS5ACOfMm42YjM7HbeLDOhOfb
# aORymwe6tFeySJGGhY2zcbQRs5j84wK2KUK3cbP2DGO0pKE1oyoa91HEiNN3uZIl
# DZ94/LQYvf+zua/2IoRtKOxe0UTe4BDRMukFepaeka2KaDZGmKMtqyIXrLLeoMpu
# auOwjVmkDKQZXwoUnzdnmkBukD4FB47SpY2qdsWtWTalPYdFbMy81dbEkvjctNiZ
# u6Q9Tw9h0FkDtKTEYp23WHcvdqP8tiy+4mhyZxULDbMMW8yp7xtEz4flZPmWt5wd
# AFlagB5U9m63SJzvDlLr6Xslz0J1hP1GoYIXKTCCFyUGCisGAQQBgjcDAwExghcV
# MIIXEQYJKoZIhvcNAQcCoIIXAjCCFv4CAQMxDzANBglghkgBZQMEAgEFADCCAVkG
# CyqGSIb3DQEJEAEEoIIBSASCAUQwggFAAgEBBgorBgEEAYRZCgMBMDEwDQYJYIZI
# AWUDBAIBBQAEIPnmFWCcI1sLfjjMEqqLtmVRNPMqIqmDaRouVeNcrqeDAgZkbPJS
# 2dMYEzIwMjMwNjA1MTgyNTQ1LjkyOVowBIACAfSggdikgdUwgdIxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJ
# cmVsYW5kIE9wZXJhdGlvbnMgTGltaXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBF
# U046ODZERi00QkJDLTkzMzUxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1w
# IFNlcnZpY2WgghF4MIIHJzCCBQ+gAwIBAgITMwAAAbchJxoHoiqGRgABAAABtzAN
# BgkqhkiG9w0BAQsFADB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3Rv
# bjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0
# aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0y
# MjA5MjAyMDIyMTRaFw0yMzEyMTQyMDIyMTRaMIHSMQswCQYDVQQGEwJVUzETMBEG
# A1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWlj
# cm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJlbGFuZCBP
# cGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjg2REYt
# NEJCQy05MzM1MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNl
# MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAx/3PV1A0E2RMGrcclyXK
# mNBwkiUMCCm+zDi8cl7TqfnfZEoaRyfRXunrk54DXA6g77w2yimeM+lVnz7iz9GF
# 0wIw09AlehZ2RY6n/em4gSzV/M8GBMmt2bN3JRjOsCWggJjHvbaCZ2ls1/c/TLln
# aBE7jyxYhjJh40lhyH5l8nNeqq+6+rsbw2bwgxCLxlrK/H7l1IYEzlVgcHEISNcX
# 0Q3pDDsDrRJpeMqOiNKlSalozgWZV5z3zk811KHyE54/a0vvzVIFqf3YNPX2180e
# /0fQUCYTYcZHCLMeQn/+YBl1LSzpuL9TA8ySwCJrlumcgME6hph1aRXSVUbms3T6
# W1HP3OOVof26F0ZMn5aI0o6vuZGeXNhADnd+1JIkGqwSlPMK/tzrvd92+W3HfLjw
# 96vq9zpRHl7iRJmwfXjUiHGGZFHZKYRpu5go5N07tD++W8B9DG4Scn3c0vgthXUh
# bDw77E07qCWOsGkI5845NCBYkX4zr8g/K5ity/v0u7uVzrtL5T0wS7Z2iDQy4kih
# gIyK5VpdLn4WY4mLJ+IJmbRUmwnnvTL2T+0RB7ppBH0zENbWnYXcdZ5uiVeP2y7v
# OusSU2UcAS+kWFyCgyeLKU1OJNnMvBSPtMfzeCe6DDUUIRVWHlT2XA0w8vUga7P/
# dT5FP3BkIElgisUk93qTxS0CAwEAAaOCAUkwggFFMB0GA1UdDgQWBBSz8jk+DDQk
# BWEN1gHbI8gjyXi07DAfBgNVHSMEGDAWgBSfpxVdAF5iXYP05dJlpxtTNRnpcjBf
# BgNVHR8EWDBWMFSgUqBQhk5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3Bz
# L2NybC9NaWNyb3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIwMjAxMCgxKS5jcmww
# bAYIKwYBBQUHAQEEYDBeMFwGCCsGAQUFBzAChlBodHRwOi8vd3d3Lm1pY3Jvc29m
# dC5jb20vcGtpb3BzL2NlcnRzL01pY3Jvc29mdCUyMFRpbWUtU3RhbXAlMjBQQ0El
# MjAyMDEwKDEpLmNydDAMBgNVHRMBAf8EAjAAMBYGA1UdJQEB/wQMMAoGCCsGAQUF
# BwMIMA4GA1UdDwEB/wQEAwIHgDANBgkqhkiG9w0BAQsFAAOCAgEADZ1kzJuFXFJd
# NsnMWC82IwJXn8DKflS7MlTj3lgO1x5+iV3R6FH1AEYGEeYAy3XRZgIfPZZBTIze
# ZAPgiwd8QvUkTCAb20arvW5yf12ScsEcPfQm9tBGEgpy8VKe9EIKlWmKUzwX9hpZ
# cL1WJtJ5/89TYZYD7XOzrhUXEmod67LwqqtDJ8XbRIKd3zNFmXhhgFyOH0bQaOEk
# dQ8BgTHSvyNJaPKLajZYAcPoKmkG2TCdlJ/sDrwMvg7DAGmYUHf6+5uOA3BogJL5
# +QZW9Gc/ZmCaV+doBqzwzHuKAmpyKqrRDoCf7SsePWTGKw10iJPMWW7kbDZ6Feku
# uXn2S+yY41UAkeGd2nHef/SvvpMf7dY1L1RP2NvFCQT63a2GJ/owrmSsUyeQEgIJ
# H8NVxXWrD2yDqwwSjTBZJeVBhe9xBYDrl5XNKSizKWEiUhlksvcYdkPUtC0COnYD
# kXsLcjDg23sLtoMJ+kXGibdm6VGcUmiWU8dve6eP2ED3G9GIqdYwAylLgxkCiJXg
# 7b3NYpl1TPKCnuAPhaMorXXkoInSi8Rx/3YCfAwBcyc2zWjQsKzOD64OaJBmzl5H
# uPN0rNV8XXPtt8Ng08Am+bmlJB1vLfAg6w3+y1iMz4SRo+1TOvw7IzCsb6OkUxuw
# Hhx83q28h4a2u2SUwkW2cXrwJxlnkgAwggdxMIIFWaADAgECAhMzAAAAFcXna54C
# m0mZAAAAAAAVMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZp
# Y2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0yMTA5MzAxODIyMjVaFw0zMDA5MzAxODMy
# MjVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIICIjANBgkqhkiG9w0B
# AQEFAAOCAg8AMIICCgKCAgEA5OGmTOe0ciELeaLL1yR5vQ7VgtP97pwHB9KpbE51
# yMo1V/YBf2xK4OK9uT4XYDP/XE/HZveVU3Fa4n5KWv64NmeFRiMMtY0Tz3cywBAY
# 6GB9alKDRLemjkZrBxTzxXb1hlDcwUTIcVxRMTegCjhuje3XD9gmU3w5YQJ6xKr9
# cmmvHaus9ja+NSZk2pg7uhp7M62AW36MEBydUv626GIl3GoPz130/o5Tz9bshVZN
# 7928jaTjkY+yOSxRnOlwaQ3KNi1wjjHINSi947SHJMPgyY9+tVSP3PoFVZhtaDua
# Rr3tpK56KTesy+uDRedGbsoy1cCGMFxPLOJiss254o2I5JasAUq7vnGpF1tnYN74
# kpEeHT39IM9zfUGaRnXNxF803RKJ1v2lIH1+/NmeRd+2ci/bfV+AutuqfjbsNkz2
# K26oElHovwUDo9Fzpk03dJQcNIIP8BDyt0cY7afomXw/TNuvXsLz1dhzPUNOwTM5
# TI4CvEJoLhDqhFFG4tG9ahhaYQFzymeiXtcodgLiMxhy16cg8ML6EgrXY28MyTZk
# i1ugpoMhXV8wdJGUlNi5UPkLiWHzNgY1GIRH29wb0f2y1BzFa/ZcUlFdEtsluq9Q
# BXpsxREdcu+N+VLEhReTwDwV2xo3xwgVGD94q0W29R6HXtqPnhZyacaue7e3Pmri
# Lq0CAwEAAaOCAd0wggHZMBIGCSsGAQQBgjcVAQQFAgMBAAEwIwYJKwYBBAGCNxUC
# BBYEFCqnUv5kxJq+gpE8RjUpzxD/LwTuMB0GA1UdDgQWBBSfpxVdAF5iXYP05dJl
# pxtTNRnpcjBcBgNVHSAEVTBTMFEGDCsGAQQBgjdMg30BATBBMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL0RvY3MvUmVwb3NpdG9y
# eS5odG0wEwYDVR0lBAwwCgYIKwYBBQUHAwgwGQYJKwYBBAGCNxQCBAweCgBTAHUA
# YgBDAEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB/wQFMAMBAf8wHwYDVR0jBBgwFoAU
# 1fZWy4/oolxiaNE9lJBb186aGMQwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2Ny
# bC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljUm9vQ2VyQXV0XzIw
# MTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXRfMjAxMC0w
# Ni0yMy5jcnQwDQYJKoZIhvcNAQELBQADggIBAJ1VffwqreEsH2cBMSRb4Z5yS/yp
# b+pcFLY+TkdkeLEGk5c9MTO1OdfCcTY/2mRsfNB1OW27DzHkwo/7bNGhlBgi7ulm
# ZzpTTd2YurYeeNg2LpypglYAA7AFvonoaeC6Ce5732pvvinLbtg/SHUB2RjebYIM
# 9W0jVOR4U3UkV7ndn/OOPcbzaN9l9qRWqveVtihVJ9AkvUCgvxm2EhIRXT0n4ECW
# OKz3+SmJw7wXsFSFQrP8DJ6LGYnn8AtqgcKBGUIZUnWKNsIdw2FzLixre24/LAl4
# FOmRsqlb30mjdAy87JGA0j3mSj5mO0+7hvoyGtmW9I/2kQH2zsZ0/fZMcm8Qq3Uw
# xTSwethQ/gpY3UA8x1RtnWN0SCyxTkctwRQEcb9k+SS+c23Kjgm9swFXSVRk2XPX
# fx5bRAGOWhmRaw2fpCjcZxkoJLo4S5pu+yFUa2pFEUep8beuyOiJXk+d0tBMdrVX
# VAmxaQFEfnyhYWxz/gq77EFmPWn9y8FBSX5+k77L+DvktxW/tM4+pTFRhLy/AsGC
# onsXHRWJjXD+57XQKBqJC4822rpM+Zv/Cuk0+CQ1ZyvgDbjmjJnW4SLq8CdCPSWU
# 5nR0W2rRnj7tfqAxM328y+l7vzhwRNGQ8cirOoo6CGJ/2XBjU02N7oJtpQUQwXEG
# ahC0HVUzWLOhcGbyoYIC1DCCAj0CAQEwggEAoYHYpIHVMIHSMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJl
# bGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNO
# Ojg2REYtNEJCQy05MzM1MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQDIZ0EYw5s4OWwYFmZJRfahaB+pxqCBgzCB
# gKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0GCSqGSIb3DQEBBQUA
# AgUA6CiTjjAiGA8yMDIzMDYwNjAxMDIwNloYDzIwMjMwNjA3MDEwMjA2WjB0MDoG
# CisGAQQBhFkKBAExLDAqMAoCBQDoKJOOAgEAMAcCAQACAgIbMAcCAQACAhJ0MAoC
# BQDoKeUOAgEAMDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEA
# AgMHoSChCjAIAgEAAgMBhqAwDQYJKoZIhvcNAQEFBQADgYEAJK3RlBYYnqEZcK/K
# 6n4C4F3ySY0PGE2ldRzKsKuu7OSJq6VekpwXezOw/UR6ln76eCKFMQknK7Ungf8W
# +0UHQ1JGWaTfgduVUejb9afKE8b3puAGn1nG0aZY4LjVy2pfPaAFxddW566BX2uE
# X04L7HilOpB/CsWW+J6LdQ8ID/IxggQNMIIECQIBATCBkzB8MQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGlt
# ZS1TdGFtcCBQQ0EgMjAxMAITMwAAAbchJxoHoiqGRgABAAABtzANBglghkgBZQME
# AgEFAKCCAUowGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJ
# BDEiBCBQIYizWBL4VTk+JKzVHdT7u31cnJKcm2sOaZIG1gUOMjCB+gYLKoZIhvcN
# AQkQAi8xgeowgecwgeQwgb0EIGwneNOyHtovyE16JgYvn/wgGfzNR+vv9DuuQzyJ
# zXBBMIGYMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAG3
# IScaB6IqhkYAAQAAAbcwIgQghYjS2Gkh9kwqwQBT0CGsbOhyElELREI9YSwyav7d
# WK0wDQYJKoZIhvcNAQELBQAEggIAk7XUqLprYDz5vO08d0/Cty6towd/gX53KifA
# 9QtSRHFPxK8TLojkepB/VbItdsTdhTYic2zCwhdTS6wZtT/HY9fkuLNd9NAGERgT
# zLjyY3kTOzOBg7Q+/T/P3ARb6FKjh953VThE5SBWlvQqtD7RONDABs3dqp1+BMMw
# r7+TNf0XKVDAFloEAE+wCKYFXJgvnCbho4U9UojJk2ej+m8ixCRyT5wNmZrr3KS/
# dy/UqOy5OkQRO3Bv6lMHPJPt5Y1LC3LFjBTS004kV/A1BeMNqhXJ7D3EBZwpjJFf
# TPYiQcIB98KLqETds1pan6wM98uDDR4pjj0+iuluudqvSzYLZqjHls60ZEDR1TfI
# gkIWEXRLM+HdbWUJqOwpoM9bKYPIELxj1QUQu2poT/VehACDAyFbQBFuWoaLoXK2
# Rd4B/m8JJThd9TFw3p+PjLjfZx5S9hwqSUHwiRdTjdx+0GIzQh9n3e+hmd3yDvpE
# XC1W9SA6qFu6cbC7oculo61JOymblY6E2iwG6Ev664cOVOisGube6HU5RxDtSa6/
# g1iKGtjM8vTR7HYsNxIypExAijdwVK113VtiwPBRFixSzobT9bf6r5hOV2HsGWYU
# tfEC2Q9HlnQDfZ/X6RaejZlZp3Q1W61WcghfSVXnw0YWwxo/vKIX1wNhRf+G1Ecq
# 5upR0zI=
# SIG # End signature block
