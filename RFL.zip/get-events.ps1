<# last edit by: waltere
  File Name: get-events.ps1 - Extract last events from *.evtx Eventlogs
  Objective: This script is intended to provide a quick summary of Events from all providers (data in Eventlog folder)
  Show all last events for all providers for last 6 hours ( or maybe in a specific time-range).

 call script with -Verbose or -Debug for add. console output
 Help: get-help \\emeacssdfs\netpod\rfl\get-events.ps1 -detailed

VERSION and AUTHORs:
    Ver 1.00 - 07.08.2016
	Walter Eder	- waltere@microsoft.com (

### show Events from all providers (data in Eventlog folder) in a specifix time-range

HISTORY
	2016-08-07 v1.00 checking last 200 events
	2016-08-14 v1.01 Perf-improvement: - changed to use -FilterXPath; now checking last 12hours since *_System.evtx had been created
	2016-08-18	reducing $NrOfHours from 12 to 8h back
	2016-08-21	reducing $NrOfHours from 8 to 6h back
	2016-09-13	changed may line length per item from #4096 to 1024
	2017-01-05	changed may line length per item from #1024 to 600 = $OutFileChars
	2017-10-06 v1.03 adding 2016RS3
	2018-04-05 adding 2016RS4
	2020-08-14 using UTC time
	2022-09-08 using Utils_RflShared.psm1 library
#>

<#
.SYNOPSIS
The script reads SDP report folder and displays a quick summary of Events from all providers (data in Eventlog folder)
Show last events for all providers - or in a specifix time-range, default of NrOfHours=6.

SYNTAX: .\get-events.ps1 [full-path-to-expanded-SDP-report] [number of hours back]

.DESCRIPTION
The script reads in the *evtx file(s) from the SDP report and displays a quick summary of Events from all providers.
Note: Expand the SDP report cab file into folder before running this script.


If you experience PS error '...is not digitally signed.' run the command:
 Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned
 
.PARAMETER OpenSummary
 This switch will not open resulting summary file with Notepad/Favorite Editor if set to $False
 
.EXAMPLE
Example 1, Get only all events for last 6 hours
\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\get-events.ps1 \\ioanc00\temp\New_RFL\SDPs\FileServer

.EXAMPLE
Example 2, Get only all events for last 3 hours
\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\get-events.ps1 \\ioanc00\temp\New_RFL\SDPs\FileServer 3

.LINK
waltere@microsoft.com

#>

[CmdletBinding()]
PARAM (
	[ValidateScript({Test-Path $_ -PathType 'Container'})]
	[Parameter(Mandatory=$True,Position=0,HelpMessage='Choose a writable SDP folder location, i.e. C:\SR\SDP-report\ ')]
	[string]$SDPPath,
	[ValidateSet("1","2","3","4","5","6","7","8","9","10","11","12","24")]
	[Parameter(Mandatory=$False,Position=1,HelpMessage='optional: Choose 1,2,3,4,5,6,7,8,9,10,11,12,24 hours')]
	[string]$NrOfHours = "6",
	[ValidateSet("2008","2008R2","2012","2012R2","2016","2016RS1","2016RS2","2016RS3","2016RS4","2016RS5","201619H1","201619H2","20162004","201620H2","201621H1","201621H2","201622H2","2022","Win11","Win1122H2","Win1123H1","help","")]
	[Parameter(Mandatory=$False,Position=2,HelpMessage='optional: Choose one OS from list: [2008|2008R2|2012|2012R2|2016|2016RS1|2016RS2|2016RS3|2016RS4|2016RS5|201619H1|201619H2|20162004|201620H2|201621H1|201621H2|201622H2|2022|Win11|Win1122H2|Win1123H1]')]
	[string]$OSversion,
	[switch]$OpenSummary= $true		# open with Notepad/FavEditor
	)
	
Process
{
	$verDateScript = "2023.02.09.0"
	$ScriptFolder = Split-Path $MyInvocation.MyCommand.Path -Parent
	# Load Common Library:
	. $ScriptFolder\Utils_RflShared.ps1

#region: ###### customization section of script, logging configuration ########################
	$SDPcheckINI = (Get-content -Path "$ScriptFolder\_SDPcheck.ini")
	$InOfflineMode 	= (($SDPcheckINI[1] -split " ")[2]).trim("""")	# set $True for outsourcer or when not connected to MS network - offline-SDPcheck
	$RFLroot = (($SDPcheckINI[2] -split " ")[2]).trim("""")	# "\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\" -or- "\\localhost\ToolsShare\rfl\"
	if ($InOfflineMode -match "False") {
			$StatsServer = (($SDPcheckINI[5] -split " ")[2]).trim("""")
			if (Test-Connection -ComputerName $StatsServer -Quiet -Count 1) {[bool]$Stats=$True} else {[bool]$Stats=$False}
	} else { 
		$Stats = $False
	}
#endregion: ###### customization section

$OutFileChars=600
$ScriptBeginTimeStamp = Get-Date
$CheckDate = (Get-Date).ToUniversalTime().ToString("yy-MM-dd_HH-mm-ss")
If ($Stats) {
	$StatsServerPath="\\$StatsServer\RFLstats$\RFL\scripts\Stats\"
	$CountInvFil = $StatsServerPath +'countEvt.dat'
	$CountInvFil2 = $CountInvFil +'.us'
}
Set-Variable -Name ErrorMsgEvt -Scope Script -Force

If ($PSBoundParameters['Debug']) { $DebugPreference='Continue'}

### Trail SDPPath with \ and allow path with space character
if ($SDPPath.EndsWith("\")){$SDPPath="$SDPPath"}
else {$SDPPath="$SDPPath" +"\"}
If (-NOT (Test-Path $SDPPath -PathType 'Container')){Throw "$($SDPPath) is not a valid folder"}

#region ### === main
"`n$(Get-Date -UFormat "%R:%S") ==Events check==... runnning 'Event Log check' back $NrOfHours h based on data collected at time of the SDP report was created."

$EventLogFiles = Get-Item -path ($SDPPath + "*_*.evtx") # all *_*.evtx files in given folder
if (!$EventLogFiles) { Write-Host -BackgroundColor Black -ForegroundColor Red -Object "There is no *.evtx file in $SDPPath - Double-check SDP path again!"
			$ErrorMsgEvt += "No-Valid-Evt " }

$NodeNames = foreach ($EventLogFile in $EventLogFiles){($EventLogFile.name).split('_')[0]}
$NodeNames = $NodeNames | Sort-Object | Get-Unique
Write-Host "$(Get-Date -UFormat "%R:%S") NodeName(s): $NodeNames"
Write-Host "$(Get-Date -UFormat "%R:%S") ....working on Evt logs ... please stay tuned a couple of min's..." #could take 20min or more..
## foreach loop: processing per NodeName in Cluster report
$NodeCnt=0
foreach ($NodeName in $NodeNames) {
 $NodeCnt++
 $EvtCheckFile = $SDPPath + '!'+$NodeName+'_Evt-Check.txt' #_'+$OSVersion+'.txt'
# "$NodeName - Latest $NrOfEntries events from all recorded Eventlog providers in SDP" > $EvtCheckFile # initialize, write new file
 "$NodeName - Events from all recorded Eventlog providers in SDP report back $NrOfHours hours" > $EvtCheckFile # initialize, write new file
 $EventLogFiles = Get-Item -path ($SDPPath + $NodeName +"_*.evtx")

   ## get only events records x ($NrOfHours) hours back to collecting SDP report
   if ($EventLogSysFile = get-childitem ($SDPPath + $NodeName +"_*System.evtx")) {
   	#_#$EvtSysDate = ($EventLogSysFile.LastWriteTime).ToUniversalTime()
   	$EventLogSysFileUTC = ((get-childitem ($SDPPath + $NodeName +"_*System.evtx")).LastWriteTime).ToUniversalTime()
   	Write-host " Date of SystemEvt (UTC):	$EventLogSysFileUTC"
   	## check only Events for 12-hours back -- #-hour $NrOfHours
   	#_# $EvtStartDate = Get-Date ($EvtSysDate - (New-TimeSpan -hour $NrOfHours)) -Format o
   	$EvtStartDate = Get-Date  ($EventLogSysFileUTC - (New-TimeSpan -hour 6)) -Format o

   	" check only Events for $NrOfHours hours back - based on SDP System Eventlog time (UTC): $EventLogSysFileUTC " >> $EvtCheckFile
   	Write-host " SystemEvtDate - $NrOfHours h:	$EvtStartDate"

		Write-Host -BackgroundColor Blue -ForegroundColor Cyan -NoNewline -Object "$($NodeCnt) " -Separator .
		$NodeName = ($EventLogFile.name).split('_')[0]
		Write-Verbose "OSVersion in script param1: $($OSVersion) "
		if (!$OSversion) {GetOSfromMSinfo32 $SDPPath $NodeName}			# Call function
		Write-Verbose "OSVersion in SDP report: $($OSVersion) - ComputerName: $($NodeName)"
		if ($($NodeCnt) -lt 32) {
			if ($NodeNames.count -gt 1) {Write-Host "Node $NodeName $NodeCnt of $($NodeNames.count)"}
			### show $NrOfEntries last events for all providers:
#			Get-WinEvent -Path $EventLogFiles -Oldest | Sort-Object -Property TimeCreated -Descending | Select-Object -First $NrOfEntries | Out-file $EvtCheckFile -Append -Width 4096
			Get-WinEvent -Path $EventLogFiles -FilterXPath "*[System[TimeCreated[@SystemTime&gt;='$($EvtStartDate)']]]" -ErrorAction SilentlyContinue | Out-file $EvtCheckFile -Append -Width $OutFileChars  #1024 #4096
			##-FilterXPath "*[System[TimeCreated[@SystemTime&gt;='2016-08-03T13:06:10.000Z' and @SystemTime&lt;='2016-08-03T13:07:20.999Z']]]"
			"=> Output file will be saved to: $EvtCheckFile "
			If (($Global:OpenSummary) -or ($OpenSummary)) {Invoke-Item $EvtCheckFile}
		}
		else {Write-Host "$(Get-Date -UFormat "%R:%S") ...checked only first 32 nodes" }
	}
	else {Write-host " System Eventlog $NodeName .evtx is missing." -ForegroundColor Cyan}
}

If (($Global:OpenSummary) -or ($OpenSummary)) {
	"`nUsing favorite editor to open $NodeNames EventLog Report(s) - this could take a few seconds until your Text Editor opens with results ..."
}

	$ScriptEndTimeStamp = Get-Date
	$Duration = $(New-TimeSpan -Start $ScriptBeginTimeStamp -End $ScriptEndTimeStamp)
Write-Host -BackgroundColor Gray -ForegroundColor Black -Object "$(Get-Date -UFormat "%R:%S") Done Get-Events script version v$verDateScript took $Duration `n"

### Stats
If ($Stats) {
 ($j=[int32](Get-Content $CountInvFil -TotalCount 1 -ErrorAction SilentlyContinue)) |out-null
 Try {(++$j) | Set-Content $CountInvFil -ErrorAction SilentlyContinue} Catch { }
 Try {"$j" + " ;$CheckDate" + "; $OSVersion; " + ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name) + "; $($Duration)" + "; $NodeCnt" + "; $SDPPath" + "; $ErrorMsgEvt" + "; v$verDateScript " | Out-File $CountInvFil2 -Append -Encoding UTF8 -ErrorAction SilentlyContinue} Catch { }
 }
} # end Process
#endregion ### === main



# SIG # Begin signature block
# MIInowYJKoZIhvcNAQcCoIInlDCCJ5ACAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBQg3wku8VWWEX2
# Lh/KXXSLKs1A40B9ZjIGnxjn4SsnoaCCDYUwggYDMIID66ADAgECAhMzAAADTU6R
# phoosHiPAAAAAANNMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjMwMzE2MTg0MzI4WhcNMjQwMzE0MTg0MzI4WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDUKPcKGVa6cboGQU03ONbUKyl4WpH6Q2Xo9cP3RhXTOa6C6THltd2RfnjlUQG+
# Mwoy93iGmGKEMF/jyO2XdiwMP427j90C/PMY/d5vY31sx+udtbif7GCJ7jJ1vLzd
# j28zV4r0FGG6yEv+tUNelTIsFmmSb0FUiJtU4r5sfCThvg8dI/F9Hh6xMZoVti+k
# bVla+hlG8bf4s00VTw4uAZhjGTFCYFRytKJ3/mteg2qnwvHDOgV7QSdV5dWdd0+x
# zcuG0qgd3oCCAjH8ZmjmowkHUe4dUmbcZfXsgWlOfc6DG7JS+DeJak1DvabamYqH
# g1AUeZ0+skpkwrKwXTFwBRltAgMBAAGjggGCMIIBfjAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUId2Img2Sp05U6XI04jli2KohL+8w
# VAYDVR0RBE0wS6RJMEcxLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJh
# dGlvbnMgTGltaXRlZDEWMBQGA1UEBRMNMjMwMDEyKzUwMDUxNzAfBgNVHSMEGDAW
# gBRIbmTlUAXTgqoXNzcitW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8v
# d3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIw
# MTEtMDctMDguY3JsMGEGCCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDEx
# XzIwMTEtMDctMDguY3J0MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIB
# ACMET8WuzLrDwexuTUZe9v2xrW8WGUPRQVmyJ1b/BzKYBZ5aU4Qvh5LzZe9jOExD
# YUlKb/Y73lqIIfUcEO/6W3b+7t1P9m9M1xPrZv5cfnSCguooPDq4rQe/iCdNDwHT
# 6XYW6yetxTJMOo4tUDbSS0YiZr7Mab2wkjgNFa0jRFheS9daTS1oJ/z5bNlGinxq
# 2v8azSP/GcH/t8eTrHQfcax3WbPELoGHIbryrSUaOCphsnCNUqUN5FbEMlat5MuY
# 94rGMJnq1IEd6S8ngK6C8E9SWpGEO3NDa0NlAViorpGfI0NYIbdynyOB846aWAjN
# fgThIcdzdWFvAl/6ktWXLETn8u/lYQyWGmul3yz+w06puIPD9p4KPiWBkCesKDHv
# XLrT3BbLZ8dKqSOV8DtzLFAfc9qAsNiG8EoathluJBsbyFbpebadKlErFidAX8KE
# usk8htHqiSkNxydamL/tKfx3V/vDAoQE59ysv4r3pE+zdyfMairvkFNNw7cPn1kH
# Gcww9dFSY2QwAxhMzmoM0G+M+YvBnBu5wjfxNrMRilRbxM6Cj9hKFh0YTwba6M7z
# ntHHpX3d+nabjFm/TnMRROOgIXJzYbzKKaO2g1kWeyG2QtvIR147zlrbQD4X10Ab
# rRg9CpwW7xYxywezj+iNAc+QmFzR94dzJkEPUSCJPsTFMIIHejCCBWKgAwIBAgIK
# YQ6Q0gAAAAAAAzANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlm
# aWNhdGUgQXV0aG9yaXR5IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEw
# OTA5WjB+MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYD
# VQQDEx9NaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG
# 9w0BAQEFAAOCAg8AMIICCgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+la
# UKq4BjgaBEm6f8MMHt03a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc
# 6Whe0t+bU7IKLMOv2akrrnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4D
# dato88tt8zpcoRb0RrrgOGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+
# lD3v++MrWhAfTVYoonpy4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nk
# kDstrjNYxbc+/jLTswM9sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6
# A4aN91/w0FK/jJSHvMAhdCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmd
# X4jiJV3TIUs+UsS1Vz8kA/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL
# 5zmhD+kjSbwYuER8ReTBw3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zd
# sGbiwZeBe+3W7UvnSSmnEyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3
# T8HhhUSJxAlMxdSlQy90lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS
# 4NaIjAsCAwEAAaOCAe0wggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRI
# bmTlUAXTgqoXNzcitW2oynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTAL
# BgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBD
# uRQFTuHqp8cx0SOJNDBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jv
# c29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3JsMF4GCCsGAQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3J0MIGfBgNVHSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEF
# BQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1h
# cnljcHMuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkA
# YwB5AF8AcwB0AGEAdABlAG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn
# 8oalmOBUeRou09h0ZyKbC5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7
# v0epo/Np22O/IjWll11lhJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0b
# pdS1HXeUOeLpZMlEPXh6I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/
# KmtYSWMfCWluWpiW5IP0wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvy
# CInWH8MyGOLwxS3OW560STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBp
# mLJZiWhub6e3dMNABQamASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJi
# hsMdYzaXht/a8/jyFqGaJ+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYb
# BL7fQccOKO7eZS/sl/ahXJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbS
# oqKfenoi+kiVH6v7RyOA9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sL
# gOppO6/8MO0ETI7f33VtY5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtX
# cVZOSEXAQsmbdlsKgEhr/Xmfwb1tbWrJUnMTDXpQzTGCGXQwghlwAgEBMIGVMH4x
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01p
# Y3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTECEzMAAANNTpGmGiiweI8AAAAA
# A00wDQYJYIZIAWUDBAIBBQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQw
# HAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIBeI
# oUyo0pLBEBJJsUfTyosVGdKnpgmA44bWb4FQV4mdMEIGCisGAQQBgjcCAQwxNDAy
# oBSAEgBNAGkAYwByAG8AcwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20wDQYJKoZIhvcNAQEBBQAEggEAgsgHC4XbHIcTw1mfX4TDJOhwYIFe2T4tR8U3
# r/9CFXdCXHo7LSKeryMT3hCRVOoU04Lbhb26Z8tNQD3j8jxi40xeiALOmpNbGAoi
# kNWrBcvGhF96S1pnpAPP7u4Xyc8m+lsY1Ka+baV7i442vQtmksHk0ZH5PcMVrxvk
# u7/gPO6XLhfhzpPz9UrPjU0iRSAi1L+9UJLK4rRYUkV4IZU8cR4xZsY940o1bp4s
# ZFkxa0/D9z9kFxn8pXWsyTXTZ9m4cQhcmzqmsxC2NqjQJGeGqF8E/qAksyqtWPJR
# xBQr2tzITIn81B6XgYkUesPbNIjO9lLH94nz3LlU3DVfQnRIPaGCFv4wghb6Bgor
# BgEEAYI3AwMBMYIW6jCCFuYGCSqGSIb3DQEHAqCCFtcwghbTAgEDMQ8wDQYJYIZI
# AWUDBAIBBQAwggFPBgsqhkiG9w0BCRABBKCCAT4EggE6MIIBNgIBAQYKKwYBBAGE
# WQoDATAxMA0GCWCGSAFlAwQCAQUABCBNaaDVXgMiOJbTZb9knVtjDCMpHxhdulD7
# JuIN1VAuFAIGZGzXya/NGBEyMDIzMDYxNDE1NTk0Mi42WjAEgAIB9KCB0KSBzTCB
# yjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1Jl
# ZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjElMCMGA1UECxMc
# TWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0aW9uczEmMCQGA1UECxMdVGhhbGVzIFRT
# UyBFU046M0U3QS1FMzU5LUEyNUQxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0
# YW1wIFNlcnZpY2WgghFXMIIHDDCCBPSgAwIBAgITMwAAAcn61Y4lIHQCXgABAAAB
# yTANBgkqhkiG9w0BAQsFADB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGlu
# Z3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBv
# cmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAe
# Fw0yMjExMDQxOTAxMzhaFw0yNDAyMDIxOTAxMzhaMIHKMQswCQYDVQQGEwJVUzET
# MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmlj
# YSBPcGVyYXRpb25zMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjozRTdBLUUzNTkt
# QTI1RDElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZTCCAiIw
# DQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBANZy4uWOb8/CvlqMYZO6hlv7wsYu
# XrkzNNU4hGxThvIO0hQdFTI2IKOk4kc4DkPgjedzgTipcjB1s0S+Mb2ktN2ZSIHr
# SCC2IgEqILBLZY8xJURzu3wxgxVnHc/pQjWJiaM7WxtzzK58W5VBx1JK+AuxAR29
# mNOxneRiQYD/PuQGTbE5bBxnMx7OOZpj+61IHDJ//3PEPxmEqnU+DlxC6ed4ffRJ
# 8heM3LHdmRY8XY9ZT/EBsGWUuBfNiQRntqQq0mpMhY08cxSlDsHEHq8AUf2GkJcu
# 5rQq2uDzXMhEJvp/yw3Hv1VYkGvDjNpwWRysOgsjKhMxSScuR4s8/Gesa6qiyrYv
# L4iVENBbapE10kd//8PDwCsgZbyGExRfy8tyYd3G1XjoEprmzlcL/JzHoXEG9gLc
# XFP5XchFKsvP7YRByFjWm8x18eTvQ+G7UuqCXYC5h8a0wbRrHFUKsdM+f31CJCxO
# 7W8H6KvOHBf1ESxMsN6ueyldlOIDoXN+el2BFUHSV6OlRVgUA2G82p0Nuc2NtVAp
# I/NtQsg/dIKqzt60D5XEKOnq8Ftgxdn7JoAG1as0LM+kZJmn8+K3te5Ju6ntPT7s
# B8OXt8eWSBhKFZXzZyb+vvOdbsCl+gKWRcT83kKO1v+QbWk5pGRIcGOQHQj4D79G
# miBEJ9qhezLxcAnLAgMBAAGjggE2MIIBMjAdBgNVHQ4EFgQUBW+dZ0bCPKG+eDoU
# xXlRe0QuMsswHwYDVR0jBBgwFoAUn6cVXQBeYl2D9OXSZacbUzUZ6XIwXwYDVR0f
# BFgwVjBUoFKgUIZOaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jcmwv
# TWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3JsMGwGCCsG
# AQUFBwEBBGAwXjBcBggrBgEFBQcwAoZQaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraW9wcy9jZXJ0cy9NaWNyb3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIwMjAx
# MCgxKS5jcnQwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEFBQcDCDANBgkq
# hkiG9w0BAQsFAAOCAgEANqi6nGbfR4pCB3I+wJZx4Y6LsUozngWkxPhCvGl3FS5v
# XAPA9v2WNjlKWLznYbgxFfYRJVZs6KYibpP8QWIenViU0YZku4VY6xras0hVtC33
# 7EcrI8ZKbqsoR4gQ8TFzBmehnc1H6lT9mXdjvifwWECYLPTR2M/wjOF2kT/k9lTN
# yRNZkjtai2vpnweNu0Ii4/yQu01GIIeEWPqCzBVbkCWb12Jf4yExX1KaSaAGpAa9
# FXNq9ZD+Q4iWjb2Vif3LmGolkOJPcacOsBs96qu8QFp5Rs7GsMBYY7cKuRB/7N+y
# wn3ocrgsPGUSfVt7YEhXqQFTO7FBPj691Lvoj7wVeE7EwzRS9AlSD1/tVziemERm
# CdpBxqaBnP+bIANiCkHJfe2Q2CSKosYMCjX7cje9DtAE26U1YbGzdNRVZYtB/r4H
# Bocs5Oo6QMsBzw0kP8aBHhlOPujxU1zETv3zMxnFHH9GR6mTJtFIaB/LTrZNfJOg
# e+SiV07WN2TO6U37q0r9kK7+c8wgYssrLTj8PyCSPpPaKU4Grawt/S+vfysMrQ9M
# e7dI5k17ZS2Whr6EpY3csq+kA0VZKrAmi1EkrAIlnmr+aoOuFN5i5nnpKNBPUyec
# s7Tf43Is5R8dF7IDrjerLm9wj1ewADDIiqKXUGKoj17vSMb6l0+whP0jAtqXDckw
# ggdxMIIFWaADAgECAhMzAAAAFcXna54Cm0mZAAAAAAAVMA0GCSqGSIb3DQEBCwUA
# MIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQD
# EylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0y
# MTA5MzAxODIyMjVaFw0zMDA5MzAxODMyMjVaMHwxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1w
# IFBDQSAyMDEwMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA5OGmTOe0
# ciELeaLL1yR5vQ7VgtP97pwHB9KpbE51yMo1V/YBf2xK4OK9uT4XYDP/XE/HZveV
# U3Fa4n5KWv64NmeFRiMMtY0Tz3cywBAY6GB9alKDRLemjkZrBxTzxXb1hlDcwUTI
# cVxRMTegCjhuje3XD9gmU3w5YQJ6xKr9cmmvHaus9ja+NSZk2pg7uhp7M62AW36M
# EBydUv626GIl3GoPz130/o5Tz9bshVZN7928jaTjkY+yOSxRnOlwaQ3KNi1wjjHI
# NSi947SHJMPgyY9+tVSP3PoFVZhtaDuaRr3tpK56KTesy+uDRedGbsoy1cCGMFxP
# LOJiss254o2I5JasAUq7vnGpF1tnYN74kpEeHT39IM9zfUGaRnXNxF803RKJ1v2l
# IH1+/NmeRd+2ci/bfV+AutuqfjbsNkz2K26oElHovwUDo9Fzpk03dJQcNIIP8BDy
# t0cY7afomXw/TNuvXsLz1dhzPUNOwTM5TI4CvEJoLhDqhFFG4tG9ahhaYQFzymei
# XtcodgLiMxhy16cg8ML6EgrXY28MyTZki1ugpoMhXV8wdJGUlNi5UPkLiWHzNgY1
# GIRH29wb0f2y1BzFa/ZcUlFdEtsluq9QBXpsxREdcu+N+VLEhReTwDwV2xo3xwgV
# GD94q0W29R6HXtqPnhZyacaue7e3PmriLq0CAwEAAaOCAd0wggHZMBIGCSsGAQQB
# gjcVAQQFAgMBAAEwIwYJKwYBBAGCNxUCBBYEFCqnUv5kxJq+gpE8RjUpzxD/LwTu
# MB0GA1UdDgQWBBSfpxVdAF5iXYP05dJlpxtTNRnpcjBcBgNVHSAEVTBTMFEGDCsG
# AQQBgjdMg30BATBBMD8GCCsGAQUFBwIBFjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL0RvY3MvUmVwb3NpdG9yeS5odG0wEwYDVR0lBAwwCgYIKwYBBQUH
# AwgwGQYJKwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGGMA8GA1Ud
# EwEB/wQFMAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186aGMQwVgYD
# VR0fBE8wTTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwv
# cHJvZHVjdHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEB
# BE4wTDBKBggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9j
# ZXJ0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwDQYJKoZIhvcNAQELBQAD
# ggIBAJ1VffwqreEsH2cBMSRb4Z5yS/ypb+pcFLY+TkdkeLEGk5c9MTO1OdfCcTY/
# 2mRsfNB1OW27DzHkwo/7bNGhlBgi7ulmZzpTTd2YurYeeNg2LpypglYAA7AFvono
# aeC6Ce5732pvvinLbtg/SHUB2RjebYIM9W0jVOR4U3UkV7ndn/OOPcbzaN9l9qRW
# qveVtihVJ9AkvUCgvxm2EhIRXT0n4ECWOKz3+SmJw7wXsFSFQrP8DJ6LGYnn8Atq
# gcKBGUIZUnWKNsIdw2FzLixre24/LAl4FOmRsqlb30mjdAy87JGA0j3mSj5mO0+7
# hvoyGtmW9I/2kQH2zsZ0/fZMcm8Qq3UwxTSwethQ/gpY3UA8x1RtnWN0SCyxTkct
# wRQEcb9k+SS+c23Kjgm9swFXSVRk2XPXfx5bRAGOWhmRaw2fpCjcZxkoJLo4S5pu
# +yFUa2pFEUep8beuyOiJXk+d0tBMdrVXVAmxaQFEfnyhYWxz/gq77EFmPWn9y8FB
# SX5+k77L+DvktxW/tM4+pTFRhLy/AsGConsXHRWJjXD+57XQKBqJC4822rpM+Zv/
# Cuk0+CQ1ZyvgDbjmjJnW4SLq8CdCPSWU5nR0W2rRnj7tfqAxM328y+l7vzhwRNGQ
# 8cirOoo6CGJ/2XBjU02N7oJtpQUQwXEGahC0HVUzWLOhcGbyoYICzjCCAjcCAQEw
# gfihgdCkgc0wgcoxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAw
# DgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24x
# JTAjBgNVBAsTHE1pY3Jvc29mdCBBbWVyaWNhIE9wZXJhdGlvbnMxJjAkBgNVBAsT
# HVRoYWxlcyBUU1MgRVNOOjNFN0EtRTM1OS1BMjVEMSUwIwYDVQQDExxNaWNyb3Nv
# ZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQB96YvL/h4Bm41U
# LOBt+nUcVgbdDqCBgzCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEw
# MA0GCSqGSIb3DQEBBQUAAgUA6DRT2jAiGA8yMDIzMDYxNDIyNTczMFoYDzIwMjMw
# NjE1MjI1NzMwWjB3MD0GCisGAQQBhFkKBAExLzAtMAoCBQDoNFPaAgEAMAoCAQAC
# Ag6hAgH/MAcCAQACAhNeMAoCBQDoNaVaAgEAMDYGCisGAQQBhFkKBAIxKDAmMAwG
# CisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAIAgEAAgMBhqAwDQYJKoZIhvcNAQEF
# BQADgYEAe/KRFAw/QZi4d11dQGMjq0p8PxWNWxJIQDEJs1cX1E3jHd/d2hvZKX61
# zD4p7savJwFIlUUKryVXkKX8O2ABkDj3RvXgcSD1TZT49Uv5UK4/E7Gn1TuaJWVY
# +dMjgTna7CwZ6OQUW27I+T3cffI9duM33pIJnb0ouJGDR2ki/O8xggQNMIIECQIB
# ATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAAcn61Y4lIHQC
# XgABAAAByTANBglghkgBZQMEAgEFAKCCAUowGgYJKoZIhvcNAQkDMQ0GCyqGSIb3
# DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCD+R/MG3Q1r24spwQSY3zREKiv/qQoHsq6n
# 3T7myziKujCB+gYLKoZIhvcNAQkQAi8xgeowgecwgeQwgb0EIIF1zn9S3VFLECd4
# Kdh/YA0jIYkA/8194V184dk5dv2BMIGYMIGApH4wfDELMAkGA1UEBhMCVVMxEzAR
# BgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1p
# Y3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3Rh
# bXAgUENBIDIwMTACEzMAAAHJ+tWOJSB0Al4AAQAAAckwIgQg3oQ9pZTdOn0l/9Ey
# 65AaOtLbFNfj0gKv+sI1mk2XBT8wDQYJKoZIhvcNAQELBQAEggIAoP74+QNdQjCl
# vdcwCvj2KXxDiE0vRNOglq1u8DokU4VWD0Bfce2yG0B9QAkUHkNwXoWUYMy7c+g4
# PRyqW3tvl6sI5O2b9fKZvNb8e5QVHfUxymUdkyxeJ1put8gx34fAwqzUgoTslUDu
# 9McrBFxDHiJwRwOAEd/4QohAFL6qgdt77vpMDXmHQcli4RK9mlc9H2FePBwSMmbq
# dJ0xXo5NQVAKzRIA5CpHBhI991nuNf7JxYkGbTVcSp8fgw97OPqPjfQAnhtaTWXY
# n1U3SwKcqwpHBvN9gqRlhO5CQfEi3oEvHBWgNMp4FuSvbA7RoU4MGUfMHQMG2zkE
# vtiAtNcAJ6cixcZiNOUktbr3U/iyw20aYQJ2527AqjCr6CwwIxeyKj4Qg90QlVOX
# njDLDhlMwU7WxQrSIqeGztzRwRAnEMPsw5Y8NlFyAG+Dxa7I6dGByc1N3ct5H8cK
# WgPcBoklz3l7nuRXioI6eFmQzV8U9u6k2SqRW+52lMF9cvA5omvEgHPFWXUXvrbP
# 4Kn1/2vJaMJbtZZCg7LZpiyNvzYzzHfuJ4RGq9sSEO1PJUnh9eCP3wXJP9VS2L3z
# yL2tIGO4TPXVnQnkn47zFZy8N1KkULfKqfVhzB8fiKTljcgtDelYG0O/IUFV4gPr
# K/QdM4yFX2nuhX2amyfhvsG56HLbDq0=
# SIG # End signature block
