SDPcheck
==========
*** MS internal tool ***
This script collection supports MS engineers/partners to analyse SDP reports received from customers and gathered previously by running 
  PS> .\TSSv2.ps1 -SDP <speciality> 

What is SDPcheck aka RFLcheck?
------------------------------
RFLcheck is a set of Explorer Plugin and PowerShell scripts that enables engineers to identify missing Hotfixes in a customer supplied SDP report. 
Useful add-ons are 
- checks for 3rd party drivers (Pstat), 
- checks for incorrect or changed Registry settings, 
- PerformanceMonitorAnalysis (PMA), 
- Pstat-Compare, 
- Event-summary up to 6h before SDP collection, 
- check for specific Events, 
- re-Arrange-SDPFolders (for Cluster). 
For more details see internal KB3070416
  
MS internal KB: 
  3070416	Servicing: Tools: SDP + RFL PS scripts identify missing updates (Recommended Fix List)
  https://internal.support.services.microsoft.com/en-US/help/3070416
  
The script collection is supposed to be located on an MS internal File server ( currently: \\emeacssdfs.europe.corp.microsoft.com\netpod\RFL),
but for convenience a variant can also be hosted on a partner File server (preferred) or on personal engineer system (LocalHost).
In this case, the database files in subfolder \RFLlists should be updated once per month (after patch Tuesday)
To do so, you can run:  .\RFL_update-script.ps1

Setup steps for offline version
-------------------------------
- create a local share on C:\ToolsShare with name 'ToolsShare'
- download latest full package from https://github.com/walter-1/offline-SDPcheck/releases
- unzip RFL.zip into C:\ToolsShare
- doubleclick C:\ToolsShare\RFL\Rfl-Check_ShellExtension.reg
- now the offline version of SDPcheck is ready to use as an Explorer context menu
