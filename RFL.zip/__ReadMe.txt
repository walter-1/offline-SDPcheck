SDPcheck
==========
*** MS internal tool ***
This script collection supports MS engineers/partners to analyse SDP reports received from customers and gathered previously by running 
  PS> .\TSS.ps1 -SDP <speciality> 

What is SDPcheck aka RFLcheck?
------------------------------
RFLcheck is a set of Explorer Plugin and PowerShell scripts that enables engineers to identify missing Hotfixes in a customer supplied SDP report. 
Useful add-ons are 
- checks for 3rd party drivers (Pstat), 
- checks for incorrect or changed Registry settings, 
- PerformanceMonitorAnalysis (PMA), 
- Pstat-Compare, 
- Event-summary up to 6h before SDP collection, 
- check for specific Events, 
- re-Arrange-SDPFolders (for Cluster). 
For more details see internal KB3070416
  
MS internal KB: 
  3070416	Servicing: Tools: SDP + RFL PS scripts identify missing updates (Recommended Fix List)
  https://internal.support.services.microsoft.com/en-US/help/3070416
  
The script collection is supposed to be located on an MS internal File server ( currently: \\EMEA.europe.corp.microsoft.com\Shares\SDP-Check\RFL),
but for convenience a variant (aka.ms/getRFL) can also be hosted on a partner File server (preferred) or on personal engineer system (LocalHost).
In this case, the database files in subfolder \RFLlists should be updated once per month (after patch Tuesday)
To do so, you can run:  .\RFL_update-script.ps1
Note: SDP/RFLcheck will automatically update on your local PC, when a new version is available.

DL for questions:
- WW CSS RFL-check User Discussion <ww-CSS-RFL-check@microsoft.com>
 Join RFL alias: https://idwebelements/GroupManagement.aspx?Group=ww-css-rfl-check&Operation=join 
- WW CSS TSS_tools user Discussion <ww-CSS-TSS@microsoft.com>
 Join TSS alias: https://idwebelements/GroupManagement.aspx?Group=ww-css-tss&Operation=join

TEAMS channel: https://teams.microsoft.com/l/channel/19%3aa62949401f7547d89922f3f68ea97e51%40thread.skype/RFLcheck?groupId=107ce661-276a-4ab0-869e-dc0a1f7feee1&tenantId=72f988bf-86f1-41af-91ab-2d7cd011db47

__ QUICK Setup: Steps for offline version __
--------------------------------------------
- create a local share on C:\ToolsShare with name 'ToolsShare'
- download latest full package from https://github.com/walter-1/offline-SDPcheck/releases = aka.ms/getRFL
- unzip RFL.zip into C:\ToolsShare
- doubleclick C:\ToolsShare\RFL\Rfl-Check_ShellExtension.reg
- now the offline version of SDPcheck is ready to use as an Explorer context menu


___ MORE INFORMATION ___

Check RFL/SDP setup and installation instructions
=================================================
You can install SDPcheck on a TeamServer -or- locally on your PC (RFL will auto-update)

A) TeamServer
=============
If  using a TeamServer (task for TeamServer Admin):
---------------------------------------------------
We recommend to use a team share 'ToolsShare' on a TeamServer '\\TeamServer', in order to minimize monthly maintenance, but his seems to obolete as AutoUpdate feature has been introduced (in case you have internet connectivity).
If you are sharing the RFL scripts on a different \\TeamServer\ToolsShare adjust line $RFLroot in \\TeamServer\ToolsShare\RFL\_SDPcheck.ini, and also replace 'localhost\\ToolsShare'  in file Rfl-Check_ShellExtension.reg
The line for $RFLroot should reflect your actual share location
	$RFLroot = "\\localhost\ToolsShare\RFL\"
	
1. Create a new Share named 'ToolsShare' on the TeamServer
2. Expand the RFL.zip into the folder \\TeamServer\ToolsShare\ (files will be expanded in subfolder \RFL)
3. in file \\TeamServer\ToolsShare\RFL\_SDPcheck.ini replace line $RFLroot = "\\localhost\ToolsShare\rfl" with $RFLroot = "\\TeamServer\ToolsShare\RFL"
4. Edit the RFL-Check_ShellExtension.reg file and global replace '\\\\LocalHost\\ToolsShare' with '\\\\TeamServer\\ToolsShare'
5. on your own PC: download locally and DoubleClick the reg file \\TeamServer\ToolsShare\RFL\RFL-Check_ShellExtension.reg

B) Local installation
=====================
If  using only your own PC (no TeamServer):
-------------------------------------------
1. Create a new Share named 'ToolsShare' on local disk
2. Expand the RFL.zip into the folder \\LocalHost\ToolsShare\ (files will be expanded in subfolder \RFL)
3. on your own PC: DoubleClick the reg file \\LocalHost\ToolsShareRFL\RFL-Check_ShellExtension.reg


Now you can use the Explorer context menu on any extracted SDP folder
The RFLcheck will automaticaly try to open resulting *.txt files in your favorite text Editor (default is NotePad.exe);
hint: if you register *.txt files to be opend with a more sophisticated editor like Notepad++ or TextPad, all files will open as additional Tabs in your text Editor.

Note: SDP/RFLcheck will automatically update, when a new version is available.


References:
===========
:: MS internal KBs
::  Servicing: Tools: TSS TroubleShootingScript/toolset for rapid flexible data collection for CritSit and standard cases
::    Public TSS: https://docs.microsoft.com/en-us/troubleshoot/windows-client/windows-troubleshooters/introduction-to-troubleshootingscript-toolset-tssv2 =  https://aka.ms/TSSv2
::    Public download: aka.ms/getTSS -or- https://github.com/CSS-Windows/WindowsDiag/tree/master/ALL/TSSv2 =  https://aka.ms/getTSS
::   join TSS DL: https://idwebelements/GroupManagement.aspx?Group=ww-css-tss&Operation=join

::  Servicing: Tools: SDP + RFL PS scripts identify missing updates (Recommended Fix List)
::   KB: https://internal.support.services.microsoft.com/en-us/help/3070416
::   join RFL DL: https://idwebelements/GroupManagement.aspx?Group=ww-css-RFL-check&Operation=join