<# last edit by: waltere 2022-09-14
  File Name: get-PStatSum.ps1
  Objective: check for Microsoft and 3rd party modules/drivers and their installed version
  Leveraging the PstatSum.vbs script Created by AustinM
  call script with -Verbose or -Debug for add. console output

VERSION and AUTHORs:
    Ver 1.01 - 27.02.2015
	Walter Eder	- waltere@microsoft.com
	Austin Mack	- AustinM@microsoft.com (PstatSum.vbs script Created by AustinM)

#PstatSum.vbs origin: \\austinm\VBS\VBS-Notdone
'==========================================================================
'==  Created by AustinM
'==  Last Modified: 24 Mar 2010 By AustinM
'==
'== TO USE/INSTALL:
'==  Copy the custom script to a read/write folder on a local drive. Double
'==  click the VBS and then you will have the option to right click .TXT
'==  files and select "Open with PStat Summary VBS".
'==
'==  Note: The MPS report should be extracted to a folder before
'==     right clicking the file to create summary.
'==
'== HOW IT WORKS:
'==  Reads all the .TXT files created by CHECKSYM that are in the folder
'==  with the PSTAT file to get file version information. It then reads
'==  the modules loaded in memory listed at the bottom of the PSTAT.TXT
'==  file.
'==
'== Please send any comments/suggestions to AustinM
'==
'==========================================================================

HISTORY
	2015-02-07 v0.90 Note: running the PstatSum.vbs script requires to ChangeDirectory into SDPpath
		  v1.00 included in ShellExtension; changed column size of "--Company--";
			 appended to run 'registry check' script
	2015-02-07 v1.01 changed $RunAddon=0 -> no 'registry check' (already done in main script)
	2016-02-10 v1.03 using FQDN emeacssdfs.europe.corp.microsoft.com
	2016-04-17 v1.04 adding OSversion
	2016-08-03 adding 2016RS1
	2017-04-01 adding 2016RS2
  2017-06-06 changed check path to \\emeacssdfs\netpod
	2017-10-06 v1.05 adding 2016RS3
	2018-04-05 adding 2016RS4
	2021-08-12 add VBdebug switch
	2022-09-08 using Utils_RflShared.psm1 library
	
	ToDo:
		- check for high handle count (>5000)
		- check why PStatSum does not run for Pstat.TXT >~2MB

#>

<#
.SYNOPSIS
The script reads SDP report and displays overview of Microsoft and 3rd party modules/drivers that were loaded in memory when the SDP report was created.

SYNTAX: .\get-PStatSum.ps1 [full-path-to-expanded-SDP-report]

.DESCRIPTION
The script reads in the *_PStat.txt file(s) from the SDP report and displays overview of Microsoft and 3rd party modules/drivers that were loaded in memory when the SDP report was created.
Note: Expand the SDP report cab file into folder before running this script.

'== HOW IT WORKS:
'==  Reads all the .TXT files created by CHECKSYM that are in the folder
'==  with the PSTAT file to get file version information. It then reads
'==  the modules loaded in memory listed at the bottom of the PSTAT.TXT
'==  file.

If you experience PS error '...is not digitally signed.' run the command:
 Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned

.PARAMETER OpenSummary
 This switch will not open resulting summary file with Notepad/Favorite Editor if set to $False
 
.EXAMPLE
\\emeacssdfs.europe.corp.microsoft.com\netpod\rfl\get-PStatSum.ps1 \\ioanc00\temp\New_RFL\SDPs\FileServer

.LINK
\\emeacssdfs.europe.corp.microsoft.com\netpod\rfl\get-PStatSum.ps1
ioanc@microsoft.com ; waltere@microsoft.com ;

#>

Param(
	[ValidateScript({Test-Path $_ -PathType 'Container'})]
	[Parameter(Mandatory=$True,Position=0,HelpMessage='Choose a writable SDP folder location, i.e. C:\SR\SDP-report\ ')]
	[string]$SDPPath,
	[ValidateSet("2008","2008R2","2012","2012R2","2016","2016RS1","2016RS2","2016RS3","2016RS4","2016RS5","201619H1","201619H2","20162004","201620H2","201621H1","201621H2","201622H2","2022","Win11","Win1122H2","help","")]
	[Parameter(Mandatory=$False,Position=1,HelpMessage='optional: Choose one OS from list: [2008|2008R2|2012|2012R2|2016|2016RS1|2016RS2|2016RS3|2016RS4|2016RS5|201619H1|201619H2|20162004|201620H2|201621H1|201621H2|201622H2|2022|Win11|Win1122H2]')]
	[string]$OSversion,
	[switch]$OpenSummary = $true,		# open with Notepad/FavEditor
	[switch]$VBdebug = $False
	)

Process
{
	$verDateScript = "2022.09.14.0"
	$ScriptFolder = Split-Path $MyInvocation.MyCommand.Path -Parent
	# Load Common Library
	  Remove-Module Utils_RflShared -ErrorAction Ignore
	  Import-Module $ScriptFolder\Utils_RflShared.psm1 -DisableNameChecking
	  
#region: ###### customization section of script, logging configuration ########################
	$InOfflineMode 	= ((( Get-content -Path "$ScriptFolder\version_SDPcheck.dat")[1] -split " ")[2]).trim("""")	# set $True for outsourcer or when not connected to MS network - offline-SDPcheck
	$RFLroot = ((( Get-content -Path "$ScriptFolder\version_SDPcheck.dat")[2] -split " ")[2]).trim("""")	# "\\emeacssdfs.europe.corp.microsoft.com\netpod\rfl\" -or- "\\localhost\ToolsShare\rfl\"
	if ($InOfflineMode -match "False") {
		$StatsServer = ((( Get-content -Path "$ScriptFolder\version_SDPcheck.dat")[4] -split " ")[2]).trim("""")
		if (Test-Connection -ComputerName $StatsServer -Quiet -Count 1) {[bool]$Stats=$True} else {[bool]$Stats=$False}
	} else { 
		$Stats = $False
	}
	$PstatSumScript = $RFLroot + "\PstatSum.vbs"
#endregion: ###### customization section

$ScriptBeginTimeStamp = Get-Date
$CheckDate = (Get-Date).ToUniversalTime().ToString("yy-MM-dd_HH-mm-ss")
if ($Stats) {
	$StatsServerPath="\\$StatsServer\netpod\tools\RFL\"
	$CountInvFil = $StatsServerPath +'countPSsum.dat'
	$CountInvFil2 = $CountInvFil +'.us'
	#increment at start of script
	 ($j=[int32](Get-Content $CountInvFil -TotalCount 1 -ErrorAction SilentlyContinue)) |out-null
	 (++$j) | Set-Content $CountInvFil -ErrorAction SilentlyContinue
}

Set-Variable -Name ErrorMsgPS -Scope Script -Force
If ($PSBoundParameters['Debug']) { $DebugPreference='Continue'}

### Trail SDPPath with \ and allow path with space character
if ($SDPPath.EndsWith("\")){$SDPPath="$SDPPath"}
else {$SDPPath="$SDPPath" +"\"}
If (-NOT (Test-Path $SDPPath -PathType 'Container')){Throw "$($SDPPath) is not a valid folder"}

#region ### === main
"`n$(Get-Date -UFormat "%R:%S") ==Pstat Check==... Examining modules/drivers that were loaded in memory when the SDP report was created."
## change directory to $SDPPath as required by PstatSum.vbs script
Push-Location
Set-Location $SDPPath


$PStatTXTfiles = Get-Item -path ($SDPPath + "*_PStat.txt")
if (($Global:OpenSummary) -or ($OpenSummary)) {$PStatOpenS = 1 } else { $PStatOpenS = 0 }
if ($VBdebug) {$UseDebugFlag="/debug"; Write-Verbose "...enabling $UseDebugFlag"} else { $UseDebugFlag = "" }
$NodeNames = foreach ($NodeName in $PStatTXTfiles){($NodeName.name).split('_')[0]}
Write-Host "$(Get-Date -UFormat "%R:%S") NodeName(s): $NodeNames"

if (!$PStatTXTfiles) { Write-Host -BackgroundColor Black -ForegroundColor Red -Object "There is no *_PStat.txt file in $SDPPath - Double-check SDP path again!"
			$ErrorMsgPS += "No-Valid-PStat " }
$NodeCnt=0
foreach ($PStatTXTfile in $PStatTXTfiles){
	$NodeCnt++
	Write-Host -BackgroundColor Blue -ForegroundColor Cyan -NoNewline -Object "$($NodeCnt) " -Separator .
	$NodeName = ($PStatTXTfile.name).split('_')[0]
	Write-Verbose "OSVersion in script param1: $($OSVersion) "
	if (!$OSversion) {GetOSfromMSinfo32 $SDPPath $NodeName}			# Call function
	Write-Verbose "OSVersion in SDP report: $($OSVersion) - ComputerName: $($NodeName)"
	if ($($NodeCnt) -lt 32) {
		if ($NodeNames.count -gt 1) {Write-Host "Node $NodeName $NodeCnt of $($NodeNames.count)"}
		Write-Verbose "starting wscript.exe $PstatSumScript $PStatTXTfile $PStatOpenS $UseDebugFlag"
		& C:\Windows\System32\wscript.exe $PstatSumScript $PStatTXTfile $PStatOpenS $UseDebugFlag
		" => Output file will be saved to: $($SDPPath)!PStatSum_$($Nodename).TXT "
	}
	else {Write-Host "$(Get-Date -UFormat "%R:%S") ...checked only first 32 nodes"}
}
If (($Global:OpenSummary) -or ($OpenSummary)) {
	"`nUsing favorite editor to open Pstat Report(s) - this could take a few seconds until your Text Editor opens with results ..."
	#" => Output file saved to: $($SDPPath)!PStatSum_*.TXT"
}
	
	$ScriptEndTimeStamp = Get-Date
	$Duration = $(New-TimeSpan -Start $ScriptBeginTimeStamp -End $ScriptEndTimeStamp)
Write-Host -BackgroundColor Gray -ForegroundColor Black -Object "$(Get-Date -UFormat "%R:%S") Done Get-PStatSum script version v$verDateScript took $Duration `n"

Pop-Location

### Stats
If ($Stats) { #increment at start of script
 "$j" + " ;$CheckDate" + "; $OSVersion; " + ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name) + "; $($Duration)" + "; $NodeCnt" + "; $SDPPath" + "; $ErrorMsgPS" + "; v$verDateScript " | Out-File $CountInvFil2 -Append -Encoding UTF8 -ErrorAction SilentlyContinue
 }
#region ### === main
}


