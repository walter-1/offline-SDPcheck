<# last edit by: waltere 2020-01-10
  File Name: get-PStatSum.ps1
  Objective: check for Microsoft and 3rd party modules/drivers and their installed version
  Leveraging the PstatSum.vbs script Created by AustinM
  call script with -Verbose or -Debug for add. console output

VERSION and AUTHORs:
    Ver 1.01 - 27.02.2015
	Walter Eder	- waltere@microsoft.com
	Austin Mack	- AustinM@microsoft.com (PstatSum.vbs script Created by AustinM)

#PstatSum.vbs origin: \\austinm\VBS\VBS-Notdone
'==========================================================================
'==  Created by AustinM
'==  Last Modified: 24 Mar 2010 By AustinM
'==
'== TO USE/INSTALL:
'==  Copy the custom script to a read/write folder on a local drive. Double
'==  click the VBS and then you will have the option to right click .TXT
'==  files and select "Open with PStat Summary VBS".
'==
'==  Note: The MPS report should be extracted to a folder before
'==     right clicking the file to create summary.
'==
'== HOW IT WORKS:
'==  Reads all the .TXT files created by CHECKSYM that are in the folder
'==  with the PSTAT file to get file version information. It then reads
'==  the modules loaded in memory listed at the bottom of the PSTAT.TXT
'==  file.
'==
'== Please send any comments/suggestions to AustinM
'==
'==========================================================================

HISTORY
	2015-02-07 v0.90 Note: running the PstatSum.vbs script requires to ChangeDirectory into SDPpath
		  v1.00 included in ShellExtension; changed column size of "--Company--";
			 appended to run 'registry check' script
	2015-02-07 v1.01 changed $RunAddon=0 -> no 'registry check' (already done in main script)
	2016-02-10 v1.03 using FQDN localhost
	2016-04-17 v1.04 adding OSversion
	2016-08-03 adding 2016RS1
	2017-04-01 adding 2016RS2
  2017-06-06 changed check path to \\localhost\ToolsShare
	2017-10-06 v1.05 adding 2016RS3
	2018-04-05 adding 2016RS4

	ToDo:
		- check for high handle count (>5000)
		- check why PStatSum does not run for Pstat.TXT >~2MB

#>

<#
.SYNOPSIS
The script reads SDP report and displays overview of Microsoft and 3rd party modules/drivers that were loaded in memory when the SDP report was created.

SYNTAX: .\get-PStatSum.ps1 [full-path-to-expanded-SDP-report]

.DESCRIPTION
The script reads in the *_PStat.txt file(s) from the SDP report and displays overview of Microsoft and 3rd party modules/drivers that were loaded in memory when the SDP report was created.
Note: Expand the SDP report cab file into folder before running this script.

'== HOW IT WORKS:
'==  Reads all the .TXT files created by CHECKSYM that are in the folder
'==  with the PSTAT file to get file version information. It then reads
'==  the modules loaded in memory listed at the bottom of the PSTAT.TXT
'==  file.

If you experience PS error '...is not digitally signed.' run the command:
 Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned

.PARAMETER OpenSummary
 This switch will not open resulting summary file with Notepad/Favorite Editor if set to $False
 
.EXAMPLE
\\localhost\ToolsShare\rfl\get-PStatSum.ps1 \\ioanc00\temp\New_RFL\SDPs\FileServer

.LINK
\\localhost\ToolsShare\rfl\get-PStatSum.ps1
ioanc@microsoft.com ; waltere@microsoft.com ;

#>

Param(
	[ValidateScript({Test-Path $_ -PathType 'Container'})]
	[Parameter(Mandatory=$True,Position=0,HelpMessage='Choose a writable SDP folder location, i.e. C:\SR\SDP-report\ ')]
	[string]$SDPPath,
	[ValidateSet("2008","2008R2","2012","2012R2","2016","2016RS1","2016RS2","2016RS3","2016RS4","2016RS5","201619H1","201619H2","20162004","201620H2","201621H1","help","")]
	[Parameter(Mandatory=$False,Position=1,HelpMessage='optional: Choose one OS from list: [2008|2008R2|2012|2012R2|2016|2016RS1|2016RS2|2016RS3|2016RS4|2016RS5|201619H1|201619H2|20162004|201620H2|201621H1]')]
	[string]$OSversion,
	[switch]$OpenSummary= $true		# open with Notepad/FavEditor
	)

Process
{
############################################################
## customization section of script
$RFLpath = "\\localhost\ToolsShare\rfl\"
$PstatSumScript = $RFLpath + "PstatSum.vbs"
############################################################
if (Test-Connection -ComputerName waltere-vdi.europe.corp.microsoft.com -Quiet -Count 1) {[bool]$Stats=1} else {[bool]$Stats=0}
#$StatsServerPath="\\ToolsShare.europe.corp.microsoft.com\upload\RFL\"
$StatsServerPath="\\waltere-vdi.europe.corp.microsoft.com\ToolsShare\tools\RFL\"
$VerMa="1"
$VerMi="06"
$startTime = Get-Date
$CheckDate = (Get-Date).ToUniversalTime().ToString("yy-MM-dd_HH-mm-ss")
$CountInvFil = $StatsServerPath +'countPSsum.dat'
$CountInvFil2 = $CountInvFil +'.us'
Set-Variable -Name ErrorMsgPS -Scope Script -Force
#Set-Variable -Name OSVersion -value "" -Scope Script
If ($Stats) { #increment at start of script
 ($j=[int32](Get-Content $CountInvFil -TotalCount 1 -ErrorAction SilentlyContinue)) |out-null
 (++$j) | Set-Content $CountInvFil -ErrorAction SilentlyContinue
 }
If ($PSBoundParameters['Debug']) { $DebugPreference='Continue'}

### Trail SDPPath with \ and allow path with space character
if ($SDPPath.EndsWith("\")){$SDPPath="$SDPPath"}
else {$SDPPath="$SDPPath" +"\"}
If (-NOT (Test-Path $SDPPath -PathType 'Container')){Throw "$($SDPPath) is not a valid folder"}

###########################################################
### function Get-OS-from-MSinfo32* files
# Return: $OSVersion
function Get-OS-from-MSinfo32 ($SDPPath,$NodeName)
{
	write-debug "__enter Get-OS-from-MSinfo32($SDPPath,$NodeName)"
	### Validate user input of expanded SDP report and identify the number of msinfo32.txt files and the names of the computers $NodeNames (in Cluster Report)
	$msinfo32 = $SDPPath + $NodeName + '*msinfo*.txt' # Try .txt
	If (-NOT (Test-Path $msinfo32)) {
	 Write-Verbose "** $SDPPath without *msinfo32.txt"
	 $msinfo32 = $SDPPath + $NodeName + '*msinfo*.nfo' # Try .nfo
	 }
	 ### Get OS version from SDP report from msinfo.txt
	 If ("$msinfo32" -match ".txt"){
	  Write-Debug "...$NodeName Using msinfo32.txt = $msinfo32 "
	  #Read-in content from Msinfo file
	  if ($msinfo32file = get-childitem $msinfo32) {
	     Write-Debug "msinfo32file: $msinfo32file "
		 $SDPdate = $msinfo32file.LastWriteTime
		 Write-Verbose "`n$NodeName : SDP Date: $SDPdate"
		 $msinfo32 = Get-Content $msinfo32 -TotalCount 7
		 If ($msinfo32) {$OSbuild = $msinfo32[-1]
		 		$OSName = $msinfo32[-2];$OSName=$OSName.Split(" ",3)[2]
		 		$ComputerName = $msinfo32[1].Split("")[-1] }
   		 Else {$ErrorMsgRG += "No-Valid-MsI32txt "}
		 }
	 }
	 Else { # Get OS version from SDP report from msinfo.nfo / seems not to work for some localized OS
	  Write-Debug "...$NodeName Using msinfo32.nfo = $msinfo32 "
	  if ($msinfo32file = get-childitem $msinfo32) {
		$SDPdate = $msinfo32file.LastWriteTime
		Write-Verbose "`n$NodeName : SDP Date: $SDPdate"
		[xml]$nfo = Get-Content $msinfo32file
		$summary = $nfo.MSInfo.Category.Data.value
		If ($summary.'#cdata-section') {$OSbuild = $summary.'#cdata-section'[1]
		   				$OSName = $summary.'#cdata-section'[0]
		   				$computername = $summary.'#cdata-section'[4] }
   		Else {$ErrorMsgRG += "No-Valid-MsI32nfo "}
		}
	 } #end Else
	### match Build number in SDP report with OS short name
	if("$OSbuild" -match "2600"){$OSVersion_old="old-XP"}  # or Windows XP
	if("$OSbuild" -match "3790"){$OSVersion_old="old-2003"}  # or Windows 2003
	if("$OSbuild" -match "6001"){$OSVersion_old="old-2008-SP1"}  # or Windows Vista SP1
	if(("$OSbuild" -match "6002") -or ("$OSbuild" -match "6003") ){$OSVersion="2008"}  # or Windows Vista SP2
	if("$OSbuild" -match "7600"){$OSVersion_old="old-2008R2-RTM"} # or Windows 7 RTM
	if("$OSbuild" -match "7601"){$OSVersion="2008R2"} # or Windows 7
	if("$OSbuild" -match "9200"){$OSVersion="2012"}  # or Windows 8
	if("$OSbuild" -match "9600"){$OSVersion="2012R2"} # or Windows 8.1
	if("$OSbuild" -match "10.0.10240"){$OSVersion="2016"} 		# or Windows 10
	if("$OSbuild" -match "10.0.10586"){$OSVersion="2016TH2"} 	# or Windows 10 TH2
	if("$OSbuild" -match "10.0.14393"){$OSVersion="2016RS1"} 	# or Windows 10 RS1
	if("$OSbuild" -match "10.0.15063"){$OSVersion="2016RS2"} 	# or Windows 10 RS2
	if("$OSbuild" -match "10.0.16299"){$OSVersion="2016RS3"} 	# or Windows 10 RS3
	if("$OSbuild" -match "10.0.17134"){$OSVersion="2016RS4"} 	# or Windows 10 RS4
	if("$OSbuild" -match "10.0.17763"){$OSVersion="2016RS5"} 	# or Windows 10 RS5
	if("$OSbuild" -match "10.0.18362"){$OSVersion="201619H1"}	# or Windows 10 19H1
	if("$OSbuild" -match "10.0.18363"){$OSVersion="201619H2"}	# or Windows 10 19H2
	if("$OSbuild" -match "10.0.19041"){$OSVersion="20162004"} 	# or Windows 10 2004 2020 April 2020 Update
	if("$OSbuild" -match "10.0.19042"){$OSVersion="201620H2"} 	# or Windows 10 20H2 October 2020 Update
	if("$OSbuild" -match "10.0.19043"){$OSVersion="201621H1"} 	# or Windows 10 21H1 21H1 April 2021 Update

	Write-Verbose " SDP Date: $($SDPdate) / OS-Version: $($OSVersion) $($OSVersion_old)"
	Write-Verbose " SDP computer name: $ComputerName $OSbuild $OSName"
	$OSVersion
} # end function Get-OS-from-MSinfo32

### === main
"`n$(Get-Date -UFormat "%R:%S") ==Pstat Check==... Examining modules/drivers that were loaded in memory when the SDP report was created."
## change directory to $SDPPath as required by PstatSum.vbs script
Push-Location
Set-Location $SDPPath


$PStatTXTfiles = Get-Item -path ($SDPPath + "*_PStat.txt")
if (($Global:OpenSummary) -or ($OpenSummary)) {$PStatOpenS = 1 } else { $PStatOpenS = 0 }
$NodeNames = foreach ($NodeName in $PStatTXTfiles){($NodeName.name).split('_')[0]}
Write-Host "$(Get-Date -UFormat "%R:%S") ...NodeName(s): $NodeNames"

if (!$PStatTXTfiles) { Write-Host -BackgroundColor Black -ForegroundColor Red -Object "There is no *_PStat.txt file in $SDPPath - Double-check SDP path again!"
			$ErrorMsgPS += "No-Valid-PStat " }
$NodeCnt=0
foreach ($PStatTXTfile in $PStatTXTfiles){
	$NodeCnt++
	Write-Host -BackgroundColor Blue -ForegroundColor Cyan -NoNewline -Object "$($NodeCnt) " -Separator .
	$NodeName = ($PStatTXTfile.name).split('_')[0]
	Write-Verbose "OSVersion in script param1: $($OSVersion) "
	if (!$OSversion) {$OSVersion = Get-OS-from-MSinfo32 $SDPPath $NodeName}			# Call function
	Write-Verbose "OSVersion in SDP report: $($OSVersion) - ComputerName: $($NodeName)"
	if ($($NodeCnt) -lt 32) {
		if ($NodeNames.count -gt 1) {Write-Host "Node $NodeName $NodeCnt of $($NodeNames.count)"}
		& C:\Windows\System32\wscript.exe $PstatSumScript $PStatTXTfile $PStatOpenS
		"$NodeName => Output file will be saved to: $($SDPPath)!PStatSum_$($Nodename).TXT "
	}
	else {Write-Host "$(Get-Date -UFormat "%R:%S") ...checked only first 32 nodes"}
}
If (($Global:OpenSummary) -or ($OpenSummary)) {
	"`nUsing favorite editor to open Pstat Report(s) - this could take a few seconds until your Text Editor opens with results ..."
	#" => Output file saved to: $($SDPPath)!PStatSum_*.TXT"
	}
$endTime= Get-Date
Write-Host -BackgroundColor Gray -ForegroundColor Black -Object "$(Get-Date -UFormat "%R:%S") Done Get-PStatSum script version v$VerMa.$VerMi took $($endTime- $startTime) `n"

Pop-Location

### Stats
$Duration = $endTime- $startTime
If ($Stats) { #increment at start of script
 "$j" + " ;$CheckDate" + "; $OSVersion; " + ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name) + "; $($Duration)" + "; $NodeCnt" + "; $SDPPath" + "; $ErrorMsgPS" + "; v$VerMa.$VerMi" | Out-File $CountInvFil2 -Append -Encoding UTF8 -ErrorAction SilentlyContinue
 }
}
