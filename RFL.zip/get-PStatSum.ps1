<# last edit by: waltere 2022-09-12
  File Name: get-PStatSum.ps1
  Objective: check for Microsoft and 3rd party modules/drivers and their installed version
  Leveraging the PstatSum.vbs script Created by AustinM
  call script with -Verbose or -Debug for add. console output

VERSION and AUTHORs:
    Ver 1.01 - 27.02.2015
	Walter Eder	- waltere@microsoft.com
	Austin Mack	- AustinM@microsoft.com (PstatSum.vbs script Created by AustinM)

#PstatSum.vbs origin: \\austinm\VBS\VBS-Notdone
'==========================================================================
'==  Created by AustinM
'==  Last Modified: 24 Mar 2010 By AustinM
'==
'== TO USE/INSTALL:
'==  Copy the custom script to a read/write folder on a local drive. Double
'==  click the VBS and then you will have the option to right click .TXT
'==  files and select "Open with PStat Summary VBS".
'==
'==  Note: The MPS report should be extracted to a folder before
'==     right clicking the file to create summary.
'==
'== HOW IT WORKS:
'==  Reads all the .TXT files created by CHECKSYM that are in the folder
'==  with the PSTAT file to get file version information. It then reads
'==  the modules loaded in memory listed at the bottom of the PSTAT.TXT
'==  file.
'==
'== Please send any comments/suggestions to AustinM
'==
'==========================================================================

HISTORY
	2015-02-07 v0.90 Note: running the PstatSum.vbs script requires to ChangeDirectory into SDPpath
		  v1.00 included in ShellExtension; changed column size of "--Company--";
			 appended to run 'registry check' script
	2015-02-07 v1.01 changed $RunAddon=0 -> no 'registry check' (already done in main script)
	2016-02-10 v1.03 using FQDN emeacssdfs.europe.corp.microsoft.com
	2016-04-17 v1.04 adding OSversion
	2016-08-03 adding 2016RS1
	2017-04-01 adding 2016RS2
  2017-06-06 changed check path to \\emeacssdfs\netpod
	2017-10-06 v1.05 adding 2016RS3
	2018-04-05 adding 2016RS4
	2021-08-12 add VBdebug switch
	2022-09-08 using Utils_RflShared.psm1 library
	
	ToDo:
		- check for high handle count (>5000)
		- check why PStatSum does not run for Pstat.TXT >~2MB

#>

<#
.SYNOPSIS
The script reads SDP report and displays overview of Microsoft and 3rd party modules/drivers that were loaded in memory when the SDP report was created.

SYNTAX: .\get-PStatSum.ps1 [full-path-to-expanded-SDP-report]

.DESCRIPTION
The script reads in the *_PStat.txt file(s) from the SDP report and displays overview of Microsoft and 3rd party modules/drivers that were loaded in memory when the SDP report was created.
Note: Expand the SDP report cab file into folder before running this script.

'== HOW IT WORKS:
'==  Reads all the .TXT files created by CHECKSYM that are in the folder
'==  with the PSTAT file to get file version information. It then reads
'==  the modules loaded in memory listed at the bottom of the PSTAT.TXT
'==  file.

If you experience PS error '...is not digitally signed.' run the command:
 Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned

.PARAMETER OpenSummary
 This switch will not open resulting summary file with Notepad/Favorite Editor if set to $False
 
.EXAMPLE
\\emeacssdfs.europe.corp.microsoft.com\netpod\rfl\get-PStatSum.ps1 \\ioanc00\temp\New_RFL\SDPs\FileServer

.LINK
\\emeacssdfs.europe.corp.microsoft.com\netpod\rfl\get-PStatSum.ps1
ioanc@microsoft.com ; waltere@microsoft.com ;

#>

Param(
	[ValidateScript({Test-Path $_ -PathType 'Container'})]
	[Parameter(Mandatory=$True,Position=0,HelpMessage='Choose a writable SDP folder location, i.e. C:\SR\SDP-report\ ')]
	[string]$SDPPath,
	[ValidateSet("2008","2008R2","2012","2012R2","2016","2016RS1","2016RS2","2016RS3","2016RS4","2016RS5","201619H1","201619H2","20162004","201620H2","201621H1","201621H2","201622H2","2022","Win11","Win1122H2","help","")]
	[Parameter(Mandatory=$False,Position=1,HelpMessage='optional: Choose one OS from list: [2008|2008R2|2012|2012R2|2016|2016RS1|2016RS2|2016RS3|2016RS4|2016RS5|201619H1|201619H2|20162004|201620H2|201621H1|201621H2|201622H2|2022|Win11|Win1122H2]')]
	[string]$OSversion,
	[switch]$OpenSummary = $true,		# open with Notepad/FavEditor
	[switch]$VBdebug = $False
	)

Process
{
	$verDateScript = "2022.09.12.0"
	$ScriptFolder = Split-Path $MyInvocation.MyCommand.Path -Parent
	# Load Common Library
	  Remove-Module Utils_RflShared -ErrorAction Ignore
	  Import-Module $ScriptFolder\Utils_RflShared.psm1 -DisableNameChecking
	  
#region: ###### customization section of script, logging configuration ########################
	$InOfflineMode 	= ((( Get-content -Path "$ScriptFolder\version_SDPcheck.dat")[1] -split " ")[2]).trim("""")	# set $True for outsourcer or when not connected to MS network - offline-SDPcheck
	$RFLroot 		= ((( Get-content -Path "$ScriptFolder\version_SDPcheck.dat")[3] -split " ")[2]).trim("""")	# "\\emeacssdfs.europe.corp.microsoft.com\netpod\rfl\" -or- "\\localhost\ToolsShare\rfl\"
	if ($InOfflineMode -match "False") {
		$StatsServer = "waltere-vdi.europe.corp.microsoft.com"
		if (Test-Connection -ComputerName $StatsServer -Quiet -Count 1) {[bool]$Stats=$True} else {[bool]$Stats=$False}
	} else { 
		$Stats = $False
	}
	$PstatSumScript = $RFLroot + "\PstatSum.vbs"
#endregion: ###### customization section

$ScriptBeginTimeStamp = Get-Date
$CheckDate = (Get-Date).ToUniversalTime().ToString("yy-MM-dd_HH-mm-ss")
if ($Stats) {
	$StatsServerPath="\\$StatsServer\netpod\tools\RFL\"
	$CountInvFil = $StatsServerPath +'countPSsum.dat'
	$CountInvFil2 = $CountInvFil +'.us'
	#increment at start of script
	 ($j=[int32](Get-Content $CountInvFil -TotalCount 1 -ErrorAction SilentlyContinue)) |out-null
	 (++$j) | Set-Content $CountInvFil -ErrorAction SilentlyContinue
}

Set-Variable -Name ErrorMsgPS -Scope Script -Force
If ($PSBoundParameters['Debug']) { $DebugPreference='Continue'}

### Trail SDPPath with \ and allow path with space character
if ($SDPPath.EndsWith("\")){$SDPPath="$SDPPath"}
else {$SDPPath="$SDPPath" +"\"}
If (-NOT (Test-Path $SDPPath -PathType 'Container')){Throw "$($SDPPath) is not a valid folder"}

#region ### === main
"`n$(Get-Date -UFormat "%R:%S") ==Pstat Check==... Examining modules/drivers that were loaded in memory when the SDP report was created."
## change directory to $SDPPath as required by PstatSum.vbs script
Push-Location
Set-Location $SDPPath


$PStatTXTfiles = Get-Item -path ($SDPPath + "*_PStat.txt")
if (($Global:OpenSummary) -or ($OpenSummary)) {$PStatOpenS = 1 } else { $PStatOpenS = 0 }
if ($VBdebug) {$UseDebugFlag="/debug"; Write-Verbose "...enabling $UseDebugFlag"} else { $UseDebugFlag = "" }
$NodeNames = foreach ($NodeName in $PStatTXTfiles){($NodeName.name).split('_')[0]}
Write-Host "$(Get-Date -UFormat "%R:%S") NodeName(s): $NodeNames"

if (!$PStatTXTfiles) { Write-Host -BackgroundColor Black -ForegroundColor Red -Object "There is no *_PStat.txt file in $SDPPath - Double-check SDP path again!"
			$ErrorMsgPS += "No-Valid-PStat " }
$NodeCnt=0
foreach ($PStatTXTfile in $PStatTXTfiles){
	$NodeCnt++
	Write-Host -BackgroundColor Blue -ForegroundColor Cyan -NoNewline -Object "$($NodeCnt) " -Separator .
	$NodeName = ($PStatTXTfile.name).split('_')[0]
	Write-Verbose "OSVersion in script param1: $($OSVersion) "
	if (!$OSversion) {GetOSfromMSinfo32 $SDPPath $NodeName}			# Call function
	Write-Verbose "OSVersion in SDP report: $($OSVersion) - ComputerName: $($NodeName)"
	if ($($NodeCnt) -lt 32) {
		if ($NodeNames.count -gt 1) {Write-Host "Node $NodeName $NodeCnt of $($NodeNames.count)"}
		Write-Verbose "starting wscript.exe $PstatSumScript $PStatTXTfile $PStatOpenS $UseDebugFlag"
		& C:\Windows\System32\wscript.exe $PstatSumScript $PStatTXTfile $PStatOpenS $UseDebugFlag
		" => Output file will be saved to: $($SDPPath)!PStatSum_$($Nodename).TXT "
	}
	else {Write-Host "$(Get-Date -UFormat "%R:%S") ...checked only first 32 nodes"}
}
If (($Global:OpenSummary) -or ($OpenSummary)) {
	"`nUsing favorite editor to open Pstat Report(s) - this could take a few seconds until your Text Editor opens with results ..."
	#" => Output file saved to: $($SDPPath)!PStatSum_*.TXT"
}
	
	$ScriptEndTimeStamp = Get-Date
	$Duration = $(New-TimeSpan -Start $ScriptBeginTimeStamp -End $ScriptEndTimeStamp)
Write-Host -BackgroundColor Gray -ForegroundColor Black -Object "$(Get-Date -UFormat "%R:%S") Done Get-PStatSum script version v$verDateScript took $Duration `n"

Pop-Location

### Stats
If ($Stats) { #increment at start of script
 "$j" + " ;$CheckDate" + "; $OSVersion; " + ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name) + "; $($Duration)" + "; $NodeCnt" + "; $SDPPath" + "; $ErrorMsgPS" + "; v$verDateScript " | Out-File $CountInvFil2 -Append -Encoding UTF8 -ErrorAction SilentlyContinue
 }
#region ### === main
}



# SIG # Begin signature block
# MIInowYJKoZIhvcNAQcCoIInlDCCJ5ACAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBWrhzx7++XZKPx
# iWK3QGdVjlMoHfetXSyN6TbuiYz3gKCCDXYwggX0MIID3KADAgECAhMzAAACy7d1
# OfsCcUI2AAAAAALLMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjIwNTEyMjA0NTU5WhcNMjMwNTExMjA0NTU5WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC3sN0WcdGpGXPZIb5iNfFB0xZ8rnJvYnxD6Uf2BHXglpbTEfoe+mO//oLWkRxA
# wppditsSVOD0oglKbtnh9Wp2DARLcxbGaW4YanOWSB1LyLRpHnnQ5POlh2U5trg4
# 3gQjvlNZlQB3lL+zrPtbNvMA7E0Wkmo+Z6YFnsf7aek+KGzaGboAeFO4uKZjQXY5
# RmMzE70Bwaz7hvA05jDURdRKH0i/1yK96TDuP7JyRFLOvA3UXNWz00R9w7ppMDcN
# lXtrmbPigv3xE9FfpfmJRtiOZQKd73K72Wujmj6/Su3+DBTpOq7NgdntW2lJfX3X
# a6oe4F9Pk9xRhkwHsk7Ju9E/AgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUrg/nt/gj+BBLd1jZWYhok7v5/w4w
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzQ3MDUyODAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAJL5t6pVjIRlQ8j4dAFJ
# ZnMke3rRHeQDOPFxswM47HRvgQa2E1jea2aYiMk1WmdqWnYw1bal4IzRlSVf4czf
# zx2vjOIOiaGllW2ByHkfKApngOzJmAQ8F15xSHPRvNMmvpC3PFLvKMf3y5SyPJxh
# 922TTq0q5epJv1SgZDWlUlHL/Ex1nX8kzBRhHvc6D6F5la+oAO4A3o/ZC05OOgm4
# EJxZP9MqUi5iid2dw4Jg/HvtDpCcLj1GLIhCDaebKegajCJlMhhxnDXrGFLJfX8j
# 7k7LUvrZDsQniJZ3D66K+3SZTLhvwK7dMGVFuUUJUfDifrlCTjKG9mxsPDllfyck
# 4zGnRZv8Jw9RgE1zAghnU14L0vVUNOzi/4bE7wIsiRyIcCcVoXRneBA3n/frLXvd
# jDsbb2lpGu78+s1zbO5N0bhHWq4j5WMutrspBxEhqG2PSBjC5Ypi+jhtfu3+x76N
# mBvsyKuxx9+Hm/ALnlzKxr4KyMR3/z4IRMzA1QyppNk65Ui+jB14g+w4vole33M1
# pVqVckrmSebUkmjnCshCiH12IFgHZF7gRwE4YZrJ7QjxZeoZqHaKsQLRMp653beB
# fHfeva9zJPhBSdVcCW7x9q0c2HVPLJHX9YCUU714I+qtLpDGrdbZxD9mikPqL/To
# /1lDZ0ch8FtePhME7houuoPcMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGYMwghl/AgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAALLt3U5+wJxQjYAAAAAAsswDQYJYIZIAWUDBAIB
# BQCggbAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEICwsw/JztBl22gexo1HKGdQb
# oZA2C+qgSctrhIhPoVY4MEQGCisGAQQBgjcCAQwxNjA0oBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEcgBpodHRwczovL3d3dy5taWNyb3NvZnQuY29tIDANBgkqhkiG9w0B
# AQEFAASCAQBaN/cfGmcO967fgwXO6WJylNAgYUB12Y1FGeWgGcI4pFmkgBKwqDCD
# LHaI1ZE7MiJfdFWoRoDI43Yrz3De0zd/A8v/oONSJ/wykt71rZtBNo5qEocDXsPw
# Rcd3cvv1KsuK0hKEZRUeKUFiALrvXldG5316YXFqGM7Q8x+LyVxlnLB4tNP86ptt
# ZgjwwwpER64AbqkLTHSYwJX0JrgSeqjV1ZML+s7ezdYm2oRxkOqkHmRZaTl2s0jE
# nj8DGGgRIFigQ5SkeTlT5gVs6uJPILIRAYhhXEnHsN3LdxuaGI+5QmSAnbl8U3Fq
# tmCJvNDmn/U4CW42HnECgjQvwrmZ7dg2oYIXCzCCFwcGCisGAQQBgjcDAwExghb3
# MIIW8wYJKoZIhvcNAQcCoIIW5DCCFuACAQMxDzANBglghkgBZQMEAgEFADCCAVQG
# CyqGSIb3DQEJEAEEoIIBQwSCAT8wggE7AgEBBgorBgEEAYRZCgMBMDEwDQYJYIZI
# AWUDBAIBBQAEIKoQT5n9wk3fAkDKTfTApzG228xteybQ8eCDSKYatjEOAgZjEVAz
# G10YEjIwMjIwOTEyMTM0MDM2LjMxWjAEgAIB9KCB1KSB0TCBzjELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9w
# ZXJhdGlvbnMgUHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjc4
# ODAtRTM5MC04MDE0MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2
# aWNloIIRXzCCBxAwggT4oAMCAQICEzMAAAGoVfBhqcwwGFwAAQAAAagwDQYJKoZI
# hvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEm
# MCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjIwMzAy
# MTg1MTIzWhcNMjMwNTExMTg1MTIzWjCBzjELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMgUHVl
# cnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjc4ODAtRTM5MC04MDE0
# MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIICIjANBgkq
# hkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAo9ptysAuJdfymPJelww3z0pO9yaUCIPD
# ilT4d6NmGJtR6j8dTL4/1XFaEJfuiB54o8nrvv4t5V090bmFO8YOBK6jfD4BybNx
# dnZAIZSBRF4tQpuauvTpsHTGG+1nCh6WHG0+SMkWxtMa1K35XsThUKM91ipBn+I3
# QCtdeaBsR9XILBL6Ha6igGEzlRxs+iC2vlWmB3NtQzj+ta6mYVWM8HVqyff7C/to
# EIryP1BQmuhjjLWmZlJ/RK4YxZjtybZy+tt2bteV2WOpF0db4JAAHgSqI6qC6Z9H
# 5pKmjlPvkobT6ewGSOUZKxTUGLXmnis/zylmdKinvcZ6b0ZY7YZEvA/XlgScqxzP
# GEZj5nw0RrRDAwyJWWSx09Tsnmor2DEBCM4nOohInOEjBBa0QuqAmgfCSpPF6beC
# tjsHsM7NBOdCkpagvQdZH0qoi9oLuL1eU+/657z2P17t+YHieHWG6XMQnNfpExT1
# MckyVs7o6s/c00QolbyOKkKfLwfV+69K4V+4Hu374or2DZzY0q7kTNKzWco2q2Xg
# o7dTPJcta9NEM7gPk9VA51rS2qNL8BahSvEoLlk+WQsT5g+xLkb4T9UKAJqCE/IF
# mwc0rvAeVJ//bq6EucqnpdEAiuiIRiX/nJbSZKGO+cBE+vQYiVKbQqupLAKNHlyR
# ZPWwpoRvzDcCAwEAAaOCATYwggEyMB0GA1UdDgQWBBQ2x9vj4vhS62U2H8zGMaSP
# SQsi1TAfBgNVHSMEGDAWgBSfpxVdAF5iXYP05dJlpxtTNRnpcjBfBgNVHR8EWDBW
# MFSgUqBQhk5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9NaWNy
# b3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIwMjAxMCgxKS5jcmwwbAYIKwYBBQUH
# AQEEYDBeMFwGCCsGAQUFBzAChlBodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtp
# b3BzL2NlcnRzL01pY3Jvc29mdCUyMFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEp
# LmNydDAMBgNVHRMBAf8EAjAAMBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3
# DQEBCwUAA4ICAQBxO4JLZGqqZ/aY+vo5TJ2GZTH6bq+kQ+zNaKglduexFufLracX
# 1hdMq5I1YfVAV/Jz/Y3dhMSniETxi2FgqAMz8dSFRERfdZPAax5i64N5LFZElYKi
# sAcXWTBDMgqCtRzcb65XACYb8QjUQtETEDh+3HQSGt/n1ombs6eCfSVNJKIpR64Y
# D4zLqgKL9XwRPHP55uW9AA1qW0mAZ+mm5ZdhPiOKxAoRO+gmMG/nH4EDSgQW7uAZ
# p4wORmOc7m91/od4qd4guz1m/AhaSBhCLZl6jNvGCUbljATGiLF6TGtFMNnAyiQh
# jFeZxyxxDTFeaH4je+juFX1kwpNr09rPmd7hxzw53DVP7rbiYHRZpb0cATWGiMHo
# Jt+6d21X+PDGZ0qHXmmUlec3XIzs4v3bgeoCImKwdqek4QnhSb1veEVRcTa4Qkv1
# pi4iCSxVgirU/b2tHhfuXPe4QkfoI6SgTr5Rxq43olgWCE30jwlEFYCEdfgZAeWe
# Cx1+1YsuINkzKeWBEJnORgjbg31zH4PfrtjByWo1joJm4CDPDLXa5FgVBqxgdgrW
# GnPJO24j8DYHxwb4czpfWN/Z324BHAfr6EuQ+23f/k0GUtek6XmJnJGUGLuINeRY
# 1reO4Z8sAnchIPI2HvK74fjJBjJGz8xWsKRZQmz0SK8sqw0nYH8iM2tK1jCCB3Ew
# ggVZoAMCAQICEzMAAAAVxedrngKbSZkAAAAAABUwDQYJKoZIhvcNAQELBQAwgYgx
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1p
# Y3Jvc29mdCBSb290IENlcnRpZmljYXRlIEF1dGhvcml0eSAyMDEwMB4XDTIxMDkz
# MDE4MjIyNVoXDTMwMDkzMDE4MzIyNVowfDELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENB
# IDIwMTAwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDk4aZM57RyIQt5
# osvXJHm9DtWC0/3unAcH0qlsTnXIyjVX9gF/bErg4r25PhdgM/9cT8dm95VTcVri
# fkpa/rg2Z4VGIwy1jRPPdzLAEBjoYH1qUoNEt6aORmsHFPPFdvWGUNzBRMhxXFEx
# N6AKOG6N7dcP2CZTfDlhAnrEqv1yaa8dq6z2Nr41JmTamDu6GnszrYBbfowQHJ1S
# /rboYiXcag/PXfT+jlPP1uyFVk3v3byNpOORj7I5LFGc6XBpDco2LXCOMcg1KL3j
# tIckw+DJj361VI/c+gVVmG1oO5pGve2krnopN6zL64NF50ZuyjLVwIYwXE8s4mKy
# zbnijYjklqwBSru+cakXW2dg3viSkR4dPf0gz3N9QZpGdc3EXzTdEonW/aUgfX78
# 2Z5F37ZyL9t9X4C626p+Nuw2TPYrbqgSUei/BQOj0XOmTTd0lBw0gg/wEPK3Rxjt
# p+iZfD9M269ewvPV2HM9Q07BMzlMjgK8QmguEOqEUUbi0b1qGFphAXPKZ6Je1yh2
# AuIzGHLXpyDwwvoSCtdjbwzJNmSLW6CmgyFdXzB0kZSU2LlQ+QuJYfM2BjUYhEfb
# 3BvR/bLUHMVr9lxSUV0S2yW6r1AFemzFER1y7435UsSFF5PAPBXbGjfHCBUYP3ir
# Rbb1Hode2o+eFnJpxq57t7c+auIurQIDAQABo4IB3TCCAdkwEgYJKwYBBAGCNxUB
# BAUCAwEAATAjBgkrBgEEAYI3FQIEFgQUKqdS/mTEmr6CkTxGNSnPEP8vBO4wHQYD
# VR0OBBYEFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMFwGA1UdIARVMFMwUQYMKwYBBAGC
# N0yDfQEBMEEwPwYIKwYBBQUHAgEWM2h0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9w
# a2lvcHMvRG9jcy9SZXBvc2l0b3J5Lmh0bTATBgNVHSUEDDAKBggrBgEFBQcDCDAZ
# BgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/
# BAUwAwEB/zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvXzpoYxDBWBgNVHR8E
# TzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9k
# dWN0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYIKwYBBQUHAQEETjBM
# MEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRz
# L01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNydDANBgkqhkiG9w0BAQsFAAOCAgEA
# nVV9/Cqt4SwfZwExJFvhnnJL/Klv6lwUtj5OR2R4sQaTlz0xM7U518JxNj/aZGx8
# 0HU5bbsPMeTCj/ts0aGUGCLu6WZnOlNN3Zi6th542DYunKmCVgADsAW+iehp4LoJ
# 7nvfam++Kctu2D9IdQHZGN5tggz1bSNU5HhTdSRXud2f8449xvNo32X2pFaq95W2
# KFUn0CS9QKC/GbYSEhFdPSfgQJY4rPf5KYnDvBewVIVCs/wMnosZiefwC2qBwoEZ
# QhlSdYo2wh3DYXMuLGt7bj8sCXgU6ZGyqVvfSaN0DLzskYDSPeZKPmY7T7uG+jIa
# 2Zb0j/aRAfbOxnT99kxybxCrdTDFNLB62FD+CljdQDzHVG2dY3RILLFORy3BFARx
# v2T5JL5zbcqOCb2zAVdJVGTZc9d/HltEAY5aGZFrDZ+kKNxnGSgkujhLmm77IVRr
# akURR6nxt67I6IleT53S0Ex2tVdUCbFpAUR+fKFhbHP+CrvsQWY9af3LwUFJfn6T
# vsv4O+S3Fb+0zj6lMVGEvL8CwYKiexcdFYmNcP7ntdAoGokLjzbaukz5m/8K6TT4
# JDVnK+ANuOaMmdbhIurwJ0I9JZTmdHRbatGePu1+oDEzfbzL6Xu/OHBE0ZDxyKs6
# ijoIYn/ZcGNTTY3ugm2lBRDBcQZqELQdVTNYs6FwZvKhggLSMIICOwIBATCB/KGB
# 1KSB0TCBzjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEpMCcG
# A1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMgUHVlcnRvIFJpY28xJjAkBgNVBAsT
# HVRoYWxlcyBUU1MgRVNOOjc4ODAtRTM5MC04MDE0MSUwIwYDVQQDExxNaWNyb3Nv
# ZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQBsuvzEn0EHisvh
# iDnxfUtnmJB3LKCBgzCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEw
# MA0GCSqGSIb3DQEBBQUAAgUA5sml/zAiGA8yMDIyMDkxMjE2MzUxMVoYDzIwMjIw
# OTEzMTYzNTExWjB3MD0GCisGAQQBhFkKBAExLzAtMAoCBQDmyaX/AgEAMAoCAQAC
# AhPRAgH/MAcCAQACAhKAMAoCBQDmyvd/AgEAMDYGCisGAQQBhFkKBAIxKDAmMAwG
# CisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAIAgEAAgMBhqAwDQYJKoZIhvcNAQEF
# BQADgYEAz3xV4GSni7PxQU8bwWLHew5yximW23bCVAaJFXXjOn1YQSVv3FdmuHcI
# Sue3ttxwLUx0cAE8I+IXAuz3Pf2MuMY9GbiYrZT3825uO+uGwFboT9gtLJhPeV8z
# b5a9A1ova/0pddB6hO2zGPnMCnEJ5ycNcBIJT6CtMwQUuxrBQn0xggQNMIIECQIB
# ATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAAahV8GGpzDAY
# XAABAAABqDANBglghkgBZQMEAgEFAKCCAUowGgYJKoZIhvcNAQkDMQ0GCyqGSIb3
# DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCAtasWnN64epyAiseCqDUc6xcUU7d+M3SJu
# c8i29UloXTCB+gYLKoZIhvcNAQkQAi8xgeowgecwgeQwgb0EIHT+yx0AywfCc3CF
# 8UFc+UWdG9aEepJf1gtTEEOXXGWmMIGYMIGApH4wfDELMAkGA1UEBhMCVVMxEzAR
# BgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1p
# Y3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3Rh
# bXAgUENBIDIwMTACEzMAAAGoVfBhqcwwGFwAAQAAAagwIgQgnjMlSYoztylWD7F1
# Hjv9bVSiE2Rt60J90kL3cnK13l8wDQYJKoZIhvcNAQELBQAEggIAKzMIieodsL9Q
# u4PxGyb71AjWGe6YaWXcRjopGwReR0BfV1ZxI58RlOHKZPye+UreP+ka/W1hU25q
# 9sS9mpOjFsnVZdm50DTiBTT3lQu4IRzJE2crNLiOCuyEKaNqZ8Y53oOTKn6IGsCP
# bFdsOV4gJMn1sPWrKVuhIgGSVkC9OdIFJv37OH5JLtfj2WgsJbsXfC00NxhYj1Ye
# feMMul4xdGT20D18CULT9szRZglB/HJLKhLZ8+pY2GYJYA8GGR9oF9C6EQo5ElHg
# tqH8MKjsEl4gzPHpsp5XBnV8LDJCt0dBo9VKqUs5MlGSvAQ5qfkoTTghNpYDNvSb
# w8rDk8WWx5dN7jEtO8UcPuqK+EzvwURWSSKUKj8zi2IaJ3TWli4S2sN5X3SCChbL
# XNA0HTpEAEUUnNejNto0n88qJzJuFlp2P99YBvpdd+Ts172bmIu4Q1agGrOLk9Eh
# ykufRTLE2rTwe8GT8jlEGcMJVgklaCpQLYvYjk/wY3WjGa1wlHExvw4ufPjcDxkm
# 0mg1A5QHIrD8MWF90WT8+Z+kq7tIcSNx5IEYfqc8MChU0o0pnYXhlK00xTFZ2tjf
# 4Pgr47WMSRS55Zb3CcQdkVUKeVtH9oopKdE0xgDkSuzO0swDLkM2Y2Dp6FPSgLk6
# zESjApyIMaPkQPW0aSzwTu4v9d8iSkc=
# SIG # End signature block
