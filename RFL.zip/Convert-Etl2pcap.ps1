<# last edit by: waltere 2022-11-28
  File Name: Convert-Etl2pcap.ps1
  Objective: This script converts a network trace capture .etl file to Wireshark compatible .pcap file
  Source GitHub https://github.com/microsoft/etl2pcapng/releases 
  etl2pcapng.exe v1.9 
#>

<#
.SYNOPSIS
Convert-Etl2pcap - Script to convert a network trace capture .etl file to Wireshark compatible .pcap file using tool etl2pcapng.exe
 https://github.com/microsoft/etl2pcapng/releases - 'etl2pcapng.exe -v' displays version

How to use it:

SYNTAX: .\Convert-Etl2pcap.ps1 -FolderPath [full-path-to-expanded-SDP-folder] [ -HostMode ]


.DESCRIPTION
The script can be used to convert all *.etl files (which contain network packets) within a folder into a pcap format, which is readaby with WireShark

Note: If you experience PS error '...is not digitally signed.' run the command:
 Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy Bypass


.PARAMETER HostMode
  This tells the logging functions to show logging on the screen

.PARAMETER ScriptMode
  This tells the logging functions to show logging in log file _Convert-Etl2pcap.log

.EXAMPLE
	 \\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\Convert-Etl2pcap.ps1 -FolderPath \\MyPC\temp\SDP -HostMode
	 - in Offline-version, the path would be \\localhost\ToolsShare\rfl\Convert-Etl2pcap.ps1
	 This command will convert the known trace .etl files in \\MyPC\temp\SDP folder
	 It will also show detailed output in the console when switch -HostMode is supplied.

.LINK
	 \ \emeacssdfs.europe.corp.microsoft.com\netpod\rfl\Convert-Etl2pcap.ps1
	waltere@microsoft.com
#>

[CmdletBinding()]
PARAM (
	[Parameter(Mandatory = $true,Position=0,HelpMessage='Choose the .etl folder location, i.e. C:\SR\SDP-Folder\ ')]
	[string] $FolderPath,			# Path to folder containing *.etl files
	[switch]$HostMode  = $true, 	# This tells the logging functions to show logging on the screen
	[switch]$ScriptMode = $false	# This tells the logging functions to show logging in log file _Convert-Etl2pcap.log
)

BEGIN {
	$verDateScript = "2022.11.28.0"
	$ScriptFolder = Split-Path $MyInvocation.MyCommand.Path -Parent
	$verEtl2pcapng = "v1.10"
	# Load Common Library:
	. $ScriptFolder\Utils_RflShared.ps1

  # This saves the starting ErrorActionPreference and then sets it to 'Stop'.
	$startErrorActionPreference = $errorActionPreference
	$errorActionPreference = 'Stop'
  # This gets the current path and name of the script.
	$invocation = (Get-Variable MyInvocation).Value
	#$scriptPath = Split-Path $invocation.MyCommand.Path
	$scriptName = $invocation.MyCommand.Name
  #Write-Host "Running `"$scriptPath\$scriptName`"..." -BackgroundColor Black -ForegroundColor Green

	Set-Variable -Name ErrorMsg -Scope Script -Force
	[string]$Script:ErrorMsg=""
	### Trail FolderPath with \ and allow path with space character
		if ($FolderPath.EndsWith("\")){$FolderPath="$FolderPath"}
		else {$FolderPath="$FolderPath" +"\"}
		If (-NOT (Test-Path $FolderPath -PathType 'Container')){Throw "$($FolderPath) is not a valid folder"}

#region: ###### customization section of script, logging configuration ########################
	$useIsnetcap = $False	# set to $True if old behaviour with isnetcap.exe check is needed
	$SDPcheckINI = (Get-content -Path "$ScriptFolder\_SDPcheck.ini")
	$InOfflineMode 	= (($SDPcheckINI[1] -split " ")[2]).trim("""")	# set $True for outsourcer or when not connected to MS network - offline-SDPcheck
	$DFSserverName = (($SDPcheckINI[7] -split " ")[2]).trim("""")
	$RFLroot = (($SDPcheckINI[2] -split " ")[2]).trim("""")	# "\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\" -or- "\\localhost\ToolsShare\rfl\"
	if ($InOfflineMode -match "False") {
		$RFLserver = "emea.europe.corp.microsoft.com"
		$StatsServer = (($SDPcheckINI[4] -split " ")[2]).trim("""")
		if (Test-Connection -ComputerName $StatsServer -Quiet -Count 1) {[bool]$Stats=$True} else {[bool]$Stats=$False}
	} else { 
		$RFLserver = "localhost"
		$Stats = $False
		Write-host "OfflineMode: $InOfflineMode"
	}
#endregion: ###### customization section

	$LogLevel = 0
	$CheckDate = (Get-Date).ToUniversalTime().ToString("yy-MM-dd_HH-mm-ss")
	$LogPath = $FolderPath + "_" + $scriptName + ".log"
	$ErrorThrown = $null
	If ($Stats) {
		$StatsServerPath="\\$StatsServer\RFLstats$\RFL\scripts\Stats\"
		$CountInvFil = $StatsServerPath +'countEtl2pcap.dat'
		$CountInvFil2 = $CountInvFil +'.us'
		#increment at start of script
		 ($j=[int32](Get-Content $CountInvFil -TotalCount 1 -ErrorAction SilentlyContinue)) |out-null
		 (++$j) | Set-Content $CountInvFil -ErrorAction SilentlyContinue
	 }
	If ($PSBoundParameters['Debug']) { $DebugPreference='Continue'}

} #end BEGIN

PROCESS {
	try {
		$ScriptBeginTimeStamp = Get-Date
		#region: MAIN :::::

		# $NodeIP = (Test-Connection $RFLserver -Count 1 -ErrorAction SilentlyContinue).IPV4Address.IPAddressToString 
		# if ($NodeIP) { $NameHostObj = (Resolve-DnsName $NodeIP -ErrorAction SilentlyContinue) }
		# if ($NameHostObj) { $NameHost = ($NameHostObj.NameHost.split('.')[0]) }
		#if ($DFSserverName -match "EmeaCssDfs") {$NameHost = "Hypergate"} else {$NameHost = "Emea"}
		switch($DFSserverName)
			{	
			"EmeaCssDfs"	{$NameHost = "Hypergate"}
			"Emea"			{$NameHost = "Emea"}
			"localhost"		{$NameHost = "Localhost"}
			default			{$NameHost = "Emea"}
			}
		Write-Host "...Starting '$scriptName' on $(Get-Date) - served by host: $NameHost, using Etl2pcapng.exe $verEtl2pcapng"

		WriteInfoHighlighted "...looking for trace files *.etl which contain packet capture"
		# Check the argument is a folder
		if ((Test-Path -LiteralPath $FolderPath -PathType Container) -eq $false) {
			$wshell = New-Object -ComObject Wscript.Shell
			$wshell.Popup("This folder doesn't exist!",0,$FolderPath,0x1)
		}
		else{
			#$ListOfEtlFiles = (Get-ChildItem -LiteralPath $FolderPath -File -Filter *.etl | ? { $_.Name -ne "Merge.etl" }).FullName
			#$ListOfEtlFiles = (Get-ChildItem -LiteralPath $FolderPath -File -Filter *.etl) #| ? { $_.Name -match "packetcapture|NetTrace|capture|NdisCap|sniff" }).FullName #_# get-childitem  -Recurse -Path
			try {
				$ListOfEtlFiles = Get-ChildItem  -Recurse -Path $FolderPath -File -Filter *.etl -ErrorAction SilentlyContinue # -exclude *msdbg* #| ? { $_.Name -match "packetcapture|NetTrace|capture|NdisCap|sniff" }).FullName #_# get-childitem  -Recurse -Path
				#$ListOfEtlFiles
			}
			catch [System.IO.IOException] {
				Write-Host "FAIL: errorRecord is: $error" # [System.IO.PathTooLongException]
				$ListOfEtlFiles = (Get-ChildItem -LiteralPath $FolderPath -File -Filter *.etl)
			}
			$netcaplist = [System.Collections.ArrayList]@()
			# Check if the folder contains .etl files
			if ($ListOfEtlFiles.count -eq 0){
				Write-Host -BackgroundColor Black -ForegroundColor Red -Object "There is no *.etl file with given filter in $FolderPath - Double-check Folder path again!"
				$ErrorMsg += "No-Etl-found "
				$wshell = New-Object -ComObject Wscript.Shell
				$wshell.Popup("Invalid path: Doesn't contain any trace *packetcapture|NetTrace|capture|NdisCap|sniff*.etl file!",0,$FolderPath,0x1)
			}
			else{
				try {
					$redistInstalled = (Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\DevDiv\vc\Servicing\14.0\RuntimeMinimum\").Install
				}
				catch { Write-Host -ForegroundColor Red "Error in retrieving HKLM:\SOFTWARE\Microsoft\DevDiv\vc\Servicing\14.0\RuntimeMinimum\"}
				if (($redistInstalled -eq $False) -or ([String]::IsNullOrEmpty($redistInstalled))) {
					Write-Host -ForegroundColor  Magenta "VCruntime 14.0 not installed. Registry key not found, or value: $redistInstalled. Please install VCruntime from https://aka.ms/vs/16/release/VC_redist.x64.exe"
					#_# ToDo: autoinstall ?
				} Else {
					# 2021-02-10 - after v 1.4.1 of etl2pcapng.exe
					foreach ($file in $ListOfEtlFiles){
						if ($errorRecord.Exception -is [System.IO.PathTooLongException]){
								Write-Warning "Path too long in directory '$($errorRecord.TargetObject)'."
						}
						else{
							#Write-Host  $file.FullName has size of: ($file.Length/1024) KB
							if ($useIsnetcap) {
								& $RFLroot\isnetcap.exe $file.FullName 						# using this helper executable should no more be required, as etl2pcapng.exe has it built in now. But PktMon etl file need special treatment converting with PktMon (https://docs.microsoft.com/en-us/windows-server/networking/technologies/pktmon/pktmon-pcapng-support)
								Write-Output "Note: isnetcap.exe may fail for traces like *Firewall/WFP*.etl"
								if ( $LastExitCode -eq 3) {	$netcaplist = $netcaplist + $file.FullName }
							}else {$netcaplist +=  $file.FullName}
						}
					}
					#
					if ($netcaplist) {
						#WriteInfoHighlighted "...Working on list of found netcap files:"
						#Write-host "...Working on list of ETL files:"
						#$netcaplist
						
						#WriteInfo -message "Converting the $($netcaplist.count) Capture *.etl files found in the `"$FolderPath`" folder ..." 
						Write-Host -ForegroundColor Gray "Converting the $($netcaplist.count) *.etl files found in the '$FolderPath' folder tree..." # WriteInfo
						# Informing the user
						foreach ($capfile in $netcaplist){
							write-host -ForegroundColor Yellow " $capfile" #Green
							WriteInfo -message "...Working on $capfile `n"
							$outfile = Join-Path ([System.IO.Path]::GetDirectoryName($capfile)) (([System.IO.Path]::GetFileNameWithoutExtension($capfile)) + ".pcap")
							& $RFLroot\etl2pcapng.exe $capfile $outfile									# Converting .etl to .pacap		
							# delete the 'dummy' output file if it has a size of 1KB (lenght=28) -- remove once issue is fixed on GitHub https://github.com/microsoft/etl2pcapng
							$OutFilesize=(Get-Item $outfile).length
							if ("28" -eq $OutFilesize) {remove-item $outfile}
						}
					}
					#Write-Host -ForegroundColor Green "`nAll network traces *packetcapture|NetTrace|capture|NdisCap|sniff*.etl files are now converted into the corresponding *.pcap files:"
					#(Get-ChildItem -LiteralPath $FolderPath -File -Filter *.pcap | ? { $_.Name -match "packetcapture|NetTrace|capture|NdisCap|sniff" }).FullName
					Write-verbose "`n If you see lots of 'WARNING: Skipped packet that doesn't have both KW_PACKET_START and KW_PACKET_END set!', better convert using MA or Netmon Save-As .cap"
				}
			}
		}
		#endregion: MAIN
	} # end try PROCESS
	catch {
		WriteError -message "An Error occured"
		WriteError -message $error[0].Exception.Message
		$ErrorThrown = $true

		$errorMessage = "$scriptName caught an exception on $($ENV:COMPUTERNAME):"
		$errorMessage += "`n`n"
		$errorMessage += "Exception Type: $($_.Exception.GetType().FullName)"
		$errorMessage += "`n`n"
		$errorMessage += "Exception Message: $($_.Exception.Message)"
		Write-Host "Possible explanation of: Exception Message: Could not find a part of the path ...
		There are too many nested folders, i.e. expanded psSDP folder. Solution: move the psSDP folder up one level."
		Write-Error $errorMessage -ErrorAction Continue
		Start-Sleep -Seconds 3
		Write-Debug $errorMessage
		if ($UseExitCode){
			$error.clear()	# clear script errors
			exit 1
		} #end UseExitCode
	} #end Catch PROCESS
	Finally {
	}
} #end PROCESS

END {
	$ScriptEndTimeStamp = Get-Date
	$Duration = $(New-TimeSpan -Start $ScriptBeginTimeStamp -End $ScriptEndTimeStamp)
	$LogLevel = 0
	Write-Host -BackgroundColor Gray -ForegroundColor Black -Object "Script $scriptName v$verDateScript execution finished. Duration: $Duration"
	if($ErrorThrown) {Throw $error[0].Exception.Message
		}
	# Stats
	If ($Stats) { #increment at start of script
	 "$j" + " ;$CheckDate" + "; " + ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name) + "; $($Duration)" + "; $NodeCnt" + "; $FolderPath" + "; $($ListOfEtlFiles.count); $ErrorMsg" + "; v$verDateScript" + "; $NameHost" | Out-File $CountInvFil2 -Append -Encoding UTF8 -ErrorAction SilentlyContinue
	 }
  # This resets the ErrorActionPreference to the value at script start.
  $errorActionPreference = $startErrorActionPreference
} #end END


