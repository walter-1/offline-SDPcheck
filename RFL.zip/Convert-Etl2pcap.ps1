<# last edit by: waltere 2020-04-01
  File Name: Convert-Etl2pcap.ps1
  Objective: This script converts a network trace capture .etl file to Wireshark compatible .pcap file
#>

# Load Common Library
#. ./utils_common_functions.ps1

<#
.SYNOPSIS
Convert-Etl2pcap - Script to convert a network trace capture .etl file to Wireshark compatible .pcap file using tool etl2pcapng.exe
version v1.0.0 from https://github.com/microsoft/etl2pcapng/releases - etl2pcapng.exe -v

How to use it:

SYNTAX: .\Convert-Etl2pcap.ps1 -FolderPath [full-path-to-expanded-TSS-folder] [ -HostMode ]


.DESCRIPTION
The script is used when a SDP report is used to collect data from multiple servers, like from a failover cluster.
When running, it will move the files into separate folders by computer name. It will also place RFL output into its own folder.

Store all the .etl files you want to convert in a unique folder and run the script by giving the -FolderPath argument.

Note: If you experience PS error '...is not digitally signed.' run the command:
 Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy Bypass


.PARAMETER HostMode
  This tells the logging functions to show logging on the screen

.PARAMETER ScriptMode
  This tells the logging functions to show logging in log file _Convert-Etl2pcap.log

.EXAMPLE
	 \\localhost\ToolsShare\rfl\Convert-Etl2pcap.ps1 -FolderPath \\MyPC\temp\TSS -HostMode
	 This command will convert the known trace .etl files in \\MyPC\temp\TSS folder
	 It will also show detailed output in the console when switch -HostMode is supplied.

.LINK
	 \ \localhost\ToolsShare\rfl\Convert-Etl2pcap.ps1
	waltere@microsoft.com
#>

[CmdletBinding()]
PARAM (
	# Path to folder containing *.etl files
	[Parameter(Mandatory = $true,Position=0,HelpMessage='Choose the .etl folder location, i.e. C:\SR\TSS-Folder\ ')]
	[string] $FolderPath,

	[switch]$HostMode  = $true,  # This tells the logging functions to show logging on the screen
	[switch]$ScriptMode = $false # This tells the logging functions to show logging in log file _Convert-Etl2pcap.log
)


BEGIN {
  # This saves the starting ErrorActionPreference and then sets it to 'Stop'.
		$startErrorActionPreference = $errorActionPreference
		$errorActionPreference = 'Stop'
  # This gets the current path and name of the script.
		$invocation = (Get-Variable MyInvocation).Value
		#$scriptPath = Split-Path $invocation.MyCommand.Path
		$scriptName = $invocation.MyCommand.Name
  #Write-Host "Running `"$scriptPath\$scriptName`"..." -BackgroundColor Black -ForegroundColor Green

	Set-Variable -Name ErrorMsg -Scope Script -Force
	[string]$Script:ErrorMsg=""
	### Trail FolderPath with \ and allow path with space character
		if ($FolderPath.EndsWith("\")){$FolderPath="$FolderPath"}
		else {$FolderPath="$FolderPath" +"\"}
		If (-NOT (Test-Path $FolderPath -PathType 'Container')){Throw "$($FolderPath) is not a valid folder"}

	#region: ###### customization section of script, logging configuration ########################
		$VerMa="1"
		$VerMi="06"
		#$ErrorActionPreference = "Continue" #"Stop"
		$RFLpath = "\\localhost\ToolsShare\rfl"
		$LogLevel = 0
		#if (Test-Connection -ComputerName waltere-vdi.europe.corp.microsoft.com -Quiet -Count 1) {[bool]$Stats=1} else {[bool]$Stats=0}
		$Stats=0
		$StatsServerPath="\\waltere-vdi.europe.corp.microsoft.com\ToolsShare\tools\RFL\"
		$CheckDate = (Get-Date).ToUniversalTime().ToString("yy-MM-dd_HH-mm-ss")
		$CountInvFil = $StatsServerPath +'countEtl2pcap.dat'
		$CountInvFil2 = $CountInvFil +'.us'
		$LogPath = $FolderPath + "_" + $scriptName + ".log"
		$ErrorThrown = $null
	#endregion: ###### customization section

	If ($Stats) { #increment at start of script
	 ($j=[int32](Get-Content $CountInvFil -TotalCount 1 -ErrorAction SilentlyContinue)) |out-null
	 (++$j) | Set-Content $CountInvFil -ErrorAction SilentlyContinue
	 }
	If ($PSBoundParameters['Debug']) { $DebugPreference='Continue'}


#region: Logging Functions
	function WriteLine ([string]$line,[string]$ForegroundColor, [switch]$NoNewLine){
		# SYNOPSIS: writes the actual output - used by other Logging Functions
    if($Script:ScriptMode){
      if($NoNewLine) {
        $Script:Trace += "$line"
      }
      else {
        $Script:Trace += "$line`r`n"
      }
      Set-Content -Path $script:LogPath -Value $Script:Trace
    }
    if($Script:HostMode){
      $Params = @{
        NoNewLine    = $NoNewLine -eq $true
        ForegroundColor = if($ForegroundColor) {$ForegroundColor} else {"White"}
      }
      Write-Host $line @Params
    }
  }

  function WriteInfo([string]$message,[switch]$WaitForResult,[string[]]$AdditionalStringArray,[string]$AdditionalMultilineString){
		# SYNOPSIS: handles informational logs
    if($WaitForResult){
      WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)$message" -NoNewline
    }
    else{
      WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)$message"
    }
    if($AdditionalStringArray){
      foreach ($String in $AdditionalStringArray){
        WriteLine "          $("`t" * $script:LogLevel)`t$String"
      }
    }
    if($AdditionalMultilineString){
      foreach ($String in ($AdditionalMultilineString -split "`r`n" | Where-Object {$_ -ne ""})){
        WriteLine "          $("`t" * $script:LogLevel)`t$String"
      }
    }
  }

  function WriteResult([string]$message,[switch]$Pass,[switch]$Success){
		# SYNOPSIS: writes results - should be used after -WaitForResult in WriteInfo
    if($Pass){
      WriteLine " - Pass" -ForegroundColor Cyan
      if($message){
        WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)`t$message" -ForegroundColor Cyan
      }
    }
    if($Success){
      WriteLine " - Success" -ForegroundColor Green
      if($message){
        WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)`t$message" -ForegroundColor Green
      }
    }
  }

  function WriteInfoHighlighted([string]$message,[string[]]$AdditionalStringArray,[string]$AdditionalMultilineString){
		# SYNOPSIS: write highlighted info
    WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)$message" -ForegroundColor Cyan
    if($AdditionalStringArray){
      foreach ($String in $AdditionalStringArray){
        WriteLine "[$(Get-Date -Format hh:mm:ss)]     $("`t" * $script:LogLevel)`t$String" -ForegroundColor Cyan
      }
    }
    if($AdditionalMultilineString){
      foreach ($String in ($AdditionalMultilineString -split "`r`n" | Where-Object {$_ -ne ""})){
        WriteLine "[$(Get-Date -Format hh:mm:ss)]     $("`t" * $script:LogLevel)`t$String" -ForegroundColor Cyan
      }
    }
  }

  function WriteWarning([string]$message,[string[]]$AdditionalStringArray,[string]$AdditionalMultilineString){
		# SYNOPSIS: write warning logs
    WriteLine "[$(Get-Date -Format hh:mm:ss)] WARNING: $("`t" * $script:LogLevel)$message" -ForegroundColor Yellow
    if($AdditionalStringArray){
      foreach ($String in $AdditionalStringArray){
        WriteLine "[$(Get-Date -Format hh:mm:ss)]     $("`t" * $script:LogLevel)`t$String" -ForegroundColor Yellow
      }
    }
    if($AdditionalMultilineString){
      foreach ($String in ($AdditionalMultilineString -split "`r`n" | Where-Object {$_ -ne ""})){
        WriteLine "[$(Get-Date -Format hh:mm:ss)]     $("`t" * $script:LogLevel)`t$String" -ForegroundColor Yellow
      }
    }
  }

  function WriteError([string]$message){
		# SYNOPSIS: logs errors
			WriteLine ""
			WriteLine "[$(Get-Date -Format hh:mm:ss)] ERROR:  $("`t`t" * $script:LogLevel)$message" -ForegroundColor Red
  }

  function WriteErrorAndExit($message){
		# SYNOPSIS: logs errors and terminates script
			WriteLine "[$(Get-Date -Format hh:mm:ss)] ERROR:  $("`t" * $script:LogLevel)$message" -ForegroundColor Red
			Write-Host "Press any key to continue ..."
			$host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") | OUT-NULL
			$HOST.UI.RawUI.Flushinputbuffer()
			Throw "Terminating Error"
	}

	#endregion: Logging Functions

	#region: Script Functions
	function CheckVCruntime140 ($key) {
		HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\DevDiv\vc\Servicing\14.0\RuntimeMinimum\Install\
	}
	function Test-RegistryValue {
		param (
		 [parameter(Mandatory=$true)]
		 [ValidateNotNullOrEmpty()]$Path,
		 [parameter(Mandatory=$true)]
		 [ValidateNotNullOrEmpty()]$Value
		)
			try {
			Get-ItemProperty -Path "$Path" -ErrorAction Stop | Select-Object -ExpandProperty $Value -ErrorAction Stop | Out-Null
				return #$true
			}
			catch {
				return $false
			}
	}
	#endregion: Script Functions

} #end BEGIN

PROCESS {
	try {
		$ScriptBeginTimeStamp = Get-Date
		#region: MAIN :::::

		# Validate SDP folder for not having more than one consecutive space characters
		# if ($FolderPath -match "  ") {Throw "$($FolderPath) contains more consecutive space characters, please rename folder"} else {write-host "SDP folder is OK"}

		 $NodeIP = (Test-Connection localhost -Count 1 -ErrorAction SilentlyContinue).IPV4Address.IPAddressToString 
		 if ($NodeIP) { $NameHostObj = (Resolve-DnsName $NodeIP -ErrorAction SilentlyContinue) }
		 if ($NameHostObj) { $NameHost = ($NameHostObj.NameHost.split('.')[0]) }
	 
		WriteInfo -message "...Starting '$scriptName' on $(Get-Date) - served by localhost node: $NodeInfo $NameHost"
		#WriteInfoHighlighted "...looking for trace files with name *packetcapture|NetTrace|capture|NdisCap|sniff*.etl"
		WriteInfoHighlighted "...looking for trace files *.etl which contain packet capture"

		# Check the argument is a folder
		if ((Test-Path -LiteralPath $FolderPath -PathType Container) -eq $false) {
			$wshell = New-Object -ComObject Wscript.Shell
			$wshell.Popup("This folder doesn't exist!",0,$FolderPath,0x1)
		}
		else
		{
			#$ListOfEtlFiles = (Get-ChildItem -LiteralPath $FolderPath -File -Filter *.etl | ? { $_.Name -ne "Merge.etl" }).FullName
			#$ListOfEtlFiles = (Get-ChildItem -LiteralPath $FolderPath -File -Filter *.etl) #| ? { $_.Name -match "packetcapture|NetTrace|capture|NdisCap|sniff" }).FullName #_# get-childitem  -Recurse -Path
			try {
				$ListOfEtlFiles = Get-ChildItem  -Recurse -Path $FolderPath -File -Filter *.etl -ErrorAction SilentlyContinue # -exclude *msdbg* #| ? { $_.Name -match "packetcapture|NetTrace|capture|NdisCap|sniff" }).FullName #_# get-childitem  -Recurse -Path
				#$ListOfEtlFiles
			}
			catch [System.IO.IOException] {
				Write-Host "FAIL: errorRecord is: $error" # [System.IO.PathTooLongException]
				$ListOfEtlFiles = (Get-ChildItem -LiteralPath $FolderPath -File -Filter *.etl)
			}
			$netcaplist = [System.Collections.ArrayList]@()
			# Check if the folder contains .etl files
			if ($ListOfEtlFiles.count -eq 0)
			{
				Write-Host -BackgroundColor Black -ForegroundColor Red -Object "There is no *.etl file with given filter in $FolderPath - Double-check Folder path again!"
				$ErrorMsg += "No-Etl-found "
				$wshell = New-Object -ComObject Wscript.Shell
				$wshell.Popup("Invalid path: Doesn't contain any trace *packetcapture|NetTrace|capture|NdisCap|sniff*.etl file!",0,$FolderPath,0x1)
			}
			else
			{
			 $redistInstalled = (Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\DevDiv\vc\Servicing\14.0\RuntimeMinimum\").Install
             if ($redistInstalled -eq $False) { Write-Error "VCruntime 14.0 not installed. Registry key not found, or value: $redistInstalled. Please install VCruntime from https://aka.ms/vs/16/release/VC_redist.x64.exe"
			 #_# ToDo: autoinstall ?
			} Else {
                # 2021-02-10 - after v 1.4.1 of etl2pcapng.exe
				foreach ($file in $ListOfEtlFiles)
				{
					if ($errorRecord.Exception -is [System.IO.PathTooLongException])
						{
							Write-Warning "Path too long in directory '$($errorRecord.TargetObject)'."
						}
						else
						{
										#Write-Host  $file.FullName has size of: ($file.Length/1024) KB
										& $RFLpath\isnetcap.exe $file.FullName 
										if ( $LastExitCode -eq 3) {	$netcaplist = $netcaplist + $file.FullName }
					  }
				}
				#
				if ($netcaplist) {
					WriteInfoHighlighted "...Working on list of found netcap files:"
					$netcaplist
					
					WriteInfo -message "Converting the $($netcaplist.count) Capture *.etl files found in the `"$FolderPath`" folder ..."
					# Informing the user
					foreach ($capfile in $netcaplist)
					{
						write-host -ForegroundColor Green $capfile 

						WriteInfo -message "...Working on $capfile `n"
						$outfile = Join-Path ([System.IO.Path]::GetDirectoryName($capfile)) (([System.IO.Path]::GetFileNameWithoutExtension($capfile)) + ".pcap")
						& $RFLpath\etl2pcapng.exe $capfile $outfile					
					}
				}
				#Write-Host -ForegroundColor Green "`nAll network traces *packetcapture|NetTrace|capture|NdisCap|sniff*.etl files are now converted into the corresponding *.pcap files:"
				#(Get-ChildItem -LiteralPath $FolderPath -File -Filter *.pcap | ? { $_.Name -match "packetcapture|NetTrace|capture|NdisCap|sniff" }).FullName
				# Write-Host -ForegroundColor Yellow "`nPlease be aware that the timestamps in *.pcap out file are not reliable, but order of packet sequence is correct!"
				Write-verbose "`n If you see lots of 'WARNING: Skipped packet that doesn't have both KW_PACKET_START and KW_PACKET_END set!', better convert using MA or Netmon Save-As .cap"
				}
			}
		}
		#endregion: MAIN
	} # end try PROCESS
	catch {
		WriteError -message "An Error occured"
		WriteError -message $error[0].Exception.Message
		$ErrorThrown = $true

		$errorMessage = "$scriptName caught an exception on $($ENV:COMPUTERNAME):"
		$errorMessage += "`n`n"
		$errorMessage += "Exception Type: $($_.Exception.GetType().FullName)"
		$errorMessage += "`n`n"
		$errorMessage += "Exception Message: $($_.Exception.Message)"
		Write-Host "Possible explanation of: Exception Message: Could not find a part of the path ...
		There are too many nested folders, i.e. expanded psSDP folder. Solution: move the psSDP folder up one level."
		Write-Error $errorMessage -ErrorAction Continue
		Start-Sleep -Seconds 3
		Write-Debug $errorMessage
		if ( $UseExitCode ) {
			$error.clear()	# clear script errors
			exit 1
		} #end UseExitCode
  } #end Catch PROCESS
	Finally {
	} #end Finally PROCESS
} #end PROCESS

END {
	$ScriptEndTimeStamp = Get-Date
	$Duration = $(New-TimeSpan -Start $ScriptBeginTimeStamp -End $ScriptEndTimeStamp)
	$LogLevel = 0
	Write-Host -BackgroundColor Gray -ForegroundColor Black -Object "Script $scriptName v$VerMa.$VerMi execution finished. Duration: $Duration"
	if($ErrorThrown) {Throw $error[0].Exception.Message
		}
	# Stats
	If ($Stats) { #increment at start of script
	 "$j" + " ;$CheckDate" + "; " + ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name) + "; $($Duration)" + "; $NodeCnt" + "; $FolderPath" + "; $($ListOfEtlFiles.count); $ErrorMsg" + "; v$VerMa.$VerMi" | Out-File $CountInvFil2 -Append -Encoding UTF8 -ErrorAction SilentlyContinue
	 }
  # This resets the ErrorActionPreference to the value at script start.
  $errorActionPreference = $startErrorActionPreference
} #end END

#region :comments & ToDo's
#
#
#endregion :comments & ToDo's