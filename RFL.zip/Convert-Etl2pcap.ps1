<# last edit by: waltere 2022-11-28
  File Name: Convert-Etl2pcap.ps1
  Objective: This script converts a network trace capture .etl file to Wireshark compatible .pcap file
  Source GitHub https://github.com/microsoft/etl2pcapng/releases 
  etl2pcapng.exe v1.9 
#>

<#
.SYNOPSIS
Convert-Etl2pcap - Script to convert a network trace capture .etl file to Wireshark compatible .pcap file using tool etl2pcapng.exe
 https://github.com/microsoft/etl2pcapng/releases - 'etl2pcapng.exe -v' displays version

How to use it:

SYNTAX: .\Convert-Etl2pcap.ps1 -FolderPath [full-path-to-expanded-SDP-folder] [ -HostMode ]


.DESCRIPTION
The script can be used to convert all *.etl files (which contain network packets) within a folder into a pcap format, which is readaby with WireShark

Note: If you experience PS error '...is not digitally signed.' run the command:
 Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy Bypass


.PARAMETER HostMode
  This tells the logging functions to show logging on the screen

.PARAMETER ScriptMode
  This tells the logging functions to show logging in log file _Convert-Etl2pcap.log

.EXAMPLE
	 \\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\Convert-Etl2pcap.ps1 -FolderPath \\MyPC\temp\SDP -HostMode
	 - in Offline-version, the path would be \\localhost\ToolsShare\rfl\Convert-Etl2pcap.ps1
	 This command will convert the known trace .etl files in \\MyPC\temp\SDP folder
	 It will also show detailed output in the console when switch -HostMode is supplied.

.LINK
	 \ \emeacssdfs.europe.corp.microsoft.com\netpod\rfl\Convert-Etl2pcap.ps1
	waltere@microsoft.com
#>

[CmdletBinding()]
PARAM (
	[Parameter(Mandatory = $true,Position=0,HelpMessage='Choose the .etl folder location, i.e. C:\SR\SDP-Folder\ ')]
	[string] $FolderPath,			# Path to folder containing *.etl files
	[switch]$HostMode  = $true, 	# This tells the logging functions to show logging on the screen
	[switch]$ScriptMode = $false	# This tells the logging functions to show logging in log file _Convert-Etl2pcap.log
)

BEGIN {
	$verDateScript = "2022.11.28.0"
	$ScriptFolder = Split-Path $MyInvocation.MyCommand.Path -Parent
	$verEtl2pcapng = "v1.10"
	# Load Common Library:
	. $ScriptFolder\Utils_RflShared.ps1

  # This saves the starting ErrorActionPreference and then sets it to 'Stop'.
	$startErrorActionPreference = $errorActionPreference
	$errorActionPreference = 'Stop'
  # This gets the current path and name of the script.
	$invocation = (Get-Variable MyInvocation).Value
	#$scriptPath = Split-Path $invocation.MyCommand.Path
	$scriptName = $invocation.MyCommand.Name
  #Write-Host "Running `"$scriptPath\$scriptName`"..." -BackgroundColor Black -ForegroundColor Green

	Set-Variable -Name ErrorMsg -Scope Script -Force
	[string]$Script:ErrorMsg=""
	### Trail FolderPath with \ and allow path with space character
		if ($FolderPath.EndsWith("\")){$FolderPath="$FolderPath"}
		else {$FolderPath="$FolderPath" +"\"}
		If (-NOT (Test-Path $FolderPath -PathType 'Container')){Throw "$($FolderPath) is not a valid folder"}

#region: ###### customization section of script, logging configuration ########################
	$useIsnetcap = $False	# set to $True if old behaviour with isnetcap.exe check is needed
	$SDPcheckINI = (Get-content -Path "$ScriptFolder\_SDPcheck.ini")
	$InOfflineMode 	= (($SDPcheckINI[1] -split " ")[2]).trim("""")	# set $True for outsourcer or when not connected to MS network - offline-SDPcheck
	$DFSserverName = (($SDPcheckINI[7] -split " ")[2]).trim("""")
	$RFLroot = (($SDPcheckINI[2] -split " ")[2]).trim("""")	# "\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\" -or- "\\localhost\ToolsShare\rfl\"
	if ($InOfflineMode -match "False") {
		$RFLserver = "emea.europe.corp.microsoft.com"
		$StatsServer = (($SDPcheckINI[4] -split " ")[2]).trim("""")
		if (Test-Connection -ComputerName $StatsServer -Quiet -Count 1) {[bool]$Stats=$True} else {[bool]$Stats=$False}
	} else { 
		$RFLserver = "localhost"
		$Stats = $False
		Write-host "OfflineMode: $InOfflineMode"
	}
#endregion: ###### customization section

	$LogLevel = 0
	$CheckDate = (Get-Date).ToUniversalTime().ToString("yy-MM-dd_HH-mm-ss")
	$LogPath = $FolderPath + "_" + $scriptName + ".log"
	$ErrorThrown = $null
	If ($Stats) {
		$StatsServerPath="\\$StatsServer\RFLstats$\RFL\scripts\Stats\"
		$CountInvFil = $StatsServerPath +'countEtl2pcap.dat'
		$CountInvFil2 = $CountInvFil +'.us'
		#increment at start of script
		 ($j=[int32](Get-Content $CountInvFil -TotalCount 1 -ErrorAction SilentlyContinue)) |out-null
		 (++$j) | Set-Content $CountInvFil -ErrorAction SilentlyContinue
	 }
	If ($PSBoundParameters['Debug']) { $DebugPreference='Continue'}

} #end BEGIN

PROCESS {
	try {
		$ScriptBeginTimeStamp = Get-Date
		#region: MAIN :::::

		# $NodeIP = (Test-Connection $RFLserver -Count 1 -ErrorAction SilentlyContinue).IPV4Address.IPAddressToString 
		# if ($NodeIP) { $NameHostObj = (Resolve-DnsName $NodeIP -ErrorAction SilentlyContinue) }
		# if ($NameHostObj) { $NameHost = ($NameHostObj.NameHost.split('.')[0]) }
		#if ($DFSserverName -match "EmeaCssDfs") {$NameHost = "Hypergate"} else {$NameHost = "Emea"}
		switch($DFSserverName)
			{	
			"EmeaCssDfs"	{$NameHost = "Hypergate"}
			"Emea"			{$NameHost = "Emea"}
			"localhost"		{$NameHost = "Localhost"}
			default			{$NameHost = "Emea"}
			}
		Write-Host "...Starting '$scriptName' on $(Get-Date) - served by host: $NameHost, using Etl2pcapng.exe $verEtl2pcapng"

		WriteInfoHighlighted "...looking for trace files *.etl which contain packet capture"
		# Check the argument is a folder
		if ((Test-Path -LiteralPath $FolderPath -PathType Container) -eq $false) {
			$wshell = New-Object -ComObject Wscript.Shell
			$wshell.Popup("This folder doesn't exist!",0,$FolderPath,0x1)
		}
		else{
			#$ListOfEtlFiles = (Get-ChildItem -LiteralPath $FolderPath -File -Filter *.etl | ? { $_.Name -ne "Merge.etl" }).FullName
			#$ListOfEtlFiles = (Get-ChildItem -LiteralPath $FolderPath -File -Filter *.etl) #| ? { $_.Name -match "packetcapture|NetTrace|capture|NdisCap|sniff" }).FullName #_# get-childitem  -Recurse -Path
			try {
				$ListOfEtlFiles = Get-ChildItem  -Recurse -Path $FolderPath -File -Filter *.etl -ErrorAction SilentlyContinue # -exclude *msdbg* #| ? { $_.Name -match "packetcapture|NetTrace|capture|NdisCap|sniff" }).FullName #_# get-childitem  -Recurse -Path
				#$ListOfEtlFiles
			}
			catch [System.IO.IOException] {
				Write-Host "FAIL: errorRecord is: $error" # [System.IO.PathTooLongException]
				$ListOfEtlFiles = (Get-ChildItem -LiteralPath $FolderPath -File -Filter *.etl)
			}
			$netcaplist = [System.Collections.ArrayList]@()
			# Check if the folder contains .etl files
			if ($ListOfEtlFiles.count -eq 0){
				Write-Host -BackgroundColor Black -ForegroundColor Red -Object "There is no *.etl file with given filter in $FolderPath - Double-check Folder path again!"
				$ErrorMsg += "No-Etl-found "
				$wshell = New-Object -ComObject Wscript.Shell
				$wshell.Popup("Invalid path: Doesn't contain any trace *packetcapture|NetTrace|capture|NdisCap|sniff*.etl file!",0,$FolderPath,0x1)
			}
			else{
				try {
					$redistInstalled = (Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\DevDiv\vc\Servicing\14.0\RuntimeMinimum\").Install
				}
				catch { Write-Host -ForegroundColor Red "Error in retrieving HKLM:\SOFTWARE\Microsoft\DevDiv\vc\Servicing\14.0\RuntimeMinimum\"}
				if (($redistInstalled -eq $False) -or ([String]::IsNullOrEmpty($redistInstalled))) {
					Write-Host -ForegroundColor  Magenta "VCruntime 14.0 not installed. Registry key not found, or value: $redistInstalled. Please install VCruntime from https://aka.ms/vs/16/release/VC_redist.x64.exe"
					#_# ToDo: autoinstall ?
				} Else {
					# 2021-02-10 - after v 1.4.1 of etl2pcapng.exe
					foreach ($file in $ListOfEtlFiles){
						if ($errorRecord.Exception -is [System.IO.PathTooLongException]){
								Write-Warning "Path too long in directory '$($errorRecord.TargetObject)'."
						}
						else{
							#Write-Host  $file.FullName has size of: ($file.Length/1024) KB
							if ($useIsnetcap) {
								& $RFLroot\isnetcap.exe $file.FullName 						# using this helper executable should no more be required, as etl2pcapng.exe has it built in now. But PktMon etl file need special treatment converting with PktMon (https://docs.microsoft.com/en-us/windows-server/networking/technologies/pktmon/pktmon-pcapng-support)
								Write-Output "Note: isnetcap.exe may fail for traces like *Firewall/WFP*.etl"
								if ( $LastExitCode -eq 3) {	$netcaplist = $netcaplist + $file.FullName }
							}else {$netcaplist +=  $file.FullName}
						}
					}
					#
					if ($netcaplist) {
						#WriteInfoHighlighted "...Working on list of found netcap files:"
						#Write-host "...Working on list of ETL files:"
						#$netcaplist
						
						#WriteInfo -message "Converting the $($netcaplist.count) Capture *.etl files found in the `"$FolderPath`" folder ..." 
						Write-Host -ForegroundColor Gray "Converting the $($netcaplist.count) *.etl files found in the '$FolderPath' folder tree..." # WriteInfo
						# Informing the user
						foreach ($capfile in $netcaplist){
							write-host -ForegroundColor Yellow " $capfile" #Green
							WriteInfo -message "...Working on $capfile `n"
							$outfile = Join-Path ([System.IO.Path]::GetDirectoryName($capfile)) (([System.IO.Path]::GetFileNameWithoutExtension($capfile)) + ".pcap")
							& $RFLroot\etl2pcapng.exe $capfile $outfile									# Converting .etl to .pacap		
							# delete the 'dummy' output file if it has a size of 1KB (lenght=28) -- remove once issue is fixed on GitHub https://github.com/microsoft/etl2pcapng
							$OutFilesize=(Get-Item $outfile).length
							if ("28" -eq $OutFilesize) {remove-item $outfile}
						}
					}
					#Write-Host -ForegroundColor Green "`nAll network traces *packetcapture|NetTrace|capture|NdisCap|sniff*.etl files are now converted into the corresponding *.pcap files:"
					#(Get-ChildItem -LiteralPath $FolderPath -File -Filter *.pcap | ? { $_.Name -match "packetcapture|NetTrace|capture|NdisCap|sniff" }).FullName
					Write-verbose "`n If you see lots of 'WARNING: Skipped packet that doesn't have both KW_PACKET_START and KW_PACKET_END set!', better convert using MA or Netmon Save-As .cap"
				}
			}
		}
		#endregion: MAIN
	} # end try PROCESS
	catch {
		WriteError -message "An Error occured"
		WriteError -message $error[0].Exception.Message
		$ErrorThrown = $true

		$errorMessage = "$scriptName caught an exception on $($ENV:COMPUTERNAME):"
		$errorMessage += "`n`n"
		$errorMessage += "Exception Type: $($_.Exception.GetType().FullName)"
		$errorMessage += "`n`n"
		$errorMessage += "Exception Message: $($_.Exception.Message)"
		Write-Host "Possible explanation of: Exception Message: Could not find a part of the path ...
		There are too many nested folders, i.e. expanded psSDP folder. Solution: move the psSDP folder up one level."
		Write-Error $errorMessage -ErrorAction Continue
		Start-Sleep -Seconds 3
		Write-Debug $errorMessage
		if ($UseExitCode){
			$error.clear()	# clear script errors
			exit 1
		} #end UseExitCode
	} #end Catch PROCESS
	Finally {
	}
} #end PROCESS

END {
	$ScriptEndTimeStamp = Get-Date
	$Duration = $(New-TimeSpan -Start $ScriptBeginTimeStamp -End $ScriptEndTimeStamp)
	$LogLevel = 0
	Write-Host -BackgroundColor Gray -ForegroundColor Black -Object "Script $scriptName v$verDateScript execution finished. Duration: $Duration"
	if($ErrorThrown) {Throw $error[0].Exception.Message
		}
	# Stats
	If ($Stats) { #increment at start of script
	 "$j" + " ;$CheckDate" + "; " + ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name) + "; $($Duration)" + "; $NodeCnt" + "; $FolderPath" + "; $($ListOfEtlFiles.count); $ErrorMsg" + "; v$verDateScript" + "; $NameHost" | Out-File $CountInvFil2 -Append -Encoding UTF8 -ErrorAction SilentlyContinue
	 }
  # This resets the ErrorActionPreference to the value at script start.
  $errorActionPreference = $startErrorActionPreference
} #end END



# SIG # Begin signature block
# MIInlQYJKoZIhvcNAQcCoIInhjCCJ4ICAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCFAUwAcY93dey7
# 4c0vJfQ5SJjxzT2YXv9heE8PiIzEo6CCDXYwggX0MIID3KADAgECAhMzAAACy7d1
# OfsCcUI2AAAAAALLMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjIwNTEyMjA0NTU5WhcNMjMwNTExMjA0NTU5WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC3sN0WcdGpGXPZIb5iNfFB0xZ8rnJvYnxD6Uf2BHXglpbTEfoe+mO//oLWkRxA
# wppditsSVOD0oglKbtnh9Wp2DARLcxbGaW4YanOWSB1LyLRpHnnQ5POlh2U5trg4
# 3gQjvlNZlQB3lL+zrPtbNvMA7E0Wkmo+Z6YFnsf7aek+KGzaGboAeFO4uKZjQXY5
# RmMzE70Bwaz7hvA05jDURdRKH0i/1yK96TDuP7JyRFLOvA3UXNWz00R9w7ppMDcN
# lXtrmbPigv3xE9FfpfmJRtiOZQKd73K72Wujmj6/Su3+DBTpOq7NgdntW2lJfX3X
# a6oe4F9Pk9xRhkwHsk7Ju9E/AgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUrg/nt/gj+BBLd1jZWYhok7v5/w4w
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzQ3MDUyODAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAJL5t6pVjIRlQ8j4dAFJ
# ZnMke3rRHeQDOPFxswM47HRvgQa2E1jea2aYiMk1WmdqWnYw1bal4IzRlSVf4czf
# zx2vjOIOiaGllW2ByHkfKApngOzJmAQ8F15xSHPRvNMmvpC3PFLvKMf3y5SyPJxh
# 922TTq0q5epJv1SgZDWlUlHL/Ex1nX8kzBRhHvc6D6F5la+oAO4A3o/ZC05OOgm4
# EJxZP9MqUi5iid2dw4Jg/HvtDpCcLj1GLIhCDaebKegajCJlMhhxnDXrGFLJfX8j
# 7k7LUvrZDsQniJZ3D66K+3SZTLhvwK7dMGVFuUUJUfDifrlCTjKG9mxsPDllfyck
# 4zGnRZv8Jw9RgE1zAghnU14L0vVUNOzi/4bE7wIsiRyIcCcVoXRneBA3n/frLXvd
# jDsbb2lpGu78+s1zbO5N0bhHWq4j5WMutrspBxEhqG2PSBjC5Ypi+jhtfu3+x76N
# mBvsyKuxx9+Hm/ALnlzKxr4KyMR3/z4IRMzA1QyppNk65Ui+jB14g+w4vole33M1
# pVqVckrmSebUkmjnCshCiH12IFgHZF7gRwE4YZrJ7QjxZeoZqHaKsQLRMp653beB
# fHfeva9zJPhBSdVcCW7x9q0c2HVPLJHX9YCUU714I+qtLpDGrdbZxD9mikPqL/To
# /1lDZ0ch8FtePhME7houuoPcMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGXUwghlxAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAALLt3U5+wJxQjYAAAAAAsswDQYJYIZIAWUDBAIB
# BQCggbAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIPSgJWHds/By1KXjTIqdpkE/
# P5Gg0d6dCU3RKnup3DNFMEQGCisGAQQBgjcCAQwxNjA0oBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEcgBpodHRwczovL3d3dy5taWNyb3NvZnQuY29tIDANBgkqhkiG9w0B
# AQEFAASCAQBqxYDNxihV9MYzyuGX+C0H4YvW9PqVGAFAt/QkY9Y6cGDnsswOpFJO
# qX23jjBwYgeyXwN37jk62qMtb8DIZsIvtbyT01Udz8/O5VdK16zj2CdAY6orQEJv
# 4p5g+rq+ciiWsIh4CmQ4TyL5BbWaOPPMhhfWheWtIQeIKXLioMqjCJEdh65oMj/9
# JNeFVAAMvqie37Ikc+WlWHA41pEDui8IqEL6OuBcFoQTqG23yktRQ68sCCMYy5hS
# DiTLMOl4SMcpHGc+W3qRzD7DI6ZB0OaHr6Xh7dYQsAyoXL7AhfOjoLELE5yPM8NE
# vcl7LfMdATHA9VExIEA0RJEl+sbsPVIroYIW/TCCFvkGCisGAQQBgjcDAwExghbp
# MIIW5QYJKoZIhvcNAQcCoIIW1jCCFtICAQMxDzANBglghkgBZQMEAgEFADCCAVEG
# CyqGSIb3DQEJEAEEoIIBQASCATwwggE4AgEBBgorBgEEAYRZCgMBMDEwDQYJYIZI
# AWUDBAIBBQAEIDKfdX04ppDLm2+OIRIb4eIDQK8QKZA1SacN9XEmjpL3AgZjmwbP
# piEYEzIwMjMwMTEwMTM0MDI1LjU1MVowBIACAfSggdCkgc0wgcoxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBB
# bWVyaWNhIE9wZXJhdGlvbnMxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjIyNjQt
# RTMzRS03ODBDMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNl
# oIIRVDCCBwwwggT0oAMCAQICEzMAAAHBPqCDnOAJr8UAAQAAAcEwDQYJKoZIhvcN
# AQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQG
# A1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjIxMTA0MTkw
# MTI3WhcNMjQwMjAyMTkwMTI3WjCByjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldh
# c2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBD
# b3Jwb3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0aW9u
# czEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046MjI2NC1FMzNFLTc4MEMxJTAjBgNV
# BAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQDksdczJ3DaFQLiklTQjm48mcx5GbwsoLjFogO7cXHH
# ciln9Z7apcuPg06ajD9Y8V5ji9pPj9LhP3GgOwUaDnAQkzo4tlV9rsFQ27S0O3iu
# SXtAFg0fPPqlyv1vBqraqbvHo/3KLlbRjyyOiP5BOC2aZejEKg1eEnWgboZuoANB
# cNmRNwOMgCK14TpPGuEGkhvt7q6mJ9MZk19wKE9+7MerrUVIjAnRcLFxpHUHACVI
# qFv81Q65AY+v1nN3o6chwD5Fy3HAqB84oH1pYQQeW3SOEoqCkQG9wmcww/5ZpPCY
# yGhvV76GgIQXH+cjRge6mLrTzaQV00WtoTvaaw5hCvCtTJYJ5KY3bTYtkOlPPFlW
# 3LpCsE6T5/4ESuxH4zl6+Qq5RNZUkcje+02Bvorn6CToS5DDShywN2ymI+n6qXEF
# pbnTJRuvrCd/NiMmHtCQ9x8EhlskCFZAdpXS5LdPs6Q5t0KywJExYftVZQB5Jt6a
# 5So5cJHut2kVN9j9Jco72UIhAEBBKH7DPCHlm/Vv6NPbNbBWXzYHLdgeZJPxvwIq
# dFdIKMu2CjLLsREvCRvM8iQJ8FdzJWd4LXDb/BSeo+ICMrTBB/O19cV+gxCvxhRw
# secC16Tw5U0+5EhXptwRFsXqu0VeaeOMPhnBXEhn8czhyN5UawTCQUD1dPOpf1bU
# /wIDAQABo4IBNjCCATIwHQYDVR0OBBYEFF+vYwnrHvIT6A/m5f3FYZPClEL6MB8G
# A1UdIwQYMBaAFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMF8GA1UdHwRYMFYwVKBSoFCG
# Tmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY3Jvc29mdCUy
# MFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEpLmNybDBsBggrBgEFBQcBAQRgMF4w
# XAYIKwYBBQUHMAKGUGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY2Vy
# dHMvTWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3J0MAwG
# A1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZIhvcNAQELBQAD
# ggIBAF+6JoGCx5we8z3RFmJMOV8duUvT2v1f7mr1yS4xHQGzVKvkHYwAuFPljRHe
# CAu59FfpFBBtJztbFFcgyvm0USAHnPL/tiDzUKfZ2FN/UbOMJvv+ffC0lIa2vZDA
# exrV6FhZ0x+L4RMugRfUbv1U8WuzS3oaLCmvvi2/4IsTezqbXRU7B7zTA/jK5Pd6
# IV+pFXymhQVJ0vbByWBAqhLBsKlsmU0L8RJoNBttAWWL247mPZ/8btLhMwb+DLLG
# 8xDlAm6L0XDazuqSWajNChfYCHhoq5sp739Vm96IRM1iXUBk+PSSPWDnVU3JaO8f
# D4fPXFl6RYil8xdASLTCsZ1Z6JbiLyX3atjdlt0ewSsVirOHoVEU55eBrM2x+Qub
# DL5MrXuYDsJMRTNoBYyrn5/0rhj/eaEHivpSuKy2Ral2Q9YSjxv21uR0pJjTQT4V
# LkNS2OAB0JpEE1oG7xwVgJsSuH2uhYPFz4iy/zIxABQO4TBdLLQTGcgCVxUiuHMv
# jQ6wbZxrlHkGAB68Y/UeP16PiX/L5KHQdVw303ouY8OYj8xpTasRntj6NF8JnV36
# XkMRJ0tcjENPKxheRP7dUz/XOHrLazRmxv/e89oaenbN6PB/ZiUZaXVekKE1lN6U
# Xl44IJ9LNRSfeod7sjLIMqFqGBucqmbBwSQxUGz5EdtWQ1aoMIIHcTCCBVmgAwIB
# AgITMwAAABXF52ueAptJmQAAAAAAFTANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0
# IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTAwHhcNMjEwOTMwMTgyMjI1
# WhcNMzAwOTMwMTgzMjI1WjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGlu
# Z3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBv
# cmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCC
# AiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAOThpkzntHIhC3miy9ckeb0O
# 1YLT/e6cBwfSqWxOdcjKNVf2AX9sSuDivbk+F2Az/1xPx2b3lVNxWuJ+Slr+uDZn
# hUYjDLWNE893MsAQGOhgfWpSg0S3po5GawcU88V29YZQ3MFEyHFcUTE3oAo4bo3t
# 1w/YJlN8OWECesSq/XJprx2rrPY2vjUmZNqYO7oaezOtgFt+jBAcnVL+tuhiJdxq
# D89d9P6OU8/W7IVWTe/dvI2k45GPsjksUZzpcGkNyjYtcI4xyDUoveO0hyTD4MmP
# frVUj9z6BVWYbWg7mka97aSueik3rMvrg0XnRm7KMtXAhjBcTyziYrLNueKNiOSW
# rAFKu75xqRdbZ2De+JKRHh09/SDPc31BmkZ1zcRfNN0Sidb9pSB9fvzZnkXftnIv
# 231fgLrbqn427DZM9ituqBJR6L8FA6PRc6ZNN3SUHDSCD/AQ8rdHGO2n6Jl8P0zb
# r17C89XYcz1DTsEzOUyOArxCaC4Q6oRRRuLRvWoYWmEBc8pnol7XKHYC4jMYcten
# IPDC+hIK12NvDMk2ZItboKaDIV1fMHSRlJTYuVD5C4lh8zYGNRiER9vcG9H9stQc
# xWv2XFJRXRLbJbqvUAV6bMURHXLvjflSxIUXk8A8FdsaN8cIFRg/eKtFtvUeh17a
# j54WcmnGrnu3tz5q4i6tAgMBAAGjggHdMIIB2TASBgkrBgEEAYI3FQEEBQIDAQAB
# MCMGCSsGAQQBgjcVAgQWBBQqp1L+ZMSavoKRPEY1Kc8Q/y8E7jAdBgNVHQ4EFgQU
# n6cVXQBeYl2D9OXSZacbUzUZ6XIwXAYDVR0gBFUwUzBRBgwrBgEEAYI3TIN9AQEw
# QTA/BggrBgEFBQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9E
# b2NzL1JlcG9zaXRvcnkuaHRtMBMGA1UdJQQMMAoGCCsGAQUFBwMIMBkGCSsGAQQB
# gjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/
# MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1UdHwRPME0wS6BJ
# oEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01p
# Y1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYB
# BQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljUm9v
# Q2VyQXV0XzIwMTAtMDYtMjMuY3J0MA0GCSqGSIb3DQEBCwUAA4ICAQCdVX38Kq3h
# LB9nATEkW+Geckv8qW/qXBS2Pk5HZHixBpOXPTEztTnXwnE2P9pkbHzQdTltuw8x
# 5MKP+2zRoZQYIu7pZmc6U03dmLq2HnjYNi6cqYJWAAOwBb6J6Gngugnue99qb74p
# y27YP0h1AdkY3m2CDPVtI1TkeFN1JFe53Z/zjj3G82jfZfakVqr3lbYoVSfQJL1A
# oL8ZthISEV09J+BAljis9/kpicO8F7BUhUKz/AyeixmJ5/ALaoHCgRlCGVJ1ijbC
# HcNhcy4sa3tuPywJeBTpkbKpW99Jo3QMvOyRgNI95ko+ZjtPu4b6MhrZlvSP9pEB
# 9s7GdP32THJvEKt1MMU0sHrYUP4KWN1APMdUbZ1jdEgssU5HLcEUBHG/ZPkkvnNt
# yo4JvbMBV0lUZNlz138eW0QBjloZkWsNn6Qo3GcZKCS6OEuabvshVGtqRRFHqfG3
# rsjoiV5PndLQTHa1V1QJsWkBRH58oWFsc/4Ku+xBZj1p/cvBQUl+fpO+y/g75LcV
# v7TOPqUxUYS8vwLBgqJ7Fx0ViY1w/ue10CgaiQuPNtq6TPmb/wrpNPgkNWcr4A24
# 5oyZ1uEi6vAnQj0llOZ0dFtq0Z4+7X6gMTN9vMvpe784cETRkPHIqzqKOghif9lw
# Y1NNje6CbaUFEMFxBmoQtB1VM1izoXBm8qGCAsswggI0AgEBMIH4oYHQpIHNMIHK
# MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQLExxN
# aWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25zMSYwJAYDVQQLEx1UaGFsZXMgVFNT
# IEVTTjoyMjY0LUUzM0UtNzgwQzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3Rh
# bXAgU2VydmljZaIjCgEBMAcGBSsOAwIaAxUARIo61IrtFVUr5KL5qoV3RhJj5U+g
# gYMwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYw
# JAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0B
# AQUFAAIFAOdny9MwIhgPMjAyMzAxMTAxOTM0NDNaGA8yMDIzMDExMTE5MzQ0M1ow
# dDA6BgorBgEEAYRZCgQBMSwwKjAKAgUA52fL0wIBADAHAgEAAgIOOTAHAgEAAgIR
# +zAKAgUA52kdUwIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAow
# CAIBAAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBAA18Bb1SDcbr
# +hB+ExBBlAY1H+/qKvbAqB9KfwijgNGOu+UZ7D2yS6YscCjJ1HsNDmoTfVHQVQ7M
# Huh6lLO2HjIQCj6AX6YqZW/04mJx//fDf7iDg+OR4xWGybSPRqADokudRiVWXLjG
# tL6zOf8lOgg1bCnSIvp0Q3HIFw2IEkbwMYIEDTCCBAkCAQEwgZMwfDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAHBPqCDnOAJr8UAAQAAAcEwDQYJYIZI
# AWUDBAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG
# 9w0BCQQxIgQgwH1FiyRcN4rM4gfBtnjFyXwKELhWqSVTSgiRlcujqLcwgfoGCyqG
# SIb3DQEJEAIvMYHqMIHnMIHkMIG9BCAKuSDq2Bgd5KAiw3eilHbPsQTFYDRiSKuS
# 9VhJMGB21DCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMz
# AAABwT6gg5zgCa/FAAEAAAHBMCIEIHL3UHSGrCUO+kN/F6EQow8F3uzt9RVoF0GI
# U+PxlPzaMA0GCSqGSIb3DQEBCwUABIICAI8WLNhlJ7kJxsxeYB6AeVY7BRPPqsdh
# Zqg+KlBQnieLy3c8oYNtdV6OHOn9PdhFPYsE+sU1Yd6ykCDlK76Sdx85vzB5M/Nt
# wTYaq9DxEUQYbt5lEELgEKNI54mpp/11oGcWg8tPK9I9WDejhWYRzuXLDydsbzhR
# 6zjUpXGJMx+JgNfPdCHwUoNGDbkSROLwMUMBBuGCtyBFTFt7VA3LqJF/Rdjl6r1Z
# g9TTh2ZOWq2ntBV+VBP2DUCkkxQsnvWY53mJyrCakklKnq/s2gKl4m7oJ7i1DAbe
# VNWARNNa9RWfpFf7/5tNvlZ6/Ohlc5ZBXVlmt5qSh9MNl1WdFHJy+ncMcBCmeWqO
# NCT0fQ/8xfRbpoNU2bqDD262W2VPHHWzyz1pxL51O31tAvhq3h62GSxW/3HQlLH7
# hsY1fHnPADkA2vGbBFgG7CfFbo6mng3fFBAWulWqY2zgNyLXWMb9M2jn+9I4O3Ol
# tswTZtVcs2OVNTPdXW0njTy7cFitGRXJ6tsY5Zi0Z++YY4I36/ObcrCMpqSS30YT
# IXcTIfE9nUkUIRZnIpsMshUeLmFe/RDnzLBZ9OlmkZmx82Q3A8QzNZeQ8fwD9z8u
# KbkoJjBmn2fQNexOZfYMRn9qYFDg5UQGldgKiLfTP8O4cksU6WPxs25Zgw1VnPdx
# XNkyrEA8V1gg
# SIG # End signature block
