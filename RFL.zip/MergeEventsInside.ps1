<# last edit by: waltere 2019-04-05
  File Name: MergeEventsInside.ps1
  Objective: This script merges all the .evtx files from a specific folder into one single Merge.evtx file
  supplied by Serge Gourraud <sergeg@microsoft.com>
#>

# Load Common Library
#. ./utils_common_functions.ps1

<#
.SYNOPSIS
MergeEvents - Script to merge all the evtx files from a specific folder into one single evtx file

When you collect several event logs from a server and you don't know yet what to look for, and can be tedious to load all of them in your event logs and explore each of them by going from one to the other.
To get quicker and avoiding loading several event logs (and being obliged to unload them one by one) you can merge them all in one single evtx file.

How to use it:
Store all the evtx files you want to merge in a unique folder and run the script by giving the -FolderPath argument.
It will merge all the events inside into a Merge.evtx file

You can also run the installer that will create some registry entries to give the possibility to right-click the folder then run the script that will merge the content


SYNTAX: .\MergeEventsInside.ps1 -FolderPath [full-path-to-expanded-SDP-report] [ -HostMode ]

.DESCRIPTION
The script is used when a SDP report is used to collect data from multiple servers, like from a failover cluster.
When running, it will move the files into separate folders by computer name. It will also place RFL output into its own folder.

Store all the evtx files you want to merge in a unique folder and run the script by giving the -FolderPath argument.
It will merge all the events inside into a Merge.evtx file

Note: If you experience PS error '...is not digitally signed.' run the command:
 Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy Bypass

	
.PARAMETER HostMode
  This tells the logging functions to show logging on the screen

.PARAMETER ScriptMode
  This tells the logging functions to show logging in log file _MergeEventsInside.log
	
.EXAMPLE
	 \\localhost\ToolsShare\rfl\MergeEventsInside.ps1 -FolderPath \\MyPC\temp\SDPs\ClusterReports -HostMode
	 This command will arrange the files in \\MyPC\temp\SDPs\ClusterReports by computer name and RFL folder
	 It will also show detailed output in the console when switch -HostMode is supplied.

.LINK
	 \ \localhost\ToolsShare\rfl\MergeEventsInside.ps1
	sergeg@microsoft.com ; waltere@microsoft.com
#>

[CmdletBinding()]
PARAM (
	# Path to SDP result folder containing !PStatSum_*.txt and other SDP analysis files
	[Parameter(Mandatory = $true,Position=0,HelpMessage='Choose the consolidated evtx folder location, i.e. C:\SR\SDP-report\EvtxFolder\ ')]
	[string] $FolderPath,

	[switch]$HostMode  = $true, # This tells the logging functions to show logging on the screen
	[switch]$ScriptMode = $false # This tells the logging functions to show logging in log file _MergeEventsInside.log
)


BEGIN {
  # This saves the starting ErrorActionPreference and then sets it to 'Stop'.
		$startErrorActionPreference = $errorActionPreference
		$errorActionPreference = 'Stop'
  # This gets the current path and name of the script.
		$invocation = (Get-Variable MyInvocation).Value
		#$scriptPath = Split-Path $invocation.MyCommand.Path
		$scriptName = $invocation.MyCommand.Name
  #Write-Host "Running `"$scriptPath\$scriptName`"..." -BackgroundColor Black -ForegroundColor Green
	
	Set-Variable -Name ErrorMsg -Scope Script -Force
	[string]$Script:ErrorMsg=""
	### Trail FolderPath with \ and allow path with space character
		if ($FolderPath.EndsWith("\")){$FolderPath="$FolderPath"}
		else {$FolderPath="$FolderPath" +"\"}
		If (-NOT (Test-Path $FolderPath -PathType 'Container')){Throw "$($FolderPath) is not a valid folder"}

	#region: ###### customization section of script, logging configuration ########################
		$VerMa="3"
		$VerMi="00"
		#$ErrorActionPreference = "Continue" #"Stop"
		#$RFLpath = "\\localhost\ToolsShare\rfl\"
		$LogLevel = 0
		$Stats=0
		$StatsServerPath="\\waltere-vdi.europe.corp.microsoft.com\netpod\tools\RFL\"
		$CheckDate = (Get-Date -UFormat "%Y-%m-%d_%R-%S").Replace(":","-")
		$CountInvFil = $StatsServerPath +'countMergeEvt.dat'
		$CountInvFil2 = $CountInvFil +'.us'
		$LogPath = $FolderPath + "_" + $scriptName + ".log"
		$ErrorThrown = $null
	#endregion: ###### customization section
	
	If ($Stats) { #increment at start of script
	 ($j=[int32](Get-Content $CountInvFil -ErrorAction SilentlyContinue)) |out-null
	 (++$j) | Set-Content $CountInvFil -ErrorAction SilentlyContinue
	 }
	If ($PSBoundParameters['Debug']) { $DebugPreference='Continue'}
	

	#region: Logging Functions 
	function WriteLine ([string]$line,[string]$ForegroundColor, [switch]$NoNewLine){
		# SYNOPSIS: writes the actual output - used by other Logging Functions
    if($Script:ScriptMode){
      if($NoNewLine) {
        $Script:Trace += "$line"
      }
      else {
        $Script:Trace += "$line`r`n"
      }
      Set-Content -Path $script:LogPath -Value $Script:Trace
    }
    if($Script:HostMode){
      $Params = @{
        NoNewLine    = $NoNewLine -eq $true
        ForegroundColor = if($ForegroundColor) {$ForegroundColor} else {"White"}
      }
      Write-Host $line @Params
    }
  }
  
  function WriteInfo([string]$message,[switch]$WaitForResult,[string[]]$AdditionalStringArray,[string]$AdditionalMultilineString){
		# SYNOPSIS: handles informational logs
    if($WaitForResult){
      WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)$message" -NoNewline
    }
    else{
      WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)$message" 
    }
    if($AdditionalStringArray){
      foreach ($String in $AdditionalStringArray){
        WriteLine "          $("`t" * $script:LogLevel)`t$String"   
      }    
    }
    if($AdditionalMultilineString){
      foreach ($String in ($AdditionalMultilineString -split "`r`n" | Where-Object {$_ -ne ""})){
        WriteLine "          $("`t" * $script:LogLevel)`t$String"   
      }
    }
  }

  function WriteResult([string]$message,[switch]$Pass,[switch]$Success){
		# SYNOPSIS: writes results - should be used after -WaitForResult in WriteInfo
    if($Pass){
      WriteLine " - Pass" -ForegroundColor Cyan
      if($message){
        WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)`t$message" -ForegroundColor Cyan
      }
    }
    if($Success){
      WriteLine " - Success" -ForegroundColor Green
      if($message){
        WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)`t$message" -ForegroundColor Green
      }
    } 
  }

  function WriteInfoHighlighted([string]$message,[string[]]$AdditionalStringArray,[string]$AdditionalMultilineString){
		# SYNOPSIS: write highlighted info 
    WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)$message" -ForegroundColor Cyan
    if($AdditionalStringArray){
      foreach ($String in $AdditionalStringArray){
        WriteLine "[$(Get-Date -Format hh:mm:ss)]     $("`t" * $script:LogLevel)`t$String" -ForegroundColor Cyan
      }
    }
    if($AdditionalMultilineString){
      foreach ($String in ($AdditionalMultilineString -split "`r`n" | Where-Object {$_ -ne ""})){
        WriteLine "[$(Get-Date -Format hh:mm:ss)]     $("`t" * $script:LogLevel)`t$String" -ForegroundColor Cyan
      }
    }
  }

  function WriteWarning([string]$message,[string[]]$AdditionalStringArray,[string]$AdditionalMultilineString){ 
		# SYNOPSIS: write warning logs 
    WriteLine "[$(Get-Date -Format hh:mm:ss)] WARNING: $("`t" * $script:LogLevel)$message" -ForegroundColor Yellow
    if($AdditionalStringArray){
      foreach ($String in $AdditionalStringArray){
        WriteLine "[$(Get-Date -Format hh:mm:ss)]     $("`t" * $script:LogLevel)`t$String" -ForegroundColor Yellow
      }
    }
    if($AdditionalMultilineString){
      foreach ($String in ($AdditionalMultilineString -split "`r`n" | Where-Object {$_ -ne ""})){
        WriteLine "[$(Get-Date -Format hh:mm:ss)]     $("`t" * $script:LogLevel)`t$String" -ForegroundColor Yellow
      }
    }
  }

  function WriteError([string]$message){
		# SYNOPSIS: logs errors
			WriteLine ""
			WriteLine "[$(Get-Date -Format hh:mm:ss)] ERROR:  $("`t`t" * $script:LogLevel)$message" -ForegroundColor Red
  }

  function WriteErrorAndExit($message){
		# SYNOPSIS: logs errors and terminates script 
			WriteLine "[$(Get-Date -Format hh:mm:ss)] ERROR:  $("`t" * $script:LogLevel)$message" -ForegroundColor Red
			Write-Host "Press any key to continue ..."
			$host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") | OUT-NULL
			$HOST.UI.RawUI.Flushinputbuffer()
			Throw "Terminating Error"
	}

	#endregion: Logging Functions

	#region: Script Functions
	function MoveItemLogErrorAndContinue ($File,$TargetFolder){
		#SYNOPSIS: This moves an item, adds any error to the log and resumes
		$MoveError = $null
		Move-Item -Path $File.FullName -Destination $TargetFolder -Force -ErrorAction SilentlyContinue -ErrorVariable MoveError | Out-Null
		if($MoveError){
			WriteError -message "An error ocurred while moving $($File.BaseName). Review the error below, correct it, and run the script again - $($MoveError.Exception.Message)"
		}
	}
	#endregion: Script Functions

} #end BEGIN

PROCESS {
	try {
		$ScriptBeginTimeStamp = Get-Date
		#region: MAIN :::::

		# Validate SDP folder for not having more than one consecutive space characters
		# if ($FolderPath -match "  ") {Throw "$($FolderPath) contains more consecutive space characters, please rename folder"} else {write-host "SDP folder is OK"}

		WriteInfo -message "...Starting '$scriptName' on $(Get-Date)"

		<#
		# Check if an argument is provided
		# If no argument: Look for evtx files in the current folder, supposing it's been started manually 
		if (!$FolderPath)
		{
			$FolderPath = Split-Path ((Get-Variable MyInvocation).Value).MyCommand.Path
		}
		#>

		write-host "Consolidating evtx log in folder: $FolderPath" -ForegroundColor Cyan

		# Check the argument is a folder
		if ((Test-Path -LiteralPath $FolderPath -PathType Container) -eq $false) {
			$wshell = New-Object -ComObject Wscript.Shell
			$wshell.Popup("This folder doesn't exist!",0,$FolderPath,0x1)
		}
		else
		{
			$ListOfEvtxFiles = (Get-ChildItem -LiteralPath $FolderPath -File -Filter *.evtx | ? { $_.Name -ne "Merge.evtx" }).FullName
			
			# Check if the folder contains .evtx files
			if ($ListOfEvtxFiles.count -eq 0)
			{
				$wshell = New-Object -ComObject Wscript.Shell
				$wshell.Popup("Invalid path: Doesn't contain any evtx files!",0,$FolderPath,0x1)
			}
			else
			{
				# Informing the user
				Write-Host "Merging the $($ListOfEvtxFiles.count) event files found in the `"$FolderPath`" folder ..."

				# Generate the XML File for the merge operation
				$Filter = "*"
				$StructuredQueryFilePath = $FolderPath+"\StructuredQuery.xml"
				$StructuredQueryXMLFile = New-Item -Path $StructuredQueryFilePath -ItemType File -Force
				
				$String = "<QueryList>`n"
				$String += "  <Query Id=`"0`" Path=`"file://"+$ListOfEvtxFiles[0]+"`">`n"
				$ListOfEvtxFiles | % {
					$String += "    <Select Path=`"file://$_`">"+$Filter+"</Select>`n"
				}
				$String += "  </Query>`n"
				$String += "</QueryList>`n"

				$string | Out-File -LiteralPath $StructuredQueryXMLFile
		  
				# Generate the merge operation
				wevtutil /sq epl $StructuredQueryXMLFile "$FolderPath\Merge.evtx" /ow:true

				Write-Host -ForegroundColor Green "All the events are merged into the $FolderPath\Merge.evtx file"

				#$wshell = New-Object -ComObject Wscript.Shell
				#$wshell.Popup("Done in $FolderPath\Merge.evtx",0,"Merge operation",0x1)
			}
		}
		#endregion: MAIN
	} # end try PROCESS
	catch {
		WriteError -message "An Error occured"
		WriteError -message $error[0].Exception.Message
		$ErrorThrown = $true
			
		$errorMessage = "$scriptName caught an exception on $($ENV:COMPUTERNAME):"
		$errorMessage += "`n`n"
		$errorMessage += "Exception Type: $($_.Exception.GetType().FullName)"
		$errorMessage += "`n`n"
		$errorMessage += "Exception Message: $($_.Exception.Message)"

		Write-Error $errorMessage -ErrorAction Continue
		<# Log error
				Write-Verbose "Logging the script's error..."
		# Log error - EventLog
				#An event log source needs to be preconfigured to use this.
				Write-EventLog `
					-EventId $AlertNumber `
					-LogName $LogName `
					-Source $EventSource `
					-Message $errorMessage `
					-EntryType Error
		# Log error - Email
				# This will attempt to send an immediate alert about the error.
				# The EventLog also needs to log the error because this one may not be sent.
				#use Send-MailMessage
		#>
		Start-Sleep -Seconds 3
		Write-Debug $errorMessage
		if ( $UseExitCode ) {
			$error.clear()	# clear script errors
			exit 1
		} #end UseExitCode
  } #end Catch PROCESS
	Finally {  
	} #end Finally PROCESS
} #end PROCESS

END {
	$ScriptEndTimeStamp = Get-Date
	$Duration = $(New-TimeSpan -Start $ScriptBeginTimeStamp -End $ScriptEndTimeStamp)
	$LogLevel = 0
	WriteInfo -message "Script $scriptName v$VerMa.$VerMi execution finished. Duration: $Duration `n"
	if($ErrorThrown) {Throw $error[0].Exception.Message}
	# Stats
	If ($Stats) { #increment at start of script
	 "$j" + " ;$CheckDate" + "; " + ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name) + "; $($Duration)" + "; $NodeCnt" + "; $FolderPath" + "; $ErrorMsg" + "; v$VerMa.$VerMi" | Out-File $CountInvFil2 -Append -Encoding UTF8 -ErrorAction SilentlyContinue
	 }
  # This resets the ErrorActionPreference to the value at script start.
  $errorActionPreference = $startErrorActionPreference
} #end END

#region :comments & ToDo's
#
# MergeEventsInside.ps1
#
# - v2 : Fixed Installer bug (setting wrong registry keys in v1)
#      : Add the possibility to run the script manually or just double click on it
#
# - v3 : Fixed a bug in FolderPath management to handle path with special characters such ad '[' & ']'
#        Using -LiteralPath instead of -Path and Out-File instead of Add-Content 
#
#endregion :comments & ToDo's