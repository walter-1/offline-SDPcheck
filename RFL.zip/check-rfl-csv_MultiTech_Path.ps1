<# last edit by: waltere 2018-04-05
 File Name: check-rfl-csv_MultiTech_Path.ps1 [Net|Dom|Cluster|Core|VSS|HyperV|RDS|Print|Custom|HyCoClNe|Client|Exchange|SCVMM2012SP1|SCVMM2012R2|CM2007|CM2012RTM|CM2012SP1|CM2012SP2|CM2012R2|All_OS|SQL] [full-path-to-expanded-SDP-report] [optional: -OSVersion 2008|2008R2|2012|2012R2|2016 -Validate val]
 Help: get-help \\localhost\ToolsShare\rfl\check-rfl-csv_MultiTech_Path.ps1 -detailed
       call script with -Verbose or -Debug for add. console output

HISTORY and AUTHORs:
        Ioan Corcodel  	- ioanc@microsoft.com
	Walter Eder	- waltere@microsoft.com

HISTORY
				display hotfix detailed information that need to be installed, compared to reference list
				add logic mandatory parameters with validation
				add logic to check if installed hotfix is LDR and do not display last LDR if RFL hotfix is LDRGDR
				save report as \\<SDP_path>\!%computername%_Engineer_RFL_list_<tech>_<RFLOSVersion>.txt and open it with Notepad
		2014-07-20	changed input files names, no more SPx, Derive OSversion from SDP-report
			   		add logic to check for kb only entry in the rfl list, against the SDP
		2014-07-26 	add short customer ready kb list !%computername%_Customer_KB-list_RFL_, sorted by Prio
			   		check for '*msinfo32.txt' in extracted SDP folder
		2014-07-28 	pick up KB_info_<Tech>_<OS>.txt and append EngineerInfo (if available) to Engineer RFL output
		2014-08-07 	add HelpMessage for parameter input
		2014-09-08 	script is capable to parse automaticaly every computer in the sdp folder - Cluster SDP specific output
					add hotfixes to switch to LDR branch  to !<computername>_Customer_KB-list_RFL_<tech>_<OSVersion>
					"NO LDROnly hotfixes" will not be written to !<computername>_Customer_KB-list_RFL_<tech>_<OSVersion>
		2014-11-05 	optional parameter#3 is OSVersion, valid list: [2008|2008R2|2012|2012R2|2016] (needed for SDP of Russian System)
		2014-11-04	Add new file, with allready installed hotfixes
		2014-11-06	PUAS report with missing KBs, installed KBs, and full info for missing KBs
		2014-11-10	PUAS *.csv report with missing KBs and installed KBs
					Prio,KB,Component,Binary,RflVer,SdpVer,url,isInstalled,branch,release,LDROnlyKB,LDROnlyTitle,LDROnlyLink,isInRollup
		2014-11-15	Add functionality to test simultaneously against more then one Tech.
					<computername>_PUAS_DSE_CombinedList_<tech1-tech2-techx>_<OS>.csv contains the combined info, sorted by unique Binary
					Syntax : .\check-rfl-csv_Tech_Path.ps1 Core,[Net,Dom] [full-path-to-expanded-SDP-report]
		2014-11-24	v1.07 added ###Build list of unique missing KB across all Techs
		2014-12-01	write FileDate of RFL check file per ref__*_latest.csv into report
		2014-12-03	optional script arguments: -OSVersion 2008 - Validate val, Val = Detailed output for PUAS script validation
		2014-12-04	v1.11 adjusted PUAS script with Tech_Path script, so that Tech_Path accepts multiple Techs, comma separated
		2014-12-08	use of �space� character allowed in  �expanded SDP path� (using Explorer Plugin was working fine)
					Count number of Hotfixes missing/installed per Tech and in combined summary
		2014-12-14	Corrected Cluster report, was only working on first NodeName. Create separate report for each NodeName
		2015-01-12	allow for nonOS-Fixes : SCVMM2012SP1|SCVMM2012R2|CM2007|CM2012RTM|CM2012SP1|CM2012SP2|CM2012R2|All_OS|SQL|Exchange
		2015-01-21	Corrected: RTM SDPs script throws warning/error:
				 "The variable cannot be validated because the value old-2008R2-RTM is not a valid value for the OSVersion variable."
				 Expected:
				 "WARNING: COMPUTERNAME with old-2008R2-RTM is outdated! apply latest Service Pack for: Vista/2008, Win7/2008R2
		2015-01-23	solved bug for srv.sys in line "$SdpVer = Select-String -Pattern $Binary -Path $SDPpathSym -ErrorAction SilentlyContinue", which takes Version# for wrong *srv.sys binary
		2015-02-03	- inform Engineer about last RFL update $csvpathReleaseDate (+ yellow block markers about missing Hotfixes)
		2015-02-05	changed $ShortSDPPath in PUAS report Appendix
		2015-02-06	included All_OS; Performance enhancement (avoid multiple >> file outputs)
		2015-02-09	v1.14 corrected regression, added ErrorMsg
				append script
		2015-02-10	v1.15 added blank lines after 'Number of Unique ...'
		2015-02-27	v1.16 changed '*msinfo32. to '*msinfo*., error handling for SDPs without msinfo etc.
		2015-03-06	temp. added: [Addon 3]...now performing internal check for AZURE response time in your region
				- added Release Date to [Table] list in section 1.3
		2015-04-11 	need to make sure, user pointed to correct extracted SDP folder - throw correct (informative/more descriptive ) error message! i.e. "are you sure this is the right SDP folder?" OnError --> "unexptected error: Please feedback WalterE when something goes wrong..."
				- throw WARNING for insufficient SDPs like VSS, SCCM or SQL SDP reports (not suited for PUAS)
		2015-09-11	v1.17 basic Win10 support
		2015-09-20	  - for Win2012R2: in Check-rfl-csv scripts: if cumulative updates April+Nov are installed, omit 05-10-2014 updates (changed KBOnlyRollup_2012R2.csv)
 		2015-10-04	v1.18 changes to suppress [Missing latest] GDR KBs in section 1.1.1.2 that are already installed (T-SYS issue)
				  - DCR done: v-majorg: how could we implement a better approach, if QFE/LDR is already installed in SDP, we can omitt same component in section 1.1.1.1 in the output
		2015-10-05	v1.19 (version jump to adjust and match Version-nr in related Multi-Tech script)
				  - $FeedHigherSDPver=1 - add feedback/telemetry data with binary + version, if RflVer < SDPver, into Out-file
				   This telemetry data info will help to keep the RFL list up-to-date!
		2015-10-09	run report for each $NodeName in Cluster
		2015-11-19	v1.20 adding support for Win10/2016TH2
		2016-01-18	v1.22 DCR EriqS inform user if SDP report is not suited, i.e. VSS, SCCM or SQL SDP reports (or if *sym or *hotfix files are missing)
		2016-02-04	v1.23 corrected bug for section	[Missing LDR-only]: Do not list LDRonly if same LDRGDR binary listed in section [Missing latest] is already installed as LDR
 		2016-02-10	v1.24 using FQDN emeacssdfs.europe.corp.microsoft.com
		2016-02-14	- Done:  for 2016TH2: binaries apear as installed if minor version starts with bigger first number, i.e. Rfl 6.2.10586.103 : Sdp 6.2.10586.3 (-> using CompareTo)
			    	- 2016*: check for installed rollup fixes
		2016-02-15	v1.25 removing "KBOnlyVersion" "KB Only" info in output files for KB# entries, when processing KB articles
		2016-02-16	      recording $StatsErr
		2016-02-28	v1.26 DCR EriqS done: addition to compare MissingArrays of Cluster Nodes
				    - DCR from Eriq Stern for Cluster SDP: One last thing that would be awesome if it could somehow be integrated is the Performance Monitor Analyzer (http://toolbox/PMAVBS) tool that is on Toolbox.  This spits out a very handy report from BLG files which shows the �areas to investigate� at the top, and each cluster SDP contains a <nodename>_Performance_Counter.blg file which it would be very handy to be able to see the output of (in yet another text file).  I can always do this manually, but I�m all about automation � if there is a way�
		2016-03-06	v1.27 adding 'Performance Monitor Analyzer' check (tool that is on Toolbox http://toolbox/PMAVBS)
		2016-03-14	v1.28 appending Cluster Nodes differences to Engineer output files.
		2016-04-16	v1.29 changed $Binary = ($line.Binary).ToUpper()	#2016-04-15 for Turkish character 'i /I'
				      replace check for stdout.log with results.xml;
				      add feedback/telemetry data only if OS had been determined by script (not entered by user)
		2016-04-17	v1.30 replaced '("$OSversion" �notmatch "2012R2")' with (("$OSversion" �notmatch "2012R2") -and ("$OSversion" �notmatch "2016"))
				     - see check-rfl-csv_Tech_Path.ps1 2016-02-04	v1.23 corrected bug for section	[Missing LDR-only]: Do not list LDRonly if same LDRGDR binary listed in section [Missing latest] is already installed as LDR
				      + 2016* fix for no LDRonly output
		2016-04-18	for tr-TR Turkish character 'i /I': implemented function to choose culture -> $SdpVer = Using-Culture en-US
		2016-06-20	changed $CheckDate to include Sec
		2016-07-13	v1.31 no telemetry for Win7 Conv pack: if ($SdpVer -NotMatch ".7601.23403")
		2016-07-27	v1.32 using your favorite editor (FavEditor instead of notepad) to open result file
		2016-08-03  adding 2016RS1
		2016-08-07      v1.33 adding DCR Evt-check (display last total 100 events of all providers)
		2016-09-23      ;$SdpVer = $SdpVer.Replace(".10585.",".10586.") 
		2016-10-15      v1.34 Config: $OmitFullList=1 - Omit duplicate long list output: "1.3.2   Net :: [Full List] Missing Fixes"
		2016-10-19      v1.35 #2012 is cumulativ starting Oct 2016
		2016-04-01	adding 2016RS2
		2017-10-06  	v1.36 #adding 2016RS3
		2018-04-05  	v1.36 #adding 2016RS4
		
		Known issues:

		*ToDo:
		2016-10-01	- return Platform (x86/x64) in telemetry data
		2016-04-18	- check for outdated Explorer-Plugin 'Rfl-Check_ShellExtension.reg' - "Plugin_Version"="1.0"
		2016-03-10 	prepend cluster-nodes comparison results to output, + Regcheck (today they are appended)
				- ## need to check for NULL List (output: .. no fix installed)
				- consider removing PUAS 'Validate', as we have same information (without Sort Prio) in Engineer list
				- perhaps Check if consolidated Hotfixes are available on MS Catalog
				- may omitt APPENDIX if only ONE tech is specified in Engineer script
				- check if destination path is writeable, else prompt for writable folder
				- work with SDP*.cab file, so Engineer does not need to extract files himself

#>

<#
.SYNOPSIS
The script creates a RFL report, it reads SDP report and displays list of missing detailed hotfix information that needs to be installed, compared to CSS RFL list.
SDP report must contain msinfo32*txt or *.nfo, *hotfix*.txt, multiple *sym*.csv files

SYNTAX: .\check-rfl-csv_Tech_Path.ps1 [Net|Dom|Cluster|Core|VSS|HyperV|RDS|Print|Custom|HyCoClNe|Client|Exchange|SCVMM2012SP1|SCVMM2012R2|CM2007|CM2012RTM|CM2012SP1|CM2012SP2|CM2012R2|All_OS|SQL] [full-path-to-expanded-SDP-report] [optional: -OSVersion 2008|2008R2|2012|2012R2|2016|2016RS1|2016RS2|2016RS3|2016RS4|2016RS5|201619H1 -Validate val]
  Client	= PUAS, domain member for Client Win OS
  Cluster 	= Microsoft Failover Cluster
  Core  	= Core Operating System
  Custom 	= currently used for testing with a low number of modules
  Dom 		= Domains/ActiveDirectory
  HyperV  	= Microsoft Windows Hyper-V Hypervisor
  HyCoClNe 	= combination of HyperV, Core, Cluster, Net
  Master	= combination of all platform RFLs
  Net 		= Networking
  Print 	= Printing
  RDS 		= Remote Desktop Services (Terminal Services)
  SCVMM2012SP1 	= System Center Virtual Machine Manager 2012 SP1
  SCVMM2012R2 	= System Center Virtual Machine Manager 2012 R2
  Exchange 	= Microsoft Exchange Server
  VSS 		= Volume Shadow Copy Service
  CM2007  	= System Center Configuration Manager 2007
  CM2012RTM  	= System Center Configuration Manager 2012RTM
  CM2012SP1  	= System Center Configuration Manager 2012SP1
  CM2012SP2  	= System Center Configuration Manager 2012SP2
  CM2012R2  	= System Center Configuration Manager 2012R2
  SQL	 	= Microsoft SQL Server

If you experience PS error '...is not digitally signed.' run the command:
 #Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned
 Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force

.DESCRIPTION
The script will check the binaries available in the most recent RFL list(s) against the installed binaries seen in expanded SDP report.
It will generate a *.CSV file and an output file in the SDP folder named !%computername%_Engineer_RFL_list_<tech>_<OSVersion>.txt containing the following information:

Prio         :
Component    :
Branch       :
Binary       :
RflVer       :
SdpVer       :
Release Date :
KB           :
Title        :
Url          :
LDROnlyKB    : [LDR only KB if needed]
LDROnlyTitle : [LDR only KB title if needed]
LDROnlyLink  : [LDR only KB url if needed]

.EXAMPLE
\\localhost\ToolsShare\rfl\check-rfl-csv_MultiTech_Path_PUAS.ps1 Net \\ioanc00\temp\New_RFL\SDPs\FileServer
\\localhost\ToolsShare\rfl\check-rfl-csv_MultiTech_Path_PUAS.ps1 Core,Dom,Net \\ioanc00\temp\New_RFL\SDPs\FileServer

...
Prio         : 0
Component    : SMBServer
Branch       : LDRGDR
Binary       : srv.sys
RflVer       : 6.1.7601.22608
SdpVer       : 6.1.7600.16385
Release Date : 2/23/2014
KB           : 2831013
Title        : User receives SMB change notifications from a subfolder that the user does not have permission to access in Windows 7 SP1 or Windows Server 2008 R2 SP1
Url          : http://support.microsoft.com/kb/2831013
LDROnlyKB    : 2625434 (v1.0)
LDROnlyTitle : "ERROR_SHARING_VIOLATION" error message in Windows XP or in Windows Server 2003 when you try to open a file on an SMB share on a server that is running Windows 7 or Windows
               Server 2008 R2
LDROnlyLink  : http://support.microsoft.com/kb/2625434


.LINK
\\localhost\ToolsShare\rfl\
ioanc@microsoft.com ; waltere@microsoft.com ;

#>
Param(
	[ValidateSet("net","dom","cluster","core","vss","hyperv","rds","print","HyCoClNe","Exchange","Client","SCVMM2012SP1","SCVMM2012R2","CM2007","CM2012RTM","CM2012SP1","CM2012SP2","CM2012R2","All_OS","SQL","custom")]
	[Parameter(Mandatory=$True,Position=0,HelpMessage='Choose one technology from: Net|Dom|Cluster|Core|VSS|HyperV|RDS|Print|Custom|HyCoClNe|Client|Exchange|SCVMM2012SP1|SCVMM2012R2|CM2007|CM2012RTM|CM2012SP1|CM2012SP2|CM2012R2|All_OS|SQL')]
	[string[]]$RFLFixesTechs
,
	[ValidateScript({Test-Path $_ -PathType 'Container'})]
	[Parameter(Mandatory=$True,Position=1,HelpMessage='Choose a writable SDP folder location, i.e. C:\SR\SDP-report\ ')]
	[string]$SDPPath
,
	[ValidateSet("2008","2008R2","2012","2012R2","2016","2016RS1","2016RS2","2016RS3","2016RS4","2016RS5","201619H1","help")]
	[Parameter(Mandatory=$False,Position=2,HelpMessage='optional: Choose one OS from list: [2008|2008R2|2012|2012R2|2016|2016RS1|2016RS2|2016RS3|2016RS4|2016RS5|201619H1]')]
	[string]$OSVersion
,
	[ValidateSet("Val","Validate","no")]
	[Parameter(Mandatory=$False,Position=3,HelpMessage='optional: Choose from list: [Validate|val|no]')]
	[string]$Validate = "no"
)

Process
{
############################################################
## customization section of script
$RFLroot = "\\localhost\ToolsShare\rfl\"
$RFLpath = $RFLroot + "RflLists\"
$csvDelimiter=","
$Report_Type="Engineer_RFL" # "Engineer_RFL" or "PUAS_DSE"
############################################################

$DbgOut=0		# used for verbose debug output
$Stats=0		# used for stats on RFL data
#$StatsServerPath="\\netpod.europe.corp.microsoft.com\upload\RFL\"
$StatsServerPath="\\waltere-vdi.europe.corp.microsoft.com\netpod\tools\RFL\"
if ($Stats) {$StatsErr=1}		# used for PS last error stats
$RunAddon=1		# used for running additonal checks
$RunAddon5=0		# used for running version check
$FeedHigherSDPver=1	# used for accurancy of RFL database
$HigherSDPverBinExceptList = "qmgr.dll","repdrvfs.dll","tzres.dll"
$OutFileChars=300
$UsrOSVersion = [Environment]::OSVersion.Version.ToString(3)
$VerMa="1"
$VerMi="36"
$start = Get-Date
$CheckDate = (Get-Date -UFormat "%Y-%m-%d_%R-%S").Replace(":","-")
$Report_Mode="Detailed"
$PUASCopyBlock=0
$FileExt=""
Set-Variable -Name ErrorMsg -Scope Script -Force

If ($PSBoundParameters[�Debug�]) { $DebugPreference='Continue'}


switch($Report_Type)
	{
	"Engineer_RFL" 	{
			$ScriptName= "check-rfl-csv_MultiTech_Path.ps1"
			$i=$i_start=1
			$Build_summary=0
			$CountInvFil = $StatsServerPath +'countRFL.dat'
			$CsvFilename = "latest"
			$AppendEngInfo=1
			$OmitFullList=1
			$Separator  = "====================================================================================="
			$newline_Separator  = "
====================================================================================="
			}

	"PUAS_DSE"	{
			$ScriptName= "check-rfl-csv_MultiTech_Path_PUAS.ps1"
			$i=$i_start=3
			$PuasPath="\\localhost\ToolsShare\rfl\Puas\"
			If ($Validate -NotMatch "Val") 	{$Report_Mode="Normal"
							 $PUASCopyBlock=1
							 }
			Else			 	{$Report_Mode="DetailedPUAS"
			 				 $FileExt=".Log"}
			$CountInvFil = $StatsServerPath +'countPuas.dat'
			$CsvFilename = "Puas_min_1" # Choose: "latest" "Puas_min_1" "Puas_min_2"
			$OmitFullList=0
			$Separator  = "==========================================================="
			$newline_Separator  = "
==========================================================="
			}
	}
$Separator2 = "___________________"
$Separator_space = " "
$CountInvFil2 = $CountInvFil +'.us'
If ($StatsErr) {$CountInvFil4 = $CountInvFil +'.PSErrAddon.txt' }
If ($Stats) { #increment at start of script
  ($j=[int32](Get-Content $CountInvFil -ErrorAction SilentlyContinue)) |out-null
  (++$j) | Set-Content $CountInvFil -ErrorAction SilentlyContinue
  }

########################################################### 2016-04-15
function Get-FileEncoding	#not-used-so-far
{
 [CmdletBinding()] Param (
 [Parameter(Mandatory = $True, ValueFromPipelineByPropertyName = $True)] [string]$Path
 )

[byte[]]$byte = get-content -Encoding byte -ReadCount 4 -TotalCount 4 -Path $Path

if ( $byte[0] -eq 0xef -and $byte[1] -eq 0xbb -and $byte[2] -eq 0xbf )
 { Write-Output 'UTF8' }
 elseif ($byte[0] -eq 0xfe -and $byte[1] -eq 0xff)
 { Write-Output 'Unicode' }
 elseif ($byte[0] -eq 0 -and $byte[1] -eq 0 -and $byte[2] -eq 0xfe -and $byte[3] -eq 0xff)
 { Write-Output 'UTF32' }
 elseif ($byte[0] -eq 0x2b -and $byte[1] -eq 0x2f -and $byte[2] -eq 0x76)
 { Write-Output 'UTF7'}
 else
 { Write-Output 'ASCII' }
}

########################################################### 2016-04-18
## avoid tr-TR issue with Turkish character 'i /I' in Select-String -Pattern calls
Function Using-Culture (
[System.Globalization.CultureInfo]$culture = (throw �USAGE: Using-Culture -Culture culture -Script {scriptblock}�),
[ScriptBlock]$script= (throw �USAGE: Using-Culture -Culture culture -Script {scriptblock}�))
{
    $OldCulture = [System.Threading.Thread]::CurrentThread.CurrentCulture
    trap
    {
        [System.Threading.Thread]::CurrentThread.CurrentCulture = $OldCulture
    }
    [System.Threading.Thread]::CurrentThread.CurrentCulture = $culture
    Invoke-Command $script
    [System.Threading.Thread]::CurrentThread.CurrentCulture = $OldCulture
}

### Trail SDPPath with \ and allow path with space character
if ($SDPPath.EndsWith("\")){$SDPPath="$SDPPath"} else { $SDPPath="$SDPPath" +"\" }

If (-NOT (Test-Path $SDPPath -PathType 'Container')){
	$ErrorMsg += "No-Valid-SDP-path "
	Write-Host -BackgroundColor Black -ForegroundColor Red -Object "$($SDPPath) is not a valid SDP folder"
}

### Validate user input of expanded SDP report and identify the number of msinfo32.txt files and the names of the computers $NodeNames (in Cluster Report)
$MsinfoFiles = Get-Item -path ($SDPPath + $NodeName + "*Msinfo*.txt")
 if (!$MsinfoFiles) {$MsinfoFiles = Get-Item -path ($SDPPath + $NodeName + "*Msinfo*.nfo")}
  if (!$MsinfoFiles) {
	Write-Host -BackgroundColor Black -ForegroundColor Red -Object " WARNING: OSVersion cannot be determined! This error happens for non-standard SDP reports, i.e. VSS, SCCM or SQL SDP reports"
	Write-Host -BackgroundColor Black -ForegroundColor Red -Object " There are no *Msinfo*.* files in $SDPPath - Please double-check expanded SDP-path again!"
	Write-Host " to continue anyways, type Y and then please type OS-Version: [2008|2008R2|2012|2012R2|2016|2016RS1|2016RS2|2016RS3|2016RS4|2016RS5|201619H1]"
	#Get user input to continue:
	$UserInputYN = Read-Host 'Do you want to continue [Y|N]'
		if ($UserInputYN -match 'n') {Write-Host " ...ending RFL-check per User Input: $UserInputYN "
					    break}
	$UserInputOS = Read-Host 'OSVersion: [2008|2008R2|2012|2012R2|2016|2016RS1|2016RS2|2016RS3|2016RS4|2016RS5|201619H1]'
		if ($UserInputOS -Notmatch '20') {Write-Host " ...ending RFL-check, wrong input for OS version: $UserInputOS "
						  $ErrorMsg += "No-Valid-OS-$($UserInputOS) "
					    break}
		else {$OSVersion = $UserInputOS}
	$ErrorMsg += "Usr_$($UserInputOS) No-Valid-msinfo32 "
      	$MsinfoFiles = Get-Item -path ($SDPPath + $NodeName + '*evt_System.txt')
	Write-Host " Proceed with Files: $MsinfoFiles "
	}
$NodeNames = foreach ($NodeName in $MsinfoFiles){($NodeName.name).split('_')[0]}
Write-Host "$(Get-Date -UFormat "%R:%S") ...NodeName(s): $NodeNames"

"`n$Report_Type Report for Tech: '$RFLFixesTechs' $OSVersion - from SDP path:"
"  $SDPPath"

##########################################################
# Run report for each $NodeName in Cluster
# and create separate output files per node
$NodeCnt=0
foreach ($NodeName in $NodeNames){
	$NodeCnt++
	if ($($NodeNames.count) -gt 1) {Write-Host "$(Get-Date -UFormat "%R:%S") ___Node $NodeCnt $NodeName"}
$start_NodeName = Get-Date
$msinfo32 = $SDPPath + $NodeName + '*msinfo*.txt' # Try .txt
If (-NOT (Test-Path $msinfo32)) {
 Write-Verbose "** $SDPPath without *msinfo*.txt"
 $msinfo32 = $SDPPath + $NodeName + '*msinfo*.nfo' # Try .nfo
 }

  ### Get OS version from SDP report from msinfo.txt
  If ("$msinfo32" -match ".txt"){
    Write-Debug "...$NodeName Using msinfo32.txt = $msinfo32[$i] "
    #Read-in content from Msinfo file
    if ($msinfo32file = get-childitem $msinfo32) {
     	 Write-Debug "msinfo32file: $msinfo32file "
	 $SDPdate = $msinfo32file.LastWriteTime
	 Write-Host "`n$NodeName : SDP Date: $SDPdate"
	 $msinfo32 = Get-Content $msinfo32 -TotalCount 7
	 $OSbuild = $msinfo32[-1]
	 $OSName = $msinfo32[-2];$OSName=$OSName.Split(" ",3)[2]
	 $computername = $msinfo32[1].Split("")[-1]
	 }
   }
   Else { # Get OS version from SDP report from msinfo.nfo
    Write-Debug "...NodeName Using msinfo32.nfo = $msinfo32 "
    if ($msinfo32file = get-childitem $msinfo32) {
	$SDPdate = $msinfo32file.LastWriteTime
	Write-Host "`n$NodeName : SDP Date: $SDPdate"
	[xml]$nfo = Get-Content $msinfo32file
	$summary = $nfo.MSInfo.Category.Data.value
	If ($summary.'#cdata-section') {$OSbuild = $summary.'#cdata-section'[1]
		      			$OSName = $summary.'#cdata-section'[0]
		      			$computername = $summary.'#cdata-section'[4] }
      	Else {  $ErrorMsg += "No-Valid-Nfo "
		Write-Host -BackgroundColor Black -ForegroundColor Yellow -Object "WARNING: SDP with no valid MSinfo files"}
    } #end If
   } #end Else
### match Build number in SDP report with OS short name
if("$OSbuild" �match "2600"){$OSVersion_old="old-XP"}   	# or Windows XP
if("$OSbuild" �match "3790"){$OSVersion_old="old-2003"}   	# or Windows 2003
if("$OSbuild" �match "6001"){$OSVersion_old="old-2008-SP1"}   	# or Windows Vista SP1
if(("$OSbuild" -match "6002") -or ("$OSbuild" -match "6003") ){$OSVersion="2008"}   		# or Windows Vista SP2
if("$OSbuild" �match "7600"){$OSVersion_old="old-2008R2-RTM"} 	# or Windows 7 RTM
if("$OSbuild" �match "7601"){$OSVersion="2008R2"} 		# or Windows 7
if("$OSbuild" �match "9200"){$OSVersion="2012"}   		# or Windows 8
if("$OSbuild" �match "9600"){$OSVersion="2012R2"} 		# or Windows 8.1
if("$OSbuild" �match "10.0.10240"){$OSVersion="2016"} 		# or Windows 10
if("$OSbuild" �match "10.0.10586"){$OSVersion="2016TH2"} 	# or Windows 10 TH2
if("$OSbuild" �match "10.0.14393"){$OSVersion="2016RS1"} 	# or Windows 10 RS1
if("$OSbuild" -match "10.0.15063"){$OSVersion="2016RS2"} 	# or Windows 10 RS2
if("$OSbuild" -match "10.0.16299"){$OSVersion="2016RS3"} 	# or Windows 10 RS3
if("$OSbuild" -match "10.0.17134"){$OSVersion="2016RS4"} 	# or Windows 10 RS4
if("$OSbuild" -match "10.0.17763"){$OSVersion="2016RS5"} 	# or Windows 10 1809 RS5 October 2018 Update
if("$OSbuild" -match "10.0.18309"){$OSVersion="201619H1"} # or Windows 10 1903 19H1 March 2019 Update 
Write-Verbose "OS build: $OSbuild - $OSVersion $OSVersion_old"
If ($OSVersion_old) {
	Write-Host -BackgroundColor Black -ForegroundColor Red -Object "WARNING: $computername with $OSVersion_old is outdated! apply latest Service Pack for: Vista/2008, Win7/2008R2
	 to continue anyways, please retry using the optional parameter 3:`n  .\$($ScriptName) [Net] [SDP-path] [2008|2008R2|2012|2012R2|2016|2016RS1|2016RS2|2016RS3|2016RS4|2016RS5|201619H1] - no RFL for XP/2003 "
	#break
	}
if("$OSVersion" -match "old"){Throw "$OSVersion is outdated! apply latest SP for: Vista/2008, Win7/2008R2, Win8/2012, Win8.1/2012R2, Win10"}
if("$OSVersion" -eq ""){
	Write-Host -BackgroundColor Black -ForegroundColor Red -Object " WARNING: OSVersion cannot be determined! This error happens for non-standard SDP reports, i.e. VSS, SCCM or SQL SDP reports"
	Write-Host " to continue anyways, please type OSVersion: [2008|2008R2|2012|2012R2|2016|2016RS1|2016RS2|2016RS3|2016RS4|2016RS5|201619H1]"
	$UserInputYN = Read-Host 'Do you want to continue [Y|N]'
		if ($UserInputYN -match 'n') {Write-Host " ...ending RFL-check per User Input: $UserInputYN "
					    break}
	$UserInputOS = Read-Host 'OSVersion: [2008|2008R2|2012|2012R2|2016|2016RS1|2016RS2|2016RS3|2016RS4|2016RS5|201619H1]'
		if ($UserInputOS -Notmatch '20') {Write-Host " ...ending RFL-check per User Input: $UserInputOS "
							$ErrorMsg += "No-Valid-OS-$($UserInputOS) "
					    break}
		else {$OSVersion = $UserInputOS}
	$ErrorMsg += "User-Supplied-$($UserInputOS) "
	# Throw "$ OSVersion is not a valid name! Check OS version in SDP report for: Vista/2008, Win7/2008R2, Win8/2012, Win8.1/2012R2, Win10 - you may re-run script with 3rd parameter 20008|2008R2|2012|2012R2|2016|2016RS1|2016RS2|2016RS3|2016RS4|2016RS5|201619H1"
	}
"SDP computer name: $computername $OSbuild $OSName"

#initialize
[string[]]$savepathMissingKB_Appendix 	 = $Null
[string[]]$savepathMissingKB_content = $Null

##########################################################
### walk through each Tech in script inputlist (like Core,Dom,Net)
foreach ($RFLFixesTech in $RFLFixesTechs) {
    ### Validate user input for Technology
    If ("net","dom","cluster","core","vss","hyperv","rds","print","HyCoClNe","Exchange","Client","SCVMM2012SP1","SCVMM2012R2","CM2007","CM2012RTM","CM2012SP1","CM2012SP2","CM2012R2","All_OS","SQL","custom" -NotContains $RFLFixesTech)
	    {Throw "$($RFLFixesTech) is not a valid name! Please use one or more separated by comma : Net|Dom|Cluster|Core|VSS|HyperV|RDS|Print|Custom|HyCoClNe|Client|Exchange|SCVMM2012SP1|SCVMM2012R2|CM2007|CM2012RTM|CM2012SP1|CM2012SP2|CM2012R2|All_OS|SQL"}
    #If ("2008","2008R2","2012","2012R2","2016","2016RS1","2016RS2","2016RS3","2016RS4","2016RS5","201619H1" -NotContains $OSVersion){Throw "$($OSVersion) is not a valid version! Please use: 2008|2008R2|2012|2012R2|2016|2016RS1|2016RS2|2016RS3|2016RS4|2016RS5|201619H1"}
    #If ("Val" -NotMatch $Validate){Throw "$($Validate) is not a valid argument! Please use: val|Validate"}

    ##########################################################
    ### build $RFLFixesPath for ref__Tech+OS+latest.csv files
    switch($Report_Type)
	    {
	    "Engineer_RFL" 	{
			    $csvpath = $RFLpath +'*'+$RFLFixesTech+'*'+$OSVersion+'_'+$CsvFilename+'.csv'
			    If ("$RFLFixesTech" -match "CM") {$csvpath = $RFLpath +'*'+$RFLFixesTech+'_'+$CsvFilename+'.csv'}
			    If ("$RFLFixesTech" -match "SCVMM") {$csvpath = $RFLpath +'*'+$RFLFixesTech+'_'+$CsvFilename+'.csv'}
			    If ("$RFLFixesTech" -match "Exchange") {$csvpath = $RFLpath +'*'+$RFLFixesTech+'_'+$CsvFilename+'.csv'}
			    If ("$RFLFixesTech" -match "SQL") {$csvpath = $RFLpath +'*'+$RFLFixesTech+'_'+$CsvFilename+'.csv'}
			    }

	    "PUAS_DSE"	{
			    $csvpath = $PuasPath +'*'+$RFLFixesTech+'*'+$OSVersion+'_'+$CsvFilename+'.csv'
			    If ("$RFLFixesTech" -match "CM") {$csvpath = $PuasPath +'*'+$RFLFixesTech+'_'+$CsvFilename+'.csv'}
			    If ("$RFLFixesTech" -match "SCVMM") {$csvpath = $PuasPath +'*'+$RFLFixesTech+'_'+$CsvFilename+'.csv'}
			    If ("$RFLFixesTech" -match "Exchange") {$csvpath = $PuasPath +'*'+$RFLFixesTech+'_'+$CsvFilename+'.csv'}
			    If ("$RFLFixesTech" -match "SQL") {$csvpath = $PuasPath +'*'+$RFLFixesTech+'_'+$CsvFilename+'.csv'}
        		}
    }
    Write-Verbose "** Csv-Path: $csvpath "
    If (-NOT (Test-Path $csvpath)){Throw "$($csvpath) is not available."}
    $RFLFixesPath = ((get-item $csvpath)[-1]).FullName
    $csvpathReleaseDate = ((get-item $csvpath)[-1]).LastWriteTime

    Write-Host -BackgroundColor Gray -ForegroundColor Black -Object "`n* Latest '$RFLFixesTech' RFL update: $csvpathReleaseDate *"

    $rfl = Import-Csv $RFLFixesPath
    $SDPpathSym = $SDPPath + $NodeName + '*sym*.csv'
    $SDPpathHotfix = $SDPPath + $NodeName + '*Hotfixes.csv'

    ### inform user if SDP report is not suited, i.e. VSS, SCCM or SQL SDP reports (or if *sym or *hotfix files are missing) #2016-01-18
    $SDPpathSymFiles = get-childitem $SDPpathSym
    #$SDPpathStdoutFile = Get-Item -path ($SDPPath + "stdout.log") -ErrorAction SilentlyContinue
    #if (!$SDPpathStdoutFile) {$ErrorMsg += "No-Valid-stdout "}
    #else { 	$stdout = Get-Content $SDPpathStdoutFile -TotalCount 3
    # 		$SDPtype = $stdout[-1];$SDPtype=$SDPtype.Split(" ",2)[0]
    $SDPpathResultsFile = Get-Item -path ($SDPPath + "results.xml") -ErrorAction SilentlyContinue
    if (!$SDPpathResultsFile) {$ErrorMsg += "No-Valid-resultsXml "}
    else { 	[xml]$Types = Get-Content $SDPpathResultsFile	#Select-Xml -Xml $Types -XPath "//ID"
	   	$SDPtype = $Types.SelectSingleNode("//ID")|  % {  $_.InnerText }
 		Write-Host "SDP report type: $SDPtype" }

    if (!$SDPpathSymFiles) {
	Write-Host -BackgroundColor Black -ForegroundColor Red -Object  "There are no '*sym*.csv' files in $SDPPath - Please double-check expanded SDP-path again!"
	Write-Host " Note: This error happens for non-standard SDP reports, i.e. VSS, SCCM or SQL SDP reports [results.xml shows report-type] $SDPtype"
	Write-Host " RFL-check may show inconsistent results because of missing file versions in this report."
	$UserInput = Read-Host 'Do you want to continue [Y|N]'
		if ($UserInput -match 'n') {Write-Host " ...ending RFL-check per User Input: $UserInput "
					    break}
	$ErrorMsg += "No-Valid-sym_csv "
	Write-Host "***ErrorMsg: $ErrorMsg "
	}

    ###
    "...processing '$RFLFixesTech' RFL list for Windows $OSVersion (or Client OS)"
    "...Please wait ... `n"
    if(("$OSversion" �match "2012R2") -or ("$OSversion" �match "2016")) {" - Yellow blocks mark missing fixes ... `n"}
    else {" - Yellow blocks mark missing fixes, - Cyan=lightBlue blocks mark GDR-fix only installed ... `n"}
    ### Initialize
    [array]$myArrayMissingKB = $null
    [array]$myArrayInstalledKB = $null
    if ($FeedHigherSDPver){[array]$myArrayHigherSDPver = $null}
    $SdpVer=$null
    $sdpkb=$null
    # v1.18 added 3 lines for test if GDR version is installed
    $SDPpathHotfixFile = (get-childitem $SDPpathHotfix)
    write-debug "SDPpathHotfixFile: $SDPpathHotfixFile"
    #$SDPpathHotfixFileContent = (Get-Content $SDPpathHotfixFile)
    if ($SDPpathHotfixFile) {$SDPpathHotfixFileContent = (Get-Content $SDPpathHotfixFile)} #2016-01-18
    else		{$ErrorMsg += "No-Valid-hotfix_csv "
			  Write-Host -BackgroundColor Black -ForegroundColor Red -Object  "There is no '*hotfix.csv' file in $SDPPath - Please double-check expanded SDP-path again!"
			}

    $myArrayInstalledKBs = @()
    $myArrayMissingKBs = @()
    $myArrayHigherSDPvers = @()
    $combinedListsDSE = @()
    $ArrayUniqueShortListOfMissingKBlatest_Techs = @()
    $ArrayUniqueShortListOfMissingKBLDR_Techs  = @()
    $ArrayUniqueShortListOfInstalledKB_Techs = @()
    $UniqueShortListOfMissingKBLdr_Techs = @()
    $UniqueShortListOfMissingKBlatest_Techs = @()
    $UniqueShortListOfInstalledKB_Techs = @()

    ### processing RFL list for missing binaries and KB numbers
    foreach ($line in $rfl)
	    {
	    Write-Host -BackgroundColor Blue -ForegroundColor Cyan -NoNewline -Object "." -Separator .
	    $Binary = $line.Binary
	    #$Binary = ($line.Binary).ToUpper()	#2016-04-15 for Turkish character 'i /I'
	    $RflVer = $line.Version
	    $KB = ((($line.Article).split("("))[0]).Replace(" ","") # 2015-10-04 v1.18 replaced trailing blank
	    $Title = $line.Title
	    $url = $line.Link
	    $release = $line.Published
	    $Prio = $line.Prio
	    $branch = $line.Branch
	    $Component = $line.Component
	    $LDROnlyKB =$line.LDROnlyKB
	    $LDROnlyTitle =$line.LDROnlyTitle
	    $LDROnlyLink =$line.LDROnlyLink
	    $isInRollup=$line.RollupInfo

	    if ($Binary -notmatch "[1-9][0-9][0-9][0-9][0-9]")
	      { # processing binaries
	     #if ($SDPpathSym.count) {$SdpVer = Select-String -Pattern "\\$($Binary)" -Path $SDPpathSym -List -ErrorAction SilentlyContinue } #2016-01-18
	     if ($SDPpathSym.count) {$SdpVer = Using-Culture en-US { Select-String -Pattern "\\$($Binary)" -Path $SDPpathSym -List -Encoding ascii -ErrorAction SilentlyContinue} } #2016-04-18

	      if($SdpVer)
		    {
		    $SdpVer=(($SdpVer[0]).ToString()).split(',')[15]
		    $SdpVer = $SdpVer.Replace("(","");$SdpVer = $SdpVer.Replace(")","");$SdpVer = $SdpVer.Replace(":",".");$SdpVer = $SdpVer.Replace(".10585.",".10586.") 
			# add feedback with binary + version if RflVer < SDPver
			# ([version]$($V1)).CompareTo([version]$($V2)) // Result: if V1>V2 ->"1", if V1=V2 -> "0", if V1<V2 -> "-1"
			if (([version]$($SDPver)).CompareTo([version]$($RFLver)) -eq 1)	#($RflVer -lt $SdpVer) -- now check for $SdpVer -gt $RflVer
				{
				if ($FeedHigherSDPver){
					if ($HigherSDPverBinExceptList -NotContains $Binary){  ### (-NotContains ?) todo: -NotMatch seems not to work for multiple entries in list HigherSDPverBinExceptList
					    if ($SdpVer -NotMatch ".7601.23403"){ # unless version matches Win7 Convenience pack version "6.1.7601.23403"
						write-verbose "non expected higher SDPver $SdpVer"
						Write-Host -BackgroundColor Gray -ForegroundColor Black -NoNewline -Object "." -Separator .
						$obj2 = new-object PSObject -Property @{CheckDate=$CheckDate;OSVersion=$OSVersion;Prio=$Prio;Binary=$Binary;
						Branch=$Branch;RflVer=$RflVer;SdpVer=$SdpVer;Title=$Title;Release=$Release;KB=$KB;Url=$Url;
						LDROnlyKB=$LDROnlyKB;LDROnlyTitle=$LDROnlyTitle;LDROnlyLink=$LDROnlyLink;Component=$Component;IsInRollup=$IsInRollup;Comment="rEX"}
						$myArrayHigherSDPver += $obj2
						}
					}
				}
			}
			# now do standard RFL check
			if (([version]$($RFLver)).CompareTo([version]$($SDPver)) -eq 1) #($RflVer -gt $SdpVer)
			{
		  	write-verbose "$KB"
		    	$KBgdrInstalled = $SDPpathHotfixFileContent | Select-String "$KB" #-quiet -ErrorAction SilentlyContinue
			Write-debug "KBgdrInstalled: $KBgdrInstalled"
			if($KBgdrInstalled) { #GDR is IsInstalled="Yes"
				if ($KBgdrInstalled.Line -match "Completed successfully")
				{
			#	Write-Verbose -BackgroundColor Red -ForegroundColor Cyan -NoNewline -Object "yes: $KB GDR is installed: $($KBgdrInstalled.Line)"
			#	Write-Host -BackgroundColor DarkYellow -ForegroundColor Black -NoNewline -Object "$KB GDR is installed"
				Write-Host -BackgroundColor Cyan -ForegroundColor Black -NoNewline -Object "." -Separator .
				$obj = new-object PSObject -Property @{Prio=$Prio;Binary=$Binary;
				branch=$branch;RflVer=$RflVer;SdpVer=$SdpVer;Title=$Title;release=$release;KB=$KB;url=$url;
				LDROnlyKB=$LDROnlyKB;LDROnlyTitle=$LDROnlyTitle;LDROnlyLink=$LDROnlyLink;Component=$Component;isInRollup=$isInRollup;IsInstalled="Yes"}
				$myArrayMissingKB += $obj
				}
			}
			else { #GDR is not installed
				Write-Host -BackgroundColor Yellow -ForegroundColor Cyan -NoNewline -Object "." -Separator .
				$obj = new-object PSObject -Property @{Prio=$Prio;Binary=$Binary;
				branch=$branch;RflVer=$RflVer;SdpVer=$SdpVer;Title=$Title;release=$release;KB=$KB;url=$url;
				LDROnlyKB=$LDROnlyKB;LDROnlyTitle=$LDROnlyTitle;LDROnlyLink=$LDROnlyLink;Component=$Component;isInRollup=$isInRollup;IsInstalled="No"}
				$myArrayMissingKB += $obj
				}
			}
		    else{ #IsInstalled="Yes"
				$obj1 = new-object PSObject -Property @{Prio=$Prio;Binary=$Binary;
				branch=$branch;RflVer=$RflVer;SdpVer=$SdpVer;Title=$Title;release=$release;KB=$KB;url=$url;
				LDROnlyKB=$LDROnlyKB;LDROnlyTitle=$LDROnlyTitle;LDROnlyLink=$LDROnlyLink;Component=$Component;isInRollup=$isInRollup;IsInstalled="Yes"}
				$myArrayInstalledKB += $obj1
				}
		    }
	      }
	      else
	      { # processing KB articles
	      $sdpkb = Using-Culture en-US { Select-String -Pattern $Binary -Path $SDPpathHotfix -ErrorAction SilentlyContinue } #2016-0418
	      if(!($sdpkb))
		    {
			    Write-Host -BackgroundColor Yellow -ForegroundColor Cyan -NoNewline -Object "." -Separator .
			    $obj = new-object PSObject -Property @{Prio=$Prio;Binary="";
			    Branch=$Branch;RflVer="";SdpVer="";Title=$Title;Release=$Release;KB=$KB;Url=$Url;
			    LDROnlyKB="";LDROnlyTitle="";LDROnlyLink="";Component=$Component;IsInRollup=$IsInRollup;IsInstalled="No"}
			    $myArrayMissingKB += $obj
		    }
		    else
		    { #IsInstalled="Yes"
			    $obj1 = new-object PSObject -Property @{Prio=$Prio;Binary=$Binary;
			    Branch=$Branch;RflVer="";SdpVer="";Title=$Title;Release=$Release;KB=$KB;Url=$Url;
			    LDROnlyKB="";LDROnlyTitle="";LDROnlyLink="";Component=$Component;IsInRollup=$IsInRollup;IsInstalled="Yes"}
			    $myArrayInstalledKB += $obj1
		    }
	      }
	    } #end foreach ($line in $rfl)

### processing KBOnlyRollup_2012R2_History.txt and KBOnlyRollup_2016*_History.txt for installed cumulative KB numbers
if (($OSVersion -match "2012") -or ($OSVersion -match "2016")) { #2012 is cumulativ starting Oct 2016
#if (($OSVersion -match "2012R2") -or ($OSVersion -match "2016")) { 
	$KBOnlyRollupFile     = $null	#initialize
	$KBOnlyRollupFileName = $RFLpath + "KBOnlyRollup_" +$OSVersion+ "_History.txt"
	$KBOnlyRollupFile     = Import-Csv $KBOnlyRollupFileName

	foreach ($line in $KBOnlyRollupFile)
	   {
		Write-Host -BackgroundColor Blue -ForegroundColor Cyan -NoNewline -Object "." -Separator .
		$Binary = $line.Binary
		$Component = $line.Component
		$Prio = $line.Prio
		$Release = $line.Published
		$Branch = $line.Branch
		$KB = ((($line.Article).split("("))[0]).Replace(" ","") # 2015-10-04 replaced trailing blank
		$Title = $line.Title
		$Url = $line.Link
		$IsInRollup=$line.RollupInfo

		if ($Binary -match "[1-9][0-9][0-9][0-9][0-9]") #working on KB#s
		  {
		   $CumulativeKBinstalled = $SDPpathHotfixFileContent | Select-String "$($Binary).*Completed successfully"
		   Write-Verbose "KB $Binary match $($CumulativeKBinstalled)"
		   if ($CumulativeKBinstalled) {#IsInstalled="Yes"
		   			$obj1 = new-object PSObject -Property @{Prio=$Prio;Binary="";
		   			Branch=$Branch;RflVer="";SdpVer="";Title=$Title;Release=$Release;KB=$KB;Url=$Url;
		   			LDROnlyKB="";LDROnlyTitle="";LDROnlyLink="";Component=$Component;IsInRollup=$IsInRollup;IsInstalled="Yes"}
		   			$myArrayInstalledKB += $obj1
					}
		  }
	   } #end foreach ($line in $KBOnlyRollupFile)
} #end if (($OSVersion -match "2012R2") -or ($OSVersion -match "2016"))

        ### build list of missing binaries and KB numbers
    $ListOfMissingKB = @()
    if($myArrayMissingKB)
	    { # build list of missing binaries
	    $ListOfMissingKB = foreach ($EntryMissKB in $myArrayMissingKB )
	      { # working on Binary, no KB#
	      if(($EntryMissKB.Binary -notmatch "[1-9][0-9][0-9][0-9][0-9]"))
		    {
		    if($EntryMissKB.branch -eq "LDRGDR" -and (($EntryMissKB).SdpVer).Substring(9).StartsWith(1))
			    { # only LDRGDR is installed, minor version starts with "1" like 6.1.7601.17725
			    $EntryMissKB|
				    select @{Label="Prio";Expression={$_.Prio}},
				    @{Label="Component";Expression={$_.Component}},
				    @{Label="Branch";Expression={$_.branch}},
				    @{Label="Binary";Expression={$_.Binary}},
				    @{Label="RflVer";Expression={$_.RflVer}},
				    @{Label="SdpVer";Expression={$_.SdpVer}},
				    @{Label="Release Date";Expression={$_.release}},
				    @{Label="KB";Expression={$_.KB}},
				    @{Label="Title";Expression={$_.Title}},
				    @{Label="Url";Expression={$_.url}},
				    @{Label="LDROnlyKB";Expression={$_.LDROnlyKB}},
				    @{Label="LDROnlyTitle";Expression={$_.LDROnlyTitle}},
				    @{Label="LDROnlyLink";Expression={$_.LDROnlyLink}},
				    @{Label="isInstalled";Expression={$_.isInstalled}},
				    @{Label="isInRollup";Expression={$_.isInRollup}}
			    }
		    elseif(($EntryMissKB.branch -eq "LDRGDR" -and (($EntryMissKB).SdpVer).Substring(9).StartsWith(2)))
			    { # LDR is already installed, minor version starts with "2" like 6.1.7601.23153
			    $EntryMissKB|
				    select @{Label="Prio";Expression={$_.Prio}},
				    @{Label="Component";Expression={$_.Component}},
				    @{Label="Branch";Expression={$_.branch}},
				    @{Label="Binary";Expression={$_.Binary}},
				    @{Label="RflVer";Expression={$_.RflVer}},
				    @{Label="SdpVer";Expression={$_.SdpVer}},
				    @{Label="Release Date";Expression={$_.release}},
				    @{Label="KB";Expression={$_.KB}},
				    @{Label="Title";Expression={$_.Title}},
				    @{Label="Url";Expression={$_.url}},
				    @{Label="isInstalled";Expression={$_.isInstalled}},
				    @{Label="isInRollup";Expression={$_.isInRollup}}
			    }
		    else
			    { #Branch is LDR
			    $EntryMissKB|
				    select @{Label="Prio";Expression={$_.Prio}},
				    @{Label="Component";Expression={$_.Component}},
				    @{Label="Branch";Expression={$_.branch}},
				    @{Label="Binary";Expression={$_.Binary}},
				    @{Label="RflVer";Expression={$_.RflVer}},
				    @{Label="SdpVer";Expression={$_.SdpVer}},
				    @{Label="Release Date";Expression={$_.release}},
				    @{Label="KB";Expression={$_.KB}},
				    @{Label="Title";Expression={$_.Title}},
				    @{Label="Url";Expression={$_.url}},
				    @{Label="isInstalled";Expression={$_.isInstalled}},
				    @{Label="isInRollup";Expression={$_.isInRollup}}
			    }
		    if($DbgOut) { "$EntryMissKB |select KB,title,url| ft" }
		    }
	      else
		    { # KB# in Binary field - build list of missing KB#s
		    $EntryMissKB|
			    select @{Label="Prio";Expression={$_.Prio}},
			    @{Label="Component";Expression={$_.Component}},
			    @{Label="Branch";Expression={$_.branch}},
			    @{Label="Release Date";Expression={$_.release}},
			    @{Label="KB";Expression={$_.KB}},
			    @{Label="Title";Expression={$_.Title}},
			    @{Label="Url";Expression={$_.url}},
			    @{Label="isInstalled";Expression={$_.isInstalled}},
			    @{Label="isInRollup";Expression={$_.isInRollup}}
		    }
	      }
	    }
    else { # no matching binaries *or* KBs in SDP
        $ListOfMissingKB = "Up to date - or no binaries matched with given SDP report, i.e. no cluster binaries on Client OS"
        Write-Verbose "$ListOfMissingKB"
     }

    ### build list of installed binaries and KB numbers
    $ListOfInstalledKB = @()
    if($myArrayInstalledKB)
	    { # build list of Installed binaries
	    $ListOfInstalledKB = foreach ($EntryInstalledKB in $myArrayInstalledKB)
	      { # working on Binary, no KB#
	      if(($EntryInstalledKB.Binary -notmatch "[1-9][0-9][0-9][0-9][0-9]"))
			    {
		    $EntryInstalledKB|	select @{Label="Prio";Expression={$_.Prio}},
				    @{Label="Component";Expression={$_.Component}},
				    @{Label="Branch";Expression={$_.branch}},
				    @{Label="Binary";Expression={$_.Binary}},
				    @{Label="RflVer";Expression={$_.RflVer}},
				    @{Label="SdpVer";Expression={$_.SdpVer}},
				    @{Label="Release Date";Expression={$_.release}},
				    @{Label="KB";Expression={$_.KB}}
				    @{Label="Title";Expression={$_.Title}},
				    @{Label="Url";Expression={$_.url}},
				    @{Label="isInstalled";Expression={$_.isInstalled}},
				    @{Label="isInRollup";Expression={$_.isInRollup}}
			    }

	      else
		    { # build list of Installed KB#s
		    $EntryInstalledKB|
			    select @{Label="Prio";Expression={$_.Prio}},
			    @{Label="Component";Expression={$_.Component}},
			    @{Label="Branch";Expression={$_.branch}},
			    @{Label="Release Date";Expression={$_.release}},
			    @{Label="Binary";Expression={$_.Binary}},
			    @{Label="KB";Expression={$_.KB}}
			    @{Label="Title";Expression={$_.Title}},
			    @{Label="Url";Expression={$_.url}},
			    @{Label="isInstalled";Expression={$_.isInstalled}},
			    @{Label="isInRollup";Expression={$_.isInRollup}}
		    }
	      }
	    }
    else { # no matching Installed binaries or KBs in SDP
        $ListOfInstalledKB = "No Hotfix from current '$RFLFixesTech $OSVersion' RFL list installed.`n"
        Write-Verbose "$ListOfInstalledKB"
        }

    ### build list of non-expected higher SDPver binaries
    if ($FeedHigherSDPver){
       $ListOfHigherSDPver = @()
       if($myArrayHigherSDPver)
	{ # build list of non-expected higher SDPver binaries
	$ListOfHigherSDPver = foreach ($EntryHigherSDPver in $myArrayHigherSDPver)
	  { # working on Binary
	  if(($EntryHigherSDPver.Binary -notmatch "[1-9][0-9][0-9][0-9][0-9]"))
			{
			$EntryHigherSDPver|
				select @{Label="CheckDate";Expression={$_.CheckDate}},
				@{Label="OSVersion";Expression={$_.OSVersion}},
				@{Label="SdpVer";Expression={$_.SdpVer}},
				@{Label="Binary";Expression={$_.Binary}},
				@{Label="Component";Expression={$_.Component}},
				@{Label="RflVer";Expression={$_.RflVer}},
				@{Label="Prio";Expression={$_.Prio}},
				@{Label="Release";Expression={$_.Release}},
				@{Label="Branch";Expression={$_.Branch}},
				@{Label="KB";Expression={$_.KB}}
				@{Label="Title";Expression={$_.Title}},
				@{Label="Url";Expression={$_.Url}},
				@{Label="LDROnlyKB";Expression={$_.LDROnlyKB}},
				@{Label="LDROnlyTitle";Expression={$_.LDROnlyTitle}},
				@{Label="LDROnlyLink";Expression={$_.LDROnlyLink}},
				@{Label="Comment";Expression={$_.Comment}},
				@{Label="IsInRollup";Expression={$_.IsInRollup}}
			}
    	  } #end of foreach
       } #end if($myArrayHigherSDPver)
    } #end if ($FeedHigherSDPver)

    # Add new dynamic variable with the name myArrayMissingKB_$RFLFixesTech, for every RFLFixesTech
    # To access variable use:  get-variable -Name "myArrayMissingKB_$RFLFixesTech"
    new-variable -Name "myArrayMissingKB_$RFLFixesTech" -Value $myArrayMissingKB -Force
    new-variable -Name "myArrayInstalledKB_$RFLFixesTech" -value $myArrayInstalledKB -Force

    ## Script Output
    if($DbgOut) {$myArrayMissingKB |select KB,url,title|sort -Unique KB |ft -auto}


    ### RFL OUTPUT files: write detailed report with customer-ready unique KB#s
    $CheckDate_full = (Get-Date)
    ##$CheckDate = (Get-Date -UFormat "%Y-%m-%d_%R").Replace(":","-")
    $combinedListDSEcsv  	= $SDPPath + ('!'+$computername+'_'+$Report_Type+'_CombinedList_'+$RFLFixesTechs+'_'+$OSVersion+'.csv').replace(" ","-")
    $savepathMissingKB_TxtFile 	= $SDPPath + ('!'+$computername+'_'+$Report_Type+'_list_'+$RFLFixesTechs+'_'+$OSVersion+'.txt'+$FileExt).replace(" ","-")
    $ListOfHigherSDPverFile = $StatsServerPath +'ToDo_RFLupdates.csv'
    #$savepathMissingKB_tmpFile = $savepathMissingKB_TxtFile + '.tmp'


    #################################################################
    ### Detailed Tech section starts here, will be shown in APPENDIX
    #Add-Content $savepathMissingKB_tmpFile -Encoding String -Value $Title

    $i++	# loop counter for APPENDIX numbering
    ## ToDo: unless $i > $($i_start+1) {omitt APPENDIX}
    #Write-Verbose "i_start+1: $($i_start+1) - Build_summary=$Build_summary"
    if ("$i" -ge "$($i_start+1)")  { #Write Summary section
				    $Build_summary=1
				    Write-Debug " Build_summary: $Build_summary - More than one Tech: i = $i"}
    if ("$i" -eq "$($i_start+1)")  {
		    Write-Debug "Create / Filling APPENDIX: $savepathMissingKB_Appendix"
		    $savepathMissingKB_Appendix += $newline_Separator
		    $savepathMissingKB_Appendix += "     `tAPPENDIX "
		    $savepathMissingKB_Appendix += $Separator
		    If ($PUASCopyBlock){ $savepathMissingKB_Appendix += "[*CopyBlock_5* till end]"}
		    $ShortSDPPath = ($SDPPath.Split('\\')[-3,-2,-1]) -join ('\') #[-2,-1]#| Select-Object -Last 1
		    $savepathMissingKB_Appendix += "$Report_Type Report date: $CheckDate - Data processed for this report:
    - Report generated with (script version v$VerMa.$VerMi):
       '$ScriptName $RFLFixesTechs $ShortSDPPath'
    - Customer SDP report date:`t $SDPdate
    - for sample system name: `t $computername
    - Operating System: `t`t $OSName
    - OS Version Build: `t`t $OSbuild
    - Report(s) for Technologies: `t $RFLFixesTechs `n
    "
    $savepathMissingKB_Appendix += $Separator
    $savepathMissingKB_Appendix += "$i.1     $RFLFixesTech :: `tMissing Fixes RFL "
     } # write above section only once

    $savepathMissingKB_Appendix += $Separator
    $savepathMissingKB_Appendix += "$i.1.1   $RFLFixesTech :: `tMissing Fixes � Short KB-List, just KB-Numbers with Url Link (Unique KB numbers of all missing '$RFLFixesTech' KBs) on the System: $computername "
    $savepathMissingKB_Appendix += $Separator

    switch($Report_Mode)
      {			#v1.23 swap $myArrayMissingKB with $ListOfMissingKB
	    "Normal" {
		    $UniqueShortListOfMissingKBLdr = $ListOfMissingKB |?{$_.branch -eq 'LDRGDR'}|?{$_.LDROnlyKB -ne 'No LDR Only available'}|select Prio,LDROnlyKB,LDROnlyLink|sort -Unique LDROnlyKB|sort Prio |ft -auto
	     	    $UniqueShortListOfMissingKB = $ListOfMissingKB |?{$_.IsInstalled -eq 'No' -and ($_.Component -match 'rollup_KB' -or $_.isInRollup -eq 'No Rollup')} |select Prio,KB,Url|sort -Unique KB |sort Prio |ft -auto
	   	    $ListOfInstalledKB = $myArrayInstalledKB | select Prio,KB,Component,Binary,RflVer,SdpVer |sort Prio,Component |ft -auto
		    }
	    "Detailed" {
		    $UniqueShortListOfMissingKBLdr = $ListOfMissingKB |?{$_.branch -eq 'LDRGDR'}|?{$_.LDROnlyKB -ne 'No LDR Only available'}|?{$_.LDROnlyKB -ne 'KB only'}|select LDROnlyKB,Binary,Component,LDROnlyLink,LDROnlyTitle |sort -Unique LDROnlyKB|sort Component |ft -auto
		    $UniqueShortListOfMissingKB = $ListOfMissingKB |?{$_.IsInstalled -eq 'No' -and ($_.Component -match 'rollup_KB' -or $_.isInRollup -eq 'No Rollup')} |select KB,Binary,Component,Url,Title |sort -Unique KB |sort Component |ft -auto
		    $ListOfInstalledKB = $myArrayInstalledKB | select KB,Binary,Component,RflVer,SdpVer,Release,isInstalled,Title |sort Component |ft -auto
		    }
	    "DetailedPUAS" {
		    $UniqueShortListOfMissingKBLdr = $ListOfMissingKB |?{$_.branch -eq 'LDRGDR'}|?{$_.LDROnlyKB -ne 'No LDR Only available'}|select Prio,KB,LDROnlyKB,LDROnlyLink,Binary,Component,Branch|sort -Unique LDROnlyKB|sort Prio,Component |ft -auto
	     	    $UniqueShortListOfMissingKB = $ListOfMissingKB |?{$_.IsInstalled -eq 'No' -and ($_.Component -match 'rollup_KB' -or $_.isInRollup -eq 'No Rollup')} |select Prio,KB,Url,Binary,Component,Branch,Title |sort -Unique KB |sort Prio,Component |ft -auto
		    $ListOfInstalledKB = $myArrayInstalledKB | select Prio,KB,Binary,Component,RflVer,SdpVer,Release,isInstalled,Title |sort Prio,Component |ft -auto
		    }
      }

    if(("$OSversion" �notmatch "2012R2") -and ("$OSversion" �notmatch "2016")) { #no LDRonly for 2012R2
        $savepathMissingKB_Appendix += "$i.1.1.1 $RFLFixesTech :: `t[Missing LDR-only] Please install following LDR-Only KBs to switch included binaries to LDR branch:"
        $savepathMissingKB_Appendix += $UniqueShortListOfMissingKBLdr |Out-String -Width $OutFileChars
        $m = $ListOfMissingKB |?{$_.branch -eq 'LDRGDR'}|?{$_.LDROnlyKB -ne 'No LDR Only available'} |?{$_.LDROnlyKB -ne 'KB only'} |select LDROnlyKB |sort -Unique LDROnlyKB |measure
        $savepathMissingKB_Appendix += "Number of Unique [Missing LDR-only] $RFLFixesTech : $($m.Count)"
        $savepathMissingKB_Appendix += $Separator_space
    }
    $savepathMissingKB_Appendix += "$i.1.1.2 $RFLFixesTech :: `t[Missing latest] Please install the following missing latest Hotfixes to update related binaries to the recommended version:"
       Write-Debug " UniqueShortListOfMissingKB $RFLFixesTech"
     $savepathMissingKB_Appendix += $UniqueShortListOfMissingKB |Out-String -Width $OutFileChars
     $m = $ListOfMissingKB |?{$_.Component -match 'rollup_KB' -or $_.isInRollup -eq 'No Rollup'} |select KB |sort -Unique KB |measure
     $savepathMissingKB_Appendix += "Number of Unique [Missing latest] Hotfixes $RFLFixesTech : $($m.Count)"
     $savepathMissingKB_Appendix += $Separator_space

    Write-Debug "***** $Report_Type"
    if ("$Report_Type" -eq "PUAS_DSE") {
        $savepathMissingKB_Appendix += "$i.1.2   $RFLFixesTech :: `tMissing Fixes - Binary-Table (potential duplicate KB numbers of all missing '$RFLFixesTech' KBs) on the System: $computername"
        $savepathMissingKB_Appendix += $Separator

        if(("$OSversion" �notmatch "2012R2") -and ("$OSversion" �notmatch "2016")) {
            $savepathMissingKB_Appendix += "$i.1.2.1 $RFLFixesTech :: `t[Missing LDR-only] Please install following LDR-Only Hotfixes to switch included binaries to LDR branch:"
	        Write-Debug " ListOfKBLDROnly $RFLFixesTech"
   	        $ListOfKBLDROnly = $ListOfMissingKB |?{$_.branch -eq 'LDRGDR'}|?{$_.LDROnlyKB -ne 'No LDR Only available'} |?{$_.LDROnlyKB -ne 'KB only'} |select Prio,LDROnlyKB,Component,Binary,RflVer,SdpVer|sort Prio,Component |ft -auto
  	        $savepathMissingKB_Appendix += $ListOfKBLDROnly |Out-String -Width $OutFileChars
        }

         $savepathMissingKB_Appendix += "$i.1.2.2 $RFLFixesTech :: `t[Missing latest] Please install the following latest Hotfixes to update related binaries to the recommended version:"
         #$ShortListOfMissingKB = $myArrayMissingKB |select Prio,Binary,Branch,KB,title,url|sort -Unique KB |sort Prio |fl
         $ShortListOfMissingKB = $ListOfMissingKB |select Prio,KB,Component,Binary,Branch,RflVer,SdpVer |sort Prio,Component |ft -auto
         $savepathMissingKB_Appendix += $ShortListOfMissingKB |Out-String -Width $OutFileChars
     }

    $savepathMissingKB_Appendix += $newline_Separator
    $savepathMissingKB_Appendix += "$i.2     $RFLFixesTech :: `tRFL � Hotfixes already installed, Hotfixes including Binary Information "
    $savepathMissingKB_Appendix += $Separator
    $savepathMissingKB_Appendix += "$RFLFixesTech ::`t[Info] Installed Fixes (Binary-Table) on the System: $computername "
      ## need to check for NULL List
      if ($ListOfInstalledKB -match "No Hotfix from current") { $savepathMissingKB_Appendix += $ListOfInstalledKB }
      $savepathMissingKB_Appendix += $ListOfInstalledKB |Out-String -Width $OutFileChars
     $m = $myArrayInstalledKB |select KB |sort -Unique KB |measure
     $savepathMissingKB_Appendix += "Number of Unique Hotfixes [already installed] $RFLFixesTech : $($m.Count) "
     $savepathMissingKB_Appendix += $Separator_space

    $savepathMissingKB_Appendix += $newline_Separator
    $savepathMissingKB_Appendix += "$i.3     $RFLFixesTech :: `tRFL � Full List including Binary Information with installed (SdpVer) and recommended version (RflVer)"

    $k=1
    if ("$Report_Type" -eq "Engineer_RFL") {
     $savepathMissingKB_Appendix += $Separator
     $savepathMissingKB_Appendix += "$i.3.$k $RFLFixesTech :: [Full Table] Missing Fixes on the System: $computername - $OSName $OSbuild "
      $ListOfMissingKBtable = $myArrayMissingKB| select KB,Binary,Component,RflVer,SdpVer,Release,isInstalled,branch,isInRollup,Title  |?{$_ -match '[0-9]'}|sort Component |ft -auto
      $savepathMissingKB_Appendix += $ListOfMissingKBtable |Out-String -Width $OutFileChars
      $k++
    }

    If ($OmitFullList -eq 0) {
    	$savepathMissingKB_Appendix += $Separator
        $savepathMissingKB_Appendix += "$i.3.$k $RFLFixesTech :: [Full List] Missing Fixes on the System: $computername - $OSName $OSbuild "
      	$savepathMissingKB_Appendix += $ListOfMissingKB |Out-String -Width $OutFileChars
      }
    $savepathMissingKB_Appendix += $Separator2
    $savepathMissingKB_Appendix += "Release Date of RFL list for module '$RFLFixesTech' = $csvpathReleaseDate `n"
    $savepathMissingKB_Appendix += $Separator

    If ($AppendEngInfo) {
      ### append EngineerInfo (if available) to Engineer RFL output
      $EngineerInfo = $RFLpath + 'KB_info_'+$RFLFixesTech+'_'+$OSVersion+'.txt'
      If (Test-Path $EngineerInfo){
	    Write-Debug "`n** EngineerInfo: '$EngineerInfo'"
	    "`n...appending EngineerInfo for '$RFLFixesTech' $OSVersion "
	    $savepathMissingKB_Appendix += $newline_Separator
	    $savepathMissingKB_Appendix += "$i.4     $RFLFixesTech :: `t Internal EngineerInfo"
	    #Get-Content $EngineerInfo -Encoding Ascii | Out-File $savepathMissingKB_tmp -Append -Encoding String
	    $savepathMissingKB_Appendix += Get-Content $EngineerInfo -Encoding Ascii
	    }
      }

    Write-Debug "NodeName/Tech/i: $NodeName $RFLFixesTech : i = $i - end per NodeName "
    #Reset $msinfo32
} #end foreach ($RFLFixesTech in $RFLFixesTechs) loop: processing RFL list for missing binaries and KB numbers, # walk through each Tech in inputlist (like Core,Dom,Net)


foreach ($RFLFixesTech in $RFLFixesTechs)
	{
	$myArrayMissingKBs += , (get-variable -Name "myArrayMissingKB_$RFLFixesTech")
	$myArrayInstalledKBs += , (get-variable -Name "myArrayInstalledKB_$RFLFixesTech")
	}

####################################################
###Build list of unique missing KB across all Techs
# write a new file 888
#"" >$savepathMissingKB_content
"" > $savepathMissingKB_TxtFile #initialize
if ($Build_summary) {
$i=$i_start
  Write-Verbose "$Build_summary ###Build list of unique missing KB across all Techs - iSum = $i"

$ArrayUniqueShortListOfMissingKBLDR_Techs    = $myArrayMissingKBs |select -ExpandProperty value |sort -Unique LDROnlyKB
$ArrayUniqueShortListOfMissingKBlatest_Techs = $myArrayMissingKBs |select -ExpandProperty value #|sort -Unique KB ## removed sort because of missing monthly rollup KB in 2012R2 output, if missing binaries are in same rollup KB
$ArrayUniqueShortListOfInstalledKB_Techs     = $myArrayInstalledKBs |select -ExpandProperty value |sort -Unique KB

Write-Debug " switch mode: $Report_Mode"
switch($Report_Mode)
  {
	"Normal" {
		 Write-Debug " UniqueShortListOfMissingKBLdr_Techs Val - $RFLFixesTechs"
		   $UniqueShortListOfMissingKBLdr_Techs    = $ArrayUniqueShortListOfMissingKBLDR_Techs |?{$_.branch -eq 'LDRGDR'}|?{$_.LDROnlyKB -ne 'No LDR Only available'}|?{$_.LDROnlyKB -ne 'KB only'}|select Prio,LDROnlyKB,LDROnlyLink |sort -Unique LDROnlyKB|sort Prio |ft -auto
		   $UniqueShortListOfMissingKBlatest_Techs = $ArrayUniqueShortListOfMissingKBlatest_Techs |?{$_.Component -match 'rollup_KB' -or $_.isInRollup -eq 'No Rollup'} |select Prio,KB,Url |sort -Unique KB |sort Prio |ft -auto
		   $UniqueShortListOfInstalledKB_Techs     = $ArrayUniqueShortListOfInstalledKB_Techs |?{$_.isInstalled -eq 'Yes'}|select Prio,KB,Component,Binary,RflVer,SdpVer |sort -Unique KB|sort Prio,Component |ft -auto
	}
	"Detailed" {
		Write-Debug " UniqueShortListOfMissingKBLdr_Techs Val - $RFLFixesTechs"
		   $UniqueShortListOfMissingKBLdr_Techs    = $ArrayUniqueShortListOfMissingKBLDR_Techs |?{$_.branch -eq 'LDRGDR'}|?{$_.LDROnlyKB -ne 'No LDR Only available'}|?{$_.LDROnlyKB -ne 'KB only'}|select LDROnlyKB,LDROnlyLink,Component,Binary |sort -Unique LDROnlyKB|sort Component |ft -auto
		Write-Debug " UniqueShortListOfMissingKBlatest_Techs Val - $RFLFixesTechs"
		   $UniqueShortListOfMissingKBlatest_Techs = $ArrayUniqueShortListOfMissingKBlatest_Techs |?{$_.Component -match 'rollup_KB' -or $_.isInRollup -eq 'No Rollup'} |select KB,Url,Component,Branch,Binary,RflVer,SdpVer |sort -Unique KB |sort Component |ft -auto
		   $UniqueShortListOfInstalledKB_Techs     = $ArrayUniqueShortListOfInstalledKB_Techs |?{$_.isInstalled -eq 'Yes'}|select KB,Url,Component,Branch,Binary,RflVer,SdpVer |sort -Unique KB|sort Component |ft -auto
	}
	"DetailedPUAS" {
		Write-Debug " UniqueShortListOfMissingKBLdr_Techs Val - $RFLFixesTechs"
		   $UniqueShortListOfMissingKBLdr_Techs    = $ArrayUniqueShortListOfMissingKBLDR_Techs |?{$_.branch -eq 'LDRGDR'}|?{$_.LDROnlyKB -ne 'No LDR Only available'}|?{$_.LDROnlyKB -ne 'KB only'}|select Prio,KB,LDROnlyKB,LDROnlyLink,Component,Branch,Binary |sort -Unique LDROnlyKB|sort Prio,Component |ft -auto
		Write-Debug " UniqueShortListOfMissingKBlatest_Techs Val - $RFLFixesTechs"
		   $UniqueShortListOfMissingKBlatest_Techs = $ArrayUniqueShortListOfMissingKBlatest_Techs |?{$_.Component -match 'rollup_KB' -or $_.isInRollup -eq 'No Rollup'} |select Prio,KB,Url,Component,Branch,Binary,RflVer,SdpVer |sort -Unique KB |sort Prio,Component |ft -auto #
		   $UniqueShortListOfInstalledKB_Techs     = $ArrayUniqueShortListOfInstalledKB_Techs |?{$_.isInstalled -eq 'Yes'}|select Prio,KB,Url,Component,Branch,Binary,RflVer,SdpVer |sort -Unique KB|sort Prio,Component |ft -auto
	}
  }
$curr_UniDiffMissingArray   = $ArrayUniqueShortListOfMissingKBlatest_Techs |?{$_.IsInstalled -eq 'No' -and ($_.Component -match 'rollup_KB' -or $_.IsInRollup -eq 'No Rollup')} |select KB,Binary,Component,RflVer,SdpVer,Release,isInstalled,Branch,IsInRollup |sort -Unique KB |sort Component

### Format output file
"`n...working on final report (might take a couple of seconds)..."
Write-Debug " switch type: $Report_Type"
switch($Report_Type)
	{
	"Engineer_RFL" 	{
			$ReportDateName = "Date of RFL check"
#!Note: Q13: Why does the RFL output show some Security fixes MSxx-yyy as missing in section 1.1.1.2 :: 	 [Missing latest], although the GDR version is already installed?
#A13: The script logic checks for highest LDR version number (.2xxxx) expected. If only the GDR version (.1yyyy)  of the security fix is installed, and no LDR only fix for the same binary is installed, the LDR version (.2xxxx) of the security fix is displayed as missing on the system � that�s why the KB-article is listed in this section 1.1.1.2 as missing, although the GDR version of same fix might be applied already. In this case the customer still should apply the corresponding LDR-only fix of this binary, and run a new SDP report. Then the Security Fix KB-number will no longer appear as 'missing'. In this case, there is no need to re-install the Security fix, as it will be automatically applied from the DUAL package with LDR fix, once the LDR-only fix has been installed successfully.
			$Header = "SDP date: $SDPdate - Missing '$RFLFixesTechs' Hotfixes on: $computername - $OSName $OSbuild `n
SDP report type: $SDPtype
*** $ErrorMsg
____*** Disclaimer ***____
!please reTHINK - before sending long hotfix/update lists to customer! Which Hotfixes are really necessary to solve this issue? i.e. for network connectivity issues, you should recommend only:
 + Update NIC driver(s)
 + Update Microsoft (stack/protocol) drivers involved in sending/receiving network packets, -> see category/components 'Net_Protocol'

Note: You can obtain multiple stand-alone update packages through the Microsoft Download Center on http://catalog.update.microsoft.com

(Questions, Feedback for improvements welcome @: waltere / ioanc
Please also report any inconsistency in RFL output, i.e. customer cannot install a recommended KB article, this will help the whole -now worldwide- community using this service!)

$Separator2
- Section $i.1 contains the actual hotfix/potential hotfix recommendations for your customer, based on findings of received SDP Report.
- This 'Customer Ready' Consolidated List of [Missing LDR-only] and [Missing latest] Unique Hotfix-numbers for your chosen technologies: '$RFLFixesTechs' in section $i.1.1
- Section $i.2 is FYI, it lists Hotfixes [already installed].
- Section APPENDIX: If you have selected more than one Tech (i.e. Core,Dom,Net) this section will show information in same format, but grouped per Tech [Core|Dom|Net]
- including Internal EngineerInfo in Section *.4 (if available)
$Separator2 "
			}

	"PUAS_DSE"	{
			$ReportDateName = "PUAS iteration date"
			$Header = "$i	`tRecommended Hotfix List (RFL) by system/server role`n
This chapter contains the actual recommendations found based on your provided representative sample system data (SDP Report):"
			If ($Validate -Match "Val"){ $PUASValText = "VALIDATION MODE is ON - for internal use only `n
$newline_Separator "}
			}
	}

$savepathMissingKB_content += $Separator
$savepathMissingKB_content += $PUASValText
$savepathMissingKB_content += $Header
If ($PUASCopyBlock){ $savepathMissingKB_content += "[*CopyBlock_1*]" }
$savepathMissingKB_content += " Report for Technologies: '$RFLFixesTechs'
 Computername: `t`t $computername
 Operating System: `t $OSName
 SDP Report Date: `t $SDPdate
 SDP Report Type: `t $SDPtype
 $($ReportDateName): `t $CheckDate_full "
If ($PUASCopyBlock){ $savepathMissingKB_content += "[/*CopyBlock_1*]" }
$savepathMissingKB_content += $newline_Separator
$savepathMissingKB_content += "$i.1     '$RFLFixesTechs' :: RFL � Short List of Unique Hotfix-numbers, just KB-Numbers with Url Link"
$savepathMissingKB_content += $Separator
$savepathMissingKB_content += "$i.1.1   '$RFLFixesTechs' ::	Consolidated List of Missing Hotfixes RFL - Unique Hotfix-numbers on the System: $computername `n"
if(("$OSversion" �notmatch "2012R2") -and ("$OSversion" �notmatch "2016")) { #no LDRonly for 2012R2
 $savepathMissingKB_content += "$i.1.1.1 '$RFLFixesTechs' :: `tMissing [LDRonly Hotfixes] RFL - Unique Hotfix-numbers`n"
 If ($PUASCopyBlock){ $savepathMissingKB_content += "[*CopyBlock_2*]" }
 $savepathMissingKB_content += $UniqueShortListOfMissingKBLdr_Techs |Out-String -Width $OutFileChars
 If ($PUASCopyBlock){ $savepathMissingKB_content += "[/*CopyBlock_2*]" }
 $m = $ArrayUniqueShortListOfMissingKBLDR_Techs |?{$_.branch -eq 'LDRGDR'}|?{$_.LDROnlyKB -ne 'No LDR Only available'}|?{$_.LDROnlyKB -ne 'KB only'} |select LDROnlyKB |sort -Unique LDROnlyKB |measure
 $savepathMissingKB_content += "Number of Unique [Missing LDR-only] '$RFLFixesTechs' : $($m.Count) "
 $savepathMissingKB_content += $Separator_space
}
$savepathMissingKB_content += "$i.1.1.2 '$RFLFixesTechs' :: `tMissing [latest Hotfixes] RFL  - Unique Hotfix-numbers`n"
If ($PUASCopyBlock){ $savepathMissingKB_content += "[*CopyBlock_3*]" }
$savepathMissingKB_content += $UniqueShortListOfMissingKBlatest_Techs |Out-String -Width $OutFileChars
If ($PUASCopyBlock){ $savepathMissingKB_content += "[/*CopyBlock_3*]" }
 $m = $ArrayUniqueShortListOfMissingKBlatest_Techs |?{$_.Component -match 'rollup_KB' -or $_.isInRollup -eq 'No Rollup'} |select KB |sort -Unique KB |measure
 $savepathMissingKB_content += "Number of Unique [Missing latest] Hotfixes '$RFLFixesTechs' : $($m.Count) "
 $savepathMissingKB_content += $Separator_space
$savepathMissingKB_content += $newline_Separator
$savepathMissingKB_content += "$i.2.  '$RFLFixesTechs' :: `tRFL � Hotfixes [already installed], Hotfixes including Binary Information`n"
$savepathMissingKB_content += $Separator
If ($PUASCopyBlock){ $savepathMissingKB_content += "[*CopyBlock_4*]" }
  if ($UniqueShortListOfInstalledKB_Techs -match "No Hotfix from current") { $savepathMissingKB_content += $UniqueShortListOfInstalledKB_Techs }
$savepathMissingKB_content += $UniqueShortListOfInstalledKB_Techs |Out-String -Width $OutFileChars
If ($PUASCopyBlock){ $savepathMissingKB_content += "[/*CopyBlock_4*]" }
 $m = $ArrayUniqueShortListOfInstalledKB_Techs |?{$_.isInstalled -eq 'Yes'} |select KB |sort -Unique KB |measure
 $savepathMissingKB_content += "Number of Unique Hotfixes [already installed] '$RFLFixesTechs' : $($m.Count) "
 $savepathMissingKB_content += $Separator_space

 #write _content to file
$savepathMissingKB_content | Out-File $savepathMissingKB_TxtFile -Append -Encoding String

} #end if ($Build_summary)
$savepathMissingKB_Appendix  | Out-File $savepathMissingKB_TxtFile -Append -Encoding String

### Write Excel Csv file
#Set-Content $combinedListDSEcsv -Encoding String -Value ""
"" > $combinedListDSEcsv

$combinedListsDSE = $myArrayMissingKBs + $myArrayInstalledKBs
$combinedListsDSE = $combinedListsDSE |select -ExpandProperty value |sort -Unique KB
$combinedListsDSE 	|select Prio,KB,Component,Binary,RflVer,SdpVer,url,isInstalled,branch,release,LDROnlyKB,LDROnlyTitle,LDROnlyLink,isInRollup `
			|sort Prio,Component|Export-Csv -Path $combinedListDSEcsv -NoTypeInformation -UseCulture #-Delimiter "$csvDelimiter"

### END: Script PS output
"`nCSV Overview and $Report_Type Report of missing unique Hotfix KB articles, installed KBs:
=> $combinedListDSEcsv
=> $savepathMissingKB_TxtFile "

$end_NodeName = Get-Date
Write-Host -BackgroundColor Gray -ForegroundColor Black -Object "$(Get-Date -UFormat "%R:%S") $Report_Type on $computername Windows $OSVersion script version v$VerMa.$VerMi took $($end_NodeName - $start_NodeName)"

### open output file with Notepad/FavEditor
If ($NodeCnt -eq 1) {	"`n...using FavEditor to open $Report_Type Report "
			Invoke-Item $savepathMissingKB_TxtFile }
### open output file with favorite Editor
#If ($NodeCnt -eq 1) {$savepathMissingKB_TxtFile }

### Write/Append Excel Csv file for non-expected higher SDPver in Engineer_RFL version ("$Report_Type" -eq "Engineer_RFL") #2015-12-03
 if (($FeedHigherSDPver) -and ($Stats) -and ("$Report_Type" -eq "Engineer_RFL") -and ($UserInputOS -eq $null)){
  $myArrayHigherSDPver |select CheckDate,OSVersion,SdpVer,Binary,Component,RflVer,Prio,Release,Branch,KB,Title,Url,LDROnlyKB,LDROnlyTitle,LDROnlyLink,Comment,IsInRollup `
			|sort Component|Export-Csv -Path $ListOfHigherSDPverFile -NoTypeInformation -Append -Delimiter "$csvDelimiter" -Force # -UseCulture
  }

 #####################################
 # Save result of current Cluster node
 #new-variable -Name "myRegistryArray_$NodeName" -value $RegistryArray -Force
 $curr_DiffMissingArray  = $curr_UniDiffMissingArray | select KB,Binary,Component,RflVer,SdpVer,Release,isInstalled,Branch,IsInRollup |sort KB -desc #|?{$_ -match '[0-9]'} #$ListOfMissingKBtable
 #$curr_R = (get-variable -Name "myRegistryArray_$NodeName")

 if ($NodeCnt -gt 1) {
	#Write-host "...Running Cluster nodes consistency check"
	Write-verbose "$NodeName_Prev =Prev node; Count Missing: $($prev_DiffMissingArray.count)"
	#if ($DbgOut) {	$prev_DiffMissingArray |select KB,Binary,Component,RflVer,SdpVer,Release,isInstalled,Branch,IsInRollup |ft -auto}
	$PrevArr = $prev_DiffMissingArray |select KB,Binary,Component,RflVer,SdpVer,Release,isInstalled,Branch,IsInRollup
	Write-verbose "$NodeName =Curr node; Count Missing: $($curr_DiffMissingArray.count)"
	#if ($DbgOut) {	$curr_DiffMissingArray |select KB,Binary,Component,RflVer,SdpVer,Release,isInstalled,Branch,IsInRollup #|ft -auto}
	$CurrArr = $curr_DiffMissingArray |select KB,Binary,Component,RflVer,SdpVer,Release,isInstalled,Branch,IsInRollup

	$Diffs = (Compare-Object ($PrevArr | ConvertTo-CSV) ($CurrArr | ConvertTo-CSV) -SyncWindow 20) 	# compare up to 20 lines distance
	if  ($Diffs -eq $null) {Write-Host -BackgroundColor Green -ForegroundColor Black -Object  "$NodeName_Prev / $NodeName ClusterNode '[Table] Missing Fixes' are equal"
				"$newline_Separator" >> $savepathMissingKB_TxtFile
				" - Cluster nodes consistency check in Cluster nodes: $newline_Separator" >> $savepathMissingKB_TxtFile
				" $NodeName_Prev / $NodeName ClusterNode '[Table] Missing Fixes' are equal" >> $savepathMissingKB_TxtFile }
	else {	##
		Write-host -BackgroundColor Red -ForegroundColor Black -Object "$NodeName_Prev / $NodeName Differences:"
		$Diffs |ft -auto
		## append in current $savepathMissingKB_TxtFile
		"$newline_Separator" >> $savepathMissingKB_TxtFile
		" - Checking for different recommended versions in Cluster nodes: $newline_Separator" >> $savepathMissingKB_TxtFile
		"$NodeName_Prev / $NodeName Differences:"  >> $savepathMissingKB_TxtFile
		$Diffs |ft -auto | Out-file $savepathMissingKB_TxtFile -Append -Encoding String -Width $OutFileChars

		### open output file with Notepad/FavEditor
		Write-Host "... open output Summary file with FavEditor, because inconsistencies or differences were found for $NodeName."
		Invoke-Item $savepathMissingKB_TxtFile
		} #end else
	} #end if ($NodeCnt -gt 1)
 # save previous NodeName and DiffMissingArray for next node loop
 $NodeName_Prev = $NodeName
 $prev_DiffMissingArray = $curr_DiffMissingArray
 } #end foreach ($NodeName in $NodeNames) #Run report for each $NodeName in Cluster

Write-debug "Errors: $($ErrorMsg)"
$end = Get-Date
### Stats
$Duration = $end - $start

If ($Stats) {
  "$j" + " ;$CheckDate; $OSVersion; $PSculture; '$RFLFixesTechs'; " + ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name) + "; $($Duration)" + "; $SDPPath $Validate " + "; $SDPtype" + "; $ErrorMsg" + "; $NodeCnt" + "; $UsrOSVersion" + "; v$VerMa.$VerMi"| Out-File $CountInvFil2 -Append -Encoding UTF8 -ErrorAction SilentlyContinue
  }
If  (("$Report_Type" -eq "Engineer_RFL") -and ($RunAddon)) {
	#Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned -Force
	Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force
	Unblock-File -Path $RFLroot\get-PStatSum.ps1 -ErrorAction SilentlyContinue
    $PStatTXTfiles = Get-Item -path ($SDPPath + "*_PStat.txt")
    if ($PStatTXTfiles) {
	"`n [Addon 1] $(Get-Date -UFormat "%R:%S") ...now running PstatSum:"
	& "$($RFLroot)get-PStatSum.ps1" $SDPPath
        }
    	Unblock-File -Path $RFLroot\check-RegistryKeyNames.ps1 -ErrorAction SilentlyContinue
    $RegistryFiles = Get-Item -path ($SDPPath + "*_reg*")
    if ($RegistryFiles) {
	"`n [Addon 2] $(Get-Date -UFormat "%R:%S") ...now [faster] checks for leading or trailing blank/space characters in registry key names in all Reg files:"
	#PowerShell.exe -Command "'$($RFLpath)check-RegistryKeyNames.ps1 $($SDPPath)'; Exit $LASTEXITCODE" > "test.log" 2>&1
	& "$($RFLroot)check-RegistryKeyNames.ps1" $SDPPath
	}
    $PerfCounterFiles = Get-Item -path ($SDPPath + "*_Performance Counter.blg") #_Performance Counter.blg
    if ($PerfCounterFiles) {
	"`n [Addon 3] $(Get-Date -UFormat "%R:%S") ...now running 'Performance Monitor Analyzer':"
	& "$($RFLroot)get-pma.ps1" $SDPPath
    }
    $EvtCheckFiles = Get-Item -path ($SDPPath + "*.evtx")
    if ($EvtCheckFiles) {
	"`n [Addon 4] $(Get-Date -UFormat "%R:%S") ...running [now 30x faster] 'Eventlog provider entries for last 12h ':"
	& "$($RFLroot)get-events.ps1" $SDPPath
    	}
   If ($RunAddon5) {
    	Unblock-File -Path $RFLroot\get-version-RFLShellExt.ps1 -ErrorAction SilentlyContinue
    "`n [Addon 5] $(Get-Date -UFormat "%R:%S") ...now running get-version-RFLShellExt; checking for Explorer shell plugin updates:"
    & "$($RFLroot)get-version-RFLShellExt.ps1" Check-RFL $RFLFixesTech $OSVersion
    } #end If ($RunAddon5)
#    "`n [Addon 6] $(Get-Date -UFormat "%R:%S") ...now performing internal check for AZURE response time in your region (performance test: http://Support.Microsoft.com):"
#    & "$($RFLroot)get-KB-measure.ps1" $SDPPath
   " [Addon's] $(Get-Date -UFormat "%R:%S") ...checks done...  Thx for using this service! Please verify above results. Q's?: ask WalterE or IoanC."
  } #end If ($RunAddon)
  ### Log latest script Addon errors
 If ($StatsErr) {$ScriptErrorAddon = $Error
		 $PS_culture = Get-Culture
  	If ($ScriptErrorAddon){"$j" +  " ;$CheckDate; $OSVersion; $PS_culture; $RFLFixesTech; " + ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name) + "; $($Duration)" + "; $SDPPath" + "; $SDPtype" + "; $ErrorMsg" + "; $NodeCnt" + "; $UsrOSVersion" + "; $ScriptErrorAddon" + "; v$VerMa.$VerMi"| Out-File $CountInvFil4 -Append -Encoding UTF8 -ErrorAction SilentlyContinue}
  }
### Notes/Hints  
If ($OSVersion -eq "2016")  {Write-host -BackgroundColor Yellow -ForegroundColor Black "Note: Windows 10 RTM v1507 CB/CBB - End of Servicing: May 09 2017"}
} #end Process
