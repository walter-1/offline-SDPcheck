# File: common file for get-update-RFLShellExt.ps1 and get-version-RFLShellExt.ps1
# last edit by: waltere 

<#
.SYNOPSIS
The script will show version, install, update to latest version or remove your current version of the SDP/RFL Explorer PlugIn on your system.
The registry file for the latest version of the shell extension is located here: \\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\Rfl-Check_ShellExtension.reg

SYNTAX: .\get-update-RFLShellExt.ps1 [- CheckType Check-RFL|Check_RFL_anchor|Check_SDP_anchor] [-GetVersion|-GetUpdate|-Remove]

.DESCRIPTION
The script reads in your current registry RFL information and writes new registry keys.
The script tries to run -GetUpdate or -Remove in elevated mode and ask user to agree (UAC prompt), because REG changes need admin permission.
Note: In case of any error, you still can download to local drive and doubleclick the *.reg file on
   \\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\Rfl-Check_ShellExtension.reg
	 
Reg-Locations for RFL ShellExtension: "HKCU:\SOFTWARE\RFLcheck\" and
	V1: "HKCR:\Directory\shell\Check-RFL"
		"HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Chk_*" 
	V2: "HKCR:\Directory\shell\Check_RFL_anchor"
		"HKCR:\*\ContextMenus\Check_RFL\Shell"
		"HKCR:\Directory\shell\Check_SDP_anchor"
		"HKCR:\*\ContextMenus\Check_SDP\Shell"

.PARAMETER SkipAdminCheck
	If this switch is present, then the check for administrator privileges will be skipped
	Script needs Admin priv for Remove, and for Update if installed version does not match current version

.PARAMETER Remove
	If this switch is present, then the script will remove old Shell Extension

.PARAMETER GetUpdate
	If this switch is present, then the script will check and update version of Shell Extension 

.PARAMETER GetVersion
	If this switch is present, then the script will check and display version of Shell Extension

.PARAMETER HostMode
	If this switch is present, then the script will display output on screen

.PARAMETER ScriptMode
	If this switch is present, then the script will log output in logfile

.EXAMPLE
	To run the RFL shell PlugIn check and update on UNC path
	\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\get-update-RFLShellExt.ps1 -HostMode -GetUpdate

.EXAMPLE
	To run the RFL shell PlugIn VERSION check only
	\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\get-update-RFLShellExt.ps1 -HostMode -GetVersion

.EXAMPLE
	To remove the RFL shell PlugIn only
	\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\get-update-RFLShellExt.ps1 -HostMode -Remove
	
.LINK
	Update script: \\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\get-update-RFLShellExt.ps1
	ShellExtension: \\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\Rfl-Check_ShellExtension.reg
	RFL core team: waltere@microsoft.com

#>


[CmdletBinding()]
PARAM (
	[ValidateSet("Check-RFL","Check_RFL_anchor","Check_SDP_anchor")]
	[parameter(Mandatory=$False,Position=0,HelpMessage='Choose one from: [Check-RFL|Check_RFL_anchor|Check_SDP_anchor]')]
	[string]$CheckType = "Check_RFL_anchor"
	,
	[parameter(Mandatory=$false)]
	[switch]$SkipAdminCheck = $true,	# if $True, then the check for administrator privileges will be skipped
	[switch]$Elevated 		= $false,	# This will run script in elevated Admin mode
	[switch]$Script:IsRunAsAdmin = $false,
	[switch]$Remove 		= $false,	# $True for script remove-RFLShellExt.ps1
	[switch]$GetUpdate 	= $false,		# $True for script get-update-RFLShellExt.ps1
	[switch]$GetVersion 	= $true,	# $True for script get-version-RFLShellExt.ps1
	[switch]$InformUser		= $true,	# $False for suppressing Update info for user
	[switch]$HostMode		= $true,	# This tells the logging functions to show logging on the screen
	[switch]$ScriptMode		= $false, 	# This tells the logging functions to show logging into log file
	[switch]$UseExitCode	= $true,	# This will cause the script to close after the error is logged if an error occurs
	[Switch]$DebugMode,					# used for debugging
	[switch]$DbgOut 		= $false	# $True for script debugging
)

BEGIN {
	$verDateScript = "2023.02.09.0"
	$ScriptFolder = Split-Path $MyInvocation.MyCommand.Path -Parent
	# Load Common Library:
	. $ScriptFolder\Utils_RflShared.ps1

	# This saves the starting ErrorActionPreference and then sets it to 'Stop'.
	$startErrorActionPreference = $errorActionPreference
	# This gets the current path and name of the script.
	$invocation = (Get-Variable MyInvocation).Value
	$scriptPath = Split-Path $invocation.MyCommand.Path
	$FullScriptPath = (Get-Variable MyInvocation).Value.MyCommand.Path
	if ($DbgOut) {
		Write-host "invocation: $invocation"
		Write-host "scriptPath: $scriptPath"
		Write-host "FullScriptPath: $FullScriptPath"
	}
	$scriptName = $invocation.MyCommand.Name
	#$scriptDefinition = $myinvocation.MyCommand.Definition	#Full script path
	$UserName  = ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name)
	$UsrOSVersion = [Environment]::OSVersion.Version.ToString(3)
	if ($DbgOut) {Write-Host "Running `"$scriptPath\$scriptName`"..." -BackgroundColor Black -ForegroundColor Green}
	Set-Variable -Name ErrorMsg -Scope Script -Force
	[string]$Script:ErrorMsg=""
	
#region: ###### customization section of script, logging configuration ########################
	$SDPcheckINI = (Get-content -Path "$ScriptFolder\_SDPcheck.ini")
	$InOfflineMode 	= (($SDPcheckINI[1] -split " ")[2]).trim("""")	# set $True for outsourcer or when not connected to MS network - offline-SDPcheck
	$ExpectedShellExtVersion = (($SDPcheckINI[6] -split " ")[2]).trim("""")
	$RFLroot = (($SDPcheckINI[2] -split " ")[2]).trim("""")	# "\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\" -or- "\\localhost\ToolsShare\rfl\"
	if ($InOfflineMode -match "False") {
		$StatsServer = (($SDPcheckINI[5] -split " ")[2]).trim("""")
		if (Test-Connection -ComputerName $StatsServer -Quiet -Count 1) {[bool]$Stats=$True} else {[bool]$Stats=$False}
	} else { 
		$Stats = $False
	}
	$LogLevel = 0
	$CheckDate = (Get-Date).ToUniversalTime().ToString("yy-MM-dd_HH-mm-ss")
	$Script:regFileV1remove = "$RFLroot\Rfl-Check_ShellExtension_V1-Remove.reg"
	$Script:regFileV2add = "$RFLroot\Rfl-Check_ShellExtension.reg"
	$Script:regFileV2remove = "$RFLroot\Rfl-Check_ShellExtension_Remove.reg"
	#$ExpectedShellExtVersionV1 = "1.11"	# in registry HKCR:\Directory\shell\Check-RFL
#endregion: ###### customization section
	if ($Stats) {
		$StatsServerPath = "\\$StatsServer\RFLstats$\RFL\scripts\Stats\"

		if ($GetVersion) {
			[string]$InfoString = "RFLshExt_Version"
			$CountInvFil = $StatsServerPath +'countRFLshExVer.dat'
		}
		if ($GetUpdate) {
			[string]$InfoString = "RFLshExt_Update"
			$CountInvFil = $StatsServerPath +'countRFLshExUpd.dat'
		}
		if ($Remove) {
			Write-Host "`n Note: Admin priv needed for -Remove" 
			[string]$InfoString = "RFLshExt_Remove"
			$CountInvFil = $StatsServerPath +'countRFLshExRemove.dat'
		}
		$CountInvFil2 = $CountInvFil +'.us'
		#increment at start of script
		 ($j=[int32](Get-Content $CountInvFil -TotalCount 1 -ErrorAction SilentlyContinue)) |out-null
		 Try {(++$j) | Set-Content $CountInvFil -ErrorAction SilentlyContinue} Catch { }
	}
	#initialize
	$ErrorThrown = $null
	$Script:CurrShellExtVer ='undefined'
	$Script:ResultMsg = ""

	If ($PSBoundParameters['Debug']) { $DebugPreference='Continue'}
	Set-Variable -Name ShellExtExists	-Scope Script -Force
	Set-Variable -Name ShellExtVersion	-Scope Script -Force
	Set-Variable -Name regFile 		-Scope Script -Force
	Set-Variable -Name FullScriptPath	-Scope Script -Force
			
#region: Script Functions
function CheckAdminPrivileges {
	# SYNOPSIS: check for PowerShell Admin priv
	# Return: $True if running as Admin
	[CmdletBinding()]
	Param(
		[parameter(Mandatory=$true)] [Bool] $SkipAdminCheck
	)
	EnterFuncDbg $MyInvocation.MyCommand.Name
	if ($DbgOut) {Write-host "ENTER: CheckAdminPrivileges"}
	if (-not $SkipAdminCheck) {
		# Yep, this is the easiest way to do this.
		$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")
		if (-not $isAdmin) {
			throw "You do not have the required permission to complete this task. Please run this command in an Administrator PowerShell window or specify the -SkipAdminCheck option."
		}
	}
	EndFunc $MyInvocation.MyCommand.Name
}

function Test-Admin {
	# SYNOPSIS: check for PowerShell Admin priv
	# Return: $True if running as Admin, $False if not
	EnterFuncDbg $MyInvocation.MyCommand.Name
	if ($DbgOut) {Write-host "ENTER: Test-Admin"}
	$currentUser = New-Object Security.Principal.WindowsPrincipal $([Security.Principal.WindowsIdentity]::GetCurrent())
	$currentUser.IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)
	EndFunc $MyInvocation.MyCommand.Name
}

function checkRegKey ($rKey) {
	# SYNOPSIS - check if RegKey exists
	# Return: $True if found, $False if not found 
	EnterFuncDbg $MyInvocation.MyCommand.Name
	if ($DbgOut) {Write-host "ENTER: checkRegKey"}
	New-PSDrive -Name HKCR -PSProvider Registry -Root HKEY_CLASSES_ROOT |out-null
	$ErrorActionPreference = "stop"
	Try { 
		$exists = Get-Item -Path $rKey
		if ($exists) {WriteInfo -message "$rKey exists." 
		return $True}
		}
	Catch [System.Management.Automation.PSArgumentException]
	 {	 return $False}
	Catch [System.Management.Automation.ItemNotFoundException]
	 {	WriteError -message "$rKey is missing."
		return $False }
	Finally { $ErrorActionPreference = "Continue" }
	EndFunc $MyInvocation.MyCommand.Name
} # end of checkRegKey

function checkPlugin-ShellExt ($CheckType,$registryPath,$CheckedVer) {
	# SYNOPSIS - check if RFLShellExt is installed, Write message to user if Plugin is missing
	# $CheckType can be "Check-RFL" or "Check_RFL_anchor" or "Check_SDP_anchor"
	# Return: '__Found ..' or '.. itself is missing'
	EnterFuncDbg $MyInvocation.MyCommand.Name
	if ($DbgOut) {Write-host "ENTER: checkPlugin-ShellExt"}
	 New-PSDrive -Name HKCR -PSProvider Registry -Root HKEY_CLASSES_ROOT |out-null
	 #$registryPath = "HKCR:\Directory\shell\$($CheckType)"
	 $ErrorActionPreference = "stop"
	 
	 Try { 
		#check if RFLShellExt is installed and 'Version' key exists
		WriteInfo -message "[RFLshExt_Plugin] _Checking for existing ShellExt $($CheckType) in $registryPath"
		$Script:ShellExtKey = (Get-ItemProperty -Path $registryPath -ErrorAction SilentlyContinue)
		if ($Script:ShellExtKey) {
			$Script:CurrShellExtVer = $($Script:ShellExtKey.Version)
			WriteInfo -message "[$InfoString`] __Found ShellExt in $registryPath ver: $Script:CurrShellExtVer "
			$Script:ResultMsg += "$CheckedVer $CheckType ver: $Script:CurrShellExtVer "
		}
			# EndFunc ($MyInvocation.MyCommand.Name + "(Found $Script:CurrShellExtVer)")
			#return "Found $Script:CurrShellExtVer"
	 }
	 Catch [System.Management.Automation.ItemNotFoundException]
	 {
		if ($InformUser) {
			 #Write message to user if Plugin is missing
			 Write-host -BackgroundColor Black -ForegroundColor Yellow -Object "... Simplify: Consider to run Explorer-Extension V2 update $ExpectedShellExtVersion in elevated PowerShell window, see also _Help.rtf:"
			 Write-host -BackgroundColor Black -ForegroundColor Cyan -Object " Powershell -ExecutionPolicy Bypass $RFLroot\get-update-RFLShellExt.ps1"
		}
		WriteError -message "$registryPath itself is missing."
		$Script:ResultMsg += "$CheckedVer $CheckType is missing. "
		EndFunc ($MyInvocation.MyCommand.Name + "($CheckedVer $registryPath itself is missing.)")
		return "$CheckedVer $registryPath itself is missing."
	}
	 Finally { $ErrorActionPreference = "Continue" }
	 EndFunc $MyInvocation.MyCommand.Name
} # end of checkPlugin-ShellExt

function checkVer-ShellExt ($CheckType,$registryPath,$ExpectedShellExtVersion) {
	# SYNOPSIS - check if RFLShellExt 'Version' key exists
	# Return: "$Script:CurrShellExtVer _up_to_date" - "$Script:CurrShellExtVer _outdated - user_informed." - ".. Property Version missing." - ""
	 #check if 'Version' key exists
	 EnterFuncDbg $MyInvocation.MyCommand.Name
	 if ($DbgOut) {Write-host "ENTER: checkVer-ShellExt"}
	 New-PSDrive -Name HKCR -PSProvider Registry -Root HKEY_CLASSES_ROOT |out-null
	 #$registryPath = "HKCR:\Directory\shell\$($CheckType)"
	 Try { $ErrorActionPreference = "stop"
		WriteInfo -message "[$InfoString`] _Checking current version for $($CheckType) in $registryPath"
		$Script:CurrShellExtVer = (Get-ItemProperty -Path $registryPath -Name Version -ErrorAction SilentlyContinue).Version
		if ($Script:CurrShellExtVer){
			WriteInfo -message "[$InfoString`] __comparing your RFL ShellExtension version: $Script:CurrShellExtVer with latest $Script:ExpectedShellExtVersion"
			if ($Script:CurrShellExtVer -match $ExpectedShellExtVersion){
				WriteInfo -message "[$InfoString`] __Your RFL ShellExtension version $Script:CurrShellExtVer is up-to-date";
				EndFunc ($MyInvocation.MyCommand.Name + "($Script:CurrShellExtVer _up_to_date.)")
				return " $Script:CurrShellExtVer _up_to_date"
			}
			else {
				if ($Script:CurrShellExtVer -lt 1.09) {Write-host -BackgroundColor Black -ForegroundColor Red -Object " Support for this older RFL version has ended."}
				Write-host -BackgroundColor Yellow -ForegroundColor Black -Object "[$InfoString`] __Your RFL ShellExtension version $Script:CurrShellExtVer is outdated! (Available: v$ExpectedShellExtVersion)
	 .. Consider updating the RFL Shell Explorer Plugin to v$ExpectedShellExtVersion `n $Script:regFileV2add
	 To do so, run in ELEVATED (Run as Administrator) PS window the commands:"
				Write-host -ForegroundColor Cyan -Object " Powershell -ExecutionPolicy Bypass $RFLroot\remove-RFLShellExt.ps1"
				Write-host -ForegroundColor Cyan -Object " Powershell -ExecutionPolicy Bypass $RFLroot\get-update-RFLShellExt.ps1"
				EndFunc ($MyInvocation.MyCommand.Name + "($Script:CurrShellExtVer _outdated - user_informed.)")
				return "$Script:CurrShellExtVer _outdated - user_informed."
			}
		}
		else { WriteInfo -message "[$InfoString`] $registryPath\Version not found"
			$Script:CurrShellExtVer ='V-undefined'
		}
	}
	Catch [System.Management.Automation.PSArgumentException]
	{	
		EndFunc ($MyInvocation.MyCommand.Name + "([$InfoString`] RegKey $registryPath Property Version missing.)")
		return "[$InfoString`] RegKey $registryPath Property Version missing."
	}
	Catch [System.Management.Automation.ItemNotFoundException]
	{ WriteInfo -message "[$InfoString`] RegKey $registryPath\Version is missing."
		 Write-debug "[$InfoString`] ...RFLshellPlugin not up-to-date - creating it."
		 Write-debug "[$InfoString`] ...***please allow registry Version update when UAC prompted***"
		 EndFunc ($MyInvocation.MyCommand.Name + "([$InfoString`] $registryPath\Version is missing.)")
		 return "[$InfoString`] RegKey $registryPath\Version is missing."
	}
	Finally { $ErrorActionPreference = "Continue" }
	EndFunc $MyInvocation.MyCommand.Name
} # end of checkVer-ShellExt

function CheckForUpdates-RFLShellExt ($CheckType,$ExpectedShellExtVersion) { ### currently not in use
	# SYNOPSIS - 													
	# Return: nothing
	EnterFuncDbg $MyInvocation.MyCommand.Name
	if ($DbgOut) {Write-host "ENTER: CheckForUpdates-RFLShellEx"}
		WriteInfo -message "[RFLshExt_ChkUpdates] checking registryPath: $registryPathHKCR\CheckForUpdates"
		$name = "CheckForUpdates"
		$value = "1"
		 Try { $ErrorActionPreference = "stop"
		$CheckForUpdates = (Get-ItemProperty -Path $registryPathHKCR -Name CheckForUpdates -ErrorAction SilentlyContinue).CheckForUpdates
		if ($CheckForUpdates) {WriteInfo -message "[RFLshExt_ChkUpdates] Current CheckForUpdates: $CheckForUpdates"}
		if ($CheckForUpdates -NotMatch "0") {WriteInfo -message "[RFLshExt_ChkUpdates] Current ShellExt setting for CheckForUpdates: $CheckForUpdates"}
		else {	WriteInfo -message "[RFLshExt_ChkUpdates] CheckForUpdates: '$CheckForUpdates' - .. Consider updating the RFL Shell Explorer Plugin to v$ExpectedShellExtVersion `n $Script:regFileV2add "
			WriteInfo -message "[RFLshExt_ChkUpdates] ... keep existing plugin settings because $registryPathHKCR\CheckForUpdates is set to '$CheckForUpdates'"
			break #continue
			}
		}
		Catch [System.Management.Automation.PSArgumentException]
		 { "[RFLshExt_ChkUpdates] RegKey $registryPathHKCR Property $name missing."
			New-ItemProperty -Path $registryPathHKCR -Name $name -Value $value -PropertyType DWORD -Force | Out-Null
		 }
		Catch [System.Management.Automation.ItemNotFoundException]
		 { "[RFLshExt_ChkUpdates] RegKey $registryPathHKCR itself is missing."
			WriteInfo -message "[RFLshExt_ChkUpdates] ...RFLshellPlugin not installed - creating it"
			New-Item -Path $registryPathHKCR -Force #| Out-Null
			New-ItemProperty -Path $registryPathHKCR -Name $name -Value $value -PropertyType DWORD -Force | Out-Null
		}
		Finally {
			"[RFLshExt_ChkUpdates] CheckForUpdates reg: $CheckForUpdates"
			$ErrorActionPreference = "Continue" }
	EndFunc $MyInvocation.MyCommand.Name
} # end of CheckForUpdates-RFLShellExt

function update-ShellExt ($CheckType,$ExpectedShellExtVersion) {
	# SYNOPSIS - update the existing ShellExtension
	# Return: nothing
	#IF (!($Script:CurrShellExtVer -match $ExpectedShellExtVersion) -and ($CheckForUpdates -NotMatch "0")) {
	EnterFuncDbg $MyInvocation.MyCommand.Name
	if ($DbgOut) {Write-host "ENTER: update-ShellExt"}
	if ($Script:CurrShellExtVer -NotMatch $ExpectedShellExtVersion) {
		#WriteInfo -message "[$InfoString`] ...Outdated Check-RFL ShellExtVersion '$Script:CurrShellExtVer', removing existing entry $registryPathHKCR '$Script:CurrShellExtVer'"
		Try
			{
			WriteInfo -message "[$InfoString`] ...***please allow registry REMOVE when UAC prompted***"

			WriteInfo -message "[$InfoString`] ...Step#1 Remove v1: Importing $Script:regFileV1remove silently"
			WriteInfo -message "[$InfoString`] ...***please allow registry UPDATE when UAC prompted***"
			$RegTry = regedit /s $Script:regFileV1remove

			WriteInfo -message "[$InfoString`] ...Step#2 Importing latest $Script:regFileV2add silently"
			WriteInfo -message "[$InfoString`] ...***please allow registry UPDATE when UAC prompted***"
			$RegTry = regedit /s $Script:regFileV2add
			#WriteInfo -message "[$InfoString`] ...RegTry result: $RegTry"
			Write-host -BackgroundColor Black -ForegroundColor Green -Object "[$InfoString`] RFLShellExt $CheckType successfully updated"
			"RegImport-done for exp. v$ExpectedShellExtVersion"
			}
		Catch [System.Security.SecurityException]
			{ WriteError -message "Registry Remove-Item $registryPathHKCR"
				WriteError -message "[$InfoString`] Aborted. The error was '$($_.Exception.Message)'"
				Write-host -BackgroundColor Black -ForegroundColor Red -Object "[$InfoString`] Aborted by user"
				"Aborted by user."
			}
		Finally
			{
			"RegVersion-not-matched, inst.Ver: '$Script:CurrShellExtVer'"
			}
	}
	EndFunc $MyInvocation.MyCommand.Name
} # end of update-ShellExt

function autoupdate-ShellExt ($CheckType,$registryPath,$ExpectedShellExtVersion) { ### currently not in use
	# SYNOPSIS - AutoUpdate the existing ShellExtension
	# Return: nothing
	EnterFuncDbg $MyInvocation.MyCommand.Name
	if ($DbgOut) {Write-host "ENTER: autoupdate-ShellExt"}
		if ($Script:ShellExtKey)	{
		checkVer-ShellExt $CheckType $registryPath $ExpectedShellExtVersion		#call function
		if ($Script:CurrShellExtVer -lt 1.09) {
			if ($GetVersion) {
				Write-host -BackgroundColor Black -ForegroundColor Yellow -Object "`n Trying Auto-Update, Please agree when prompted for running in elevated PS and Registry modification."
				Powershell -noprofile -ExecutionPolicy Bypass $RFLroot\get-update-RFLShellExt_v1.16.ps1 -SkipAdminCheck -GetUpdate
				checkVer-ShellExt $CheckType $registryPath $ExpectedShellExtVersion
				if ($Script:CurrShellExtVer -match $ExpectedShellExtVersion) {Write-host -BackgroundColor Black -ForegroundColor Green -Object " AutoUpdate version completed: v$Script:CurrShellExtVer"}
			}
		}
	}
	if ($GetUpdate) {update-ShellExt $CheckType $ExpectedShellExtVersion}	#call function
	EndFunc $MyInvocation.MyCommand.Name
} #end function autoupdate-ShellExt

function remove-ShellExt ($CheckType,$registryPath) {
	# SYNOPSIS - Delete all the registry rentries for the existing ShellExtension
	# Return: result of action done
	EnterFuncDbg $MyInvocation.MyCommand.Name
	if ($DbgOut) {Write-host "ENTER: remove-ShellExt"}
	WriteInfo -message "[RFLshExt_Remove] Checking ShellExt for $($CheckType) $registryPath"
	switch($registryPath)
		{
		"$($registryPathHKCR)"		{New-PSDrive -Name HKCR -PSProvider Registry -Root HKEY_CLASSES_ROOT |out-null}
		"$($registryPathHKCR2)"		{New-PSDrive -Name HKCR -PSProvider Registry -Root HKEY_CLASSES_ROOT |out-null}
		"$($registryPathHKLM)"		{New-PSDrive -Name HKLM -PSProvider Registry -Root HKEY_LOCAL_MACHINE |out-null}
		"$($registryPathHKCU)"		{New-PSDrive -Name HKCU -PSProvider Registry -Root HKEY_CURRENT_USER |out-null}
		}
	
	#WriteInfo -message "[RFLshExt_Remove] ...***please allow registry REMOVE when UAC prompted***"
	$ErrorActionPreference = "stop"
	
	Try
	{
		$Script:RegPathKey = (Get-ItemProperty -Path $registryPath )
		if ($Script:RegPathKey) {
			WriteInfo -message "[RFLshExt_Remove] _Trying to remove registry-tree $registryPath"
			Remove-Item $registryPath -Recurse
			EndFunc ($MyInvocation.MyCommand.Name + "(removed $registryPath)")
			return " removed $registryPath"
		}
	}
	Catch [System.Security.SecurityException]
		{	WriteError "RegKey $registryPath SecurityException" 
			WriteError "[RFLshExt_Remove] Aborted. The error was '$($_.Exception.Message)'"
			WriteError "[RFLshExt_Remove] Aborted by user SecurityException"
			EndFunc ($MyInvocation.MyCommand.Name + "( RegRemove $registryPath aborted by user SecurityException)")
			return " RegRemove $registryPath aborted by user SecurityException."
		}
	Catch [System.Management.Automation.ItemNotFoundException]
		{	WriteError "[RFLshExt_Remove] Cannot find path or item $registryPath"
			EndFunc ($MyInvocation.MyCommand.Name + "( RegRemove ItemNotFoundException)")
			return " RegRemove ItemNotFoundException."
		}
	#Catch [System.Management.Automation.PathNotFound]
	#	{ "[RFLshExt_Remove] Cannot find path $registryPath"}
	Finally
	{
		$ErrorActionPreference = "Continue" 
		#"RFLShellExt $CheckType successfully removed"
	}
	EndFunc $MyInvocation.MyCommand.Name
} # end of remove-ShellExt

function LaunchElevated {
 # SYNOPSIS : Launches an elevated process running the current script to perform tasks that require administrative privileges. This function waits until the elevated process terminates.
	# Set up command line arguments to the elevated process
	EnterFuncDbg $MyInvocation.MyCommand.Name
	if ($DbgOut) {Write-host "ENTER: LaunchElevated"}
	$Script:RelaunchArgs = '-NoExit -ExecutionPolicy Bypass -file "' + $FullScriptPath + '" -IsRunAsAdmin'

	# Launch the process and wait for it to finish
	try
	{
		$AdminProcess = Start-Process "$PsHome\PowerShell.exe" -Verb RunAs -ArgumentList $Script:RelaunchArgs -PassThru
	}
	catch
	{
		$Error[0] # Dump details about the last error
		exit 1
	}

	# Wait until the elevated process terminates
	while (!($AdminProcess.HasExited))
	{
		Start-Sleep -Seconds 2
	}
	EndFunc $MyInvocation.MyCommand.Name
}

function DoElevatedOperations {	#currently not used
	EnterFuncDbg $MyInvocation.MyCommand.Name
	Write-Host "Do elevated operations"
	Start-Sleep -Seconds 5
	EndFunc $MyInvocation.MyCommand.Name
}

function DoStandardOperations {
	EnterFuncDbg $MyInvocation.MyCommand.Name
	Write-Host "Do standard operations"

	LaunchElevated
	Start-Sleep -Seconds 5
	EndFunc $MyInvocation.MyCommand.Name
}

function DoGetVersion ($CheckType,$ExpectedShellExtVersion) {
#	$CallStack = Get-PSCallStack
#	Write-host -ForegroundColor Cyan "CS: $CallStack"
#	$CallerInfo = $CallStack[1]
#	If($CallerInfo.FunctionName -eq '<ScriptBlock>'){
#		 $FuncName = 'Main'
#	}Else{
#		$FuncName = $CallerInfo.FunctionName
#	}
#	EnterFunc ("$($MyInvocation.MyCommand.Name)" + "(Caller - $($FuncName):$($CallerInfo.ScriptLineNumber))")
	EnterFuncDbg $MyInvocation.MyCommand.Name
	if ($DbgOut) {Write-host "ENTER: DoGetVersion"}
	# define registry locations for v1 Check-RFL, and v2 Check_RFL_anchor, Check_SDP_anchor
	$registryPathHKCU = "HKCU:\SOFTWARE\RFLcheck\shellExtension" 
	switch($CheckType)
	{
	"Check-RFL"			{ $CheckedVer = "v1"
						$registryPathHKCR = "HKCR:\Directory\shell\Check-RFL"
						$registryPathHKLM = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Chk_*" 
						}
	"Check_RFL_anchor"	{ $CheckedVer = "v2"
						$registryPathHKCR = "HKCR:\Directory\shell\Check_RFL_anchor"
						$registryPathHKCR2 = "HKCR:\*\ContextMenus\Check_RFL\Shell" 
						}						
	"Check_SDP_anchor"	{ $CheckedVer = "v2"
						$registryPathHKCR = "HKCR:\Directory\shell\Check_SDP_anchor"
						$registryPathHKCR2 = "HKCR:\*\ContextMenus\Check_SDP\Shell" 
						}
	}

	WriteInfo -message "$CheckedVer CheckType: $CheckType REG: $registryPathHKCR"
	
	#$au = autoupdate-ShellExt $CheckType $registryPathHKCR $ExpectedShellExtVersion	#call function
	checkPlugin-ShellExt $CheckType $registryPathHKCR $CheckedVer
	WriteInfo -message "[$InfoString`] GetVersion results: $Script:ResultMsg"
	if ($Script:CurrShellExtVer -NotMatch $ExpectedShellExtVersion) {
		Write-host -BackgroundColor Black -ForegroundColor Yellow -Object "... Outdated current $Script:CurrShellExtVer : Consider to run Explorer-Extension V2 update $ExpectedShellExtVersion in elevated PowerShell window, see also _Help.rtf:"
		Write-host -BackgroundColor Black -ForegroundColor Cyan -Object " Powershell -ExecutionPolicy Bypass $RFLroot\get-update-RFLShellExt.ps1" 
		[System.Media.SystemSounds]::Hand.Play() } # Play sound to get some attention 
	#$Script:ResultMsg += $au
	If ($Script:ResultMsg -match $ExpectedShellExtVersion) { Write-Host -ForegroundColor Green -Object "[$InfoString`] OK, you are running latest RFL/SDPcheck Explorer PlugIn version $($ExpectedShellExtVersion)"}
	else { 
		Write-Host -ForegroundColor Red -Object "[$InfoString`] Your RFL/SDP Eplorer Plug-in version $Script:CurrShellExtVer is outdated, expected: $($ExpectedShellExtVersion)"
		Write-Host -ForegroundColor cyan -Object "[$InfoString`] for update, run: $RFLroot\get-update-RFLShellExt.ps1"
	}
	If ($Script:ResultMsg -match "missing") {
		WriteInfo -message "[$InfoString`] .. Consider installing the RFL Shell Explorer Plugin v$ExpectedShellExtVersion`n	$Script:regFileV2add
To do so, run in elevated (Run as Administrator) PS window the command: 
Powershell -ExecutionPolicy Bypass $RFLroot\get-update-RFLShellExt.ps1"
	}
	EndFunc $MyInvocation.MyCommand.Name
	return $Script:ResultMsg
}

function DoGetUpdate ($CheckType,$ExpectedShellExtVersion) {
	EnterFuncDbg $MyInvocation.MyCommand.Name
	if ($DbgOut) {Write-host "ENTER: DoGetUpdate"}
	$au = update-ShellExt $CheckType $ExpectedShellExtVersion		#call function
	Write-host -BackgroundColor Black -ForegroundColor Green -Object "[$InfoString`] ...done. New RFL ShellExt $ExpectedShellExtVersion plugin should be available in your Windows Explorer context menu for folders right now."
	WriteInfo -message "Note: In case of any error, you still can download to local drive and doubleclick the *.reg file on`n $($RFLroot)\Rfl-Check_ShellExtension.reg"
	$Script:ResultMsg += $au
	EndFunc $MyInvocation.MyCommand.Name
}

function DoRemove ($CheckType,$ExpectedShellExtVersion) {
	EnterFuncDbg $MyInvocation.MyCommand.Name
	if ($DbgOut) {Write-host "ENTER: DoRemove"}
	WriteInfo -message "[RFLshExt_Remove] ***Deleting reg-locations for RFL Shell-Extension version '$Script:CurrShellExtVer'`n "
	$registryPaths = $registryPathHKCR,$registryPathHKLM,$registryPathHKCU
	foreach ($registryPath in $registryPaths)
		{
		$exists = checkRegKey $registryPath
		if ($exists) { 
			$au += remove-ShellExt $CheckType $registryPath	#call function "Check-RFL"
			WriteInfo -message "[RFLshExt_Remove] __results: $au `n"
			}
		}
	$Script:ResultMsg = $au
	EndFunc $MyInvocation.MyCommand.Name
}
#endregion: Script Functions
} #end BEGIN


PROCESS {
	try {
			$ScriptBeginTimeStamp = Get-Date
			#region: MAIN :::::

			if ($GetVersion) {
				$V2check = DoGetVersion Check_RFL_anchor $ExpectedShellExtVersion
				WriteInfo -message "[$InfoString`] *** V2check: $V2check"
#				if ($Script:ResultMsg -notmatch "2.0") {
#					$V1check = DoGetVersion Check-RFL $ExpectedShellExtVersionV1
#					WriteInfo -message "[$InfoString`] *** V1check : $V1check"
#				}
			}

			if ($GetUpdate) {
				$V2check = DoGetVersion Check_RFL_anchor $ExpectedShellExtVersion
				if ($Script:CurrShellExtVer -NotMatch $ExpectedShellExtVersion) { 
					DoGetUpdate $CheckType $ExpectedShellExtVersion
				} else { WriteInfo -message "-GetUpdate requires Admin priv."}
			}

			if ($Remove) {
				if ((Test-Admin) -eq $true) { DoRemove $CheckType $ExpectedShellExtVersion}
				else { WriteInfo -message "-Remove requires Admin priv."
					#.\get-update-RFLShellExt_v1.16.ps1 -CheckType Check-RFL -Remove -Hostmode
					DoStandardOperations
					Write-Host "RelaunchArgs: $Script:RelaunchArgs"
					#DoElevatedOperations
							
					#LaunchElevated 
					#Start-Sleep -Seconds 5
				<#	if ($IsRunAsAdmin) {
						Write-Host "RelaunchArgs: $RelaunchArgs"
						DoElevatedOperations
					}
					else
						{
							DoStandardOperations
						} #>
				}
			}
			WriteInfo -message "Overall-Results: $Script:ResultMsg"
			#endregion: MAIN
	} # end try PROCESS
	catch {
		$errorMessage = "$scriptName caught an exception on $($ENV:COMPUTERNAME):"
		$errorMessage += "`n`n"
		$errorMessage += "Exception Type: $($_.Exception.GetType().FullName)"
		$errorMessage += "`n`n"
		$errorMessage += "Exception Message: $($_.Exception.Message)"

		Write-Error $errorMessage -ErrorAction Continue
		Write-Debug $errorMessage
		if ( $UseExitCode ) {
			$error.clear()	# clear script errors
			exit 1
		} #end UseExitCode
	} #end Catch PROCESS
	Finally {
	}
} #end PROCESS

END {
	$ScriptEndTimeStamp = Get-Date
	$Duration = $(New-TimeSpan -Start $ScriptBeginTimeStamp -End $ScriptEndTimeStamp)
	$LogLevel = 0
	#Write-Host -BackgroundColor Gray -ForegroundColor Black -Object "[Done] Script $scriptName v$verDateScript execution finished. Duration: $Duration"
	WriteInfo -message "[Done] Script $scriptName v$verDateScript execution finished. Duration: $Duration `n"
	if($ErrorThrown) {Throw $error[0].Exception.Message}
	# Stats
	If ($Stats) { #increment at start of script
		Try {"$j; $CheckDate; $UsrOSVersion; $UserName; $Duration; [$InfoString`]; $Script:CurrShellExtVer; $Script:ResultMsg; v$verDateScript ; $env:computername" | Out-File $CountInvFil2 -Append -Encoding UTF8 -ErrorAction SilentlyContinue} Catch { }
	}
  # This resets the ErrorActionPreference to the value at script start.
  $errorActionPreference = $startErrorActionPreference
	#Write full error message
	#$error[0] |fl * -force
} #end END

#region: comments
<#
	The top section is comment based help so the Get-Help command will work with the script.
	The [CmdletBinding()] turns on advanced options like the common parameters.
	All sub functions are in the "BEGIN" section.
	My script code goes in the "PROCESS try" block.

VERSION and AUTHOR:
	Walter Eder	- waltere@microsoft.com

HISTORY
	2015-02-02	V1.04
	2016-07-02	V1.06 add capability to remove all RFL registry settings, see remove-RFLShellExt.ps1
	2017-04-03	V1.08 (removed platform, re-added VSS in Rfl-Check_ShellExtension_FQDN.reg)
	2017-10-06	v1.11 changed [RFLshExt_Update] to [$InfoString`] + output enhancements
	2017-11-19	v1.13 using PS fuctions
	2019-01-13	v1.16 consolidating get-version-RFLShellExt.ps1 and get-update-RFLShellExt.ps1 and remove-RFLShellExt.ps1
	2019-09-26	v1.18 new ShellExtVersion v2.08, $InformUser= $true 
	2022-09-08 using Utils_RflShared.psm1 library
	
	ToDo: 	/known issue:
	#https://blogs.msdn.microsoft.com/virtual_pc_guy/2010/09/23/a-self-elevating-powershell-script/

#>
#endregion: comments 


# SIG # Begin signature block
# MIInzgYJKoZIhvcNAQcCoIInvzCCJ7sCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDdkvh7FbIAuXUZ
# hY+6chJRhSWHZlYFBx8IQcsrYey0daCCDYUwggYDMIID66ADAgECAhMzAAADTU6R
# phoosHiPAAAAAANNMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjMwMzE2MTg0MzI4WhcNMjQwMzE0MTg0MzI4WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDUKPcKGVa6cboGQU03ONbUKyl4WpH6Q2Xo9cP3RhXTOa6C6THltd2RfnjlUQG+
# Mwoy93iGmGKEMF/jyO2XdiwMP427j90C/PMY/d5vY31sx+udtbif7GCJ7jJ1vLzd
# j28zV4r0FGG6yEv+tUNelTIsFmmSb0FUiJtU4r5sfCThvg8dI/F9Hh6xMZoVti+k
# bVla+hlG8bf4s00VTw4uAZhjGTFCYFRytKJ3/mteg2qnwvHDOgV7QSdV5dWdd0+x
# zcuG0qgd3oCCAjH8ZmjmowkHUe4dUmbcZfXsgWlOfc6DG7JS+DeJak1DvabamYqH
# g1AUeZ0+skpkwrKwXTFwBRltAgMBAAGjggGCMIIBfjAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUId2Img2Sp05U6XI04jli2KohL+8w
# VAYDVR0RBE0wS6RJMEcxLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJh
# dGlvbnMgTGltaXRlZDEWMBQGA1UEBRMNMjMwMDEyKzUwMDUxNzAfBgNVHSMEGDAW
# gBRIbmTlUAXTgqoXNzcitW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8v
# d3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIw
# MTEtMDctMDguY3JsMGEGCCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDEx
# XzIwMTEtMDctMDguY3J0MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIB
# ACMET8WuzLrDwexuTUZe9v2xrW8WGUPRQVmyJ1b/BzKYBZ5aU4Qvh5LzZe9jOExD
# YUlKb/Y73lqIIfUcEO/6W3b+7t1P9m9M1xPrZv5cfnSCguooPDq4rQe/iCdNDwHT
# 6XYW6yetxTJMOo4tUDbSS0YiZr7Mab2wkjgNFa0jRFheS9daTS1oJ/z5bNlGinxq
# 2v8azSP/GcH/t8eTrHQfcax3WbPELoGHIbryrSUaOCphsnCNUqUN5FbEMlat5MuY
# 94rGMJnq1IEd6S8ngK6C8E9SWpGEO3NDa0NlAViorpGfI0NYIbdynyOB846aWAjN
# fgThIcdzdWFvAl/6ktWXLETn8u/lYQyWGmul3yz+w06puIPD9p4KPiWBkCesKDHv
# XLrT3BbLZ8dKqSOV8DtzLFAfc9qAsNiG8EoathluJBsbyFbpebadKlErFidAX8KE
# usk8htHqiSkNxydamL/tKfx3V/vDAoQE59ysv4r3pE+zdyfMairvkFNNw7cPn1kH
# Gcww9dFSY2QwAxhMzmoM0G+M+YvBnBu5wjfxNrMRilRbxM6Cj9hKFh0YTwba6M7z
# ntHHpX3d+nabjFm/TnMRROOgIXJzYbzKKaO2g1kWeyG2QtvIR147zlrbQD4X10Ab
# rRg9CpwW7xYxywezj+iNAc+QmFzR94dzJkEPUSCJPsTFMIIHejCCBWKgAwIBAgIK
# YQ6Q0gAAAAAAAzANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlm
# aWNhdGUgQXV0aG9yaXR5IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEw
# OTA5WjB+MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYD
# VQQDEx9NaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG
# 9w0BAQEFAAOCAg8AMIICCgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+la
# UKq4BjgaBEm6f8MMHt03a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc
# 6Whe0t+bU7IKLMOv2akrrnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4D
# dato88tt8zpcoRb0RrrgOGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+
# lD3v++MrWhAfTVYoonpy4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nk
# kDstrjNYxbc+/jLTswM9sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6
# A4aN91/w0FK/jJSHvMAhdCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmd
# X4jiJV3TIUs+UsS1Vz8kA/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL
# 5zmhD+kjSbwYuER8ReTBw3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zd
# sGbiwZeBe+3W7UvnSSmnEyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3
# T8HhhUSJxAlMxdSlQy90lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS
# 4NaIjAsCAwEAAaOCAe0wggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRI
# bmTlUAXTgqoXNzcitW2oynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTAL
# BgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBD
# uRQFTuHqp8cx0SOJNDBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jv
# c29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3JsMF4GCCsGAQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3J0MIGfBgNVHSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEF
# BQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1h
# cnljcHMuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkA
# YwB5AF8AcwB0AGEAdABlAG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn
# 8oalmOBUeRou09h0ZyKbC5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7
# v0epo/Np22O/IjWll11lhJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0b
# pdS1HXeUOeLpZMlEPXh6I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/
# KmtYSWMfCWluWpiW5IP0wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvy
# CInWH8MyGOLwxS3OW560STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBp
# mLJZiWhub6e3dMNABQamASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJi
# hsMdYzaXht/a8/jyFqGaJ+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYb
# BL7fQccOKO7eZS/sl/ahXJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbS
# oqKfenoi+kiVH6v7RyOA9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sL
# gOppO6/8MO0ETI7f33VtY5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtX
# cVZOSEXAQsmbdlsKgEhr/Xmfwb1tbWrJUnMTDXpQzTGCGZ8wghmbAgEBMIGVMH4x
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01p
# Y3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTECEzMAAANNTpGmGiiweI8AAAAA
# A00wDQYJYIZIAWUDBAIBBQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQw
# HAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIPGY
# gzs/yDxz3l/jmu9OyeHbsvNnYf5Eo9tZiwdWk3JsMEIGCisGAQQBgjcCAQwxNDAy
# oBSAEgBNAGkAYwByAG8AcwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20wDQYJKoZIhvcNAQEBBQAEggEAVGMVcPPO/lEZKqfNtDajUgB4XCmMMAnGc/Yn
# QeN3IPOIez9PVXqDl+/V9mGOILqCXmlbhQIDuZuFfjM2eXNKXGvTqB1HFAnGN5DG
# GAB5tn7b6NllCFrZvuE8GJ/4vpCqKXngkl0dhqIt6dNn19Qbq82uXklS8yRQAQe9
# eXcjfhk5mvN2M10utlTDPGLwqF56+7ocP96fVfdNDW7Upyw8FjPxiRs7d0RDcriT
# vGx2rrD0x4fc+R284SKrYo1MV63bh0+hOmSqWi7+fwC/cswD4dSNzVPU6oKWCKPR
# 5hXEXuWyWlMf2c7go283Z6NUU42lIczzJ4OB/qguTeYgMzXLW6GCFykwghclBgor
# BgEEAYI3AwMBMYIXFTCCFxEGCSqGSIb3DQEHAqCCFwIwghb+AgEDMQ8wDQYJYIZI
# AWUDBAIBBQAwggFZBgsqhkiG9w0BCRABBKCCAUgEggFEMIIBQAIBAQYKKwYBBAGE
# WQoDATAxMA0GCWCGSAFlAwQCAQUABCCTl6BpKrFNUBwfsXKtcfDGEIM3HFTV77fz
# slrK/4IQEQIGZGzw6qsYGBMyMDIzMDYxNDE1NTkxNy41NzhaMASAAgH0oIHYpIHV
# MIHSMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQL
# EyRNaWNyb3NvZnQgSXJlbGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsT
# HVRoYWxlcyBUU1MgRVNOOjhENDEtNEJGNy1CM0I3MSUwIwYDVQQDExxNaWNyb3Nv
# ZnQgVGltZS1TdGFtcCBTZXJ2aWNloIIReDCCBycwggUPoAMCAQICEzMAAAGz/iXO
# KRsbihwAAQAAAbMwDQYJKoZIhvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# UENBIDIwMTAwHhcNMjIwOTIwMjAyMjAzWhcNMjMxMjE0MjAyMjAzWjCB0jELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9z
# b2Z0IElyZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMg
# VFNTIEVTTjo4RDQxLTRCRjctQjNCNzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUt
# U3RhbXAgU2VydmljZTCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBALR8
# D7rmGICuLLBggrK9je3hJSpc9CTwbra/4Kb2eu5DZR6oCgFtCbigMuMcY31QlHr/
# 3kuWhHJ05n4+t377PHondDDbz/dU+q/NfXSKr1pwU2OLylY0sw531VZ1sWAdyD2E
# QCEzTdLD4KJbC6wmAConiJBAqvhDyXxJ0Nuvlk74rdVEvribsDZxzClWEa4v62EN
# j/HyiCUX3MZGnY/AhDyazfpchDWoP6cJgNCSXmHV9XsJgXJ4l+AYAgaqAvN8N+Ep
# N+0TErCgFOfwZV21cg7vgenOV48gmG/EMf0LvRAeirxPUu+jNB3JSFbW1WU8Z5xs
# LEoNle35icdET+G3wDNmcSXlQYs4t94IWR541+PsUTkq0kmdP4/1O4GD54ZsJ5eU
# nLaawXOxxT1fgbWb9VRg1Z4aspWpuL5gFwHa8UNMRxsKffor6qrXVVQ1OdJOS1Jl
# evhpZlssSCVDodMc30I3fWezny6tNOofpfaPrtwJ0ukXcLD1yT+89u4uQB/rqUK6
# J7HpkNu0fR5M5xGtOch9nyncO9alorxDfiEdb6zeqtCfcbo46u+/rfsslcGSuJFz
# lwENnU+vQ+JJ6jJRUrB+mr51zWUMiWTLDVmhLd66//Da/YBjA0Bi0hcYuO/WctfW
# k/3x87ALbtqHAbk6i1cJ8a2coieuj+9BASSjuXkBAgMBAAGjggFJMIIBRTAdBgNV
# HQ4EFgQU0BpdwlFnUgwYizhIIf9eBdyfw40wHwYDVR0jBBgwFoAUn6cVXQBeYl2D
# 9OXSZacbUzUZ6XIwXwYDVR0fBFgwVjBUoFKgUIZOaHR0cDovL3d3dy5taWNyb3Nv
# ZnQuY29tL3BraW9wcy9jcmwvTWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUy
# MDIwMTAoMSkuY3JsMGwGCCsGAQUFBwEBBGAwXjBcBggrBgEFBQcwAoZQaHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0cy9NaWNyb3NvZnQlMjBUaW1l
# LVN0YW1wJTIwUENBJTIwMjAxMCgxKS5jcnQwDAYDVR0TAQH/BAIwADAWBgNVHSUB
# Af8EDDAKBggrBgEFBQcDCDAOBgNVHQ8BAf8EBAMCB4AwDQYJKoZIhvcNAQELBQAD
# ggIBAFqGuzfOsAm4wAJfERmJgWW0tNLLPk6VYj53+hBmUICsqGgj9oXNNatgCq+j
# Ht03EiTzVhxteKWOLoTMx39cCcUJgDOQIH+GjuyjYVVdOCa9Fx6lI690/OBZFlz2
# DDuLpUBuo//v3e4Kns412mO3A6mDQkndxeJSsdBSbkKqccB7TC/muFOhzg39mfij
# GICc1kZziJE/6HdKCF8p9+vs1yGUR5uzkIo+68q/n5kNt33hdaQ234VEh0wPSE+d
# CgpKRqfxgYsBT/5tXa3e8TXyJlVoG9jwXBrKnSQb4+k19jHVB3wVUflnuANJRI9a
# zWwqYFKDbZWkfQ8tpNoFfKKFRHbWomcodP1bVn7kKWUCTA8YG2RlTBtvrs3CqY3m
# ADTJUig4ckN/MG6AIr8Q+ACmKBEm4OFpOcZMX0cxasopdgxM9aSdBusaJfZ3Itl3
# vC5C3RE97uURsVB2pvC+CnjFtt/PkY71l9UTHzUCO++M4hSGSzkfu+yBhXMGeBZq
# LXl9cffgYPcnRFjQT97Gb/bg4ssLIFuNJNNAJub+IvxhomRrtWuB4SN935oMfvG5
# cEeZ7eyYpBZ4DbkvN44ZvER0EHRakL2xb1rrsj7c8I+auEqYztUpDnuq6BxpBIUA
# lF3UDJ0SMG5xqW/9hLMWnaJCvIerEWTFm64jthAi0BDMwnCwMIIHcTCCBVmgAwIB
# AgITMwAAABXF52ueAptJmQAAAAAAFTANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0
# IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTAwHhcNMjEwOTMwMTgyMjI1
# WhcNMzAwOTMwMTgzMjI1WjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGlu
# Z3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBv
# cmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCC
# AiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAOThpkzntHIhC3miy9ckeb0O
# 1YLT/e6cBwfSqWxOdcjKNVf2AX9sSuDivbk+F2Az/1xPx2b3lVNxWuJ+Slr+uDZn
# hUYjDLWNE893MsAQGOhgfWpSg0S3po5GawcU88V29YZQ3MFEyHFcUTE3oAo4bo3t
# 1w/YJlN8OWECesSq/XJprx2rrPY2vjUmZNqYO7oaezOtgFt+jBAcnVL+tuhiJdxq
# D89d9P6OU8/W7IVWTe/dvI2k45GPsjksUZzpcGkNyjYtcI4xyDUoveO0hyTD4MmP
# frVUj9z6BVWYbWg7mka97aSueik3rMvrg0XnRm7KMtXAhjBcTyziYrLNueKNiOSW
# rAFKu75xqRdbZ2De+JKRHh09/SDPc31BmkZ1zcRfNN0Sidb9pSB9fvzZnkXftnIv
# 231fgLrbqn427DZM9ituqBJR6L8FA6PRc6ZNN3SUHDSCD/AQ8rdHGO2n6Jl8P0zb
# r17C89XYcz1DTsEzOUyOArxCaC4Q6oRRRuLRvWoYWmEBc8pnol7XKHYC4jMYcten
# IPDC+hIK12NvDMk2ZItboKaDIV1fMHSRlJTYuVD5C4lh8zYGNRiER9vcG9H9stQc
# xWv2XFJRXRLbJbqvUAV6bMURHXLvjflSxIUXk8A8FdsaN8cIFRg/eKtFtvUeh17a
# j54WcmnGrnu3tz5q4i6tAgMBAAGjggHdMIIB2TASBgkrBgEEAYI3FQEEBQIDAQAB
# MCMGCSsGAQQBgjcVAgQWBBQqp1L+ZMSavoKRPEY1Kc8Q/y8E7jAdBgNVHQ4EFgQU
# n6cVXQBeYl2D9OXSZacbUzUZ6XIwXAYDVR0gBFUwUzBRBgwrBgEEAYI3TIN9AQEw
# QTA/BggrBgEFBQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9E
# b2NzL1JlcG9zaXRvcnkuaHRtMBMGA1UdJQQMMAoGCCsGAQUFBwMIMBkGCSsGAQQB
# gjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/
# MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1UdHwRPME0wS6BJ
# oEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01p
# Y1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYB
# BQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljUm9v
# Q2VyQXV0XzIwMTAtMDYtMjMuY3J0MA0GCSqGSIb3DQEBCwUAA4ICAQCdVX38Kq3h
# LB9nATEkW+Geckv8qW/qXBS2Pk5HZHixBpOXPTEztTnXwnE2P9pkbHzQdTltuw8x
# 5MKP+2zRoZQYIu7pZmc6U03dmLq2HnjYNi6cqYJWAAOwBb6J6Gngugnue99qb74p
# y27YP0h1AdkY3m2CDPVtI1TkeFN1JFe53Z/zjj3G82jfZfakVqr3lbYoVSfQJL1A
# oL8ZthISEV09J+BAljis9/kpicO8F7BUhUKz/AyeixmJ5/ALaoHCgRlCGVJ1ijbC
# HcNhcy4sa3tuPywJeBTpkbKpW99Jo3QMvOyRgNI95ko+ZjtPu4b6MhrZlvSP9pEB
# 9s7GdP32THJvEKt1MMU0sHrYUP4KWN1APMdUbZ1jdEgssU5HLcEUBHG/ZPkkvnNt
# yo4JvbMBV0lUZNlz138eW0QBjloZkWsNn6Qo3GcZKCS6OEuabvshVGtqRRFHqfG3
# rsjoiV5PndLQTHa1V1QJsWkBRH58oWFsc/4Ku+xBZj1p/cvBQUl+fpO+y/g75LcV
# v7TOPqUxUYS8vwLBgqJ7Fx0ViY1w/ue10CgaiQuPNtq6TPmb/wrpNPgkNWcr4A24
# 5oyZ1uEi6vAnQj0llOZ0dFtq0Z4+7X6gMTN9vMvpe784cETRkPHIqzqKOghif9lw
# Y1NNje6CbaUFEMFxBmoQtB1VM1izoXBm8qGCAtQwggI9AgEBMIIBAKGB2KSB1TCB
# 0jELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1Jl
# ZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMk
# TWljcm9zb2Z0IElyZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1U
# aGFsZXMgVFNTIEVTTjo4RDQxLTRCRjctQjNCNzElMCMGA1UEAxMcTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgU2VydmljZaIjCgEBMAcGBSsOAwIaAxUAcYtE6JbdHhKlwkJe
# KoCV1JIkDmGggYMwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGlu
# Z3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBv
# cmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAN
# BgkqhkiG9w0BAQUFAAIFAOgzxTAwIhgPMjAyMzA2MTQxMjQ4NDhaGA8yMDIzMDYx
# NTEyNDg0OFowdDA6BgorBgEEAYRZCgQBMSwwKjAKAgUA6DPFMAIBADAHAgEAAgIF
# HjAHAgEAAgIU3jAKAgUA6DUWsAIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEE
# AYRZCgMCoAowCAIBAAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBBQUAA4GB
# AEofLgEX7oaNu0mRSHfpFbDZi0sgmCJkr26dZcqybQFwDVgq5P3zKsesULxMyoeb
# 3fF+5/v4gLrLRZjRCo+aQpTKhktVInNwTDP014+wa6iPHanURv2s/r9ogyL8R3Ur
# n2vGrtjTctaCi+Up9sQxbw8hVrrZZpMq+BJStXRjCkyEMYIEDTCCBAkCAQEwgZMw
# fDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1Jl
# ZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMd
# TWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAGz/iXOKRsbihwAAQAA
# AbMwDQYJYIZIAWUDBAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRAB
# BDAvBgkqhkiG9w0BCQQxIgQgV2Vqv9v7r4y3WgTO9naA01FyVWfgD5r8J89TPzjZ
# hwEwgfoGCyqGSIb3DQEJEAIvMYHqMIHnMIHkMIG9BCCGoTPVKhDSB7ZG0zJQZUM2
# jk/ll1zJGh6KOhn76k+/QjCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQI
# EwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3Nv
# ZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBD
# QSAyMDEwAhMzAAABs/4lzikbG4ocAAEAAAGzMCIEIOx5HDco6S041/+giRN96XU7
# fPKC1pu3hg6nwoknF3hPMA0GCSqGSIb3DQEBCwUABIICAFPjB1UQYl+3WDfHY19n
# rJut+Jq6e6UJxDFXDmQyd+oOjfLWHjwa3726/qIZPguDZmrudsjfTaAp9esplBSV
# +QgC46ynaiRH06zULTvsIRIYobDrbPnGpgievSUzpgI3g75TqTC0xv5hNMuZxVHu
# 0GFWhMw6JBf83bko1rJOEgQ7S5Ln7d6LaDXR8A+cMfT8aIl5gcVe4KC/i6pEAYzm
# W05zJW5i3NHBNNUzpWCpYSJQQgHPm1/2LauOLkf2pUcMfl16BJHbNBuPIQp2rC+5
# nxnyiuuL3I+EQiiJjeJ901dGw0Tgfv8hLuweYomPfm1y8ioxIIygeEt3m2ig43uE
# UaSBld1dlDLOgeKhb/Q3nlQGchkc70zyT6EoAKBCoi9og9zy8dRIOC71aOsULqgD
# vqNM3XFbKYS86cMqQTxQiTDr3JcwrvxI4NA17EM2JDzL3jgvomWnuiTrVSJa0jVV
# QIwNFtDMdhrSrG+tzy1/I3Uu70oSMqZf4idTiGoDEpy9fBiuaXmrxUOkg5Ekynbr
# pEgPadSksM9ua6hKl/bLy0He91xDIE0Kbea0cHu8ScErgl/eFaupXlRXRZhCDzq2
# oNPsCirSgn6uMzxYIMX2tAJfmmaAPbqfdQTVnJTczjI0Ysq3281rMK6zhiEh5Pf8
# VtQEDprH+Ii1351kH5v2wPFc
# SIG # End signature block
