# File: common file for get-update-RFLShellExt.ps1 and get-version-RFLShellExt.ps1
# last edit by: waltere

<#
.SYNOPSIS
The script will show version, install, update to latest version or remove your current version of the SDP/RFL Explorer PlugIn on your system.
The registry file for the latest version of the shell extension is located here: \\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\Rfl-Check_ShellExtension.reg

SYNTAX: .\get-update-RFLShellExt.ps1 [- CheckType Check-RFL|Check_RFL_anchor|Check_SDP_anchor] [-GetVersion|-GetUpdate|-Remove]

.DESCRIPTION
The script reads in your current registry RFL information and writes new registry keys.
The script tries to run -GetUpdate or -Remove in elevated mode and ask user to agree (UAC prompt), because REG changes need admin permission.
Note: In case of any error, you still can download to local drive and doubleclick the *.reg file on
   \\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\Rfl-Check_ShellExtension.reg
	 
Reg-Locations for RFL ShellExtension: "HKCU:\SOFTWARE\RFLcheck\" and
	V1: "HKCR:\Directory\shell\Check-RFL"
		"HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Chk_*" 
	V2: "HKCR:\Directory\shell\Check_RFL_anchor"
		"HKCR:\*\ContextMenus\Check_RFL\Shell"
		"HKCR:\Directory\shell\Check_SDP_anchor"
		"HKCR:\*\ContextMenus\Check_SDP\Shell"

.PARAMETER SkipAdminCheck
	If this switch is present, then the check for administrator privileges will be skipped
	Script needs Admin priv for Remove, and for Update if installed version does not match current version

.PARAMETER Remove
	If this switch is present, then the script will remove old Shell Extension

.PARAMETER GetUpdate
	If this switch is present, then the script will check and update version of Shell Extension 

.PARAMETER GetVersion
	If this switch is present, then the script will check and display version of Shell Extension

.PARAMETER HostMode
	If this switch is present, then the script will display output on screen

.PARAMETER ScriptMode
	If this switch is present, then the script will log output in logfile

.EXAMPLE
	To run the RFL shell PlugIn check and update on UNC path
	\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\get-update-RFLShellExt.ps1 -HostMode -GetUpdate

.EXAMPLE
	To run the RFL shell PlugIn VERSION check only
	\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\get-update-RFLShellExt.ps1 -HostMode -GetVersion

.EXAMPLE
	To remove the RFL shell PlugIn only
	\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\get-update-RFLShellExt.ps1 -HostMode -Remove
	
.LINK
	Update script: \\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\get-update-RFLShellExt.ps1
	ShellExtension: \\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\Rfl-Check_ShellExtension.reg
	RFL core team: waltere@microsoft.com

#>


[CmdletBinding()]
PARAM (
	[ValidateSet("Check-RFL","Check_RFL_anchor","Check_SDP_anchor")]
	[parameter(Mandatory=$False,Position=0,HelpMessage='Choose one from: [Check-RFL|Check_RFL_anchor|Check_SDP_anchor]')]
	[string]$CheckType = "Check_RFL_anchor"
	,
	[parameter(Mandatory=$false)]
	[switch]$SkipAdminCheck = $true,	# if $True, then the check for administrator privileges will be skipped
	[switch]$Elevated 		= $false,	# This will run script in elevated Admin mode
	[switch]$Script:IsRunAsAdmin = $false,
	[switch]$Remove 		= $false,	# $True for script remove-RFLShellExt.ps1
	[switch]$GetUpdate 	= $false,		# $True for script get-update-RFLShellExt.ps1
	[switch]$GetVersion 	= $true,	# $True for script get-version-RFLShellExt.ps1
	[switch]$InformUser		= $true,	# $False for suppressing Update info for user
	[switch]$HostMode		= $true,	# This tells the logging functions to show logging on the screen
	[switch]$ScriptMode		= $false, 	# This tells the logging functions to show logging into log file
	[switch]$UseExitCode	= $true,	# This will cause the script to close after the error is logged if an error occurs
	[Switch]$DebugMode,					# used for debugging
	[switch]$DbgOut 		= $false	# $True for script debugging
)

BEGIN {
	$verDateScript = "2023.02.09.0"
	$ScriptFolder = Split-Path $MyInvocation.MyCommand.Path -Parent
	# Load Common Library:
	. $ScriptFolder\Utils_RflShared.ps1

	# This saves the starting ErrorActionPreference and then sets it to 'Stop'.
	$startErrorActionPreference = $errorActionPreference
	# This gets the current path and name of the script.
	$invocation = (Get-Variable MyInvocation).Value
	$scriptPath = Split-Path $invocation.MyCommand.Path
	$FullScriptPath = (Get-Variable MyInvocation).Value.MyCommand.Path
	if ($DbgOut) {
		Write-host "invocation: $invocation"
		Write-host "scriptPath: $scriptPath"
		Write-host "FullScriptPath: $FullScriptPath"
	}
	$scriptName = $invocation.MyCommand.Name
	#$scriptDefinition = $myinvocation.MyCommand.Definition	#Full script path
	$UserName  = ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name)
	$UsrOSVersion = [Environment]::OSVersion.Version.ToString(3)
	if ($DbgOut) {Write-Host "Running `"$scriptPath\$scriptName`"..." -BackgroundColor Black -ForegroundColor Green}
	Set-Variable -Name ErrorMsg -Scope Script -Force
	[string]$Script:ErrorMsg=""
	
#region: ###### customization section of script, logging configuration ########################
	$SDPcheckINI = (Get-content -Path "$ScriptFolder\_SDPcheck.ini")
	$InOfflineMode 	= (($SDPcheckINI[1] -split " ")[2]).trim("""")	# set $True for outsourcer or when not connected to MS network - offline-SDPcheck
	$ExpectedShellExtVersion = (($SDPcheckINI[6] -split " ")[2]).trim("""")
	$RFLroot = (($SDPcheckINI[2] -split " ")[2]).trim("""")	# "\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\" -or- "\\localhost\ToolsShare\rfl\"
	if ($InOfflineMode -match "False") {
		$StatsServer = (($SDPcheckINI[5] -split " ")[2]).trim("""")
		if (Test-Connection -ComputerName $StatsServer -Quiet -Count 1) {[bool]$Stats=$True} else {[bool]$Stats=$False}
	} else { 
		$Stats = $False
	}
	$LogLevel = 0
	$CheckDate = (Get-Date).ToUniversalTime().ToString("yy-MM-dd_HH-mm-ss")
	$Script:regFileV1remove = "$RFLroot\Rfl-Check_ShellExtension_V1-Remove.reg"
	$Script:regFileV2add = "$RFLroot\Rfl-Check_ShellExtension.reg"
	$Script:regFileV2remove = "$RFLroot\Rfl-Check_ShellExtension_Remove.reg"
	#$ExpectedShellExtVersionV1 = "1.11"	# in registry HKCR:\Directory\shell\Check-RFL
#endregion: ###### customization section
	if ($Stats) {
		$StatsServerPath = "\\$StatsServer\RFLstats$\RFL\scripts\Stats\"

		if ($GetVersion) {
			[string]$InfoString = "RFLshExt_Version"
			$CountInvFil = $StatsServerPath +'countRFLshExVer.dat'
		}
		if ($GetUpdate) {
			[string]$InfoString = "RFLshExt_Update"
			$CountInvFil = $StatsServerPath +'countRFLshExUpd.dat'
		}
		if ($Remove) {
			Write-Host "`n Note: Admin priv needed for -Remove" 
			[string]$InfoString = "RFLshExt_Remove"
			$CountInvFil = $StatsServerPath +'countRFLshExRemove.dat'
		}
		$CountInvFil2 = $CountInvFil +'.us'
		#increment at start of script
		 ($j=[int32](Get-Content $CountInvFil -TotalCount 1 -ErrorAction SilentlyContinue)) |out-null
		 Try {(++$j) | Set-Content $CountInvFil -ErrorAction SilentlyContinue} Catch { }
	}
	#initialize
	$ErrorThrown = $null
	$Script:CurrShellExtVer ='undefined'
	$Script:ResultMsg = ""

	If ($PSBoundParameters['Debug']) { $DebugPreference='Continue'}
	Set-Variable -Name ShellExtExists	-Scope Script -Force
	Set-Variable -Name ShellExtVersion	-Scope Script -Force
	Set-Variable -Name regFile 		-Scope Script -Force
	Set-Variable -Name FullScriptPath	-Scope Script -Force
			
#region: Script Functions
function CheckAdminPrivileges {
	# SYNOPSIS: check for PowerShell Admin priv
	# Return: $True if running as Admin
	[CmdletBinding()]
	Param(
		[parameter(Mandatory=$true)] [Bool] $SkipAdminCheck
	)
	RflEnterFuncDbg $MyInvocation.MyCommand.Name
	if ($DbgOut) {Write-host "ENTER: CheckAdminPrivileges"}
	if (-not $SkipAdminCheck) {
		# Yep, this is the easiest way to do this.
		$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")
		if (-not $isAdmin) {
			throw "You do not have the required permission to complete this task. Please run this command in an Administrator PowerShell window or specify the -SkipAdminCheck option."
		}
	}
	RflEndFunc $MyInvocation.MyCommand.Name
}

function Test-Admin {
	# SYNOPSIS: check for PowerShell Admin priv
	# Return: $True if running as Admin, $False if not
	RflEnterFuncDbg $MyInvocation.MyCommand.Name
	if ($DbgOut) {Write-host "ENTER: Test-Admin"}
	$currentUser = New-Object Security.Principal.WindowsPrincipal $([Security.Principal.WindowsIdentity]::GetCurrent())
	$currentUser.IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)
	RflEndFunc $MyInvocation.MyCommand.Name
}

function checkRegKey ($rKey) {
	# SYNOPSIS - check if RegKey exists
	# Return: $True if found, $False if not found 
	RflEnterFuncDbg $MyInvocation.MyCommand.Name
	if ($DbgOut) {Write-host "ENTER: checkRegKey"}
	New-PSDrive -Name HKCR -PSProvider Registry -Root HKEY_CLASSES_ROOT |out-null
	$ErrorActionPreference = "stop"
	Try { 
		$exists = Get-Item -Path $rKey
		if ($exists) {WriteInfo -message "$rKey exists." 
		return $True}
		}
	Catch [System.Management.Automation.PSArgumentException]
	 {	 return $False}
	Catch [System.Management.Automation.ItemNotFoundException]
	 {	WriteError -message "$rKey is missing."
		return $False }
	Finally { $ErrorActionPreference = "Continue" }
	RflEndFunc $MyInvocation.MyCommand.Name
} # end of checkRegKey

function checkPlugin-ShellExt ($CheckType,$registryPath,$CheckedVer) {
	# SYNOPSIS - check if RFLShellExt is installed, Write message to user if Plugin is missing
	# $CheckType can be "Check-RFL" or "Check_RFL_anchor" or "Check_SDP_anchor"
	# Return: '__Found ..' or '.. itself is missing'
	RflEnterFuncDbg $MyInvocation.MyCommand.Name
	if ($DbgOut) {Write-host "ENTER: checkPlugin-ShellExt"}
	 New-PSDrive -Name HKCR -PSProvider Registry -Root HKEY_CLASSES_ROOT |out-null
	 #$registryPath = "HKCR:\Directory\shell\$($CheckType)"
	 $ErrorActionPreference = "stop"
	 
	 Try { 
		#check if RFLShellExt is installed and 'Version' key exists
		WriteInfo -message "[RFLshExt_Plugin] _Checking for existing ShellExt $($CheckType) in $registryPath"
		$Script:ShellExtKey = (Get-ItemProperty -Path $registryPath -ErrorAction SilentlyContinue)
		if ($Script:ShellExtKey) {
			$Script:CurrShellExtVer = $($Script:ShellExtKey.Version)
			WriteInfo -message "[$InfoString`] __Found ShellExt in $registryPath ver: $Script:CurrShellExtVer "
			$Script:ResultMsg += "$CheckedVer $CheckType ver: $Script:CurrShellExtVer "
		}
			# RflEndFunc ($MyInvocation.MyCommand.Name + "(Found $Script:CurrShellExtVer)")
			#return "Found $Script:CurrShellExtVer"
	 }
	 Catch [System.Management.Automation.ItemNotFoundException]
	 {
		if ($InformUser) {
			 #Write message to user if Plugin is missing
			 Write-host -BackgroundColor Black -ForegroundColor Yellow -Object "... Simplify: Consider to run Explorer-Extension V2 update $ExpectedShellExtVersion in elevated PowerShell window, see also _Help.rtf:"
			 Write-host -BackgroundColor Black -ForegroundColor Cyan -Object " Powershell -ExecutionPolicy Bypass $RFLroot\get-update-RFLShellExt.ps1"
		}
		WriteError -message "$registryPath itself is missing."
		$Script:ResultMsg += "$CheckedVer $CheckType is missing. "
		RflEndFunc ($MyInvocation.MyCommand.Name + "($CheckedVer $registryPath itself is missing.)")
		return "$CheckedVer $registryPath itself is missing."
	}
	 Finally { $ErrorActionPreference = "Continue" }
	 RflEndFunc $MyInvocation.MyCommand.Name
} # end of checkPlugin-ShellExt

function checkVer-ShellExt ($CheckType,$registryPath,$ExpectedShellExtVersion) {
	# SYNOPSIS - check if RFLShellExt 'Version' key exists
	# Return: "$Script:CurrShellExtVer _up_to_date" - "$Script:CurrShellExtVer _outdated - user_informed." - ".. Property Version missing." - ""
	 #check if 'Version' key exists
	 RflEnterFuncDbg $MyInvocation.MyCommand.Name
	 if ($DbgOut) {Write-host "ENTER: checkVer-ShellExt"}
	 New-PSDrive -Name HKCR -PSProvider Registry -Root HKEY_CLASSES_ROOT |out-null
	 #$registryPath = "HKCR:\Directory\shell\$($CheckType)"
	 Try { $ErrorActionPreference = "stop"
		WriteInfo -message "[$InfoString`] _Checking current version for $($CheckType) in $registryPath"
		$Script:CurrShellExtVer = (Get-ItemProperty -Path $registryPath -Name Version -ErrorAction SilentlyContinue).Version
		if ($Script:CurrShellExtVer){
			WriteInfo -message "[$InfoString`] __comparing your RFL ShellExtension version: $Script:CurrShellExtVer with latest $Script:ExpectedShellExtVersion"
			if ($Script:CurrShellExtVer -match $ExpectedShellExtVersion){
				WriteInfo -message "[$InfoString`] __Your RFL ShellExtension version $Script:CurrShellExtVer is up-to-date";
				RflEndFunc ($MyInvocation.MyCommand.Name + "($Script:CurrShellExtVer _up_to_date.)")
				return " $Script:CurrShellExtVer _up_to_date"
			}
			else {
				if ($Script:CurrShellExtVer -lt 1.09) {Write-host -BackgroundColor Black -ForegroundColor Red -Object " Support for this older RFL version has ended."}
				Write-host -BackgroundColor Yellow -ForegroundColor Black -Object "[$InfoString`] __Your RFL ShellExtension version $Script:CurrShellExtVer is outdated! (Available: v$ExpectedShellExtVersion)
	 .. Consider updating the RFL Shell Explorer Plugin to v$ExpectedShellExtVersion `n $Script:regFileV2add
	 To do so, run in ELEVATED (Run as Administrator) PS window the commands:"
				Write-host -ForegroundColor Cyan -Object " Powershell -ExecutionPolicy Bypass $RFLroot\remove-RFLShellExt.ps1"
				Write-host -ForegroundColor Cyan -Object " Powershell -ExecutionPolicy Bypass $RFLroot\get-update-RFLShellExt.ps1"
				RflEndFunc ($MyInvocation.MyCommand.Name + "($Script:CurrShellExtVer _outdated - user_informed.)")
				return "$Script:CurrShellExtVer _outdated - user_informed."
			}
		}
		else { WriteInfo -message "[$InfoString`] $registryPath\Version not found"
			$Script:CurrShellExtVer ='V-undefined'
		}
	}
	Catch [System.Management.Automation.PSArgumentException]
	{	
		RflEndFunc ($MyInvocation.MyCommand.Name + "([$InfoString`] RegKey $registryPath Property Version missing.)")
		return "[$InfoString`] RegKey $registryPath Property Version missing."
	}
	Catch [System.Management.Automation.ItemNotFoundException]
	{ WriteInfo -message "[$InfoString`] RegKey $registryPath\Version is missing."
		 Write-debug "[$InfoString`] ...RFLshellPlugin not up-to-date - creating it."
		 Write-debug "[$InfoString`] ...***please allow registry Version update when UAC prompted***"
		 RflEndFunc ($MyInvocation.MyCommand.Name + "([$InfoString`] $registryPath\Version is missing.)")
		 return "[$InfoString`] RegKey $registryPath\Version is missing."
	}
	Finally { $ErrorActionPreference = "Continue" }
	RflEndFunc $MyInvocation.MyCommand.Name
} # end of checkVer-ShellExt

function CheckForUpdates-RFLShellExt ($CheckType,$ExpectedShellExtVersion) { ### currently not in use
	# SYNOPSIS - 													
	# Return: nothing
	RflEnterFuncDbg $MyInvocation.MyCommand.Name
	if ($DbgOut) {Write-host "ENTER: CheckForUpdates-RFLShellEx"}
		WriteInfo -message "[RFLshExt_ChkUpdates] checking registryPath: $registryPathHKCR\CheckForUpdates"
		$name = "CheckForUpdates"
		$value = "1"
		 Try { $ErrorActionPreference = "stop"
		$CheckForUpdates = (Get-ItemProperty -Path $registryPathHKCR -Name CheckForUpdates -ErrorAction SilentlyContinue).CheckForUpdates
		if ($CheckForUpdates) {WriteInfo -message "[RFLshExt_ChkUpdates] Current CheckForUpdates: $CheckForUpdates"}
		if ($CheckForUpdates -NotMatch "0") {WriteInfo -message "[RFLshExt_ChkUpdates] Current ShellExt setting for CheckForUpdates: $CheckForUpdates"}
		else {	WriteInfo -message "[RFLshExt_ChkUpdates] CheckForUpdates: '$CheckForUpdates' - .. Consider updating the RFL Shell Explorer Plugin to v$ExpectedShellExtVersion `n $Script:regFileV2add "
			WriteInfo -message "[RFLshExt_ChkUpdates] ... keep existing plugin settings because $registryPathHKCR\CheckForUpdates is set to '$CheckForUpdates'"
			break #continue
			}
		}
		Catch [System.Management.Automation.PSArgumentException]
		 { "[RFLshExt_ChkUpdates] RegKey $registryPathHKCR Property $name missing."
			New-ItemProperty -Path $registryPathHKCR -Name $name -Value $value -PropertyType DWORD -Force | Out-Null
		 }
		Catch [System.Management.Automation.ItemNotFoundException]
		 { "[RFLshExt_ChkUpdates] RegKey $registryPathHKCR itself is missing."
			WriteInfo -message "[RFLshExt_ChkUpdates] ...RFLshellPlugin not installed - creating it"
			New-Item -Path $registryPathHKCR -Force #| Out-Null
			New-ItemProperty -Path $registryPathHKCR -Name $name -Value $value -PropertyType DWORD -Force | Out-Null
		}
		Finally {
			"[RFLshExt_ChkUpdates] CheckForUpdates reg: $CheckForUpdates"
			$ErrorActionPreference = "Continue" }
	RflEndFunc $MyInvocation.MyCommand.Name
} # end of CheckForUpdates-RFLShellExt

function update-ShellExt ($CheckType,$ExpectedShellExtVersion) {
	# SYNOPSIS - update the existing ShellExtension
	# Return: nothing
	#IF (!($Script:CurrShellExtVer -match $ExpectedShellExtVersion) -and ($CheckForUpdates -NotMatch "0")) {
	RflEnterFuncDbg $MyInvocation.MyCommand.Name
	if ($DbgOut) {Write-host "ENTER: update-ShellExt"}
	if ($Script:CurrShellExtVer -NotMatch $ExpectedShellExtVersion) {
		#WriteInfo -message "[$InfoString`] ...Outdated Check-RFL ShellExtVersion '$Script:CurrShellExtVer', removing existing entry $registryPathHKCR '$Script:CurrShellExtVer'"
		Try
			{
			WriteInfo -message "[$InfoString`] ...***please allow registry REMOVE when UAC prompted***"

			WriteInfo -message "[$InfoString`] ...Step#1 Remove v1: Importing $Script:regFileV1remove silently"
			WriteInfo -message "[$InfoString`] ...***please allow registry UPDATE when UAC prompted***"
			$RegTry = regedit /s $Script:regFileV1remove

			WriteInfo -message "[$InfoString`] ...Step#2 Importing latest $Script:regFileV2add silently"
			WriteInfo -message "[$InfoString`] ...***please allow registry UPDATE when UAC prompted***"
			$RegTry = regedit /s $Script:regFileV2add
			#WriteInfo -message "[$InfoString`] ...RegTry result: $RegTry"
			Write-host -BackgroundColor Black -ForegroundColor Green -Object "[$InfoString`] RFLShellExt $CheckType successfully updated"
			"RegImport-done for exp. v$ExpectedShellExtVersion"
			}
		Catch [System.Security.SecurityException]
			{ WriteError -message "Registry Remove-Item $registryPathHKCR"
				WriteError -message "[$InfoString`] Aborted. The error was '$($_.Exception.Message)'"
				Write-host -BackgroundColor Black -ForegroundColor Red -Object "[$InfoString`] Aborted by user"
				"Aborted by user."
			}
		Finally
			{
			"RegVersion-not-matched, inst.Ver: '$Script:CurrShellExtVer'"
			}
	}
	RflEndFunc $MyInvocation.MyCommand.Name
} # end of update-ShellExt

function autoupdate-ShellExt ($CheckType,$registryPath,$ExpectedShellExtVersion) { ### currently not in use
	# SYNOPSIS - AutoUpdate the existing ShellExtension
	# Return: nothing
	RflEnterFuncDbg $MyInvocation.MyCommand.Name
	if ($DbgOut) {Write-host "ENTER: autoupdate-ShellExt"}
		if ($Script:ShellExtKey)	{
		checkVer-ShellExt $CheckType $registryPath $ExpectedShellExtVersion		#call function
		if ($Script:CurrShellExtVer -lt 1.09) {
			if ($GetVersion) {
				Write-host -BackgroundColor Black -ForegroundColor Yellow -Object "`n Trying Auto-Update, Please agree when prompted for running in elevated PS and Registry modification."
				Powershell -noprofile -ExecutionPolicy Bypass $RFLroot\get-update-RFLShellExt_v1.16.ps1 -SkipAdminCheck -GetUpdate
				checkVer-ShellExt $CheckType $registryPath $ExpectedShellExtVersion
				if ($Script:CurrShellExtVer -match $ExpectedShellExtVersion) {Write-host -BackgroundColor Black -ForegroundColor Green -Object " AutoUpdate version completed: v$Script:CurrShellExtVer"}
			}
		}
	}
	if ($GetUpdate) {update-ShellExt $CheckType $ExpectedShellExtVersion}	#call function
	RflEndFunc $MyInvocation.MyCommand.Name
} #end function autoupdate-ShellExt

function remove-ShellExt ($CheckType,$registryPath) {
	# SYNOPSIS - Delete all the registry rentries for the existing ShellExtension
	# Return: result of action done
	RflEnterFuncDbg $MyInvocation.MyCommand.Name
	if ($DbgOut) {Write-host "ENTER: remove-ShellExt"}
	WriteInfo -message "[RFLshExt_Remove] Checking ShellExt for $($CheckType) $registryPath"
	switch($registryPath)
		{
		"$($registryPathHKCR)"		{New-PSDrive -Name HKCR -PSProvider Registry -Root HKEY_CLASSES_ROOT |out-null}
		"$($registryPathHKCR2)"		{New-PSDrive -Name HKCR -PSProvider Registry -Root HKEY_CLASSES_ROOT |out-null}
		"$($registryPathHKLM)"		{New-PSDrive -Name HKLM -PSProvider Registry -Root HKEY_LOCAL_MACHINE |out-null}
		"$($registryPathHKCU)"		{New-PSDrive -Name HKCU -PSProvider Registry -Root HKEY_CURRENT_USER |out-null}
		}
	
	#WriteInfo -message "[RFLshExt_Remove] ...***please allow registry REMOVE when UAC prompted***"
	$ErrorActionPreference = "stop"
	
	Try
	{
		$Script:RegPathKey = (Get-ItemProperty -Path $registryPath )
		if ($Script:RegPathKey) {
			WriteInfo -message "[RFLshExt_Remove] _Trying to remove registry-tree $registryPath"
			Remove-Item $registryPath -Recurse
			RflEndFunc ($MyInvocation.MyCommand.Name + "(removed $registryPath)")
			return " removed $registryPath"
		}
	}
	Catch [System.Security.SecurityException]
		{	WriteError "RegKey $registryPath SecurityException" 
			WriteError "[RFLshExt_Remove] Aborted. The error was '$($_.Exception.Message)'"
			WriteError "[RFLshExt_Remove] Aborted by user SecurityException"
			RflEndFunc ($MyInvocation.MyCommand.Name + "( RegRemove $registryPath aborted by user SecurityException)")
			return " RegRemove $registryPath aborted by user SecurityException."
		}
	Catch [System.Management.Automation.ItemNotFoundException]
		{	WriteError "[RFLshExt_Remove] Cannot find path or item $registryPath"
			RflEndFunc ($MyInvocation.MyCommand.Name + "( RegRemove ItemNotFoundException)")
			return " RegRemove ItemNotFoundException."
		}
	#Catch [System.Management.Automation.PathNotFound]
	#	{ "[RFLshExt_Remove] Cannot find path $registryPath"}
	Finally
	{
		$ErrorActionPreference = "Continue" 
		#"RFLShellExt $CheckType successfully removed"
	}
	RflEndFunc $MyInvocation.MyCommand.Name
} # end of remove-ShellExt

function LaunchElevated {
 # SYNOPSIS : Launches an elevated process running the current script to perform tasks that require administrative privileges. This function waits until the elevated process terminates.
	# Set up command line arguments to the elevated process
	RflEnterFuncDbg $MyInvocation.MyCommand.Name
	if ($DbgOut) {Write-host "ENTER: LaunchElevated"}
	$Script:RelaunchArgs = '-NoExit -ExecutionPolicy Bypass -file "' + $FullScriptPath + '" -IsRunAsAdmin'

	# Launch the process and wait for it to finish
	try
	{
		$AdminProcess = Start-Process "$PsHome\PowerShell.exe" -Verb RunAs -ArgumentList $Script:RelaunchArgs -PassThru
	}
	catch
	{
		$Error[0] # Dump details about the last error
		exit 1
	}

	# Wait until the elevated process terminates
	while (!($AdminProcess.HasExited))
	{
		Start-Sleep -Seconds 2
	}
	RflEndFunc $MyInvocation.MyCommand.Name
}

function DoElevatedOperations {	#currently not used
	RflEnterFuncDbg $MyInvocation.MyCommand.Name
	Write-Host "Do elevated operations"
	Start-Sleep -Seconds 5
	RflEndFunc $MyInvocation.MyCommand.Name
}

function DoStandardOperations {
	RflEnterFuncDbg $MyInvocation.MyCommand.Name
	Write-Host "Do standard operations"

	LaunchElevated
	Start-Sleep -Seconds 5
	RflEndFunc $MyInvocation.MyCommand.Name
}

function DoGetVersion ($CheckType,$ExpectedShellExtVersion) {
#	$CallStack = Get-PSCallStack
#	Write-host -ForegroundColor Cyan "CS: $CallStack"
#	$CallerInfo = $CallStack[1]
#	If($CallerInfo.FunctionName -eq '<ScriptBlock>'){
#		 $FuncName = 'Main'
#	}Else{
#		$FuncName = $CallerInfo.FunctionName
#	}
#	RflEnterFunc ("$($MyInvocation.MyCommand.Name)" + "(Caller - $($FuncName):$($CallerInfo.ScriptLineNumber))")
	RflEnterFuncDbg $MyInvocation.MyCommand.Name
	if ($DbgOut) {Write-host "ENTER: DoGetVersion"}
	# define registry locations for v1 Check-RFL, and v2 Check_RFL_anchor, Check_SDP_anchor
	$registryPathHKCU = "HKCU:\SOFTWARE\RFLcheck\shellExtension" 
	switch($CheckType)
	{
	"Check-RFL"			{ $CheckedVer = "v1"
						$registryPathHKCR = "HKCR:\Directory\shell\Check-RFL"
						$registryPathHKLM = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Chk_*" 
						}
	"Check_RFL_anchor"	{ $CheckedVer = "v2"
						$registryPathHKCR = "HKCR:\Directory\shell\Check_RFL_anchor"
						$registryPathHKCR2 = "HKCR:\*\ContextMenus\Check_RFL\Shell" 
						}						
	"Check_SDP_anchor"	{ $CheckedVer = "v2"
						$registryPathHKCR = "HKCR:\Directory\shell\Check_SDP_anchor"
						$registryPathHKCR2 = "HKCR:\*\ContextMenus\Check_SDP\Shell" 
						}
	}

	WriteInfo -message "$CheckedVer CheckType: $CheckType REG: $registryPathHKCR"
	
	#$au = autoupdate-ShellExt $CheckType $registryPathHKCR $ExpectedShellExtVersion	#call function
	checkPlugin-ShellExt $CheckType $registryPathHKCR $CheckedVer
	WriteInfo -message "[$InfoString`] GetVersion results: $Script:ResultMsg"
	if ($Script:CurrShellExtVer -NotMatch $ExpectedShellExtVersion) {
		Write-host -BackgroundColor Black -ForegroundColor Yellow -Object "... Outdated current $Script:CurrShellExtVer : Consider to run Explorer-Extension V2 update $ExpectedShellExtVersion in elevated PowerShell window, see also _Help.rtf:"
		Write-host -BackgroundColor Black -ForegroundColor Cyan -Object " Powershell -ExecutionPolicy Bypass $RFLroot\get-update-RFLShellExt.ps1" 
		[System.Media.SystemSounds]::Hand.Play() } # Play sound to get some attention 
	#$Script:ResultMsg += $au
	If ($Script:ResultMsg -match $ExpectedShellExtVersion) { Write-Host -ForegroundColor Green -Object "[$InfoString`] OK, you are running latest RFL/SDPcheck Explorer PlugIn version $($ExpectedShellExtVersion)"}
	else { 
		Write-Host -ForegroundColor Red -Object "[$InfoString`] Your RFL/SDP Eplorer Plug-in version $Script:CurrShellExtVer is outdated, expected: $($ExpectedShellExtVersion)"
		Write-Host -ForegroundColor cyan -Object "[$InfoString`] for update, run: $RFLroot\get-update-RFLShellExt.ps1"
	}
	If ($Script:ResultMsg -match "missing") {
		WriteInfo -message "[$InfoString`] .. Consider installing the RFL Shell Explorer Plugin v$ExpectedShellExtVersion`n	$Script:regFileV2add
To do so, run in elevated (Run as Administrator) PS window the command: 
Powershell -ExecutionPolicy Bypass $RFLroot\get-update-RFLShellExt.ps1"
	}
	RflEndFunc $MyInvocation.MyCommand.Name
	return $Script:ResultMsg
}

function DoGetUpdate ($CheckType,$ExpectedShellExtVersion) {
	RflEnterFuncDbg $MyInvocation.MyCommand.Name
	if ($DbgOut) {Write-host "ENTER: DoGetUpdate"}
	$au = update-ShellExt $CheckType $ExpectedShellExtVersion		#call function
	Write-host -BackgroundColor Black -ForegroundColor Green -Object "[$InfoString`] ...done. New RFL ShellExt $ExpectedShellExtVersion plugin should be available in your Windows Explorer context menu for folders right now."
	WriteInfo -message "Note: In case of any error, you still can download to local drive and doubleclick the *.reg file on`n $($RFLroot)\Rfl-Check_ShellExtension.reg"
	$Script:ResultMsg += $au
	RflEndFunc $MyInvocation.MyCommand.Name
}

function DoRemove ($CheckType,$ExpectedShellExtVersion) {
	RflEnterFuncDbg $MyInvocation.MyCommand.Name
	if ($DbgOut) {Write-host "ENTER: DoRemove"}
	WriteInfo -message "[RFLshExt_Remove] ***Deleting reg-locations for RFL Shell-Extension version '$Script:CurrShellExtVer'`n "
	$registryPaths = $registryPathHKCR,$registryPathHKLM,$registryPathHKCU
	foreach ($registryPath in $registryPaths)
		{
		$exists = checkRegKey $registryPath
		if ($exists) { 
			$au += remove-ShellExt $CheckType $registryPath	#call function "Check-RFL"
			WriteInfo -message "[RFLshExt_Remove] __results: $au `n"
			}
		}
	$Script:ResultMsg = $au
	RflEndFunc $MyInvocation.MyCommand.Name
}
#endregion: Script Functions
} #end BEGIN


PROCESS {
	try {
			$ScriptBeginTimeStamp = Get-Date
			#region: MAIN :::::

			if ($GetVersion) {
				$V2check = DoGetVersion Check_RFL_anchor $ExpectedShellExtVersion
				WriteInfo -message "[$InfoString`] *** V2check: $V2check"
#				if ($Script:ResultMsg -notmatch "2.0") {
#					$V1check = DoGetVersion Check-RFL $ExpectedShellExtVersionV1
#					WriteInfo -message "[$InfoString`] *** V1check : $V1check"
#				}
			}

			if ($GetUpdate) {
				$V2check = DoGetVersion Check_RFL_anchor $ExpectedShellExtVersion
				if ($Script:CurrShellExtVer -NotMatch $ExpectedShellExtVersion) { 
					DoGetUpdate $CheckType $ExpectedShellExtVersion
				} else { WriteInfo -message "-GetUpdate requires Admin priv."}
			}

			if ($Remove) {
				if ((Test-Admin) -eq $true) { DoRemove $CheckType $ExpectedShellExtVersion}
				else { WriteInfo -message "-Remove requires Admin priv."
					#.\get-update-RFLShellExt_v1.16.ps1 -CheckType Check-RFL -Remove -Hostmode
					DoStandardOperations
					Write-Host "RelaunchArgs: $Script:RelaunchArgs"
					#DoElevatedOperations
							
					#LaunchElevated 
					#Start-Sleep -Seconds 5
				<#	if ($IsRunAsAdmin) {
						Write-Host "RelaunchArgs: $RelaunchArgs"
						DoElevatedOperations
					}
					else
						{
							DoStandardOperations
						} #>
				}
			}
			WriteInfo -message "Overall-Results: $Script:ResultMsg"
			#endregion: MAIN
	} # end try PROCESS
	catch {
		$errorMessage = "$scriptName caught an exception on $($ENV:COMPUTERNAME):"
		$errorMessage += "`n`n"
		$errorMessage += "Exception Type: $($_.Exception.GetType().FullName)"
		$errorMessage += "`n`n"
		$errorMessage += "Exception Message: $($_.Exception.Message)"

		Write-Error $errorMessage -ErrorAction Continue
		Write-Debug $errorMessage
		if ( $UseExitCode ) {
			$error.clear()	# clear script errors
			exit 1
		} #end UseExitCode
	} #end Catch PROCESS
	Finally {
	}
} #end PROCESS

END {
	$ScriptEndTimeStamp = Get-Date
	$Duration = $(New-TimeSpan -Start $ScriptBeginTimeStamp -End $ScriptEndTimeStamp)
	$LogLevel = 0
	#Write-Host -BackgroundColor Gray -ForegroundColor Black -Object "[Done] Script $scriptName v$verDateScript execution finished. Duration: $Duration"
	WriteInfo -message "[Done] Script $scriptName v$verDateScript execution finished. Duration: $Duration `n"
	if($ErrorThrown) {Throw $error[0].Exception.Message}
	# Stats
	If ($Stats) { #increment at start of script
		Try {"$j; $CheckDate; $UsrOSVersion; $UserName; $Duration; [$InfoString`]; $Script:CurrShellExtVer; $Script:ResultMsg; v$verDateScript ; $env:computername" | Out-File $CountInvFil2 -Append -Encoding UTF8 -ErrorAction SilentlyContinue} Catch { }
	}
  # This resets the ErrorActionPreference to the value at script start.
  $errorActionPreference = $startErrorActionPreference
	#Write full error message
	#$error[0] |fl * -force
} #end END

#region: comments
<#
	The top section is comment based help so the Get-Help command will work with the script.
	The [CmdletBinding()] turns on advanced options like the common parameters.
	All sub functions are in the "BEGIN" section.
	My script code goes in the "PROCESS try" block.

VERSION and AUTHOR:
	Walter Eder	- waltere@microsoft.com

HISTORY
	2015-02-02	V1.04
	2016-07-02	V1.06 add capability to remove all RFL registry settings, see remove-RFLShellExt.ps1
	2017-04-03	V1.08 (removed platform, re-added VSS in Rfl-Check_ShellExtension_FQDN.reg)
	2017-10-06	v1.11 changed [RFLshExt_Update] to [$InfoString`] + output enhancements
	2017-11-19	v1.13 using PS fuctions
	2019-01-13	v1.16 consolidating get-version-RFLShellExt.ps1 and get-update-RFLShellExt.ps1 and remove-RFLShellExt.ps1
	2019-09-26	v1.18 new ShellExtVersion v2.08, $InformUser= $true 
	2022-09-08 using Utils_RflShared.psm1 library
	
	ToDo: 	/known issue:
	#https://blogs.msdn.microsoft.com/virtual_pc_guy/2010/09/23/a-self-elevating-powershell-script/

#>
#endregion: comments 


# SIG # Begin signature block
# MIInmAYJKoZIhvcNAQcCoIIniTCCJ4UCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCJisiIFbtagiXQ
# lGVQfmBu1tXp9d6mEj+KI8Jl5Z47IaCCDXYwggX0MIID3KADAgECAhMzAAADTrU8
# esGEb+srAAAAAANOMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjMwMzE2MTg0MzI5WhcNMjQwMzE0MTg0MzI5WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDdCKiNI6IBFWuvJUmf6WdOJqZmIwYs5G7AJD5UbcL6tsC+EBPDbr36pFGo1bsU
# p53nRyFYnncoMg8FK0d8jLlw0lgexDDr7gicf2zOBFWqfv/nSLwzJFNP5W03DF/1
# 1oZ12rSFqGlm+O46cRjTDFBpMRCZZGddZlRBjivby0eI1VgTD1TvAdfBYQe82fhm
# WQkYR/lWmAK+vW/1+bO7jHaxXTNCxLIBW07F8PBjUcwFxxyfbe2mHB4h1L4U0Ofa
# +HX/aREQ7SqYZz59sXM2ySOfvYyIjnqSO80NGBaz5DvzIG88J0+BNhOu2jl6Dfcq
# jYQs1H/PMSQIK6E7lXDXSpXzAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUnMc7Zn/ukKBsBiWkwdNfsN5pdwAw
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzUwMDUxNjAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAD21v9pHoLdBSNlFAjmk
# mx4XxOZAPsVxxXbDyQv1+kGDe9XpgBnT1lXnx7JDpFMKBwAyIwdInmvhK9pGBa31
# TyeL3p7R2s0L8SABPPRJHAEk4NHpBXxHjm4TKjezAbSqqbgsy10Y7KApy+9UrKa2
# kGmsuASsk95PVm5vem7OmTs42vm0BJUU+JPQLg8Y/sdj3TtSfLYYZAaJwTAIgi7d
# hzn5hatLo7Dhz+4T+MrFd+6LUa2U3zr97QwzDthx+RP9/RZnur4inzSQsG5DCVIM
# pA1l2NWEA3KAca0tI2l6hQNYsaKL1kefdfHCrPxEry8onJjyGGv9YKoLv6AOO7Oh
# JEmbQlz/xksYG2N/JSOJ+QqYpGTEuYFYVWain7He6jgb41JbpOGKDdE/b+V2q/gX
# UgFe2gdwTpCDsvh8SMRoq1/BNXcr7iTAU38Vgr83iVtPYmFhZOVM0ULp/kKTVoir
# IpP2KCxT4OekOctt8grYnhJ16QMjmMv5o53hjNFXOxigkQWYzUO+6w50g0FAeFa8
# 5ugCCB6lXEk21FFB1FdIHpjSQf+LP/W2OV/HfhC3uTPgKbRtXo83TZYEudooyZ/A
# Vu08sibZ3MkGOJORLERNwKm2G7oqdOv4Qj8Z0JrGgMzj46NFKAxkLSpE5oHQYP1H
# tPx1lPfD7iNSbJsP6LiUHXH1MIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGXgwghl0AgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAANOtTx6wYRv6ysAAAAAA04wDQYJYIZIAWUDBAIB
# BQCggbAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIG8Ui3GfzRAjIYb5Yiknm+2z
# W2dzLVM09DC8NyqY4Nt+MEQGCisGAQQBgjcCAQwxNjA0oBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEcgBpodHRwczovL3d3dy5taWNyb3NvZnQuY29tIDANBgkqhkiG9w0B
# AQEFAASCAQAssgBvEfFXy1MqV0RJGSJMHsWwfjExuVxL1jIiJLrGzuoBf2MT+msP
# 7j/zhvKubO7K6NJ+hOYdEUcJ5VC1Hpi+RE0+Tdc6zivmVRKWBvfaA0zM1W3Uyjhk
# 1IRzinacOuoXchIgx2moneuQIejguqm5q2rX8nrikA4Y3lccVvqOvS/B7sCIri6D
# 6g12OO/v8sAX8h//jpFaTaoVqDpaLmLGtuaVWPl32+GNOQIwoLVLZCyNKi4wFyEa
# jw8HOzRaX9mTbmEwoyuU0s4rGVh1XeG2NaO1FSdt70qLFfpWt8vIVn9KPU515ys+
# 5JzMk7BeBQJgF97fW2fEfXYBSJSWJ9HboYIXADCCFvwGCisGAQQBgjcDAwExghbs
# MIIW6AYJKoZIhvcNAQcCoIIW2TCCFtUCAQMxDzANBglghkgBZQMEAgEFADCCAVEG
# CyqGSIb3DQEJEAEEoIIBQASCATwwggE4AgEBBgorBgEEAYRZCgMBMDEwDQYJYIZI
# AWUDBAIBBQAEICNjQ7zSrZNf4wTh1W7gAmRkpgM2skXSUPouQf27RSjJAgZkbNji
# Q94YEzIwMjMwNjA1MTgyNTU2LjQ5NFowBIACAfSggdCkgc0wgcoxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBB
# bWVyaWNhIE9wZXJhdGlvbnMxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjhBODIt
# RTM0Ri05RERBMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNl
# oIIRVzCCBwwwggT0oAMCAQICEzMAAAHC+n2HDlRTRyQAAQAAAcIwDQYJKoZIhvcN
# AQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQG
# A1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjIxMTA0MTkw
# MTI4WhcNMjQwMjAyMTkwMTI4WjCByjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldh
# c2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBD
# b3Jwb3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0aW9u
# czEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046OEE4Mi1FMzRGLTlEREExJTAjBgNV
# BAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQC18Qm88o5IWfel62n3Byjb39SgmYMPIemaalGu5FVY
# EXfsHLSe+uzNJw5X8r4u8dZZYLhL1yZ7g/rcSY2HFM3+TYKA+ci3+wN6nIAJKTJr
# i6SpzWxPYj7RSh3TGPL0rb6MsfxQ1v28zfIf+8JidolJSqC2plSXLzamBhIHq0N5
# khhxCg6FMj4zUeFHGbG3xFoApmcOdeAt2SGchgMmtGRAGkiBqG0TG1O46SZWnbLx
# gKgU9pSFQPYlPqE+IMPuoPsDvs8ukXMPZAWY17NPxoceEqxUG4kws9dk7WTXiPT+
# TrwNka2zVgG0Z6Bc2TK+RdKAILG3dDxYXyVoFdsOeEdoMsGEI4FplDyOpwVTHxkl
# JdDyxu8SeZYVmaAz3cH0/8lMVMXqoFUUwN39XQ8FtFALZNy1kfht+/6PJa9k54XP
# nKW08tHFSoGO/gochomAGFTae0zDgfSGmbgHuzosvGROyMuxqOMIkjw+IqL+Y8pg
# RF2ZHK8Uvz9gD892qQjBZaDZOPm3K60YW19VH7oZtwJWGKOPLuXui3Fr/BhVJfro
# ujRqVpOGNz66iNXAfimwv4DWq9tYMH2zCgqVrbR5m5vDt/MKkV7qqz74bTWyy3VJ
# oDQYabO5AJ3ThR7V4fcMVENk+w35pa8DjnlCZ31kksZe6qcGjgFfBXF1Zk2Pr5vg
# /wIDAQABo4IBNjCCATIwHQYDVR0OBBYEFEaxiHvpXjVpQJFcT1a8P76wh8ZqMB8G
# A1UdIwQYMBaAFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMF8GA1UdHwRYMFYwVKBSoFCG
# Tmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY3Jvc29mdCUy
# MFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEpLmNybDBsBggrBgEFBQcBAQRgMF4w
# XAYIKwYBBQUHMAKGUGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY2Vy
# dHMvTWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3J0MAwG
# A1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZIhvcNAQELBQAD
# ggIBABF27d0KRwss99onetHUzsP2NYe+d59+SZe8Ugm2rEcZYzWioCH5urGkjsdn
# PYx42GHUKj4T0Bps6CP3hKnWx5fF1YhIn2VEZoABbMDzvdpMHf9KPC4apupC4C9T
# MEUI7jRQn1qelq+Smr/ScOotvtcjkf6eyaMXK7zKpfU8yadvizV9tz8XfSKNoBLO
# on6nmuuBhbAOgyKEzlsXRjSuJeKHATt5NKFqT8TBzFGYbeH45P47Hwo4u4urAUWX
# WyJN5AKn5hK3gnW1ZdqmoYkOUJtivdHPz6vJNLwKhkBTS9IcI5ByrXZOHzWntCUd
# m/1xNEOFmDZNXKDwbHdfqaSk05dvnpBSiEjdKff1ZAnCMOfvgnRpVgxqLyZjr9Y6
# 6sowoS5I2EKJ6LRMrry85juwfRcQFadFJtV595K0Oj3hQhRVPB3YeYER9jyR+vKn
# dGUD0DgW99S8McxoX0G29T+krp3UJ0obb1XRY3e5XN9gRMmhGmMtgUarQy8rpBUy
# a43GTdsJF+PVpxJZ57XhQaOCXFbC/I580l7enFw0U53weHKn13gCVAZUs2i1oW+i
# mA8t4nBRPd2XlVoACEzC8gWarCx99DL3eaiuumtye/vivmDd6MLf01ikUSjL6qbM
# tbWMVrVpcTZdv8pnDbJrCqV1KnQe7hUSSMbEU1z4DO0hRbCZMIIHcTCCBVmgAwIB
# AgITMwAAABXF52ueAptJmQAAAAAAFTANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0
# IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTAwHhcNMjEwOTMwMTgyMjI1
# WhcNMzAwOTMwMTgzMjI1WjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGlu
# Z3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBv
# cmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCC
# AiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAOThpkzntHIhC3miy9ckeb0O
# 1YLT/e6cBwfSqWxOdcjKNVf2AX9sSuDivbk+F2Az/1xPx2b3lVNxWuJ+Slr+uDZn
# hUYjDLWNE893MsAQGOhgfWpSg0S3po5GawcU88V29YZQ3MFEyHFcUTE3oAo4bo3t
# 1w/YJlN8OWECesSq/XJprx2rrPY2vjUmZNqYO7oaezOtgFt+jBAcnVL+tuhiJdxq
# D89d9P6OU8/W7IVWTe/dvI2k45GPsjksUZzpcGkNyjYtcI4xyDUoveO0hyTD4MmP
# frVUj9z6BVWYbWg7mka97aSueik3rMvrg0XnRm7KMtXAhjBcTyziYrLNueKNiOSW
# rAFKu75xqRdbZ2De+JKRHh09/SDPc31BmkZ1zcRfNN0Sidb9pSB9fvzZnkXftnIv
# 231fgLrbqn427DZM9ituqBJR6L8FA6PRc6ZNN3SUHDSCD/AQ8rdHGO2n6Jl8P0zb
# r17C89XYcz1DTsEzOUyOArxCaC4Q6oRRRuLRvWoYWmEBc8pnol7XKHYC4jMYcten
# IPDC+hIK12NvDMk2ZItboKaDIV1fMHSRlJTYuVD5C4lh8zYGNRiER9vcG9H9stQc
# xWv2XFJRXRLbJbqvUAV6bMURHXLvjflSxIUXk8A8FdsaN8cIFRg/eKtFtvUeh17a
# j54WcmnGrnu3tz5q4i6tAgMBAAGjggHdMIIB2TASBgkrBgEEAYI3FQEEBQIDAQAB
# MCMGCSsGAQQBgjcVAgQWBBQqp1L+ZMSavoKRPEY1Kc8Q/y8E7jAdBgNVHQ4EFgQU
# n6cVXQBeYl2D9OXSZacbUzUZ6XIwXAYDVR0gBFUwUzBRBgwrBgEEAYI3TIN9AQEw
# QTA/BggrBgEFBQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9E
# b2NzL1JlcG9zaXRvcnkuaHRtMBMGA1UdJQQMMAoGCCsGAQUFBwMIMBkGCSsGAQQB
# gjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/
# MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1UdHwRPME0wS6BJ
# oEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01p
# Y1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYB
# BQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljUm9v
# Q2VyQXV0XzIwMTAtMDYtMjMuY3J0MA0GCSqGSIb3DQEBCwUAA4ICAQCdVX38Kq3h
# LB9nATEkW+Geckv8qW/qXBS2Pk5HZHixBpOXPTEztTnXwnE2P9pkbHzQdTltuw8x
# 5MKP+2zRoZQYIu7pZmc6U03dmLq2HnjYNi6cqYJWAAOwBb6J6Gngugnue99qb74p
# y27YP0h1AdkY3m2CDPVtI1TkeFN1JFe53Z/zjj3G82jfZfakVqr3lbYoVSfQJL1A
# oL8ZthISEV09J+BAljis9/kpicO8F7BUhUKz/AyeixmJ5/ALaoHCgRlCGVJ1ijbC
# HcNhcy4sa3tuPywJeBTpkbKpW99Jo3QMvOyRgNI95ko+ZjtPu4b6MhrZlvSP9pEB
# 9s7GdP32THJvEKt1MMU0sHrYUP4KWN1APMdUbZ1jdEgssU5HLcEUBHG/ZPkkvnNt
# yo4JvbMBV0lUZNlz138eW0QBjloZkWsNn6Qo3GcZKCS6OEuabvshVGtqRRFHqfG3
# rsjoiV5PndLQTHa1V1QJsWkBRH58oWFsc/4Ku+xBZj1p/cvBQUl+fpO+y/g75LcV
# v7TOPqUxUYS8vwLBgqJ7Fx0ViY1w/ue10CgaiQuPNtq6TPmb/wrpNPgkNWcr4A24
# 5oyZ1uEi6vAnQj0llOZ0dFtq0Z4+7X6gMTN9vMvpe784cETRkPHIqzqKOghif9lw
# Y1NNje6CbaUFEMFxBmoQtB1VM1izoXBm8qGCAs4wggI3AgEBMIH4oYHQpIHNMIHK
# MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQLExxN
# aWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25zMSYwJAYDVQQLEx1UaGFsZXMgVFNT
# IEVTTjo4QTgyLUUzNEYtOUREQTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3Rh
# bXAgU2VydmljZaIjCgEBMAcGBSsOAwIaAxUAynU3VUuE8y9ZcShl+YXhqlmWdFSg
# gYMwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYw
# JAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0B
# AQUFAAIFAOgoenQwIhgPMjAyMzA2MDUyMzE1MDBaGA8yMDIzMDYwNjIzMTUwMFow
# dzA9BgorBgEEAYRZCgQBMS8wLTAKAgUA6Ch6dAIBADAKAgEAAgIEyAIB/zAHAgEA
# AgIR8TAKAgUA6CnL9AIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMC
# oAowCAIBAAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBAGUV8sGd
# vGQuaMAM1A/NwD+xqVjz0luZQH+RExe1etz6qIUJSSfH4jtqsZtGkyKIX6/4MPWG
# uB9eKEXUVfJhNIXyZhIqK3vSbYajwQ90+1IPbY/0Y25zDJzCdWOzLjgAGoooJ6CL
# z3dNOoZ1M5gcA1NIH+KlIiqdcs3LZHbiZeWZMYIEDTCCBAkCAQEwgZMwfDELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9z
# b2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAHC+n2HDlRTRyQAAQAAAcIwDQYJ
# YIZIAWUDBAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkq
# hkiG9w0BCQQxIgQg+hVKx7eR7yLKNDXcTPI/6eCZ9J8je/lcIJLo1g3/Os0wgfoG
# CyqGSIb3DQEJEAIvMYHqMIHnMIHkMIG9BCDKk2Bbx+mwxXnuvQXlt5S6IRU5V7gF
# 2Zo757byYYNQFjCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEw
# AhMzAAABwvp9hw5UU0ckAAEAAAHCMCIEIEWjlnHwAq864yNGIhhg8rXNcuVWVqxC
# D/iBWspISDyuMA0GCSqGSIb3DQEBCwUABIICACJrzUMdZkc72Etwl7+cMybVYuhE
# 5GyLS7EZtORICkkkv1lVCnJ0H1eKTXVIfpjJ6sz6OU1u8f3afq3XPg+WEHEzgjt0
# cIJK+/+dkd7ha85jQsG6S00NMAAYhhWaNndzX7vJ9QP6vNM4NT4zfCEgnGw6OR8F
# jwQKBpjq1xqzPFp6NM9qHCnEkhgIpxKI7qxayK07o5PMHHIRrBkuz9oLu6D53J8q
# 7bMPHpNb56nif4wHb2MFvUDl6xKiHA6rkJ6VdURyzHziaQSln8/FDZBpCZ43VsdR
# b3tP6xPU+cQIz5+Ss2rxrdzZSg2zD1P3CLkKs9rBc4vcwAevXKswtjYctDrtfHzm
# VeAW5mZR9Bw9rUbdaGUyryJr3Anb0cOpF1fPlci1ZJPVDU04RbgcRAFyajGCNtfX
# cQ4oNJ8W761dgWd3p3peso36JGUw8pHJAOhFz0RkaJ4TyJFbfOK4KlJ3nsWixJfJ
# aOq1zgXoInbT9tBhRLXEdINhIpg+uR90/7SL31gd25o4ktEABpSwOtdsSlIvx+Lg
# s7Xz9XTjaVf/33NC0Ku5WaS9jfSW4OhBIHoz0VncUlNRjtVuDNvWnOi3HaZBtWHw
# +oG9AgRWmPE6yTiGPP3COIV+qG1NlQwKGrS++v510MX6DYoWTFgkiHRP8jNPBUN1
# e6N7om2SgEPC5HkO
# SIG # End signature block
