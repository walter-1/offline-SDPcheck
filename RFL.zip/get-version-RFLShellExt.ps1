# File: common file for get-update-RFLShellExt.ps1 and get-version-RFLShellExt.ps1
# last edit by: waltere 2019-09-26
<#
Dear RFL-check users,
I got notice from some colleagues that the RFL-check Explorer plugin lead to incorrect experience on Windows 10 machines prior to Creators Update, when clicking on links/shortcuts/TrayIcon for �OneDrive for Business�/(former SkyDrive).
While it is not fully clear to me, why this issue happens only for this specific app (OneDrive/Skydrive) � likely a bug in the app, I spent some time to investigate (using Sysinternals ProcMon) the issue and most likely came to a solution.
Please update the current version of the RFL PlugIn on your system to latest version v1.11 by either clicking the registry file for the new version of the shell extension \\emeacssdfs.europe.corp.microsoft.com\netpod\rfl\Rfl-Check_ShellExtension.reg  (or copying it to local drive first in case you run into this error:
Q01: the registry file Rfl-Check_ShellExtension.reg does not import on double-click, error
   Cannot import P:\Rfl-Check_ShellExtension.reg: Error opening the file. There may be a disk of file system error. [OK]
A01: Solution: Copy the .reg file at first to local disk C:\temp )
But first please make sure you delete the existing registry Key HKEY_CLASSES_ROOT\Directory\shell\Check-RFL and all subkeys. This can be done using PS script remove-RFLShellExt.ps1

Then, for your convenience just run the PowerShell script: \\emeacssdfs.europe.corp.microsoft.com\netpod\rfl\get-update-RFLShellExt.ps1 for latest update.
FYI: if you run the script without elevation, this PS script will start a new process in elevated context and ask for UAC confirmation, because of the registry changes needed, so please agree to PowerShell UAC (User Account Control) prompts.

#>

<#
.SYNOPSIS
The script will show version, install, update to latest version or remove your current version of the SDP/RFL Explorer PlugIn on your system.
The registry file for the latest version of the shell extension is located here: \\emeacssdfs.europe.corp.microsoft.com\netpod\rfl\Rfl-Check_ShellExtension.reg

SYNTAX: .\get-update-RFLShellExt.ps1 [- CheckType Check-RFL|Check_RFL_anchor|Check_SDP_anchor] [-GetVersion|-GetUpdate|-Remove]

.DESCRIPTION
The script reads in your current registry RFL information and writes new registry keys.
The script tries to run -GetUpdate or -Remove in elevated mode and ask user to agree (UAC prompt), because REG changes need admin permission.
Note: In case of any error, you still can download to local drive and doubleclick the *.reg file on
   \\emeacssdfs.europe.corp.microsoft.com\netpod\rfl\Rfl-Check_ShellExtension.reg
	 
Reg-Locations for RFL ShellExtension: "HKCU:\SOFTWARE\RFLcheck\" and
	V1: "HKCR:\Directory\shell\Check-RFL"
		"HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Chk_*" 
	V2: "HKCR:\Directory\shell\Check_RFL_anchor"
		"HKCR:\*\ContextMenus\Check_RFL\Shell"
		"HKCR:\Directory\shell\Check_SDP_anchor"
		"HKCR:\*\ContextMenus\Check_SDP\Shell"

.PARAMETER SkipAdminCheck
	If this switch is present, then the check for administrator privileges will be skipped
	Script needs Admin priv for Remove, and for Update if installed version does not match current version

.PARAMETER Remove
	If this switch is present, then the script will remove old Shell Extension

.PARAMETER GetUpdate
	If this switch is present, then the script will check and update version of Shell Extension 

.PARAMETER GetVersion
	If this switch is present, then the script will check and display version of Shell Extension

.PARAMETER HostMode
	If this switch is present, then the script will display output on screen

.PARAMETER ScriptMode
	If this switch is present, then the script will log output in logfile

.EXAMPLE
	To run the RFL shell PlugIn check and update on UNC path
	\\emeacssdfs.europe.corp.microsoft.com\netpod\rfl\get-update-RFLShellExt.ps1 -HostMode -GetUpdate

.EXAMPLE
	To run the RFL shell PlugIn VERSION check only
	\\emeacssdfs.europe.corp.microsoft.com\netpod\rfl\get-update-RFLShellExt.ps1 -HostMode -GetVersion

.EXAMPLE
	To remove the RFL shell PlugIn only
	\\emeacssdfs.europe.corp.microsoft.com\netpod\rfl\get-update-RFLShellExt.ps1 -HostMode -Remove
	
.LINK
	Update script: \\emeacssdfs.europe.corp.microsoft.com\netpod\rfl\get-update-RFLShellExt.ps1
	ShellExtension: \\emeacssdfs.europe.corp.microsoft.com\netpod\rfl\Rfl-Check_ShellExtension.reg
	RFL core team: waltere@microsoft.com

#>

[CmdletBinding()]
PARAM (
	[ValidateSet("Check-RFL","Check_RFL_anchor","Check_SDP_anchor")]
	[parameter(Mandatory=$False,Position=0,HelpMessage='Choose one from: [Check-RFL|Check_RFL_anchor|Check_SDP_anchor]')]
	[string]$CheckType = "Check_RFL_anchor"
	,
  [parameter(Mandatory=$false)]
  [switch]$SkipAdminCheck = $true,	# if $True, then the check for administrator privileges will be skipped
	[switch]$Elevated 		= $false,	# This will run script in elevated Admin mode
	[switch]$Script:IsRunAsAdmin = $false,
	[switch]$Remove 		= $false,	# $True for script remove-RFLShellExt.ps1
	[switch]$GetUpdate 	= $false,	# $True for script get-update-RFLShellExt.ps1
	[switch]$GetVersion 	= $true,	# $True for script get-version-RFLShellExt.ps1
	[switch]$InformUser		= $true,	# $False for suppressing Update info for user
	[switch]$HostMode		= $true,	# This tells the logging functions to show logging on the screen
	[switch]$ScriptMode		= $false, 	# This tells the logging functions to show logging into log file
  [switch]$UseExitCode	= $true,  # This will cause the script to close after the error is logged if an error occurs
	[switch]$DbgOut 		= $false	# $True for script debugging
)


BEGIN {

  # This saves the starting ErrorActionPreference and then sets it to 'Stop'.
  $startErrorActionPreference = $errorActionPreference
  # This gets the current path and name of the script.
  $invocation = (Get-Variable MyInvocation).Value
  $scriptPath = Split-Path $invocation.MyCommand.Path
	$FullScriptPath = (Get-Variable MyInvocation).Value.MyCommand.Path
	if ($DbgOut) {Write-host "invocation: $invocation"}
	if ($DbgOut) {Write-host "scriptPath: $scriptPath"}
	if ($DbgOut) {Write-host "FullScriptPath: $FullScriptPath"}
  $scriptName = $invocation.MyCommand.Name
	#$scriptDefinition = $myinvocation.MyCommand.Definition	#Full script path
	$UserName  = ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name)
	$UsrOSVersion = [Environment]::OSVersion.Version.ToString(3)
	if ($DbgOut) {Write-Host "Running `"$scriptPath\$scriptName`"..." -BackgroundColor Black -ForegroundColor Green}
	Set-Variable -Name ErrorMsg -Scope Script -Force
	[string]$Script:ErrorMsg=""
	
#region: ###### customization section of script, logging configuration ########################
		$VerMa="1"
		$VerMi="18"
		#$ErrorActionPreference = "Continue" #"Stop"
	$InOfflineMode = $True		# for outsourcer or when not connected to MS network - offline-SDPcheck
	if (-Not $InOfflineMode) {
		$RFLpath = "\\emeacssdfs.europe.corp.microsoft.com\netpod\rfl"
		if (Test-Connection -ComputerName waltere-vdi.europe.corp.microsoft.com -Quiet -Count 1) {[bool]$Stats=$True} else {[bool]$Stats=$False}
	} else { 
		$RFLpath = "\\localhost\ToolsShare\rfl"
		$Stats = $False
	}
		$LogLevel = 0

		$StatsServerPath = "\\waltere-vdi.europe.corp.microsoft.com\netpod\tools\RFL\"
		$CheckDate = (Get-Date).ToUniversalTime().ToString("yy-MM-dd_HH-mm-ss")
		$Script:regFileV1remove = "$RFLpath\Rfl-Check_ShellExtension_V1-Remove.reg"
		#$Script:regFileV2 = "$RFLpath\Rfl-Check_ShellExtension.reg" 
		$Script:regFileV2add = "$RFLpath\Rfl-Check_ShellExtension_V2-Add.reg"
		$Script:regFileV2remove = "$RFLpath\Rfl-Check_ShellExtension_V2-Remove.reg"
		$ExpectedShellExtVersionV1 = "1.11"	# in registry HKCR:\Directory\shell\Check-RFL
		$ExpectedShellExtVersionV2 = "2.06"	# in registry HKCR:\Directory\shell\Check_RFL_anchor|Check_SDP_anchor
		#$InformUser = $false	# inform user about available update
#endregion: ###### customization section
	
	if ($GetVersion) {
		[string]$InfoString = "RFLshExt_Version"
		$CountInvFil = $StatsServerPath +'countRFLshExVer.dat'
	}
	if ($GetUpdate) { 
		[string]$InfoString = "RFLshExt_Update"
		$CountInvFil = $StatsServerPath +'countRFLshExUpd.dat'
	}
	if ($Remove) {
		Write-Host "`n Admin priv needed for -Remove" 
		[string]$InfoString = "RFLshExt_Remove"
		$CountInvFil = $StatsServerPath +'countRFLshExRemove.dat'
	}
	$CountInvFil2 = $CountInvFil +'.us'
	$LogPath = $SDPPath + "_" + "$InfoString`.log"
	$ErrorThrown = $null
	$Script:CurrShellExtVer ='undefined'
	$Script:ResultMsg = ""

	
	If ($Stats) { #increment at start of script
	 ($j=[int32](Get-Content $CountInvFil -TotalCount 1 -ErrorAction SilentlyContinue)) |out-null
	 (++$j) | Set-Content $CountInvFil -ErrorAction SilentlyContinue
	 }
	If ($PSBoundParameters['Debug']) { $DebugPreference='Continue'}

<#	
	if (-not $CheckType) {Write-Verbose "CheckType was: $CheckType"
			$CheckType = "Check_RFL_anchor"
			Write-host "CheckType: $CheckType "
	}
#>
	Set-Variable -Name ShellExtExists	-Scope Script -Force
	Set-Variable -Name ShellExtVersion	-Scope Script -Force
	Set-Variable -Name regFile 			-Scope Script -Force
	Set-Variable -Name FullScriptPath	-Scope Script -Force
			
	#region: Logging Functions
	function WriteLine ([string]$line,[string]$ForegroundColor, [switch]$NoNewLine){
	# SYNOPSIS: writes the actual output - used by other Logging Functions
    if($Script:ScriptMode){
      if($NoNewLine) {
        $Script:Trace += "$line"
      }
      else {
        $Script:Trace += "$line`r`n"
      }
      Set-Content -Path $script:LogPath -Value $Script:Trace
    }
    if($Script:HostMode){
      $Params = @{
        NoNewLine    = $NoNewLine -eq $true
        ForegroundColor = if($ForegroundColor) {$ForegroundColor} else {"White"}
      }
      Write-Host $line @Params
    }
  }

  function WriteInfo([string]$message,[switch]$WaitForResult,[string[]]$AdditionalStringArray,[string]$AdditionalMultilineString){
	# SYNOPSIS: handles informational logs
    if($WaitForResult){
      WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)$message" -NoNewline
    }
    else{
      WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)$message"
    }
    if($AdditionalStringArray){
      foreach ($String in $AdditionalStringArray){
        WriteLine "          $("`t" * $script:LogLevel)`t$String"
      }
    }
    if($AdditionalMultilineString){
      foreach ($String in ($AdditionalMultilineString -split "`r`n" | Where-Object {$_ -ne ""})){
        WriteLine "          $("`t" * $script:LogLevel)`t$String"
      }
    }
  }

  function WriteResult([string]$message,[switch]$Pass,[switch]$Success){
	# SYNOPSIS: writes results - should be used after -WaitForResult in WriteInfo
    if($Pass){
      WriteLine " - Pass" -ForegroundColor Cyan
      if($message){
        WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)`t$message" -ForegroundColor Cyan
      }
    }
    if($Success){
      WriteLine " - Success" -ForegroundColor Green
      if($message){
        WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)`t$message" -ForegroundColor Green
      }
    }
  }

  function WriteInfoHighlighted([string]$message,[string[]]$AdditionalStringArray,[string]$AdditionalMultilineString){
	# SYNOPSIS: write highlighted info
    WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)$message" -ForegroundColor Cyan
    if($AdditionalStringArray){
      foreach ($String in $AdditionalStringArray){
        WriteLine "[$(Get-Date -Format hh:mm:ss)]     $("`t" * $script:LogLevel)`t$String" -ForegroundColor Cyan
      }
    }
    if($AdditionalMultilineString){
      foreach ($String in ($AdditionalMultilineString -split "`r`n" | Where-Object {$_ -ne ""})){
        WriteLine "[$(Get-Date -Format hh:mm:ss)]     $("`t" * $script:LogLevel)`t$String" -ForegroundColor Cyan
      }
    }
  }

  function WriteWarning([string]$message,[string[]]$AdditionalStringArray,[string]$AdditionalMultilineString){
	# SYNOPSIS: write warning logs
    WriteLine "[$(Get-Date -Format hh:mm:ss)] WARNING: $("`t" * $script:LogLevel)$message" -ForegroundColor Yellow
    if($AdditionalStringArray){
      foreach ($String in $AdditionalStringArray){
        WriteLine "[$(Get-Date -Format hh:mm:ss)]     $("`t" * $script:LogLevel)`t$String" -ForegroundColor Yellow
      }
    }
    if($AdditionalMultilineString){
      foreach ($String in ($AdditionalMultilineString -split "`r`n" | Where-Object {$_ -ne ""})){
        WriteLine "[$(Get-Date -Format hh:mm:ss)]     $("`t" * $script:LogLevel)`t$String" -ForegroundColor Yellow
      }
    }
  }

  function WriteError([string]$message){
	# SYNOPSIS: logs errors
    WriteLine ""
    WriteLine "[$(Get-Date -Format hh:mm:ss)] ERROR:  $("`t`t" * $script:LogLevel)$message" -ForegroundColor Red
  }

  function WriteErrorAndExit($message){
	# SYNOPSIS: logs errors and terminates script
    WriteLine "[$(Get-Date -Format hh:mm:ss)] ERROR:  $("`t" * $script:LogLevel)$message" -ForegroundColor Red
    Write-Host "Press any key to continue ..."
    $host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") | OUT-NULL
    $HOST.UI.RawUI.Flushinputbuffer()
    Throw "Terminating Error"
  }
	#endregion: Logging Functions

	#region: Script Functions
	function CheckAdminPrivileges {
		# SYNOPSIS: check for PowerShell Admin priv
		# Return: $True if running as Admin
		[CmdletBinding()]
		Param(
			[parameter(Mandatory=$true)] [Bool] $SkipAdminCheck
		)
		if ($DbgOut) {Write-host "ENTER: CheckAdminPrivileges"}
		if (-not $SkipAdminCheck) {
			# Yep, this is the easiest way to do this.
			$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")
			if (-not $isAdmin) {
				throw "You do not have the required permission to complete this task. Please run this command in an Administrator PowerShell window or specify the -SkipAdminCheck option."
			}
		}
	} # CheckAdminPrivileges()

	function Test-Admin {
		# SYNOPSIS: check for PowerShell Admin priv
		# Return: $True if running as Admin, $False if not
		if ($DbgOut) {Write-host "ENTER: Test-Admin"}
		$currentUser = New-Object Security.Principal.WindowsPrincipal $([Security.Principal.WindowsIdentity]::GetCurrent())
		$currentUser.IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)
	}
	
	function checkRegKey ($rKey) {
		# SYNOPSIS - check if RegKey exists
		# Return: $True if found, $False if not found 
		if ($DbgOut) {Write-host "ENTER: checkRegKey"}
		New-PSDrive -Name HKCR -PSProvider Registry -Root HKEY_CLASSES_ROOT |out-null
		$ErrorActionPreference = "stop"
		Try { 
			$exists = Get-Item -Path $rKey
			if ($exists) {WriteInfo -message "$rKey exists." 
			return $True}
			}
		Catch [System.Management.Automation.PSArgumentException]
		 {	 return $False}
		Catch [System.Management.Automation.ItemNotFoundException]
		 {	WriteError -message "$rKey is missing."
			return $False }
		Finally { $ErrorActionPreference = "Continue" }
	} # end of checkRegKey

	function checkPlugin-ShellExt ($CheckType,$registryPath,$CheckedVer) {
		# SYNOPSIS - check if RFLShellExt is installed, Write message to user if Plugin is missing
		# $CheckType can be "Check-RFL" or "Check_RFL_anchor" or "Check_SDP_anchor"
		# Return: '__Found ..' or '.. itself is missing'
		if ($DbgOut) {Write-host "ENTER: checkPlugin-ShellExt"}
		 New-PSDrive -Name HKCR -PSProvider Registry -Root HKEY_CLASSES_ROOT |out-null
		 #$registryPath = "HKCR:\Directory\shell\$($CheckType)"
		 $ErrorActionPreference = "stop"
		 
		 Try { 
			#check if RFLShellExt is installed and 'Version' key exists
			WriteInfo -message "[RFLshExt_Plugin] _Checking for existing ShellExt $($CheckType) in $registryPath"
			$Script:ShellExtKey = (Get-ItemProperty -Path $registryPath )
			if ($Script:ShellExtKey) {
				$Script:CurrShellExtVer = $($Script:ShellExtKey.Version)
				WriteInfo -message "[$InfoString`] __Found ShellExt in $registryPath ver: $Script:CurrShellExtVer "
				$Script:ResultMsg += "$CheckedVer $CheckType ver: $Script:CurrShellExtVer " }
				#return "Found $Script:CurrShellExtVer"
		 }
		 Catch [System.Management.Automation.ItemNotFoundException]
		  { 
			if ($InformUser) {
				 #Write message to user if Plugin is missing
				 Write-host -BackgroundColor Black -ForegroundColor Yellow -Object "... Simplify: Consider to run Explorer-Extension V2 update $ExpectedShellExtVersionV2 in elevated PowerShell window, see also _Help.rtf:"
				 Write-host -BackgroundColor Black -ForegroundColor Cyan -Object " Powershell -ExecutionPolicy Bypass $RFLpath\get-update-RFLShellExt.ps1"
			}
			 WriteError -message "$registryPath itself is missing."
			 $Script:ResultMsg += "$CheckedVer $CheckType is missing. "
			 return "$CheckedVer $registryPath itself is missing."
		 }
		 Finally { $ErrorActionPreference = "Continue" }
	} # end of checkPlugin-ShellExt

	function checkVer-ShellExt ($CheckType,$registryPath,$ExpectedShellExtVersion) {
		# SYNOPSIS - check if RFLShellExt 'Version' key exists
		# Return: "$Script:CurrShellExtVer _up_to_date" - "$Script:CurrShellExtVer _outdated - user_informed." - ".. Property Version missing." - ""
		 #check if 'Version' key exists
		 if ($DbgOut) {Write-host "ENTER: checkVer-ShellExt"}
		 New-PSDrive -Name HKCR -PSProvider Registry -Root HKEY_CLASSES_ROOT |out-null
		 #$registryPath = "HKCR:\Directory\shell\$($CheckType)"
		 Try { $ErrorActionPreference = "stop"
			WriteInfo -message "[$InfoString`] _Checking current version for $($CheckType) in $registryPath"
			$Script:CurrShellExtVer = (Get-ItemProperty -Path $registryPath -Name Version -ErrorAction SilentlyContinue).Version
			if ($Script:CurrShellExtVer)	{
				WriteInfo -message "[$InfoString`] __comparing your RFL ShellExtension version: $Script:CurrShellExtVer with latest $Script:ExpectedShellExtVersion"
				if ($Script:CurrShellExtVer -match $ExpectedShellExtVersion) {
					WriteInfo -message "[$InfoString`] __Your RFL ShellExtension version $Script:CurrShellExtVer is up-to-date";
					return " $Script:CurrShellExtVer _up_to_date"}
				else {
					if ($Script:CurrShellExtVer -lt 1.09) {Write-host -BackgroundColor Black -ForegroundColor Red -Object " Support for this older RFL version has ended, because Server \\muc-vfs-01a is decommissioned."}
					Write-host -BackgroundColor Yellow -ForegroundColor Black -Object "[$InfoString`] __Your RFL ShellExtension version $Script:CurrShellExtVer is outdated! (Available: v$ExpectedShellExtVersion)
		 .. Consider updating the RFL Shell Explorer Plugin to v$ExpectedShellExtVersion `n $Script:regFileV2add
		 To do so, run in ELEVATED (Run as Administrator) PS window the commands:"
					Write-host -ForegroundColor Cyan -Object " Powershell -ExecutionPolicy Bypass $RFLpath\remove-RFLShellExt.ps1"
					Write-host -ForegroundColor Cyan -Object " Powershell -ExecutionPolicy Bypass $RFLpath\get-update-RFLShellExt.ps1"
					return "$Script:CurrShellExtVer _outdated - user_informed."}
				}
			else { WriteInfo -message "[$InfoString`] $registryPath\Version not found"
					$Script:CurrShellExtVer ='V-undefined' }
		 }
		 Catch [System.Management.Automation.PSArgumentException]
		  {
			 return "[$InfoString`] RegKey $registryPath Property Version missing."
		  }
		 Catch [System.Management.Automation.ItemNotFoundException]
		  { WriteInfo -message "[$InfoString`] RegKey $registryPath\Version is missing."
			 Write-debug "[$InfoString`] ...RFLshellPlugin not up-to-date - creating it."
			 Write-debug "[$InfoString`] ...***please allow registry Version update when UAC prompted***"
			 return "[$InfoString`] RegKey $registryPath\Version is missing."
		 }
		 Finally { $ErrorActionPreference = "Continue" }
	} # end of checkVer-ShellExt

	function CheckForUpdates-RFLShellExt ($CheckType,$ExpectedShellExtVersion) {
		# SYNOPSIS - 													### currently not in use
		# Return: nothing
		if ($DbgOut) {Write-host "ENTER: CheckForUpdates-RFLShellEx"}
		 WriteInfo -message "[RFLshExt_ChkUpdates] checking registryPath: $registryPathHKCR\CheckForUpdates"
		 $name = "CheckForUpdates"
		 $value = "1"
		  Try { $ErrorActionPreference = "stop"
			$CheckForUpdates = (Get-ItemProperty -Path $registryPathHKCR -Name CheckForUpdates -ErrorAction SilentlyContinue).CheckForUpdates
			if ($CheckForUpdates) {WriteInfo -message "[RFLshExt_ChkUpdates] Current CheckForUpdates: $CheckForUpdates"}
			if ($CheckForUpdates -NotMatch "0") {WriteInfo -message "[RFLshExt_ChkUpdates] Current ShellExt setting for CheckForUpdates: $CheckForUpdates"}
			else {	WriteInfo -message "[RFLshExt_ChkUpdates] CheckForUpdates: '$CheckForUpdates' - .. Consider updating the RFL Shell Explorer Plugin to v$ExpectedShellExtVersion `n $Script:regFileV2add "
				WriteInfo -message "[RFLshExt_ChkUpdates] ... keep existing plugin settings because $registryPathHKCR\CheckForUpdates is set to '$CheckForUpdates'"
				break #continue
				}
		 }
		 Catch [System.Management.Automation.PSArgumentException]
		  { "[RFLshExt_ChkUpdates] RegKey $registryPathHKCR Property $name missing."
			 New-ItemProperty -Path $registryPathHKCR -Name $name -Value $value -PropertyType DWORD -Force | Out-Null
		  }
		 Catch [System.Management.Automation.ItemNotFoundException]
		  { "[RFLshExt_ChkUpdates] RegKey $registryPathHKCR itself is missing."
			 WriteInfo -message "[RFLshExt_ChkUpdates] ...RFLshellPlugin not installed - creating it"
			 New-Item -Path $registryPathHKCR -Force #| Out-Null
			 New-ItemProperty -Path $registryPathHKCR -Name $name -Value $value -PropertyType DWORD -Force | Out-Null
		 }
		 Finally {
			 "[RFLshExt_ChkUpdates] CheckForUpdates reg: $CheckForUpdates"
			 $ErrorActionPreference = "Continue" }
	} # end of CheckForUpdates-RFLShellExt

	function update-ShellExt ($CheckType,$ExpectedShellExtVersion) {
		# SYNOPSIS - update the existing ShellExtension
		# Return: nothing
		#IF (!($Script:CurrShellExtVer -match $ExpectedShellExtVersion) -and ($CheckForUpdates -NotMatch "0")) {
		if ($DbgOut) {Write-host "ENTER: update-ShellExt"}
		if ($Script:CurrShellExtVer -NotMatch $ExpectedShellExtVersion) {
			#WriteInfo -message "[$InfoString`] ...Outdated Check-RFL ShellExtVersion '$Script:CurrShellExtVer', removing existing entry $registryPathHKCR '$Script:CurrShellExtVer'"
			Try
				{
				WriteInfo -message "[$InfoString`] ...***please allow registry REMOVE when UAC prompted***"

				WriteInfo -message "[$InfoString`] ...Step#1 Remove v1: Importing $Script:regFileV1remove silently"
				WriteInfo -message "[$InfoString`] ...***please allow registry UPDATE when UAC prompted***"
				$RegTry = regedit /s $Script:regFileV1remove

				WriteInfo -message "[$InfoString`] ...Step#2 Importing latest $Script:regFileV2add silently"
				WriteInfo -message "[$InfoString`] ...***please allow registry UPDATE when UAC prompted***"
				$RegTry = regedit /s $Script:regFileV2add
				#WriteInfo -message "[$InfoString`] ...RegTry result: $RegTry"
				Write-host -BackgroundColor Black -ForegroundColor Green -Object "[$InfoString`] RFLShellExt $CheckType successfully updated"
				"RegImport-done for exp. v$ExpectedShellExtVersion"
				}
			Catch [System.Security.SecurityException]
				{ WriteError -message "Registry Remove-Item $registryPathHKCR"
					WriteError -message "[$InfoString`] Aborted. The error was '$($_.Exception.Message)'"
					Write-host -BackgroundColor Black -ForegroundColor Red -Object "[$InfoString`] Aborted by user"
					"Aborted by user."
				}
			Finally
				{
				"RegVersion-not-matched, inst.Ver: '$Script:CurrShellExtVer'"
				}
		}
	} # end of update-ShellExt

	function autoupdate-ShellExt ($CheckType,$registryPath,$ExpectedShellExtVersion) {
		# SYNOPSIS - AutoUpdate the existing ShellExtension
		# Return: nothing
		if ($DbgOut) {Write-host "ENTER: autoupdate-ShellExt"}
		 if ($Script:ShellExtKey)	{
			checkVer-ShellExt $CheckType $registryPath $ExpectedShellExtVersion		#call function
			if ($Script:CurrShellExtVer -lt 1.09) {
				if ($GetVersion) {
					Write-host -BackgroundColor Black -ForegroundColor Yellow -Object "`n Trying Auto-Update, Please agree when prompted for running in elevated PS and Registry modification."
					Powershell -noprofile -ExecutionPolicy Bypass $RFLpath\get-update-RFLShellExt_v1.16.ps1 -SkipAdminCheck -GetUpdate
					checkVer-ShellExt $CheckType $registryPath $ExpectedShellExtVersion
					if ($Script:CurrShellExtVer -match $ExpectedShellExtVersion) {Write-host -BackgroundColor Black -ForegroundColor Green -Object " AutoUpdate version completed: v$Script:CurrShellExtVer"}
				}
			}
		}
		if ($GetUpdate) {update-ShellExt $CheckType $ExpectedShellExtVersion}	#call function
	} #end function autoupdate-ShellExt

	function remove-ShellExt ($CheckType,$registryPath) {
		# SYNOPSIS - Delete all the registry rentries for the existing ShellExtension
		# Return: result of action done
		if ($DbgOut) {Write-host "ENTER: remove-ShellExt"}
			WriteInfo -message "[RFLshExt_Remove] Checking ShellExt for $($CheckType) $registryPath"
			switch($registryPath)
				{
				"$($registryPathHKCR)"		{New-PSDrive -Name HKCR -PSProvider Registry -Root HKEY_CLASSES_ROOT |out-null}
				"$($registryPathHKCR2)"		{New-PSDrive -Name HKCR -PSProvider Registry -Root HKEY_CLASSES_ROOT |out-null}
				"$($registryPathHKLM)"		{New-PSDrive -Name HKLM -PSProvider Registry -Root HKEY_LOCAL_MACHINE |out-null}
				"$($registryPathHKCU)"		{New-PSDrive -Name HKCU -PSProvider Registry -Root HKEY_CURRENT_USER |out-null}
				}
			
			#WriteInfo -message "[RFLshExt_Remove] ...***please allow registry REMOVE when UAC prompted***"
			$ErrorActionPreference = "stop"
			
			Try
			{
				$Script:RegPathKey = (Get-ItemProperty -Path $registryPath )
				if ($Script:RegPathKey) {
					WriteInfo -message "[RFLshExt_Remove] _Trying to remove registry-tree $registryPath"
					Remove-Item $registryPath -Recurse
					return " removed $registryPath"
				}
			}
			Catch [System.Security.SecurityException]
				{	WriteError "RegKey $registryPath SecurityException" 
					WriteError "[RFLshExt_Remove] Aborted. The error was '$($_.Exception.Message)'"
					WriteError "[RFLshExt_Remove] Aborted by user SecurityException"
					return " RegRemove $registryPath aborted by user SecurityException."
				}
			Catch [System.Management.Automation.ItemNotFoundException]
				{	WriteError "[RFLshExt_Remove] Cannot find path or item $registryPath"
					return " RegRemove ItemNotFoundException."
				}
			#Catch [System.Management.Automation.PathNotFound]
			#	{ "[RFLshExt_Remove] Cannot find path $registryPath"}
			Finally
			{
				$ErrorActionPreference = "Continue" 
				#"RFLShellExt $CheckType successfully removed"
			}
	} # end of remove-ShellExt

	function LaunchElevated {
	 # SYNOPSIS : Launches an elevated process running the current script to perform tasks that require administrative privileges. This function waits until the elevated process terminates.
		# Set up command line arguments to the elevated process
		if ($DbgOut) {Write-host "ENTER: LaunchElevated"}
		$Script:RelaunchArgs = '-NoExit -ExecutionPolicy Bypass -file "' + $FullScriptPath + '" -IsRunAsAdmin'

		# Launch the process and wait for it to finish
		try
		{
			$AdminProcess = Start-Process "$PsHome\PowerShell.exe" -Verb RunAs -ArgumentList $Script:RelaunchArgs -PassThru
		}
		catch
		{
			$Error[0] # Dump details about the last error
			exit 1
		}

		# Wait until the elevated process terminates
		while (!($AdminProcess.HasExited))
		{
			Start-Sleep -Seconds 2
		}
	}

	function DoElevatedOperations {
		Write-Host "Do elevated operations"
		Start-Sleep -Seconds 5
	}

	function DoStandardOperations {
		Write-Host "Do standard operations"

		LaunchElevated
		Start-Sleep -Seconds 5
	}
	
	function DoGetVersion ($CheckType,$ExpectedShellExtVersion) {
		if ($DbgOut) {Write-host "ENTER: DoGetVersion"}
		# define registry locations for v1 Check-RFL, and v2 Check_RFL_anchor, Check_SDP_anchor
		$registryPathHKCU = "HKCU:\SOFTWARE\RFLcheck\shellExtension" 
		switch($CheckType)
		{
		"Check-RFL"			{ $CheckedVer = "v1"
							$registryPathHKCR = "HKCR:\Directory\shell\Check-RFL"
							$registryPathHKLM = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Chk_*" 
							}
		"Check_RFL_anchor"	{ $CheckedVer = "v2"
							$registryPathHKCR = "HKCR:\Directory\shell\Check_RFL_anchor"
							$registryPathHKCR2 = "HKCR:\*\ContextMenus\Check_RFL\Shell" 
							}						
		"Check_SDP_anchor"	{ $CheckedVer = "v2"
							$registryPathHKCR = "HKCR:\Directory\shell\Check_SDP_anchor"
							$registryPathHKCR2 = "HKCR:\*\ContextMenus\Check_SDP\Shell" 
							}
		}

		WriteInfo -message "$CheckedVer CheckType: $CheckType REG: $registryPathHKCR"
		
		#$au = autoupdate-ShellExt $CheckType $registryPathHKCR $ExpectedShellExtVersion	#call function
		checkPlugin-ShellExt $CheckType $registryPathHKCR $CheckedVer
		WriteInfo -message "[$InfoString`] GetVersion results: $Script:ResultMsg"
		if ($Script:CurrShellExtVer -NotMatch $ExpectedShellExtVersionV2) {
			Write-host -BackgroundColor Black -ForegroundColor Yellow -Object "... Outdated: Consider to run Explorer-Extension V2 update $ExpectedShellExtVersionV2 in elevated PowerShell window, see also _Help.rtf:"
			Write-host -BackgroundColor Black -ForegroundColor Cyan -Object " Powershell -ExecutionPolicy Bypass $RFLpath\get-update-RFLShellExt.ps1" 
			[System.Media.SystemSounds]::Hand.Play() } # Play sound to get some attention 
		#$Script:ResultMsg += $au
		If ($Script:ResultMsg-match "missing") {
			WriteInfo -message "[$InfoString`] .. Consider installing the RFL Shell Explorer Plugin v$ExpectedShellExtVersion`n	$Script:regFileV2add
	To do so, run in elevated (Run as Administrator) PS window the command: 
	Powershell -ExecutionPolicy Bypass $RFLpath\get-update-RFLShellExt.ps1"
		}
		return $Script:ResultMsg
	} # end DoGetVersion

	function DoGetUpdate ($CheckType,$ExpectedShellExtVersion) {
		if ($DbgOut) {Write-host "ENTER: DoGetUpdate"}
		$au = update-ShellExt $CheckType $ExpectedShellExtVersion		#call function
		Write-host -BackgroundColor Black -ForegroundColor Green -Object "[$InfoString`] ...done. New RFL ShellExt $ExpectedShellExtVersion plugin should be available in your Windows Explorer context menu for folders right now."
		WriteInfo -message "Note: In case of any error, you still can download to local drive and doubleclick the *.reg file on`n $($RFLpath)Rfl-Check_ShellExtension.reg"
		$Script:ResultMsg += $au
	}
	
	function DoRemove ($CheckType,$ExpectedShellExtVersion) {
		if ($DbgOut) {Write-host "ENTER: DoRemove"}
		WriteInfo -message "[RFLshExt_Remove] ***Deleting reg-locations for RFL Shell-Extension version '$Script:CurrShellExtVer'`n "
		$registryPaths = $registryPathHKCR,$registryPathHKLM,$registryPathHKCU
		foreach ($registryPath in $registryPaths)
			{
			$exists = checkRegKey $registryPath
			if ($exists) { 
				$au += remove-ShellExt $CheckType $registryPath	#call function "Check-RFL"
				WriteInfo -message "[RFLshExt_Remove] __results: $au `n"
				}
			}
		$Script:ResultMsg = $au
	}
	#endregion: Script Functions
} #end BEGIN


PROCESS {
	try {
			$ScriptBeginTimeStamp = Get-Date
			#region: MAIN :::::

			<#
			if ($Script:CurrShellExtVer -match "undefined") {
				$au = checkPlugin-ShellExt $CheckType $registryPathHKCR; $Script:ResultMsg += $au}
#>
			if ($GetVersion) {
				$V2check = DoGetVersion Check_RFL_anchor $ExpectedShellExtVersionV2
				WriteInfo -message "[$InfoString`] *** V2check : $V2check"
				if ($Script:ResultMsg -notmatch "2.0") {
					$V1check = DoGetVersion Check-RFL $ExpectedShellExtVersionV1
					WriteInfo -message "[$InfoString`] *** V1check : $V1check" }
			} #>

			if ($GetUpdate) {
				$V2check = DoGetVersion Check_RFL_anchor $ExpectedShellExtVersionV2
				if ($Script:CurrShellExtVer -NotMatch $ExpectedShellExtVersionV2) { DoGetUpdate $CheckType $ExpectedShellExtVersion}
				else { WriteInfo -message "-GetUpdate requires Admin priv."}
			}

			if ($Remove) {
				if ((Test-Admin) -eq $true) { DoRemove $CheckType $ExpectedShellExtVersion}
				else { WriteInfo -message "-Remove requires Admin priv."
					#.\get-update-RFLShellExt_v1.16.ps1 -CheckType Check-RFL -Remove -Hostmode
					DoStandardOperations
					Write-Host "RelaunchArgs: $Script:RelaunchArgs"
							#DoElevatedOperations
							
					#LaunchElevated 
					#Start-Sleep -Seconds 5
				<#	if ($IsRunAsAdmin) {
						Write-Host "RelaunchArgs: $RelaunchArgs"
							DoElevatedOperations
					}
					else
						{
							DoStandardOperations
						} #>
				}
			}

			WriteInfo -message "Overall-Results: $Script:ResultMsg"

			#endregion: MAIN
	} # end try PROCESS
	catch {
		$errorMessage = "$scriptName caught an exception on $($ENV:COMPUTERNAME):"
		$errorMessage += "`n`n"
		$errorMessage += "Exception Type: $($_.Exception.GetType().FullName)"
		$errorMessage += "`n`n"
		$errorMessage += "Exception Message: $($_.Exception.Message)"

		Write-Error $errorMessage -ErrorAction Continue
		<# Log error
				Write-Verbose "Logging the script's error..."
		# Log error - EventLog
				#An event log source needs to be preconfigured to use this.
				Write-EventLog `
					-EventId $AlertNumber `
					-LogName $LogName `
					-Source $EventSource `
					-Message $errorMessage `
					-EntryType Error
		# Log error - Email
				# This will attempt to send an immediate alert about the error.
				# The EventLog also needs to log the error because this one may not be sent.
				#use Send-MailMessage
		#>
		#_#Start-Sleep -Seconds 3
		Write-Debug $errorMessage
		if ( $UseExitCode ) {
			$error.clear()	# clear script errors
			exit 1
		} #end UseExitCode
  } #end Catch PROCESS
	Finally {
	} #end Finally PROCESS
} #end PROCESS


END {
	$ScriptEndTimeStamp = Get-Date
	$Duration = $(New-TimeSpan -Start $ScriptBeginTimeStamp -End $ScriptEndTimeStamp)
	$LogLevel = 0
	WriteInfo -message "[Done] Script $scriptName v$VerMa.$VerMi execution finished. Duration: $Duration `n"
	if($ErrorThrown) {Throw $error[0].Exception.Message}
	# Stats
	If ($Stats) { #increment at start of script
	   "$j; $CheckDate; $UsrOSVersion; $UserName; $Duration; [$InfoString`]; $Script:CurrShellExtVer; $Script:ResultMsg; v$VerMa.$VerMi; $env:computername" | Out-File $CountInvFil2 -Append -Encoding UTF8 -ErrorAction SilentlyContinue
	}
  # This resets the ErrorActionPreference to the value at script start.
  $errorActionPreference = $startErrorActionPreference
	#Write full error message
	#$error[0] |fl * -force
} #end END

#region: comments
<#
	The top section is comment based help so the Get-Help command will work with the script.
	The [CmdletBinding()] turns on advanced options like the common parameters.
	All sub functions are in the "BEGIN" section.
	My script code goes in the "PROCESS try" block.

VERSION and AUTHOR:
	Walter Eder	- waltere@microsoft.com

HISTORY
	2015-02-02	V1.04
	2016-07-02	V1.06 add capability to remove all RFL registry settings, see remove-RFLShellExt.ps1
	2017-04-03	V1.08 (removed platform, re-added VSS in Rfl-Check_ShellExtension_FQDN.reg)
	2017-10-06	v1.11 changed [RFLshExt_Update] to [$InfoString`] + output enhancements
	2017-11-19	v1.13 using PS fuctions
	2019-01-13	v1.16 consolidating get-version-RFLShellExt.ps1 and get-update-RFLShellExt.ps1 and remove-RFLShellExt.ps1
	2019-09-26	v1.18 new ShellExtVersion v2.06, $InformUser= $true 

	ToDo: 	/known issue:
	#https://blogs.msdn.microsoft.com/virtual_pc_guy/2010/09/23/a-self-elevating-powershell-script/

#>
#endregion: comments 
# SIG # Begin signature block
# MIIjkgYJKoZIhvcNAQcCoIIjgzCCI38CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBmZMnLuOJf1cB8
# Ssd8TlpRdL79dImyJspv4FWdbxDIuKCCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVZzCCFWMCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgIcrl48JR
# bzlUa4new+nWLw4JA+fWa9V5Qm0OKS9kNLEwOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBAD7mwlnxp+WtwluW4pPTONWQX7M09k17qAr5G3kvUfSO2EaOXWNFqzfJ
# Uao5P3RmkIfacyi0wqUk1KELZXrbP1KYjHrqwMXkRgx2jqu6INdPK0/kWcVEPjnI
# pxJlMK1lHmSTaTVB+rS65ON5fqqyJWX1WKGH4bhnYXeAEYRuM5wcmJROaKzXcU+2
# /HAtv+AnnZtXOX35Au4tldc56Uv3U0wznE06u28DDD/KZg2m3cgl9h2AWpmyAaOh
# q8x7m4finkwAoAGKi7tDR8VkLOT2nSpWrIp9G3kpbjHYKYkvHjD3eZ2OGSPbWFqt
# 75UtxZH181gd3R7GIKV+fM+cyn984QuhghL7MIIS9wYKKwYBBAGCNwMDATGCEucw
# ghLjBgkqhkiG9w0BBwKgghLUMIIS0AIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBWQYL
# KoZIhvcNAQkQAQSgggFIBIIBRDCCAUACAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQgkGJmCsRMZAbe7wgdrF73ppn/RG17fTjNxq6s8G3SA9kCBmFIuOmc
# 6hgTMjAyMTEwMTMwMTE1NTUuMzc5WjAEgAIB9KCB2KSB1TCB0jELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IEly
# ZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVT
# TjowODQyLTRCRTYtQzI5QTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaCCDkowggT5MIID4aADAgECAhMzAAABOczo6EOL8DThAAAAAAE5MA0G
# CSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTIw
# MTAxNTE3MjgyMVoXDTIyMDExMjE3MjgyMVowgdIxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9w
# ZXJhdGlvbnMgTGltaXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046MDg0Mi00
# QkU2LUMyOUExJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Uw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDaE/mM4yWTJaGOsyoG/KJ4
# +FofmDdPf1DB27oeoCdZwuXP39kqgL9AXPjmBvRp3Xgi+oVoWbYnqj6+GFt/ihAk
# 4cNNyNlcEpBNtBP/DosJa90JecVCXZrycR3jYSYTuvFFWYq6ZsegQpX5DBh0ZzvS
# rk7wzZiSon9K1ysWEW2aEXFy9Vn6CDhrPO8Tzv6ygjNhXrOozYpY79NLL1l6iLlf
# hChtXoAq7AkfTzJJnaVAFfOd3yvAPPLr4FioleKb5v5X7sTfvjVvpxD1+Y40Ckcu
# GQaqjTv8HXg2Qaqo73vyECNe1WhCkqMq7rLFfOyylCePSuV+xX8fJJb+X6LPHspP
# AgMBAAGjggEbMIIBFzAdBgNVHQ4EFgQUmZ6bhnJUwpnakoqxn0b2UC0GDOkwHwYD
# VR0jBBgwFoAU1WM6XIoxkPNDe3xGG8UzaFqFbVUwVgYDVR0fBE8wTTBLoEmgR4ZF
# aHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljVGlt
# U3RhUENBXzIwMTAtMDctMDEuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcw
# AoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNUaW1TdGFQ
# Q0FfMjAxMC0wNy0wMS5jcnQwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEF
# BQcDCDANBgkqhkiG9w0BAQsFAAOCAQEAWFwoavP/NxqFzcFa7UOCiL8QDbEm+7r2
# EYiToW0g8ddYyK5Wa1FAd/ynJD1qyc/Zxx9HP90yqXKT+rz4g1wIsQSWlKCb3XG4
# IVhsWECEsm2ijN/fxofmtjZnFY31u4MSScl+IaIrpD7ySQI1aZtaPYPFHAQXwh8H
# CMXsQ+FgOB2KUrPjzq7CGCiyivUa4NaKViMagw2reWvAMiRj/zcpSkmGiuWmIF2Q
# g0SxWQJ/PIQuZ70Le1qZm0xJfGtRnBfpat/d1JgQCrLfo8lkmuLBPCG/OMh6oPx4
# rNRSHe58Tb8SMQBtpsGEKjb61SjKdPpMAm2N2K9riDs/vf9VCtJwxzCCBnEwggRZ
# oAMCAQICCmEJgSoAAAAAAAIwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290
# IENlcnRpZmljYXRlIEF1dGhvcml0eSAyMDEwMB4XDTEwMDcwMTIxMzY1NVoXDTI1
# MDcwMTIxNDY1NVowfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggEiMA0G
# CSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCpHQ28dxGKOiDs/BOX9fp/aZRrdFQQ
# 1aUKAIKF++18aEssX8XD5WHCdrc+Zitb8BVTJwQxH0EbGpUdzgkTjnxhMFmxMEQP
# 8WCIhFRDDNdNuDgIs0Ldk6zWczBXJoKjRQ3Q6vVHgc2/JGAyWGBG8lhHhjKEHnRh
# Z5FfgVSxz5NMksHEpl3RYRNuKMYa+YaAu99h/EbBJx0kZxJyGiGKr0tkiVBisV39
# dx898Fd1rL2KQk1AUdEPnAY+Z3/1ZsADlkR+79BL/W7lmsqxqPJ6Kgox8NpOBpG2
# iAg16HgcsOmZzTznL0S6p/TcZL2kAcEgCZN4zfy8wMlEXV4WnAEFTyJNAgMBAAGj
# ggHmMIIB4jAQBgkrBgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQU1WM6XIoxkPNDe3xG
# G8UzaFqFbVUwGQYJKwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGG
# MA8GA1UdEwEB/wQFMAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186a
# GMQwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3Br
# aS9jcmwvcHJvZHVjdHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsG
# AQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwgaAGA1UdIAEB
# /wSBlTCBkjCBjwYJKwYBBAGCNy4DMIGBMD0GCCsGAQUFBwIBFjFodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vUEtJL2RvY3MvQ1BTL2RlZmF1bHQuaHRtMEAGCCsGAQUF
# BwICMDQeMiAdAEwAZQBnAGEAbABfAFAAbwBsAGkAYwB5AF8AUwB0AGEAdABlAG0A
# ZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQAH5ohRDeLG4Jg/gXEDPZ2joSFv
# s+umzPUxvs8F4qn++ldtGTCzwsVmyWrf9efweL3HqJ4l4/m87WtUVwgrUYJEEvu5
# U4zM9GASinbMQEBBm9xcF/9c+V4XNZgkVkt070IQyK+/f8Z/8jd9Wj8c8pl5SpFS
# AK84Dxf1L3mBZdmptWvkx872ynoAb0swRCQiPM/tA6WWj1kpvLb9BOFwnzJKJ/1V
# ry/+tuWOM7tiX5rbV0Dp8c6ZZpCM/2pif93FSguRJuI57BlKcWOdeyFtw5yjojz6
# f32WapB4pm3S4Zz5Hfw42JT0xqUKloakvZ4argRCg7i1gJsiOCC1JeVk7Pf0v35j
# WSUPei45V3aicaoGig+JFrphpxHLmtgOR5qAxdDNp9DvfYPw4TtxCd9ddJgiCGHa
# sFAeb73x4QDf5zEHpJM692VHeOj4qEir995yfmFrb3epgcunCaw5u+zGy9iCtHLN
# HfS4hQEegPsbiSpUObJb2sgNVZl6h3M7COaYLeqN4DMuEin1wC9UJyH3yKxO2ii4
# sanblrKnQqLJzxlBTeCG+SqaoxFmMNO7dDJL32N79ZmKLxvHIa9Zta7cRDyXUHHX
# odLFVeNp3lfB0d4wwP3M5k37Db9dT+mdHhk4L7zPWAUu7w2gUDXa7wknHNWzfjUe
# CLraNtvTX4/edIhJEqGCAtQwggI9AgEBMIIBAKGB2KSB1TCB0jELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IEly
# ZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVT
# TjowODQyLTRCRTYtQzI5QTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaIjCgEBMAcGBSsOAwIaAxUADU2U/hveloSNdD8d7koExrNljAeggYMw
# gYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUF
# AAIFAOUQN5gwIhgPMjAyMTEwMTMwMDM0MzJaGA8yMDIxMTAxNDAwMzQzMlowdDA6
# BgorBgEEAYRZCgQBMSwwKjAKAgUA5RA3mAIBADAHAgEAAgIbaTAHAgEAAgIRrzAK
# AgUA5RGJGAIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAowCAIB
# AAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBAJdBHw4o75gxBIYb
# /LRz+CLwFlPq5DZyoYGVJpQfkDpwxGD746D04YCKkSVQD48vIrt59mixmvg9tRyq
# KDIwERH+nbqty8f9oDun3+X94Mmkzx0/UxFrIQzopFm+V0z2WVWMiuunUnm0GiZW
# qMvFtOMMRsoMzRucEGQJ/Pj/L5doMYIDDTCCAwkCAQEwgZMwfDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRp
# bWUtU3RhbXAgUENBIDIwMTACEzMAAAE5zOjoQ4vwNOEAAAAAATkwDQYJYIZIAWUD
# BAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0B
# CQQxIgQgXT6sjbJbjBnLnbHLc+IPyiu3CpRy56MJAMzwq+UhiUUwgfoGCyqGSIb3
# DQEJEAIvMYHqMIHnMIHkMIG9BCA8oY7kOKPXJHsxQrHigQWufGpVJ/Oaep8mptSg
# Bw/8nzCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAB
# Oczo6EOL8DThAAAAAAE5MCIEIEhaDEt1r0J2RZ8MhSrNhKDQ5LQFAWyxOHzo9Eyd
# sC2/MA0GCSqGSIb3DQEBCwUABIIBAMUiKxfsiOc0pqGR4OPDRyFSfxo9M8UYm8M0
# V6SzedFz+7/Xs7jm+ISXq12SAQqzy/y7EtvXriGj91Y60Y3dloBQZjOzMDZKyE+C
# ei0MRyeDfahSd7lrV2RMJdSi81N9ZrByNSMnvy0mz9lrcsrkHH14QA5fo5CxHe+6
# GNCa/aCpXrVCK69c0/1ofbUoZM/F/9EmV9cIcTjeQ6p//xOWjKo01hxpOHemHxGw
# 14hPvKI43B8PIBdmjYv/fcTY0wOM2SKiPzplAGxoUPKH+6Xr9xRXopJkpTOr8WQb
# ZYG5RKj0rsKJzvXqRCuckq6ZIP4X2PKJ6SJsDzBCsts7mtyfv+8=
# SIG # End signature block
