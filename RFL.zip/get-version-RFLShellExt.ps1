# File: common file for get-update-RFLShellExt.ps1 and get-version-RFLShellExt.ps1
# last edit by: waltere

<#
.SYNOPSIS
The script will show version, install, update to latest version or remove your current version of the SDP/RFL Explorer PlugIn on your system.
The registry file for the latest version of the shell extension is located here: \\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\Rfl-Check_ShellExtension.reg

SYNTAX: .\get-update-RFLShellExt.ps1 [- CheckType Check-RFL|Check_RFL_anchor|Check_SDP_anchor] [-GetVersion|-GetUpdate|-Remove]

.DESCRIPTION
The script reads in your current registry RFL information and writes new registry keys.
The script tries to run -GetUpdate or -Remove in elevated mode and ask user to agree (UAC prompt), because REG changes need admin permission.
Note: In case of any error, you still can download to local drive and doubleclick the *.reg file on
   \\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\Rfl-Check_ShellExtension.reg
	 
Reg-Locations for RFL ShellExtension: "HKCU:\SOFTWARE\RFLcheck\" and
	V1: "HKCR:\Directory\shell\Check-RFL"
		"HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Chk_*" 
	V2: "HKCR:\Directory\shell\Check_RFL_anchor"
		"HKCR:\*\ContextMenus\Check_RFL\Shell"
		"HKCR:\Directory\shell\Check_SDP_anchor"
		"HKCR:\*\ContextMenus\Check_SDP\Shell"

.PARAMETER SkipAdminCheck
	If this switch is present, then the check for administrator privileges will be skipped
	Script needs Admin priv for Remove, and for Update if installed version does not match current version

.PARAMETER Remove
	If this switch is present, then the script will remove old Shell Extension

.PARAMETER GetUpdate
	If this switch is present, then the script will check and update version of Shell Extension 

.PARAMETER GetVersion
	If this switch is present, then the script will check and display version of Shell Extension

.PARAMETER HostMode
	If this switch is present, then the script will display output on screen

.PARAMETER ScriptMode
	If this switch is present, then the script will log output in logfile

.EXAMPLE
	To run the RFL shell PlugIn check and update on UNC path
	\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\get-update-RFLShellExt.ps1 -HostMode -GetUpdate

.EXAMPLE
	To run the RFL shell PlugIn VERSION check only
	\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\get-update-RFLShellExt.ps1 -HostMode -GetVersion

.EXAMPLE
	To remove the RFL shell PlugIn only
	\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\get-update-RFLShellExt.ps1 -HostMode -Remove
	
.LINK
	Update script: \\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\get-update-RFLShellExt.ps1
	ShellExtension: \\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\Rfl-Check_ShellExtension.reg
	RFL core team: waltere@microsoft.com

#>


[CmdletBinding()]
PARAM (
	[ValidateSet("Check-RFL","Check_RFL_anchor","Check_SDP_anchor")]
	[parameter(Mandatory=$False,Position=0,HelpMessage='Choose one from: [Check-RFL|Check_RFL_anchor|Check_SDP_anchor]')]
	[string]$CheckType = "Check_RFL_anchor"
	,
	[parameter(Mandatory=$false)]
	[switch]$SkipAdminCheck = $true,	# if $True, then the check for administrator privileges will be skipped
	[switch]$Elevated 		= $false,	# This will run script in elevated Admin mode
	[switch]$Script:IsRunAsAdmin = $false,
	[switch]$Remove 		= $false,	# $True for script remove-RFLShellExt.ps1
	[switch]$GetUpdate 	= $false,		# $True for script get-update-RFLShellExt.ps1
	[switch]$GetVersion 	= $true,	# $True for script get-version-RFLShellExt.ps1
	[switch]$InformUser		= $true,	# $False for suppressing Update info for user
	[switch]$HostMode		= $true,	# This tells the logging functions to show logging on the screen
	[switch]$ScriptMode		= $false, 	# This tells the logging functions to show logging into log file
	[switch]$UseExitCode	= $true,	# This will cause the script to close after the error is logged if an error occurs
	[Switch]$DebugMode,					# used for debugging
	[switch]$DbgOut 		= $false	# $True for script debugging
)

BEGIN {
	$verDateScript = "2023.01.23.0"
	$ScriptFolder = Split-Path $MyInvocation.MyCommand.Path -Parent
	# Load Common Library:
	. $ScriptFolder\Utils_RflShared.ps1

	# This saves the starting ErrorActionPreference and then sets it to 'Stop'.
	$startErrorActionPreference = $errorActionPreference
	# This gets the current path and name of the script.
	$invocation = (Get-Variable MyInvocation).Value
	$scriptPath = Split-Path $invocation.MyCommand.Path
	$FullScriptPath = (Get-Variable MyInvocation).Value.MyCommand.Path
	if ($DbgOut) {
		Write-host "invocation: $invocation"
		Write-host "scriptPath: $scriptPath"
		Write-host "FullScriptPath: $FullScriptPath"
	}
	$scriptName = $invocation.MyCommand.Name
	#$scriptDefinition = $myinvocation.MyCommand.Definition	#Full script path
	$UserName  = ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name)
	$UsrOSVersion = [Environment]::OSVersion.Version.ToString(3)
	if ($DbgOut) {Write-Host "Running `"$scriptPath\$scriptName`"..." -BackgroundColor Black -ForegroundColor Green}
	Set-Variable -Name ErrorMsg -Scope Script -Force
	[string]$Script:ErrorMsg=""
	
#region: ###### customization section of script, logging configuration ########################
	$SDPcheckINI = (Get-content -Path "$ScriptFolder\_SDPcheck.ini")
	$InOfflineMode 	= (($SDPcheckINI[1] -split " ")[2]).trim("""")	# set $True for outsourcer or when not connected to MS network - offline-SDPcheck
	$ExpectedShellExtVersion = (($SDPcheckINI[6] -split " ")[2]).trim("""")
	$RFLroot = (($SDPcheckINI[2] -split " ")[2]).trim("""")	# "\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\" -or- "\\localhost\ToolsShare\rfl\"
	if ($InOfflineMode -match "False") {
		$StatsServer = (($SDPcheckINI[4] -split " ")[2]).trim("""")
		if (Test-Connection -ComputerName $StatsServer -Quiet -Count 1) {[bool]$Stats=$True} else {[bool]$Stats=$False}
	} else { 
		$Stats = $False
	}
	$LogLevel = 0
	$CheckDate = (Get-Date).ToUniversalTime().ToString("yy-MM-dd_HH-mm-ss")
	$Script:regFileV1remove = "$RFLroot\Rfl-Check_ShellExtension_V1-Remove.reg"
	$Script:regFileV2add = "$RFLroot\Rfl-Check_ShellExtension.reg"
	$Script:regFileV2remove = "$RFLroot\Rfl-Check_ShellExtension_Remove.reg"
	#$ExpectedShellExtVersionV1 = "1.11"	# in registry HKCR:\Directory\shell\Check-RFL
#endregion: ###### customization section
	if ($Stats) {
		$StatsServerPath = "\\$StatsServer\RFLstats$\RFL\scripts\Stats\"

		if ($GetVersion) {
			[string]$InfoString = "RFLshExt_Version"
			$CountInvFil = $StatsServerPath +'countRFLshExVer.dat'
		}
		if ($GetUpdate) {
			[string]$InfoString = "RFLshExt_Update"
			$CountInvFil = $StatsServerPath +'countRFLshExUpd.dat'
		}
		if ($Remove) {
			Write-Host "`n Note: Admin priv needed for -Remove" 
			[string]$InfoString = "RFLshExt_Remove"
			$CountInvFil = $StatsServerPath +'countRFLshExRemove.dat'
		}
		$CountInvFil2 = $CountInvFil +'.us'
		#increment at start of script
		 ($j=[int32](Get-Content $CountInvFil -TotalCount 1 -ErrorAction SilentlyContinue)) |out-null
		 (++$j) | Set-Content $CountInvFil -ErrorAction SilentlyContinue
	}
	#initialize
	$ErrorThrown = $null
	$Script:CurrShellExtVer ='undefined'
	$Script:ResultMsg = ""

	If ($PSBoundParameters['Debug']) { $DebugPreference='Continue'}
	Set-Variable -Name ShellExtExists	-Scope Script -Force
	Set-Variable -Name ShellExtVersion	-Scope Script -Force
	Set-Variable -Name regFile 		-Scope Script -Force
	Set-Variable -Name FullScriptPath	-Scope Script -Force
			
#region: Script Functions
function CheckAdminPrivileges {
	# SYNOPSIS: check for PowerShell Admin priv
	# Return: $True if running as Admin
	[CmdletBinding()]
	Param(
		[parameter(Mandatory=$true)] [Bool] $SkipAdminCheck
	)
	RflEnterFuncDbg $MyInvocation.MyCommand.Name
	if ($DbgOut) {Write-host "ENTER: CheckAdminPrivileges"}
	if (-not $SkipAdminCheck) {
		# Yep, this is the easiest way to do this.
		$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")
		if (-not $isAdmin) {
			throw "You do not have the required permission to complete this task. Please run this command in an Administrator PowerShell window or specify the -SkipAdminCheck option."
		}
	}
	RflEndFunc $MyInvocation.MyCommand.Name
}

function Test-Admin {
	# SYNOPSIS: check for PowerShell Admin priv
	# Return: $True if running as Admin, $False if not
	RflEnterFuncDbg $MyInvocation.MyCommand.Name
	if ($DbgOut) {Write-host "ENTER: Test-Admin"}
	$currentUser = New-Object Security.Principal.WindowsPrincipal $([Security.Principal.WindowsIdentity]::GetCurrent())
	$currentUser.IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)
	RflEndFunc $MyInvocation.MyCommand.Name
}

function checkRegKey ($rKey) {
	# SYNOPSIS - check if RegKey exists
	# Return: $True if found, $False if not found 
	RflEnterFuncDbg $MyInvocation.MyCommand.Name
	if ($DbgOut) {Write-host "ENTER: checkRegKey"}
	New-PSDrive -Name HKCR -PSProvider Registry -Root HKEY_CLASSES_ROOT |out-null
	$ErrorActionPreference = "stop"
	Try { 
		$exists = Get-Item -Path $rKey
		if ($exists) {WriteInfo -message "$rKey exists." 
		return $True}
		}
	Catch [System.Management.Automation.PSArgumentException]
	 {	 return $False}
	Catch [System.Management.Automation.ItemNotFoundException]
	 {	WriteError -message "$rKey is missing."
		return $False }
	Finally { $ErrorActionPreference = "Continue" }
	RflEndFunc $MyInvocation.MyCommand.Name
} # end of checkRegKey

function checkPlugin-ShellExt ($CheckType,$registryPath,$CheckedVer) {
	# SYNOPSIS - check if RFLShellExt is installed, Write message to user if Plugin is missing
	# $CheckType can be "Check-RFL" or "Check_RFL_anchor" or "Check_SDP_anchor"
	# Return: '__Found ..' or '.. itself is missing'
	RflEnterFuncDbg $MyInvocation.MyCommand.Name
	if ($DbgOut) {Write-host "ENTER: checkPlugin-ShellExt"}
	 New-PSDrive -Name HKCR -PSProvider Registry -Root HKEY_CLASSES_ROOT |out-null
	 #$registryPath = "HKCR:\Directory\shell\$($CheckType)"
	 $ErrorActionPreference = "stop"
	 
	 Try { 
		#check if RFLShellExt is installed and 'Version' key exists
		WriteInfo -message "[RFLshExt_Plugin] _Checking for existing ShellExt $($CheckType) in $registryPath"
		$Script:ShellExtKey = (Get-ItemProperty -Path $registryPath -ErrorAction SilentlyContinue)
		if ($Script:ShellExtKey) {
			$Script:CurrShellExtVer = $($Script:ShellExtKey.Version)
			WriteInfo -message "[$InfoString`] __Found ShellExt in $registryPath ver: $Script:CurrShellExtVer "
			$Script:ResultMsg += "$CheckedVer $CheckType ver: $Script:CurrShellExtVer "
		}
			# RflEndFunc ($MyInvocation.MyCommand.Name + "(Found $Script:CurrShellExtVer)")
			#return "Found $Script:CurrShellExtVer"
	 }
	 Catch [System.Management.Automation.ItemNotFoundException]
	 {
		if ($InformUser) {
			 #Write message to user if Plugin is missing
			 Write-host -BackgroundColor Black -ForegroundColor Yellow -Object "... Simplify: Consider to run Explorer-Extension V2 update $ExpectedShellExtVersion in elevated PowerShell window, see also _Help.rtf:"
			 Write-host -BackgroundColor Black -ForegroundColor Cyan -Object " Powershell -ExecutionPolicy Bypass $RFLroot\get-update-RFLShellExt.ps1"
		}
		WriteError -message "$registryPath itself is missing."
		$Script:ResultMsg += "$CheckedVer $CheckType is missing. "
		RflEndFunc ($MyInvocation.MyCommand.Name + "($CheckedVer $registryPath itself is missing.)")
		return "$CheckedVer $registryPath itself is missing."
	}
	 Finally { $ErrorActionPreference = "Continue" }
	 RflEndFunc $MyInvocation.MyCommand.Name
} # end of checkPlugin-ShellExt

function checkVer-ShellExt ($CheckType,$registryPath,$ExpectedShellExtVersion) {
	# SYNOPSIS - check if RFLShellExt 'Version' key exists
	# Return: "$Script:CurrShellExtVer _up_to_date" - "$Script:CurrShellExtVer _outdated - user_informed." - ".. Property Version missing." - ""
	 #check if 'Version' key exists
	 RflEnterFuncDbg $MyInvocation.MyCommand.Name
	 if ($DbgOut) {Write-host "ENTER: checkVer-ShellExt"}
	 New-PSDrive -Name HKCR -PSProvider Registry -Root HKEY_CLASSES_ROOT |out-null
	 #$registryPath = "HKCR:\Directory\shell\$($CheckType)"
	 Try { $ErrorActionPreference = "stop"
		WriteInfo -message "[$InfoString`] _Checking current version for $($CheckType) in $registryPath"
		$Script:CurrShellExtVer = (Get-ItemProperty -Path $registryPath -Name Version -ErrorAction SilentlyContinue).Version
		if ($Script:CurrShellExtVer){
			WriteInfo -message "[$InfoString`] __comparing your RFL ShellExtension version: $Script:CurrShellExtVer with latest $Script:ExpectedShellExtVersion"
			if ($Script:CurrShellExtVer -match $ExpectedShellExtVersion){
				WriteInfo -message "[$InfoString`] __Your RFL ShellExtension version $Script:CurrShellExtVer is up-to-date";
				RflEndFunc ($MyInvocation.MyCommand.Name + "($Script:CurrShellExtVer _up_to_date.)")
				return " $Script:CurrShellExtVer _up_to_date"
			}
			else {
				if ($Script:CurrShellExtVer -lt 1.09) {Write-host -BackgroundColor Black -ForegroundColor Red -Object " Support for this older RFL version has ended."}
				Write-host -BackgroundColor Yellow -ForegroundColor Black -Object "[$InfoString`] __Your RFL ShellExtension version $Script:CurrShellExtVer is outdated! (Available: v$ExpectedShellExtVersion)
	 .. Consider updating the RFL Shell Explorer Plugin to v$ExpectedShellExtVersion `n $Script:regFileV2add
	 To do so, run in ELEVATED (Run as Administrator) PS window the commands:"
				Write-host -ForegroundColor Cyan -Object " Powershell -ExecutionPolicy Bypass $RFLroot\remove-RFLShellExt.ps1"
				Write-host -ForegroundColor Cyan -Object " Powershell -ExecutionPolicy Bypass $RFLroot\get-update-RFLShellExt.ps1"
				RflEndFunc ($MyInvocation.MyCommand.Name + "($Script:CurrShellExtVer _outdated - user_informed.)")
				return "$Script:CurrShellExtVer _outdated - user_informed."
			}
		}
		else { WriteInfo -message "[$InfoString`] $registryPath\Version not found"
			$Script:CurrShellExtVer ='V-undefined'
		}
	}
	Catch [System.Management.Automation.PSArgumentException]
	{	
		RflEndFunc ($MyInvocation.MyCommand.Name + "([$InfoString`] RegKey $registryPath Property Version missing.)")
		return "[$InfoString`] RegKey $registryPath Property Version missing."
	}
	Catch [System.Management.Automation.ItemNotFoundException]
	{ WriteInfo -message "[$InfoString`] RegKey $registryPath\Version is missing."
		 Write-debug "[$InfoString`] ...RFLshellPlugin not up-to-date - creating it."
		 Write-debug "[$InfoString`] ...***please allow registry Version update when UAC prompted***"
		 RflEndFunc ($MyInvocation.MyCommand.Name + "([$InfoString`] $registryPath\Version is missing.)")
		 return "[$InfoString`] RegKey $registryPath\Version is missing."
	}
	Finally { $ErrorActionPreference = "Continue" }
	RflEndFunc $MyInvocation.MyCommand.Name
} # end of checkVer-ShellExt

function CheckForUpdates-RFLShellExt ($CheckType,$ExpectedShellExtVersion) { ### currently not in use
	# SYNOPSIS - 													
	# Return: nothing
	RflEnterFuncDbg $MyInvocation.MyCommand.Name
	if ($DbgOut) {Write-host "ENTER: CheckForUpdates-RFLShellEx"}
		WriteInfo -message "[RFLshExt_ChkUpdates] checking registryPath: $registryPathHKCR\CheckForUpdates"
		$name = "CheckForUpdates"
		$value = "1"
		 Try { $ErrorActionPreference = "stop"
		$CheckForUpdates = (Get-ItemProperty -Path $registryPathHKCR -Name CheckForUpdates -ErrorAction SilentlyContinue).CheckForUpdates
		if ($CheckForUpdates) {WriteInfo -message "[RFLshExt_ChkUpdates] Current CheckForUpdates: $CheckForUpdates"}
		if ($CheckForUpdates -NotMatch "0") {WriteInfo -message "[RFLshExt_ChkUpdates] Current ShellExt setting for CheckForUpdates: $CheckForUpdates"}
		else {	WriteInfo -message "[RFLshExt_ChkUpdates] CheckForUpdates: '$CheckForUpdates' - .. Consider updating the RFL Shell Explorer Plugin to v$ExpectedShellExtVersion `n $Script:regFileV2add "
			WriteInfo -message "[RFLshExt_ChkUpdates] ... keep existing plugin settings because $registryPathHKCR\CheckForUpdates is set to '$CheckForUpdates'"
			break #continue
			}
		}
		Catch [System.Management.Automation.PSArgumentException]
		 { "[RFLshExt_ChkUpdates] RegKey $registryPathHKCR Property $name missing."
			New-ItemProperty -Path $registryPathHKCR -Name $name -Value $value -PropertyType DWORD -Force | Out-Null
		 }
		Catch [System.Management.Automation.ItemNotFoundException]
		 { "[RFLshExt_ChkUpdates] RegKey $registryPathHKCR itself is missing."
			WriteInfo -message "[RFLshExt_ChkUpdates] ...RFLshellPlugin not installed - creating it"
			New-Item -Path $registryPathHKCR -Force #| Out-Null
			New-ItemProperty -Path $registryPathHKCR -Name $name -Value $value -PropertyType DWORD -Force | Out-Null
		}
		Finally {
			"[RFLshExt_ChkUpdates] CheckForUpdates reg: $CheckForUpdates"
			$ErrorActionPreference = "Continue" }
	RflEndFunc $MyInvocation.MyCommand.Name
} # end of CheckForUpdates-RFLShellExt

function update-ShellExt ($CheckType,$ExpectedShellExtVersion) {
	# SYNOPSIS - update the existing ShellExtension
	# Return: nothing
	#IF (!($Script:CurrShellExtVer -match $ExpectedShellExtVersion) -and ($CheckForUpdates -NotMatch "0")) {
	RflEnterFuncDbg $MyInvocation.MyCommand.Name
	if ($DbgOut) {Write-host "ENTER: update-ShellExt"}
	if ($Script:CurrShellExtVer -NotMatch $ExpectedShellExtVersion) {
		#WriteInfo -message "[$InfoString`] ...Outdated Check-RFL ShellExtVersion '$Script:CurrShellExtVer', removing existing entry $registryPathHKCR '$Script:CurrShellExtVer'"
		Try
			{
			WriteInfo -message "[$InfoString`] ...***please allow registry REMOVE when UAC prompted***"

			WriteInfo -message "[$InfoString`] ...Step#1 Remove v1: Importing $Script:regFileV1remove silently"
			WriteInfo -message "[$InfoString`] ...***please allow registry UPDATE when UAC prompted***"
			$RegTry = regedit /s $Script:regFileV1remove

			WriteInfo -message "[$InfoString`] ...Step#2 Importing latest $Script:regFileV2add silently"
			WriteInfo -message "[$InfoString`] ...***please allow registry UPDATE when UAC prompted***"
			$RegTry = regedit /s $Script:regFileV2add
			#WriteInfo -message "[$InfoString`] ...RegTry result: $RegTry"
			Write-host -BackgroundColor Black -ForegroundColor Green -Object "[$InfoString`] RFLShellExt $CheckType successfully updated"
			"RegImport-done for exp. v$ExpectedShellExtVersion"
			}
		Catch [System.Security.SecurityException]
			{ WriteError -message "Registry Remove-Item $registryPathHKCR"
				WriteError -message "[$InfoString`] Aborted. The error was '$($_.Exception.Message)'"
				Write-host -BackgroundColor Black -ForegroundColor Red -Object "[$InfoString`] Aborted by user"
				"Aborted by user."
			}
		Finally
			{
			"RegVersion-not-matched, inst.Ver: '$Script:CurrShellExtVer'"
			}
	}
	RflEndFunc $MyInvocation.MyCommand.Name
} # end of update-ShellExt

function autoupdate-ShellExt ($CheckType,$registryPath,$ExpectedShellExtVersion) { ### currently not in use
	# SYNOPSIS - AutoUpdate the existing ShellExtension
	# Return: nothing
	RflEnterFuncDbg $MyInvocation.MyCommand.Name
	if ($DbgOut) {Write-host "ENTER: autoupdate-ShellExt"}
		if ($Script:ShellExtKey)	{
		checkVer-ShellExt $CheckType $registryPath $ExpectedShellExtVersion		#call function
		if ($Script:CurrShellExtVer -lt 1.09) {
			if ($GetVersion) {
				Write-host -BackgroundColor Black -ForegroundColor Yellow -Object "`n Trying Auto-Update, Please agree when prompted for running in elevated PS and Registry modification."
				Powershell -noprofile -ExecutionPolicy Bypass $RFLroot\get-update-RFLShellExt_v1.16.ps1 -SkipAdminCheck -GetUpdate
				checkVer-ShellExt $CheckType $registryPath $ExpectedShellExtVersion
				if ($Script:CurrShellExtVer -match $ExpectedShellExtVersion) {Write-host -BackgroundColor Black -ForegroundColor Green -Object " AutoUpdate version completed: v$Script:CurrShellExtVer"}
			}
		}
	}
	if ($GetUpdate) {update-ShellExt $CheckType $ExpectedShellExtVersion}	#call function
	RflEndFunc $MyInvocation.MyCommand.Name
} #end function autoupdate-ShellExt

function remove-ShellExt ($CheckType,$registryPath) {
	# SYNOPSIS - Delete all the registry rentries for the existing ShellExtension
	# Return: result of action done
	RflEnterFuncDbg $MyInvocation.MyCommand.Name
	if ($DbgOut) {Write-host "ENTER: remove-ShellExt"}
	WriteInfo -message "[RFLshExt_Remove] Checking ShellExt for $($CheckType) $registryPath"
	switch($registryPath)
		{
		"$($registryPathHKCR)"		{New-PSDrive -Name HKCR -PSProvider Registry -Root HKEY_CLASSES_ROOT |out-null}
		"$($registryPathHKCR2)"		{New-PSDrive -Name HKCR -PSProvider Registry -Root HKEY_CLASSES_ROOT |out-null}
		"$($registryPathHKLM)"		{New-PSDrive -Name HKLM -PSProvider Registry -Root HKEY_LOCAL_MACHINE |out-null}
		"$($registryPathHKCU)"		{New-PSDrive -Name HKCU -PSProvider Registry -Root HKEY_CURRENT_USER |out-null}
		}
	
	#WriteInfo -message "[RFLshExt_Remove] ...***please allow registry REMOVE when UAC prompted***"
	$ErrorActionPreference = "stop"
	
	Try
	{
		$Script:RegPathKey = (Get-ItemProperty -Path $registryPath )
		if ($Script:RegPathKey) {
			WriteInfo -message "[RFLshExt_Remove] _Trying to remove registry-tree $registryPath"
			Remove-Item $registryPath -Recurse
			RflEndFunc ($MyInvocation.MyCommand.Name + "(removed $registryPath)")
			return " removed $registryPath"
		}
	}
	Catch [System.Security.SecurityException]
		{	WriteError "RegKey $registryPath SecurityException" 
			WriteError "[RFLshExt_Remove] Aborted. The error was '$($_.Exception.Message)'"
			WriteError "[RFLshExt_Remove] Aborted by user SecurityException"
			RflEndFunc ($MyInvocation.MyCommand.Name + "( RegRemove $registryPath aborted by user SecurityException)")
			return " RegRemove $registryPath aborted by user SecurityException."
		}
	Catch [System.Management.Automation.ItemNotFoundException]
		{	WriteError "[RFLshExt_Remove] Cannot find path or item $registryPath"
			RflEndFunc ($MyInvocation.MyCommand.Name + "( RegRemove ItemNotFoundException)")
			return " RegRemove ItemNotFoundException."
		}
	#Catch [System.Management.Automation.PathNotFound]
	#	{ "[RFLshExt_Remove] Cannot find path $registryPath"}
	Finally
	{
		$ErrorActionPreference = "Continue" 
		#"RFLShellExt $CheckType successfully removed"
	}
	RflEndFunc $MyInvocation.MyCommand.Name
} # end of remove-ShellExt

function LaunchElevated {
 # SYNOPSIS : Launches an elevated process running the current script to perform tasks that require administrative privileges. This function waits until the elevated process terminates.
	# Set up command line arguments to the elevated process
	RflEnterFuncDbg $MyInvocation.MyCommand.Name
	if ($DbgOut) {Write-host "ENTER: LaunchElevated"}
	$Script:RelaunchArgs = '-NoExit -ExecutionPolicy Bypass -file "' + $FullScriptPath + '" -IsRunAsAdmin'

	# Launch the process and wait for it to finish
	try
	{
		$AdminProcess = Start-Process "$PsHome\PowerShell.exe" -Verb RunAs -ArgumentList $Script:RelaunchArgs -PassThru
	}
	catch
	{
		$Error[0] # Dump details about the last error
		exit 1
	}

	# Wait until the elevated process terminates
	while (!($AdminProcess.HasExited))
	{
		Start-Sleep -Seconds 2
	}
	RflEndFunc $MyInvocation.MyCommand.Name
}

function DoElevatedOperations {	#currently not used
	RflEnterFuncDbg $MyInvocation.MyCommand.Name
	Write-Host "Do elevated operations"
	Start-Sleep -Seconds 5
	RflEndFunc $MyInvocation.MyCommand.Name
}

function DoStandardOperations {
	RflEnterFuncDbg $MyInvocation.MyCommand.Name
	Write-Host "Do standard operations"

	LaunchElevated
	Start-Sleep -Seconds 5
	RflEndFunc $MyInvocation.MyCommand.Name
}

function DoGetVersion ($CheckType,$ExpectedShellExtVersion) {
#	$CallStack = Get-PSCallStack
#	Write-host -ForegroundColor Cyan "CS: $CallStack"
#	$CallerInfo = $CallStack[1]
#	If($CallerInfo.FunctionName -eq '<ScriptBlock>'){
#		 $FuncName = 'Main'
#	}Else{
#		$FuncName = $CallerInfo.FunctionName
#	}
#	RflEnterFunc ("$($MyInvocation.MyCommand.Name)" + "(Caller - $($FuncName):$($CallerInfo.ScriptLineNumber))")
	RflEnterFuncDbg $MyInvocation.MyCommand.Name
	if ($DbgOut) {Write-host "ENTER: DoGetVersion"}
	# define registry locations for v1 Check-RFL, and v2 Check_RFL_anchor, Check_SDP_anchor
	$registryPathHKCU = "HKCU:\SOFTWARE\RFLcheck\shellExtension" 
	switch($CheckType)
	{
	"Check-RFL"			{ $CheckedVer = "v1"
						$registryPathHKCR = "HKCR:\Directory\shell\Check-RFL"
						$registryPathHKLM = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CommandStore\shell\Chk_*" 
						}
	"Check_RFL_anchor"	{ $CheckedVer = "v2"
						$registryPathHKCR = "HKCR:\Directory\shell\Check_RFL_anchor"
						$registryPathHKCR2 = "HKCR:\*\ContextMenus\Check_RFL\Shell" 
						}						
	"Check_SDP_anchor"	{ $CheckedVer = "v2"
						$registryPathHKCR = "HKCR:\Directory\shell\Check_SDP_anchor"
						$registryPathHKCR2 = "HKCR:\*\ContextMenus\Check_SDP\Shell" 
						}
	}

	WriteInfo -message "$CheckedVer CheckType: $CheckType REG: $registryPathHKCR"
	
	#$au = autoupdate-ShellExt $CheckType $registryPathHKCR $ExpectedShellExtVersion	#call function
	checkPlugin-ShellExt $CheckType $registryPathHKCR $CheckedVer
	WriteInfo -message "[$InfoString`] GetVersion results: $Script:ResultMsg"
	if ($Script:CurrShellExtVer -NotMatch $ExpectedShellExtVersion) {
		Write-host -BackgroundColor Black -ForegroundColor Yellow -Object "... Outdated current $Script:CurrShellExtVer : Consider to run Explorer-Extension V2 update $ExpectedShellExtVersion in elevated PowerShell window, see also _Help.rtf:"
		Write-host -BackgroundColor Black -ForegroundColor Cyan -Object " Powershell -ExecutionPolicy Bypass $RFLroot\get-update-RFLShellExt.ps1" 
		[System.Media.SystemSounds]::Hand.Play() } # Play sound to get some attention 
	#$Script:ResultMsg += $au
	If ($Script:ResultMsg -match $ExpectedShellExtVersion) { Write-Host -ForegroundColor Green -Object "[$InfoString`] OK, you are running latest RFL/SDPcheck version $($ExpectedShellExtVersion)"}
	else { 
		Write-Host -ForegroundColor Red -Object "[$InfoString`] Your RFL/SDP Eplorer Plug-in version $Script:CurrShellExtVer is outdated, expected: $($ExpectedShellExtVersion)"
		Write-Host -ForegroundColor cyan -Object "[$InfoString`] for update, run: $RFLroot\get-update-RFLShellExt.ps1"
	}
	If ($Script:ResultMsg -match "missing") {
		WriteInfo -message "[$InfoString`] .. Consider installing the RFL Shell Explorer Plugin v$ExpectedShellExtVersion`n	$Script:regFileV2add
To do so, run in elevated (Run as Administrator) PS window the command: 
Powershell -ExecutionPolicy Bypass $RFLroot\get-update-RFLShellExt.ps1"
	}
	RflEndFunc $MyInvocation.MyCommand.Name
	return $Script:ResultMsg
}

function DoGetUpdate ($CheckType,$ExpectedShellExtVersion) {
	RflEnterFuncDbg $MyInvocation.MyCommand.Name
	if ($DbgOut) {Write-host "ENTER: DoGetUpdate"}
	$au = update-ShellExt $CheckType $ExpectedShellExtVersion		#call function
	Write-host -BackgroundColor Black -ForegroundColor Green -Object "[$InfoString`] ...done. New RFL ShellExt $ExpectedShellExtVersion plugin should be available in your Windows Explorer context menu for folders right now."
	WriteInfo -message "Note: In case of any error, you still can download to local drive and doubleclick the *.reg file on`n $($RFLroot)\Rfl-Check_ShellExtension.reg"
	$Script:ResultMsg += $au
	RflEndFunc $MyInvocation.MyCommand.Name
}

function DoRemove ($CheckType,$ExpectedShellExtVersion) {
	RflEnterFuncDbg $MyInvocation.MyCommand.Name
	if ($DbgOut) {Write-host "ENTER: DoRemove"}
	WriteInfo -message "[RFLshExt_Remove] ***Deleting reg-locations for RFL Shell-Extension version '$Script:CurrShellExtVer'`n "
	$registryPaths = $registryPathHKCR,$registryPathHKLM,$registryPathHKCU
	foreach ($registryPath in $registryPaths)
		{
		$exists = checkRegKey $registryPath
		if ($exists) { 
			$au += remove-ShellExt $CheckType $registryPath	#call function "Check-RFL"
			WriteInfo -message "[RFLshExt_Remove] __results: $au `n"
			}
		}
	$Script:ResultMsg = $au
	RflEndFunc $MyInvocation.MyCommand.Name
}
#endregion: Script Functions
} #end BEGIN


PROCESS {
	try {
			$ScriptBeginTimeStamp = Get-Date
			#region: MAIN :::::

			if ($GetVersion) {
				$V2check = DoGetVersion Check_RFL_anchor $ExpectedShellExtVersion
				WriteInfo -message "[$InfoString`] *** V2check: $V2check"
				if ($Script:ResultMsg -notmatch "2.0") {
					$V1check = DoGetVersion Check-RFL $ExpectedShellExtVersionV1
					WriteInfo -message "[$InfoString`] *** V1check : $V1check"
				}
			}

			if ($GetUpdate) {
				$V2check = DoGetVersion Check_RFL_anchor $ExpectedShellExtVersion
				if ($Script:CurrShellExtVer -NotMatch $ExpectedShellExtVersion) { 
					DoGetUpdate $CheckType $ExpectedShellExtVersion
				} else { WriteInfo -message "-GetUpdate requires Admin priv."}
			}

			if ($Remove) {
				if ((Test-Admin) -eq $true) { DoRemove $CheckType $ExpectedShellExtVersion}
				else { WriteInfo -message "-Remove requires Admin priv."
					#.\get-update-RFLShellExt_v1.16.ps1 -CheckType Check-RFL -Remove -Hostmode
					DoStandardOperations
					Write-Host "RelaunchArgs: $Script:RelaunchArgs"
					#DoElevatedOperations
							
					#LaunchElevated 
					#Start-Sleep -Seconds 5
				<#	if ($IsRunAsAdmin) {
						Write-Host "RelaunchArgs: $RelaunchArgs"
						DoElevatedOperations
					}
					else
						{
							DoStandardOperations
						} #>
				}
			}
			WriteInfo -message "Overall-Results: $Script:ResultMsg"
			#endregion: MAIN
	} # end try PROCESS
	catch {
		$errorMessage = "$scriptName caught an exception on $($ENV:COMPUTERNAME):"
		$errorMessage += "`n`n"
		$errorMessage += "Exception Type: $($_.Exception.GetType().FullName)"
		$errorMessage += "`n`n"
		$errorMessage += "Exception Message: $($_.Exception.Message)"

		Write-Error $errorMessage -ErrorAction Continue
		Write-Debug $errorMessage
		if ( $UseExitCode ) {
			$error.clear()	# clear script errors
			exit 1
		} #end UseExitCode
	} #end Catch PROCESS
	Finally {
	}
} #end PROCESS

END {
	$ScriptEndTimeStamp = Get-Date
	$Duration = $(New-TimeSpan -Start $ScriptBeginTimeStamp -End $ScriptEndTimeStamp)
	$LogLevel = 0
	#Write-Host -BackgroundColor Gray -ForegroundColor Black -Object "[Done] Script $scriptName v$verDateScript execution finished. Duration: $Duration"
	WriteInfo -message "[Done] Script $scriptName v$verDateScript execution finished. Duration: $Duration `n"
	if($ErrorThrown) {Throw $error[0].Exception.Message}
	# Stats
	If ($Stats) { #increment at start of script
		"$j; $CheckDate; $UsrOSVersion; $UserName; $Duration; [$InfoString`]; $Script:CurrShellExtVer; $Script:ResultMsg; v$verDateScript ; $env:computername" | Out-File $CountInvFil2 -Append -Encoding UTF8 -ErrorAction SilentlyContinue
	}
  # This resets the ErrorActionPreference to the value at script start.
  $errorActionPreference = $startErrorActionPreference
	#Write full error message
	#$error[0] |fl * -force
} #end END

#region: comments
<#
	The top section is comment based help so the Get-Help command will work with the script.
	The [CmdletBinding()] turns on advanced options like the common parameters.
	All sub functions are in the "BEGIN" section.
	My script code goes in the "PROCESS try" block.

VERSION and AUTHOR:
	Walter Eder	- waltere@microsoft.com

HISTORY
	2015-02-02	V1.04
	2016-07-02	V1.06 add capability to remove all RFL registry settings, see remove-RFLShellExt.ps1
	2017-04-03	V1.08 (removed platform, re-added VSS in Rfl-Check_ShellExtension_FQDN.reg)
	2017-10-06	v1.11 changed [RFLshExt_Update] to [$InfoString`] + output enhancements
	2017-11-19	v1.13 using PS fuctions
	2019-01-13	v1.16 consolidating get-version-RFLShellExt.ps1 and get-update-RFLShellExt.ps1 and remove-RFLShellExt.ps1
	2019-09-26	v1.18 new ShellExtVersion v2.08, $InformUser= $true 
	2022-09-08 using Utils_RflShared.psm1 library
	
	ToDo: 	/known issue:
	#https://blogs.msdn.microsoft.com/virtual_pc_guy/2010/09/23/a-self-elevating-powershell-script/

#>
#endregion: comments 



# SIG # Begin signature block
# MIInlQYJKoZIhvcNAQcCoIInhjCCJ4ICAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCiXFIPLt2nJvvL
# d72iYhRhMoI1YRxPE+fju4jst93LL6CCDXYwggX0MIID3KADAgECAhMzAAACy7d1
# OfsCcUI2AAAAAALLMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjIwNTEyMjA0NTU5WhcNMjMwNTExMjA0NTU5WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC3sN0WcdGpGXPZIb5iNfFB0xZ8rnJvYnxD6Uf2BHXglpbTEfoe+mO//oLWkRxA
# wppditsSVOD0oglKbtnh9Wp2DARLcxbGaW4YanOWSB1LyLRpHnnQ5POlh2U5trg4
# 3gQjvlNZlQB3lL+zrPtbNvMA7E0Wkmo+Z6YFnsf7aek+KGzaGboAeFO4uKZjQXY5
# RmMzE70Bwaz7hvA05jDURdRKH0i/1yK96TDuP7JyRFLOvA3UXNWz00R9w7ppMDcN
# lXtrmbPigv3xE9FfpfmJRtiOZQKd73K72Wujmj6/Su3+DBTpOq7NgdntW2lJfX3X
# a6oe4F9Pk9xRhkwHsk7Ju9E/AgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUrg/nt/gj+BBLd1jZWYhok7v5/w4w
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzQ3MDUyODAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAJL5t6pVjIRlQ8j4dAFJ
# ZnMke3rRHeQDOPFxswM47HRvgQa2E1jea2aYiMk1WmdqWnYw1bal4IzRlSVf4czf
# zx2vjOIOiaGllW2ByHkfKApngOzJmAQ8F15xSHPRvNMmvpC3PFLvKMf3y5SyPJxh
# 922TTq0q5epJv1SgZDWlUlHL/Ex1nX8kzBRhHvc6D6F5la+oAO4A3o/ZC05OOgm4
# EJxZP9MqUi5iid2dw4Jg/HvtDpCcLj1GLIhCDaebKegajCJlMhhxnDXrGFLJfX8j
# 7k7LUvrZDsQniJZ3D66K+3SZTLhvwK7dMGVFuUUJUfDifrlCTjKG9mxsPDllfyck
# 4zGnRZv8Jw9RgE1zAghnU14L0vVUNOzi/4bE7wIsiRyIcCcVoXRneBA3n/frLXvd
# jDsbb2lpGu78+s1zbO5N0bhHWq4j5WMutrspBxEhqG2PSBjC5Ypi+jhtfu3+x76N
# mBvsyKuxx9+Hm/ALnlzKxr4KyMR3/z4IRMzA1QyppNk65Ui+jB14g+w4vole33M1
# pVqVckrmSebUkmjnCshCiH12IFgHZF7gRwE4YZrJ7QjxZeoZqHaKsQLRMp653beB
# fHfeva9zJPhBSdVcCW7x9q0c2HVPLJHX9YCUU714I+qtLpDGrdbZxD9mikPqL/To
# /1lDZ0ch8FtePhME7houuoPcMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGXUwghlxAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAALLt3U5+wJxQjYAAAAAAsswDQYJYIZIAWUDBAIB
# BQCggbAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIGeHHXYi5ZechCHsXBZmygGO
# qk4o2tdkpg7Velz3dOmGMEQGCisGAQQBgjcCAQwxNjA0oBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEcgBpodHRwczovL3d3dy5taWNyb3NvZnQuY29tIDANBgkqhkiG9w0B
# AQEFAASCAQAVwAWLIJC103NxsDjw5U/eDzxwPbYiZIcwqiQwk+586qJIzUS5bBNn
# kV8PXZCfuTMuw8OgSmakA0Z0fcIOPzXLvLC+xbDtDyU7HBQLM/QojY0O2GPYkVJC
# /p4u/nEtJenv8Cy5PVmtSJ1emD3f2AzDO9BPV/KMb8WbqC5NjrI93JLhrOs7Riyr
# CQoU0luOAj2apA51c3vQE+QdhcQcO55mvOiWVMCgfLN/UDposjKmsV9BOjVU2vzW
# p8e6f5mG2e3hhVnmgG0f/K8NHWZ5f6zkYbpTk0v7zWr/Z7UfoLvbn3xUigMVfvcf
# ggIOmbs1+cIHFRHNEhG26z+O2oq33fgMoYIW/TCCFvkGCisGAQQBgjcDAwExghbp
# MIIW5QYJKoZIhvcNAQcCoIIW1jCCFtICAQMxDzANBglghkgBZQMEAgEFADCCAVEG
# CyqGSIb3DQEJEAEEoIIBQASCATwwggE4AgEBBgorBgEEAYRZCgMBMDEwDQYJYIZI
# AWUDBAIBBQAEIH9oAqFN1TfS/0DhPXrf+2VeWFBlGw3C0fX57yGJcGPjAgZjmwbP
# qLYYEzIwMjMwMTEwMTM0MDUwLjk1OFowBIACAfSggdCkgc0wgcoxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBB
# bWVyaWNhIE9wZXJhdGlvbnMxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjIyNjQt
# RTMzRS03ODBDMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNl
# oIIRVDCCBwwwggT0oAMCAQICEzMAAAHBPqCDnOAJr8UAAQAAAcEwDQYJKoZIhvcN
# AQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQG
# A1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjIxMTA0MTkw
# MTI3WhcNMjQwMjAyMTkwMTI3WjCByjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldh
# c2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBD
# b3Jwb3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0aW9u
# czEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046MjI2NC1FMzNFLTc4MEMxJTAjBgNV
# BAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQDksdczJ3DaFQLiklTQjm48mcx5GbwsoLjFogO7cXHH
# ciln9Z7apcuPg06ajD9Y8V5ji9pPj9LhP3GgOwUaDnAQkzo4tlV9rsFQ27S0O3iu
# SXtAFg0fPPqlyv1vBqraqbvHo/3KLlbRjyyOiP5BOC2aZejEKg1eEnWgboZuoANB
# cNmRNwOMgCK14TpPGuEGkhvt7q6mJ9MZk19wKE9+7MerrUVIjAnRcLFxpHUHACVI
# qFv81Q65AY+v1nN3o6chwD5Fy3HAqB84oH1pYQQeW3SOEoqCkQG9wmcww/5ZpPCY
# yGhvV76GgIQXH+cjRge6mLrTzaQV00WtoTvaaw5hCvCtTJYJ5KY3bTYtkOlPPFlW
# 3LpCsE6T5/4ESuxH4zl6+Qq5RNZUkcje+02Bvorn6CToS5DDShywN2ymI+n6qXEF
# pbnTJRuvrCd/NiMmHtCQ9x8EhlskCFZAdpXS5LdPs6Q5t0KywJExYftVZQB5Jt6a
# 5So5cJHut2kVN9j9Jco72UIhAEBBKH7DPCHlm/Vv6NPbNbBWXzYHLdgeZJPxvwIq
# dFdIKMu2CjLLsREvCRvM8iQJ8FdzJWd4LXDb/BSeo+ICMrTBB/O19cV+gxCvxhRw
# secC16Tw5U0+5EhXptwRFsXqu0VeaeOMPhnBXEhn8czhyN5UawTCQUD1dPOpf1bU
# /wIDAQABo4IBNjCCATIwHQYDVR0OBBYEFF+vYwnrHvIT6A/m5f3FYZPClEL6MB8G
# A1UdIwQYMBaAFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMF8GA1UdHwRYMFYwVKBSoFCG
# Tmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY3Jvc29mdCUy
# MFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEpLmNybDBsBggrBgEFBQcBAQRgMF4w
# XAYIKwYBBQUHMAKGUGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY2Vy
# dHMvTWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3J0MAwG
# A1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZIhvcNAQELBQAD
# ggIBAF+6JoGCx5we8z3RFmJMOV8duUvT2v1f7mr1yS4xHQGzVKvkHYwAuFPljRHe
# CAu59FfpFBBtJztbFFcgyvm0USAHnPL/tiDzUKfZ2FN/UbOMJvv+ffC0lIa2vZDA
# exrV6FhZ0x+L4RMugRfUbv1U8WuzS3oaLCmvvi2/4IsTezqbXRU7B7zTA/jK5Pd6
# IV+pFXymhQVJ0vbByWBAqhLBsKlsmU0L8RJoNBttAWWL247mPZ/8btLhMwb+DLLG
# 8xDlAm6L0XDazuqSWajNChfYCHhoq5sp739Vm96IRM1iXUBk+PSSPWDnVU3JaO8f
# D4fPXFl6RYil8xdASLTCsZ1Z6JbiLyX3atjdlt0ewSsVirOHoVEU55eBrM2x+Qub
# DL5MrXuYDsJMRTNoBYyrn5/0rhj/eaEHivpSuKy2Ral2Q9YSjxv21uR0pJjTQT4V
# LkNS2OAB0JpEE1oG7xwVgJsSuH2uhYPFz4iy/zIxABQO4TBdLLQTGcgCVxUiuHMv
# jQ6wbZxrlHkGAB68Y/UeP16PiX/L5KHQdVw303ouY8OYj8xpTasRntj6NF8JnV36
# XkMRJ0tcjENPKxheRP7dUz/XOHrLazRmxv/e89oaenbN6PB/ZiUZaXVekKE1lN6U
# Xl44IJ9LNRSfeod7sjLIMqFqGBucqmbBwSQxUGz5EdtWQ1aoMIIHcTCCBVmgAwIB
# AgITMwAAABXF52ueAptJmQAAAAAAFTANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0
# IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTAwHhcNMjEwOTMwMTgyMjI1
# WhcNMzAwOTMwMTgzMjI1WjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGlu
# Z3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBv
# cmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCC
# AiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAOThpkzntHIhC3miy9ckeb0O
# 1YLT/e6cBwfSqWxOdcjKNVf2AX9sSuDivbk+F2Az/1xPx2b3lVNxWuJ+Slr+uDZn
# hUYjDLWNE893MsAQGOhgfWpSg0S3po5GawcU88V29YZQ3MFEyHFcUTE3oAo4bo3t
# 1w/YJlN8OWECesSq/XJprx2rrPY2vjUmZNqYO7oaezOtgFt+jBAcnVL+tuhiJdxq
# D89d9P6OU8/W7IVWTe/dvI2k45GPsjksUZzpcGkNyjYtcI4xyDUoveO0hyTD4MmP
# frVUj9z6BVWYbWg7mka97aSueik3rMvrg0XnRm7KMtXAhjBcTyziYrLNueKNiOSW
# rAFKu75xqRdbZ2De+JKRHh09/SDPc31BmkZ1zcRfNN0Sidb9pSB9fvzZnkXftnIv
# 231fgLrbqn427DZM9ituqBJR6L8FA6PRc6ZNN3SUHDSCD/AQ8rdHGO2n6Jl8P0zb
# r17C89XYcz1DTsEzOUyOArxCaC4Q6oRRRuLRvWoYWmEBc8pnol7XKHYC4jMYcten
# IPDC+hIK12NvDMk2ZItboKaDIV1fMHSRlJTYuVD5C4lh8zYGNRiER9vcG9H9stQc
# xWv2XFJRXRLbJbqvUAV6bMURHXLvjflSxIUXk8A8FdsaN8cIFRg/eKtFtvUeh17a
# j54WcmnGrnu3tz5q4i6tAgMBAAGjggHdMIIB2TASBgkrBgEEAYI3FQEEBQIDAQAB
# MCMGCSsGAQQBgjcVAgQWBBQqp1L+ZMSavoKRPEY1Kc8Q/y8E7jAdBgNVHQ4EFgQU
# n6cVXQBeYl2D9OXSZacbUzUZ6XIwXAYDVR0gBFUwUzBRBgwrBgEEAYI3TIN9AQEw
# QTA/BggrBgEFBQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9E
# b2NzL1JlcG9zaXRvcnkuaHRtMBMGA1UdJQQMMAoGCCsGAQUFBwMIMBkGCSsGAQQB
# gjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/
# MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1UdHwRPME0wS6BJ
# oEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01p
# Y1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYB
# BQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljUm9v
# Q2VyQXV0XzIwMTAtMDYtMjMuY3J0MA0GCSqGSIb3DQEBCwUAA4ICAQCdVX38Kq3h
# LB9nATEkW+Geckv8qW/qXBS2Pk5HZHixBpOXPTEztTnXwnE2P9pkbHzQdTltuw8x
# 5MKP+2zRoZQYIu7pZmc6U03dmLq2HnjYNi6cqYJWAAOwBb6J6Gngugnue99qb74p
# y27YP0h1AdkY3m2CDPVtI1TkeFN1JFe53Z/zjj3G82jfZfakVqr3lbYoVSfQJL1A
# oL8ZthISEV09J+BAljis9/kpicO8F7BUhUKz/AyeixmJ5/ALaoHCgRlCGVJ1ijbC
# HcNhcy4sa3tuPywJeBTpkbKpW99Jo3QMvOyRgNI95ko+ZjtPu4b6MhrZlvSP9pEB
# 9s7GdP32THJvEKt1MMU0sHrYUP4KWN1APMdUbZ1jdEgssU5HLcEUBHG/ZPkkvnNt
# yo4JvbMBV0lUZNlz138eW0QBjloZkWsNn6Qo3GcZKCS6OEuabvshVGtqRRFHqfG3
# rsjoiV5PndLQTHa1V1QJsWkBRH58oWFsc/4Ku+xBZj1p/cvBQUl+fpO+y/g75LcV
# v7TOPqUxUYS8vwLBgqJ7Fx0ViY1w/ue10CgaiQuPNtq6TPmb/wrpNPgkNWcr4A24
# 5oyZ1uEi6vAnQj0llOZ0dFtq0Z4+7X6gMTN9vMvpe784cETRkPHIqzqKOghif9lw
# Y1NNje6CbaUFEMFxBmoQtB1VM1izoXBm8qGCAsswggI0AgEBMIH4oYHQpIHNMIHK
# MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQLExxN
# aWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25zMSYwJAYDVQQLEx1UaGFsZXMgVFNT
# IEVTTjoyMjY0LUUzM0UtNzgwQzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3Rh
# bXAgU2VydmljZaIjCgEBMAcGBSsOAwIaAxUARIo61IrtFVUr5KL5qoV3RhJj5U+g
# gYMwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYw
# JAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0B
# AQUFAAIFAOdny9MwIhgPMjAyMzAxMTAxOTM0NDNaGA8yMDIzMDExMTE5MzQ0M1ow
# dDA6BgorBgEEAYRZCgQBMSwwKjAKAgUA52fL0wIBADAHAgEAAgIOOTAHAgEAAgIR
# +zAKAgUA52kdUwIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAow
# CAIBAAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBAA18Bb1SDcbr
# +hB+ExBBlAY1H+/qKvbAqB9KfwijgNGOu+UZ7D2yS6YscCjJ1HsNDmoTfVHQVQ7M
# Huh6lLO2HjIQCj6AX6YqZW/04mJx//fDf7iDg+OR4xWGybSPRqADokudRiVWXLjG
# tL6zOf8lOgg1bCnSIvp0Q3HIFw2IEkbwMYIEDTCCBAkCAQEwgZMwfDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAHBPqCDnOAJr8UAAQAAAcEwDQYJYIZI
# AWUDBAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG
# 9w0BCQQxIgQg8XVGQG4ngAw+F6dMyWOXcPwGj34V8c1puNOEoPhRJscwgfoGCyqG
# SIb3DQEJEAIvMYHqMIHnMIHkMIG9BCAKuSDq2Bgd5KAiw3eilHbPsQTFYDRiSKuS
# 9VhJMGB21DCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMz
# AAABwT6gg5zgCa/FAAEAAAHBMCIEIHL3UHSGrCUO+kN/F6EQow8F3uzt9RVoF0GI
# U+PxlPzaMA0GCSqGSIb3DQEBCwUABIICAII4W4za90phQfNTKcb6mffkABp+bcY9
# AJuDBUJmoZLHE20tXA4QrQBvlvihGM3BJcY1rk1TEyq6C0a1/iSxTHwjKtPYIF5x
# IA5osr0Cc6wyxmcMU9pC8QNeStiJVxjic8hkmS8+64ULinUKeHjoq874lqvY+VK3
# HNnIIxnY5jOVUY7QD1VIYkLNgy0c4DmcNKQ+J5mxYfYrPQB0H1zg8CkldXGmv7Qy
# IrTrgGfG7kAqcL9uI0x/KWxNZbIQ/vWDGuBOynT61LBlRGO0fNShyY2kLLm+eQlV
# BenBoRnVcTdbrVlTxizCh1lZLE7UhC6X6Ohnrt1f+yuqm22IBJf24yFoBztwj1rp
# i8awisuxK/a/00rgizH4CebW09nht04EA00w4cYUvgrP2U8raz2r3S+czUMRS6ha
# CVvVlGAcgc9fBN+0O4db7949N9Wk2dpBms7SvsrleVZ1yfwrzEjHWtMO4j6MdHr/
# BX1scpVBDYpPQPdUs4eEd5NOfCpqTZ993yUxcbvVla/GQCjc+AupW/NLKUtNc10i
# 1FW/ZbNf4LyMcKYQ0V137fanGRcDfAEWGa5WyIaLSoJSACJ8/zi/Ji6rKM7+Kvru
# NmOqkJzRZhn6M6ZS8H685ROVdjXrMp+CHi8j3NKdLBcpvB6YEHe2zSHKb31qEacd
# sVV5WlXD3Tfk
# SIG # End signature block
