<# last edit by: waltere 2021-07-13
 File Name:  monthly_updateRFL_OS_Type.ps1

 MANUALLY
 1- Change: $UpdType="B"
 2- Update $NewPublishedDate
 3- Update $NewKBTitle in section 'switch($OSshort)' - and download KB's *.csv files, 
 4-    + substitute in KB titles "—" with "-"
 5a- "2008","2008R2","2012","2012R2","2016","2016RS1","2016RS4","2016RS5","201619H2","20162004","201620H2","201621H1","2022"| ForEach-Object{.\RflLists\monthly_updateRFL_OS_Type.ps1 $_}  #(for updating *History.txt, )
 5b- - delete the two lines reg. previous monthly KB in KBonlyRollup_<os>.csv
 #>

Param(
	[ValidateSet("2016","2016RS1","2016RS4","2016RS5","201619H2","20162004","201620H2","201621H1","2022","all","2008","2008R2","2012","2012R2","help")]
	[Parameter(Mandatory=$True,Position=0,HelpMessage='Choose one OS from list: [2016|2016RS1|2016RS4|2016RS5|201619H2|20162004|201620H2|201621H1|2022|2008|2008R2|2012|2012R2]')]
	[string]$OSshortList
	,
	[ValidateSet("A","B","C","D","E")]
	[Parameter(Mandatory=$False,Position=1,HelpMessage='optional: Choose from list: [A|B|C|D|E]')]
	[string]$UpdType="B"
	,
	[Parameter(Mandatory=$False,Position=2,HelpMessage='optional: Choose from list: [latest cumulative kb]')]
	[string]$CumKB
	)

############################################################
## customization section of script
$NewPublishedDate="13-Jul-2021"
$LateChange=0 # set to 1, if you manually need to run the script for the last month  #_# ToDo lateChange for D
$RFLpath 			= "\\emeacssdfs.europe.corp.microsoft.com\netpodW$\rfl\RflLists\"
$RFLPrestagingPath		= $RFLpath + "PreStaging\"
$RFLPrestagingTempPath		= $RFLpath + "PreStaging\Temp\"
$RFLPrestagingTemplatePath	= $RFLpath + "PreStaging\Template\"
$csvDelimiter=","
############################################################
$Debug_out=0
$CsvHeader = "Binary","Version","size","Published","Time","Platform","SP_requirement","Service","branch"
# 2017-03-16 Wrong csv format for 2012R2 March 2017 2012R2-03B_4012216.csv has additional column ,Hashes,
#$CsvHeader = "Binary","Version","size","Published","Time","Hashes","Platform","SP_requirement","Service","branch"

$OpenSummary=1
$Super_verbose=0
$Stats=1
$VerMa="1"
$VerMi="01"
$start = Get-Date
$CheckDate = (Get-Date -UFormat "%Y-%m-%d_%R").Replace(":","-")
$CountInvFil = "\\waltere-VDI\netpod\tools\RFL\count_mnXls-update.dat"
$CountInvFil2 = $CountInvFil +'.us'
$RefCsvDate = (Get-Date -UFormat "%Y-%m-%d_%R").Replace(":","-")
$Year		= (Get-Date -UFormat "%y").Replace(":","-")
$Month 		= (Get-Date -UFormat "-%m").Replace(":","-")
$ThisMonth 	= $Month
$LastMonth 	= Get-Date (Get-Date).AddMonths(-1) -f MM
$Ref20YYMM 	= (Get-Date -UFormat "%Y-%m").Replace(":","-")
$YYMM 		= (Get-Date -UFormat "%y-%m").Replace(":","-")
$lastYYMM 	= Get-Date (Get-Date).AddMonths(-1) -f yy-MM
#if ("$UpdType" -match "B|A") {$Month = $LastMonth} #; $YYMM = Get-Date (Get-Date).AddMonths(-1) -f yy-MM}
if ($LateChange) {$Year		= "21"
				$Month		= $LastMonth
				$Ref20YYMM	= "20" + $Year + $Month
				$YYMM		= $Year + "-" + $Month
				Write-host "LateChange: Ref20YYMM: $Ref20YYMM - YYMM: $YYMM "}
Set-Variable -Name ErrorMsg -value "" -Scope Script #$ErrorMsg = ""

If ($PSBoundParameters['Debug']) { $DebugPreference='Continue'}
If ($Stats) {
 ($j=[int32](Get-Content $CountInvFil -ErrorAction SilentlyContinue)) |Out-Null
 (++$j) | Set-Content $CountInvFil -ErrorAction SilentlyContinue
 }

function downloadCsvFile ($CsvLink)
{
	Write-host "Downloading the latest *.csv referenced in KB article: $CsvLink"
	# https://keithga.wordpress.com/2017/05/21/new-tool-get-the-latest-windows-10-cumulative-updates/
	Start-BitsTransfer $CsvLink -Destination $RFLpath
	}
function updateHistoryFiles ($csv_file)
{
	# Read last line of KBOnlyRollup_OS.csv
	KBOnlyRollup_
	# Append last line of KBOnlyRollup_OS.csv to KBOnlyRollup_OS_History.txt
	Get-Content -Path $RFLpath\$KBOnlyRollup_$OS`.csv| Out-File $RFLpath\$KBOnlyRollup_$OS`.txt -Append -Encoding ASCII
}

### MAIN __________________ Enable parameter 'all' for user input (Tech and OS, parameter #1 and #2) of this script
if ($OSshortList -eq 'all'){
	[string[]]$OSshortList = "2008","2008R2","2012","2012R2","2016","2016RS1","2016RS4","2016RS5","201619H2","20162004","201620H2","201621H1","2022"
	}


### walk through each OSshort
foreach ($OSshort in $OSshortList)
	{
		### Extracting KB and Title from current KBOnlyRollup_<$OSshort>.csv
		$KBOnlyRollupFileName	= $RFLpath + 'KBOnlyRollup_' +$OSshort+ '.csv'
		#$KBOnlyRollupFileName2	= $RFLpath + 'KBOnlyRollup_' +$OSshort+ '_2.csv'
		Write-Host "$(Get-Date -UFormat "%R:%S") ___Step#1: looking up cumulative KB-nr and Title in last line of file $KBOnlyRollupFileName "
		$KBOnlyRollupFileLastLine = Import-Csv -Path $KBOnlyRollupFileName -Header Binary,Component,Version,Prio,Published,Branch,Article,Title,Link,LDROnlyKB,LDROnlyTitle,LDROnlyLink,Comment,RollupInfo | Select-Object -last 1

	if ("$UpdType" -match "B|A") 	{$Month = $LastMonth; $LastYYMM = Get-Date (Get-Date).AddMonths(-1) -f yy-MM} #_# orig line
	#_# if ("$UpdType" -match "B") 	{$Month = $Month; $LastYYMM = $YYMM}	# uncomment if "A" existed
	if ("$UpdType" -match "C|D|E") 	{$Month = $Month; $LastYYMM = $YYMM}

		if ($KBOnlyRollupFileLastLine -match $LastYYMM) {
			$CumKB 	= $($KBOnlyRollupFileLastLine.Binary)
			$CumKBTitle = $($KBOnlyRollupFileLastLine.Title)
			Write-Host ".... Copying $LastYYMM KB to History: $CumKB Title: $CumKBTitle"
			# Append last line of KBOnlyRollup_OS.csv to KBOnlyRollup_OS_History.txt
			$KBOnlyRollupHistoryFileName	= $RFLpath + 'KBOnlyRollup_' +$OSshort+ '_History.txt'
			$KBOnlyRollupFileLastLineA = Get-Content -Path $KBOnlyRollupFileName | Select-Object -last 1
			$KBOnlyRollupHistoryFileLastLine = Get-Content -Path $KBOnlyRollupHistoryFileName | Select-Object -last 1
			if ($KBOnlyRollupHistoryFileLastLine -notMatch $KBOnlyRollupFileLastLineA) { $KBOnlyRollupFileLastLineA | Out-File $KBOnlyRollupHistoryFileName -Append -Encoding ASCII }

			}
		else {	Write-Host -BackgroundColor Black -ForegroundColor Red -Object "$($OSshort): No latest $($YYMM) rollup info in current $KBOnlyRollupFileName
		 Make sure you have updated $KBOnlyRollupFileName with latest monthly update KB"
			break}

	switch($OSshort)
			{	# use the tool WUscraper.exe -rfl  https://dev.azure.com/tdimli/_git/WUscraper to get all new W10 KB articles
			"2008"		{$NewKBTitle="July 13, 2021�KB5004305 (Monthly Rollup)"
							$CsvLink="https://download.microsoft.com/download/f/9/7/f978ea6e-6cd9-4e04-bbd4-c9b1d1372586/5004305.csv"}
			"2008R2"	{$NewKBTitle="July 13, 2021�KB5004289 (Monthly Rollup)"
							$CsvLink="https://download.microsoft.com/download/b/2/9/b29d47d0-9fa7-4d8e-ad43-797c522305ac/5004289.csv"}
			"2012"		{$NewKBTitle="July 13, 2021�KB5004294 (Monthly Rollup)"
							$CsvLink="https://download.microsoft.com/download/d/d/8/dd8d3ce0-52b3-4c5c-a23c-4db4f85de1a8/5004294.csv"}
			"2012R2"	{$NewKBTitle="July 13, 2021�KB5004298 (Monthly Rollup)"
							$CsvLink="https://download.microsoft.com/download/3/2/6/32647c6d-2296-439e-8918-21be0f8cd42a/5004298.csv"}
			"2016"		{$NewKBTitle="July 13, 2021�KB5004249 (OS Build 10240.19003)"
							$CsvLink="https://download.microsoft.com/download/6/b/6/6b6f97dc-d674-4639-8db5-f94cf26520f3/5004249.csv"}
			"2016RS1"	{$NewKBTitle="July 13, 2021�KB5004238 (OS Build 14393.4530)"
							$CsvLink="https://download.microsoft.com/download/8/d/3/8d3920d3-40d4-43c8-a4f7-c8aacffabdca/5004238.csv"}
			"2016RS4"	{$NewKBTitle="May 11, 2021�KB5003174 (OS Build 17134.2208)"
							$CsvLink="https://download.microsoft.com/download/7/5/0/750f1f8e-5f7b-4452-a339-83a2f22d9c56/5003174.csv"}
			"2016RS5"	{$NewKBTitle="July 13, 2021�KB5004244 (OS Build 17763.2061)"
							$CsvLink="https://download.microsoft.com/download/6/a/9/6a91388b-a0d7-427c-914f-3f9139aac7e4/5004244.csv"}
			"201619H2"	{$NewKBTitle="July 13, 2021�KB5004245 (OS Build 18363.1679)"
							$CsvLink="https://download.microsoft.com/download/6/7/8/67887b4b-3c2d-4fb6-827f-35c90ea0ec51/5004245.csv"}
			"20162004"	{$NewKBTitle="July 13, 2021�KB5004237 (OS Builds 19041.1110, 19042.1110, and 19043.1110)"
							$CsvLink="https://download.microsoft.com/download/6/5/2/65245c79-00e2-4474-885c-6cb7dcc68fe7/5004237.csv"}
			"201620H2"	{$NewKBTitle="July 13, 2021�KB5004237 (OS Builds 19041.1110, 19042.1110, and 19043.1110)"
							$CsvLink="https://download.microsoft.com/download/6/5/2/65245c79-00e2-4474-885c-6cb7dcc68fe7/5004237.csv"}
			"201621H1"	{$NewKBTitle="July 13, 2021�KB5004237 (OS Builds 19041.1110, 19042.1110, and 19043.1110)"
							$CsvLink="https://download.microsoft.com/download/6/5/2/65245c79-00e2-4474-885c-6cb7dcc68fe7/5004237.csv"}
			"2022"		{$NewKBTitle="July 06, 2021�KB5004945 (OS Builds 19041.1083, 19042.1083, and 19043.1083) out-of-band"
							$CsvLink="https://download.microsoft.com/download/a/f/1/af14f4f4-efcd-4cb6-b287-936ba954b36f/5004945.csv"}
			}
	[string]$NewKBTitle="$(($NewKBTitle).Replace("�","-"))"
	$NewBinary=($NewKBTitle -split '-KB')[1]
	$NewBinary=($NewBinary -split ' ')[0]
	$NewComponent="Win" + $OSshort + "_" + $YYMM + "_" + $UpdType + "_rollup_KB"
	$NewPublished=$NewPublishedDate
	$NewArticle="$NewBinary"
	$NewLink="http://support.microsoft.com/kb/$NewBinary"
	$NewRollupInfo="$YYMM`Rollup"
	$NewKBOnlyRollupFileLastLine = new-object PSObject -Property @{Binary=$NewBinary;Component=$NewComponent;Version=" ";Prio="0";Published=$NewPublished;Branch="GDR";Article=$NewArticle;Title=$NewKBTitle;Link=$NewLink;LDROnlyKB="KB only";LDROnlyTitle="KB only";LDROnlyLink="KB only";Comment=" ";RollupInfo=$NewRollupInfo}
	#$NewKBOnlyRollupFileLastLine = new-object PSObject -Property @{Binary=$Binary;Component=$Component;Version=$Version;Prio=$Prio;Published=$Published;Branch=$Branch;Article=$Article;Title=$Title;Link=$Link;LDROnlyKB=$LDROnlyKB;LDROnlyTitle=$LDROnlyTitle;LDROnlyLink=$LDROnlyLink;Comment=$Comment;RollupInfo=$RollupInfo}
	#$NewKBOnlyRollupFileLastLine=$NewBinary,$NewComponent," ","0",$NewPublished,"GDR",$NewArticle,$NewKBTitle,$NewLink,"KB only","KB only","KB Only"," ",$NewRollupInfo
	Write-Host ".... Append/Export to $KBOnlyRollupFileName "
			#$NewKBOnlyRollupFileLastLine | Select-Object Binary,Component,Version,Prio,Published,Branch,Article,Title,Link,LDROnlyKB,LDROnlyTitle,LDROnlyLink,Comment,RollupInfo `
			# | Export-Csv -Path $KBOnlyRollupFileName2 -NoTypeInformation -Append -Force
			$NewKBOnlyRollupFileLastLine | Select-Object Binary,Component,Version,Prio,Published,Branch,Article,Title,Link,LDROnlyKB,LDROnlyTitle,LDROnlyLink,Comment,RollupInfo `
			 | ConvertTo-Csv  -NoTypeInformation | Out-File $KBOnlyRollupFileName -Append -Force -Encoding Ascii
			#$NewKBOnlyRollupFileLastLine | Export-Csv -Path $KBOnlyRollupFileName2 -NoTypeInformation -Append -Force
			##$App = $NewKBOnlyRollupFileLastLine | Select-Object Binary,Component,Version,Prio,Published,Branch,Article,Title,Link,LDROnlyKB,LDROnlyTitle,LDROnlyLink,Comment,RollupInfo | ConvertTo-Csv  -NoTypeInformation | Out-File $KBOnlyRollupFileName2 -Append -Force -Encoding Ascii
			#$App | Out-File $KBOnlyRollupFileName2 -Append -Force -Encoding Ascii
			$App
			#$NewKBOnlyRollupFileLastLine | Export-Csv -Path $KBOnlyRollupFileName2 -NoTypeInformation -Append -Delimiter "$csvDelimiter"
	downloadCsvFile $CsvLink
	$NewCsvName = $OSshort + $ThisMonth + $UpdType + "_" + $NewBinary +".csv"
	Rename-Item -Path "$RFLpath$NewBinary.csv" -NewName $NewCsvName 
	} #end of foreach ($OSshort in $OSshortList)
	$end = Get-Date
$Duration = $end - $start
Write-Host -BackgroundColor Gray -ForegroundColor Black -Object "$(Get-Date -UFormat "%R") $($NodeName) Done $($OSshortList) monthly_updateRFL_OS_Type.ps1 Script version v$VerMa.$VerMi took $Duration"

Write-output "`n"
If ($Stats) {
 ([string]$j + " ;$CheckDate; $OSshortList ;" + [System.Security.Principal.WindowsIdentity]::GetCurrent().Name) + "; $($Duration)" + "; Err: $($ErrorMsg)" | Out-File $CountInvFil2 -Append -Encoding UTF8 -ErrorAction SilentlyContinue
 }