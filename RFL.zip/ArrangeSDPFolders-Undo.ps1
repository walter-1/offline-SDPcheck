<# last edit by: waltere 2022-09-14
  File Name: ArrangeSDPFolders-Undo.ps1
  Objective: This script moves all files in folders back to the root of the SDP.
  supplied by Willy Moselhy (IBS) <v-waalmo@microsoft.com>
#>

<#
.SYNOPSIS
This script moves all files in folders back to the root of the SDP.

SYNTAX: .\ArrangeSDPFolders-Undo.ps1 -SDPPath [full-path-to-expanded-SDP-report]

.DESCRIPTION
The script is used when the SDP is used when you need to bring the SDP files to their original state.
When you run, it will move all files in subfolders back to the root of the SDP and delete the folders afterwards.

If you experience PS error '...is not digitally signed.' run the command:
Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned

.EXAMPLE
\\emeacssdfs.europe.corp.microsoft.com\netpod\rfl\ArrangeSDPFolders-Undo.ps1 -SDPPath \\MyPC\temp\SDPs\ClusterReports -HostMode
This command will move files in subfolder back to \\MyPC\temp\SDPs\ClusterReports by computer name and RFL folder. 
It will also show detailed output in the console.

.LINK
\\emeacssdfs.europe.corp.microsoft.com\netpod\rfl\ArrangeSDPFolders-Undo.ps1
v-waalmo@microsoft.com ; waltere@microsoft.com
#>

Param (
  [Parameter(Mandatory = $true,Position=0,HelpMessage='Choose a writable SDP folder location, i.e. C:\SR\SDP-report\ ')]
  [string] $SDPPath,			# Path to SDP result folder containing !PStatSum_*.txt files
  [switch]$HostMode  = $false,	#This tells the logging functions to show logging on the screen
  [switch]$ScriptMode = $false 	#This tells the logging functions to show logging in log file _PStat_Sum_Compared.log
)

### Trail SDPPath with \ and allow path with space character
	if ($SDPPath.EndsWith("\")){$SDPPath="$SDPPath"}
	else {$SDPPath="$SDPPath" +"\"}
	If (-NOT (Test-Path $SDPPath -PathType 'Container')){Throw "$($SDPPath) is not a valid folder"}

	$ScriptFolder = Split-Path $MyInvocation.MyCommand.Path -Parent
	# Load Common Library
	  Remove-Module Utils_RflShared -ErrorAction Ignore
	  Import-Module $ScriptFolder\Utils_RflShared.psm1 -DisableNameChecking

#region: ###### customization section of script, logging configuration ########################
	$verDateScript = "2022.09.14.0"
	$LogPath = $SDPPath + "_ArrangeSDPFolders-Undo.log"
	$ErrorThrown = $null
	$ErrorActionPreference = "Stop"
	$LogLevel = 0
	$LogPath = $SDPPath + "Arrange-SDPFoldersUndo.log"
#endregion: ###### customization section
	$ScriptBeginTimeStamp = Get-Date

#region: Script Functions
function MoveItemLogErrorAndContinue ($File,$TargetFolder){
  #Synopsis: This moves an item, adds any error to the log and resumes
  
  $MoveError = $null
  Move-Item -Path $File.FullName -Destination $TargetFolder -Force -ErrorAction SilentlyContinue -ErrorVariable $MoveError | Out-Null
  if($MoveError){
    WriteError -message "An error ocurred while moving $($File.BaseName). Review the error below, correct it, and run the script again"
    $LogLevel++ 
      WriteError -message $MoveError.Exception.Message
    $LogLevel--
  }
}
#endregion: Script Functions

#region: MAIN
	WriteInfo -message "Starting 'ArrangeSDPFolders-Undo.ps1' on $(Get-Date)"

	try{
	  $ArrangedFolders = Get-ChildItem -Path $SDPPath -Directory
	  WriteInfo -message "Found $($ArrangedFolders.count) folders"
	  foreach ($Folder in $ArrangedFolders){
		$ChildItems = $Folder | Get-ChildItem
		WriteInfo -message "Moving $($ChildItems.count) files in $($Folder.BaseName) to $SDPPath"
		$ChildItems | ForEach-Object{ MoveItemLogErrorAndContinue -File $_ -TargetFolder $SDPPath}

		if(! ($Folder | Get-ChildItem ) ){
		  $Folder | Remove-Item -Force 
		  WriteInfo -message "Deleted $Folder"
		}
	  }
	}
	catch{
	  WriteError -message "An Error occured"
	  WriteError -message $error[0].Exception.Message
	  $ErrorThrown = $true
	}
	finally{
	  $ScriptEndTimeStamp = Get-Date
	  $LogLevel = 0
	  WriteInfo -message "Script ArrangeSDPFolders-Undo v$verDateScript execution finished."
	  Writeinfo -message "Duration: $(New-TimeSpan -Start $ScriptBeginTimeStamp -End $ScriptEndTimeStamp)"
	  
	  if($ErrorThrown) {Throw $error[0].Exception.Message}
	}
#endregion: MAIN

