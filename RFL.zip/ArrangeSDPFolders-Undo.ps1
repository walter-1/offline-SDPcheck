<# last edit by: waltere 2022-06-16
File Name: ArrangeSDPFolders-Undo.ps1
Objective: This script moves all files in folders back to the root of the SDP.
supplied by Willy Moselhy (IBS) <v-waalmo@microsoft.com>
#>

<#
.SYNOPSIS
This script moves all files in folders back to the root of the SDP.

SYNTAX: .\ArrangeSDPFolders-Undo.ps1 -SDPPath [full-path-to-expanded-SDP-report]

.DESCRIPTION
The script is used when the SDP is used when you need to bring the SDP files to their original state.
When you run, it will move all files in subfolders back to the root of the SDP and delete the folders afterwards.

If you experience PS error '...is not digitally signed.' run the command:
Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned

.EXAMPLE
\\emeacssdfs.europe.corp.microsoft.com\netpod\rfl\ArrangeSDPFolders-Undo.ps1 -SDPPath \\MyPC\temp\SDPs\ClusterReports -HostMode
This command will move files in subfolder back to \\MyPC\temp\SDPs\ClusterReports by computer name and RFL folder. 
It will also show detailed output in the console.

.LINK
\\emeacssdfs.europe.corp.microsoft.com\netpod\rfl\ArrangeSDPFolders-Undo.ps1
v-waalmo@microsoft.com ; waltere@microsoft.com
#>

Param (
  # Path to SDP result folder containing !PStatSum_*.txt files
  [Parameter(Mandatory = $true,Position=0,HelpMessage='Choose a writable SDP folder location, i.e. C:\SR\SDP-report\ ')]
  [string] $SDPPath,
  
  [switch]$HostMode  = $false, #This tells the logging functions to show logging on the screen
  [switch]$ScriptMode = $false #This tells the logging functions to show logging in log file _PStat_Sum_Compared.log
)

### Trail SDPPath with \ and allow path with space character
	if ($SDPPath.EndsWith("\")){$SDPPath="$SDPPath"}
	else {$SDPPath="$SDPPath" +"\"}
	If (-NOT (Test-Path $SDPPath -PathType 'Container')){Throw "$($SDPPath) is not a valid folder"}

	
#region: customization section of script, logging configuration
	$LogPath = $SDPPath + "_ArrangeSDPFolders-Undo.log"
	$ErrorThrown = $null
	$ScriptBeginTimeStamp = Get-Date
	$ErrorActionPreference = "Stop"
	$LogLevel = 0
	$VerMa="1"
	$VerMi="01"
	$LogPath = $SDPPath + "Arrange-SDPFoldersUndo.log"
#endregion: customization section of script, logging configuration


#region: Logging Functions 
function WriteLine ([string]$line,[string]$ForegroundColor, [switch]$NoNewLine){
	# SYNOPSIS: writes the actual output - used by other Logging Functions
    if($Script:ScriptMode){
      if($NoNewLine) {
        $Script:Trace += "$line"
      }
      else {
        $Script:Trace += "$line`r`n"
      }
      Set-Content -Path $script:LogPath -Value $Script:Trace
    }
    if($Script:HostMode){
      $Params = @{
        NoNewLine    = $NoNewLine -eq $true
        ForegroundColor = if($ForegroundColor) {$ForegroundColor} else {"White"}
      }
      Write-Host $line @Params
    }
  }
  
  function WriteInfo([string]$message,[switch]$WaitForResult,[string[]]$AdditionalStringArray,[string]$AdditionalMultilineString){
	# SYNOPSIS: handles informational logs
    if($WaitForResult){
      WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)$message" -NoNewline
    }
    else{
      WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)$message" 
    }
    if($AdditionalStringArray){
      foreach ($String in $AdditionalStringArray){
        WriteLine "          $("`t" * $script:LogLevel)`t$String"   
      }    
    }
    if($AdditionalMultilineString){
      foreach ($String in ($AdditionalMultilineString -split "`r`n" | Where-Object {$_ -ne ""})){
        WriteLine "          $("`t" * $script:LogLevel)`t$String"   
      }
    }
  }

  function WriteResult([string]$message,[switch]$Pass,[switch]$Success){
	# SYNOPSIS: writes results - should be used after -WaitForResult in WriteInfo
    if($Pass){
      WriteLine " - Pass" -ForegroundColor Cyan
      if($message){
        WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)`t$message" -ForegroundColor Cyan
      }
    }
    if($Success){
      WriteLine " - Success" -ForegroundColor Green
      if($message){
        WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)`t$message" -ForegroundColor Green
      }
    } 
  }

  function WriteInfoHighlighted([string]$message,[string[]]$AdditionalStringArray,[string]$AdditionalMultilineString){
	# SYNOPSIS: write highlighted info 
    WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)$message" -ForegroundColor Cyan
    if($AdditionalStringArray){
      foreach ($String in $AdditionalStringArray){
        WriteLine "[$(Get-Date -Format hh:mm:ss)]     $("`t" * $script:LogLevel)`t$String" -ForegroundColor Cyan
      }
    }
    if($AdditionalMultilineString){
      foreach ($String in ($AdditionalMultilineString -split "`r`n" | Where-Object {$_ -ne ""})){
        WriteLine "[$(Get-Date -Format hh:mm:ss)]     $("`t" * $script:LogLevel)`t$String" -ForegroundColor Cyan
      }
    }
  }

  function WriteWarning([string]$message,[string[]]$AdditionalStringArray,[string]$AdditionalMultilineString){ 
	# SYNOPSIS: write warning logs 
    WriteLine "[$(Get-Date -Format hh:mm:ss)] WARNING: $("`t" * $script:LogLevel)$message" -ForegroundColor Yellow
    if($AdditionalStringArray){
      foreach ($String in $AdditionalStringArray){
        WriteLine "[$(Get-Date -Format hh:mm:ss)]     $("`t" * $script:LogLevel)`t$String" -ForegroundColor Yellow
      }
    }
    if($AdditionalMultilineString){
      foreach ($String in ($AdditionalMultilineString -split "`r`n" | Where-Object {$_ -ne ""})){
        WriteLine "[$(Get-Date -Format hh:mm:ss)]     $("`t" * $script:LogLevel)`t$String" -ForegroundColor Yellow
      }
    }
  }

  function WriteError([string]$message){
	# SYNOPSIS: logs errors
    WriteLine ""
    WriteLine "[$(Get-Date -Format hh:mm:ss)] ERROR:  $("`t`t" * $script:LogLevel)$message" -ForegroundColor Red
  }

  function WriteErrorAndExit($message){
	# SYNOPSIS: logs errors and terminates script 
    WriteLine "[$(Get-Date -Format hh:mm:ss)] ERROR:  $("`t" * $script:LogLevel)$message" -ForegroundColor Red
    Write-Host "Press any key to continue ..."
    $host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") | OUT-NULL
    $HOST.UI.RawUI.Flushinputbuffer()
    Throw "Terminating Error"
  }
#endregion: Logging Functions

#region: Script Functions
function MoveItemLogErrorAndContinue ($File,$TargetFolder){
  #Synopsis: This moves an item, adds any error to the log and resumes
  
  $MoveError = $null
  Move-Item -Path $File.FullName -Destination $TargetFolder -Force -ErrorAction SilentlyContinue -ErrorVariable $MoveError | Out-Null
  if($MoveError){
    WriteError -message "An error ocurred while moving $($File.BaseName). Review the error below, correct it, and run the script again"
    $LogLevel++ 
      WriteError -message $MoveError.Exception.Message
    $LogLevel--
  }
}

#endregion: Script Functions

#region: MAIN
	WriteInfo -message "Starting 'ArrangeSDPFolders-Undo.ps1' on $(Get-Date)"

	try{
	  $ArrangedFolders = Get-ChildItem -Path $SDPPath -Directory
	  WriteInfo -message "Found $($ArrangedFolders.count) folders"
	  foreach ($Folder in $ArrangedFolders){
		$ChildItems = $Folder | Get-ChildItem
		WriteInfo -message "Moving $($ChildItems.count) files in $($Folder.BaseName) to $SDPPath"
		$ChildItems | ForEach-Object{ MoveItemLogErrorAndContinue -File $_ -TargetFolder $SDPPath}

		if(! ($Folder | Get-ChildItem ) ){
		  $Folder | Remove-Item -Force 
		  WriteInfo -message "Deleted $Folder"
		}
	  }
	}
	catch{
	  WriteError -message "An Error occured"
	  WriteError -message $error[0].Exception.Message
	  $ErrorThrown = $true
	}
	finally{
	  $ScriptEndTimeStamp = Get-Date
	  $LogLevel = 0
	  WriteInfo -message "Script ArrangeSDPFolders-Undo v$VerMa.$VerMi execution finished."
	  Writeinfo -message "Duration: $(New-TimeSpan -Start $ScriptBeginTimeStamp -End $ScriptEndTimeStamp)"
	  
	  if($ErrorThrown) {Throw $error[0].Exception.Message}
	}

#endregion: MAIN

