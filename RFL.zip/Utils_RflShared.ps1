# ******************************************* RFL ***********************************************
# File: Utils_RflShared.ps1
# Version 1.0
# Date:  
# Description:  Utility Script to load common functions for RFL.
# last edit by: waltere 
# ***********************************************************************************************


##########################
## Set Variables        ##
##########################
$verDatePsm1 = "2023.06.07.0"
#$ComputerName = $Env:computername
#$UserOSVersion = [Environment]::OSVersion.Version

##########################
## Function Definitions ##
##########################

#region Logging functions
Function global:EnterFunc([String]$FunctionName){
	Write-Verbose "---> Enter $FunctionName"
}
Function global:EnterFuncDbg([String]$FunctionName){	# enter with callstack info
	$CallStack = Get-PSCallStack
	$CallerInfo = $CallStack[1]
	$2ndCallerInfo = $CallStack[$Index+1]
	$3rdCallerInfo = $CallStack[$Index+2]
#write-host "1-2-3: $CallerInfo $2ndCallerInfo $3ndCallerInfo"
	# LogMessage() is called from wrapper function like LogInfo() and EnterFunc(). In this case, we show caller of the wrapper function.
	If($CallerInfo.FunctionName -notlike "*LogException" -and ($CallerInfo.FunctionName -like "global:Log*" -or $CallerInfo.FunctionName -like "*EnterFunc*" -or $CallerInfo.FunctionName -like "*EndFunc" -or $CallerInfo.FunctionName -like "DoGetVersion")){
		$CallerInfo = $2ndCallerInfo # Set actual function name calling LogInfo/LogWarn/LogError
		If($CallerInfo.FunctionName -like "*LogException"){
			$CallerInfo = $3rdCallerInfo
		}
	}
	$FuncName = $CallerInfo.FunctionName.Replace("global:","")
	If($CallerInfo.FunctionName -like '<ScriptBlock>'){ #-eq
		 $FuncName = 'Main'
	}Else{
		$FuncName = $CallerInfo.FunctionName
	}
	EnterFunc ("$FuncName" + " (Caller - $($FuncName):$($CallerInfo.ScriptLineNumber))")
}
Function global:EndFunc([String]$FunctionName){
	Write-Verbose "<--- End $FunctionName"
}

Function global:WriteLine ([string]$line,[string]$ForegroundColor, [switch]$NoNewLine){
	# SYNOPSIS: writes the actual output - used by other Logging Functions
	if($Script:ScriptMode){
	  if($NoNewLine) {
		$Script:Trace += "$line"
	  }
	  else {
		$Script:Trace += "$line`r`n"
	  }
	  Set-Content -Path $script:LogPath -Value $Script:Trace
	}
	if($Script:HostMode){
	  $Params = @{
		NoNewLine    = $NoNewLine -eq $true
		ForegroundColor = if($ForegroundColor) {$ForegroundColor} else {"White"}
	  }
	  Write-Host $line @Params
	}
}

Function global:WriteInfo([string]$message,[switch]$WaitForResult,[string[]]$AdditionalStringArray,[string]$AdditionalMultilineString){
	# SYNOPSIS: handles informational logs
	if($WaitForResult){
	  WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)$message" -NoNewline
	}
	else{
	  WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)$message"
	}
	if($AdditionalStringArray){
	  foreach ($String in $AdditionalStringArray){
		WriteLine "          $("`t" * $script:LogLevel)`t$String"
	  }
	}
	if($AdditionalMultilineString){
	  foreach ($String in ($AdditionalMultilineString -split "`r`n" | Where-Object {$_ -ne ""})){
		WriteLine "          $("`t" * $script:LogLevel)`t$String"
	  }
	}
}

Function global:WriteResult([string]$message,[switch]$Pass,[switch]$Success){
	# SYNOPSIS: writes results - should be used after -WaitForResult in WriteInfo
	if($Pass){
	  WriteLine " - Pass" -ForegroundColor Cyan
	  if($message){
		WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)`t$message" -ForegroundColor Cyan
	  }
	}
	if($Success){
	  WriteLine " - Success" -ForegroundColor Green
	  if($message){
		WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)`t$message" -ForegroundColor Green
	  }
	}
}

Function global:WriteInfoHighlighted([string]$message,[string[]]$AdditionalStringArray,[string]$AdditionalMultilineString){
	# SYNOPSIS: write highlighted info
	WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)$message" -ForegroundColor Cyan
	if($AdditionalStringArray){
	  foreach ($String in $AdditionalStringArray){
		WriteLine "[$(Get-Date -Format hh:mm:ss)]     $("`t" * $script:LogLevel)`t$String" -ForegroundColor Cyan
	  }
	}
	if($AdditionalMultilineString){
	  foreach ($String in ($AdditionalMultilineString -split "`r`n" | Where-Object {$_ -ne ""})){
		WriteLine "[$(Get-Date -Format hh:mm:ss)]     $("`t" * $script:LogLevel)`t$String" -ForegroundColor Cyan
	  }
	}
}

Function global:WriteWarning([string]$message,[string[]]$AdditionalStringArray,[string]$AdditionalMultilineString){
	# SYNOPSIS: write warning logs
	WriteLine "[$(Get-Date -Format hh:mm:ss)] WARNING: $("`t" * $script:LogLevel)$message" -ForegroundColor Magenta
	if($AdditionalStringArray){
	  foreach ($String in $AdditionalStringArray){
		WriteLine "[$(Get-Date -Format hh:mm:ss)]     $("`t" * $script:LogLevel)`t$String" -ForegroundColor Magenta
	  }
	}
	if($AdditionalMultilineString){
	  foreach ($String in ($AdditionalMultilineString -split "`r`n" | Where-Object {$_ -ne ""})){
		WriteLine "[$(Get-Date -Format hh:mm:ss)]     $("`t" * $script:LogLevel)`t$String" -ForegroundColor Magenta
	  }
	}
}

Function global:WriteError([string]$message){
	# SYNOPSIS: logs errors
	WriteLine ""
	WriteLine "[$(Get-Date -Format hh:mm:ss)] ERROR:  $("`t`t" * $script:LogLevel)$message" -ForegroundColor Red
}

Function global:WriteErrorAndExit($message){
	# SYNOPSIS: logs errors and terminates script
	WriteLine "[$(Get-Date -Format hh:mm:ss)] ERROR:  $("`t" * $script:LogLevel)$message" -ForegroundColor Red
	Write-Host "Press any key to continue ..."
	$host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") | OUT-NULL
	$HOST.UI.RawUI.Flushinputbuffer()
	Throw "Terminating Error"
}

Function global:ExitWithCode ($Ecode) {
	# set ErrorLevel to be picked up by invoking CMD script
	if ( $UseExitCode ) {
		Write-Verbose "[ExitWithCode] Return Code: $Ecode"
		#error.clear()	# clear script errors
		exit $Ecode
		}
}
Function global:VersionInt($verString){
	EnterFunc $MyInvocation.MyCommand.Name
	$verSplit = $verString.Split([char]0x0a, [char]0x0d, '.')
	$vFull = 0; $i = 0; $vNum = 256 * 256 * 256
	while ($vNum -gt 0) { $vFull += [int] $verSplit[$i] * $vNum; $vNum = $vNum / 256; $i++ };
	EndFunc ($MyInvocation.MyCommand.Name + "($vFull)")
	return $vFull
}
Function global:CheckVersion ($verCurrent){	
	EnterFunc ($MyInvocation.MyCommand.Name + "(verCurrent: $verCurrent)")
  if ( -Not $noVersionChk.IsPresent){
	# automated version checking. When launched, the script will warn if a newer version is available online and recommend to download it. 
	# Internet access is required and the repository to be reachable, for the version check to be successful. It will not automatically download the new version; this will be up to the user to do.
	#$RFLReleaseServer = "cesdiagtools.blob.core.windows.net"
	$UpdateSource = "cesdiagtools"
	Write-Host -ForegroundColor Gray "[CheckVersion] Checking if a new version is available on https://aka.ms/getRFL"
	Try{
		$checkConn = FwTestConnWebSite $RFLReleaseServer # FwTestConnWebSite could throw an exception
	}Catch{
		Write-Host -ForegroundColor Magenta "Connectivity to $RFLReleaseServer failed."
		$checkConn = $False
	}
	if ( $checkConn -eq "True") {
		try
			{
				$WebClient = New-Object System.Net.WebClient
				[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
				$verNew = $WebClient.DownloadString('https://cesdiagtools.blob.core.windows.net/windows/RFL.ver')
				$verNew = $verNew.TrimEnd([char]0x0a, [char]0x0d)
				[long] $lNew = VersionInt($verNew)
				[long] $lCur = VersionInt($verCurrent)
				if($lNew -gt $lCur) {
					Write-Host -ForegroundColor Magenta ("A newer version is available: v" + $verNew + " (you are currently on v"+$verCurrent+"). `n For best results, download and use the latest version from https://aka.ms/getRFL")
					$Script:fUpToDate = $False
					$Script:RFLVerOnline = $lNew 
					Write-Host -ForegroundColor Yellow "*** trying auto-update..."
					UpdateRFL
					Write-Host -ForegroundColor Yellow "*** Note: results will only be accurate at next run! ***"
				}
				else {
					Write-Host  ("You are running the latest RFL version (v"+$verCurrent+")") -ForegroundColor Green
					$Script:fUpToDate = $True
				}
			}
		catch
			{
				WriteWarning ("Unable to check RFL script version online... (local version: v"+$verCurrent+")" + $_)
				WriteInfo "For best results, always use the latest version from https://aka.ms/getRFL"
			}
	}Else{
		WriteWarning ("Unable to contact MS tools store: $RFLReleaseServer (local version: v" +$verCurrent+ ")")
		WriteInfo "For best results, always use the latest version from https://aka.ms/getRFL"
	}
	EndFunc $MyInvocation.MyCommand.Name
  }else{ WriteInfo "skipping online version check (-noVersionChk)"}
}
Function global:CheckVersionGitHub ($verCurrent){	
	# deprecated
	EnterFunc ($MyInvocation.MyCommand.Name + "(verCurrent: $verCurrent)")
  if (-Not $noVersionChk.IsPresent){
	# automated version checking. When launched, the script will warn if a newer version is available online and recommend to download it. 
	# Internet access is required and the repository to be reachable, for the version check to be successful. It will NOT automatically download the new version; this will be up to the user to do.
#	$RFLReleaseServer = "api.Github.com"
	$UpdateSource = "GitHub"
	Try{
		$checkConn = FwTestConnWebSite $RFLReleaseServer # FwTestConnWebSite could throw an exception
	}Catch{
		Write-Host -ForegroundColor Magenta "Connectivity to $RFLReleaseServer failed."
		$checkConn = $False
	}
	if ( $checkConn -eq "True") {
		try	{
			Write-Debug "[$($MyInvocation.MyCommand.Name)] try Invoke-WebRequest "
			# GitHub: Get web content and convert from JSON
			[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
			try { $web_content = Invoke-WebRequest -Uri $RFL_release_url -UseBasicParsing | ConvertFrom-Json } catch { "`n$(Get-Date -UFormat "%D %R:%S")*** Failure during RFL update. Exception Message:`n $($_.Exception.Message)" | Out-File $RflUpdLogfile -Append }
			if ($web_content.tag_name) {
				[version]$expected_latest_RFL_version = $web_content.tag_name.replace("v","")
				$verNew = $expected_latest_RFL_version
				write-verbose "[$($MyInvocation.MyCommand.Name)] $UpdateSource Version of '$RFL_release_url': --> $verNew"
				
				$installedRFLver = New-Object System.Version($verCurrent)
				$expectedVersion = New-Object System.Version($expected_latest_RFL_version)
				if ($($($installedRFLver).CompareTo($($expectedVersion))) -eq 0) { 		# If versions match, display message
						"`n $(Get-Date -UFormat "%D %R:%S")[$($MyInvocation.MyCommand.Name)] [Info] Latest RFL version $expectedVersion is installed. " | Out-File $RflUpdLogfile -Append
				}
				elseif ($($installedRFLver.CompareTo($expectedVersion)) -lt 0) {	# if installed current version is lower than latest $UpdateSource Release version
						"`n $(Get-Date -UFormat "%D %R:%S")[Action: $RFL_action -[Warning] Actually installed RFL version $installedRFLver is outdated - please run $ScriptFolder\RFL_update-script.ps1] " | Out-File $RflUpdLogfile -Append
						Write-Host -ForegroundColor red "[$($MyInvocation.MyCommand.Name)] [Warning] Actually installed RFL version $installedRFLver is outdated!`n - please run $ScriptFolder\RFL_update-script.ps1"
						Write-Host -ForegroundColor cyan "[$($MyInvocation.MyCommand.Name)] [Info] Latest available version on Github is: $expectedVersion `n Trying AutoUpdate now..."
						Write-Host -ForegroundColor Magenta "*** Note: results will only be accurate at next run! ***"
						& $ScriptFolder\RFL_update-script.ps1
				}
				else{
					"`n $(Get-Date -UFormat "%D %R:%S")[[Info] installedRFLver $installedRFLver -newer than- expectedVersion $expectedVersion] " | Out-File $RflUpdLogfile -Append
					Write-host "[$($MyInvocation.MyCommand.Name)] installedRFLver $installedRFLver -newer than- expectedVersion $expectedVersion"
					}
				Write-verbose "[$($MyInvocation.MyCommand.Name)] installedRFLver $installedRFLver - expectedVersion $expectedVersion"

				if($expectedVersion -gt $installedRFLver) {
					WriteWarning (" A newer version is available: v"+$verNew+" (you are currently on v"+$verCurrent+"). For best results, download and use the latest version from https://aka.ms/getRFL")
					$Script:fUpToDate = $False
				}else {
					write-verbose " [$($MyInvocation.MyCommand.Name)] verNew $verNewt - verCurrent $verCurrent"
					Write-Host -ForegroundColor Green  ("[$($MyInvocation.MyCommand.Name)] You are running the latest version (v"+$verCurrent+")")
					$Script:fUpToDate = $True
				}
				#return $expected_latest_RFL_version
			}else { 
				Write-Host -ForegroundColor Red "[$($MyInvocation.MyCommand.Name)] [ERROR] cannot securely access $RflReleaseServer. Please download https://aka.ms/getRFL"
				"`n $(GGet-Date -UFormat "%D %R:%S") [ERROR] cannot securely access $RflReleaseServer. Please download https://aka.ms/getRFL" | Out-File $RflUpdLogfile -Append
				$script:ChkFailed=$TRUE
				return 2022.0.0.0
			}
		}catch{
				WriteWarning ("[$($MyInvocation.MyCommand.Name)] Unable to check RFL script version online... (local version: v"+$verCurrent+")" + $_)
				WriteInfo "[$($MyInvocation.MyCommand.Name)] For best results, always use the latest version from https://aka.ms/getRFL"
		}
	}Else{
		WriteWarning ("[$($MyInvocation.MyCommand.Name)] Unable to contact MS tools store: $RFLReleaseServer (local version: v" +$verCurrent+ ")")
		WriteInfo "[$($MyInvocation.MyCommand.Name)] For best results, always use the latest version from https://aka.ms/getRFL"
	}
  }
  EndFunc ($MyInvocation.MyCommand.Name + "(fUpToDate: $Script:fUpToDate)")
}
#endregion Logging functions

#region RFL functions
function GetOSfromMSinfo32 ($SDPPath,$NodeName){
	# Return: $OSshortVer of SDP report
	EnterFunc ($MyInvocation.MyCommand.Name + "(NodeName: $NodeName)")
	### Validate user input of expanded SDP report and identify the number of msinfo32.txt files and the names of the computers $NodeNames (in Cluster Report)
	$msinfo32 = $SDPPath + $NodeName + '*msinfo*.txt' # Try .txt
	If (-NOT (Test-Path $msinfo32)) {
	    Write-Verbose "[GetOSfromMSinfo32]** $SDPPath without *msinfo32.txt"
	    $msinfo32 = $SDPPath + $NodeName + '*msinfo*.nfo' # Try .nfo
	}

	### Get OS version of SDP report from msinfo.txt
	If ("$msinfo32" -match ".txt"){
	    Write-Verbose "[GetOSfromMSinfo32]Node: $NodeName Using msinfo32.txt = $msinfo32 "
	    #Read-in content from Msinfo file
	    if ($msinfo32file = get-childitem $msinfo32) {
			Write-Debug "[GetOSfromMSinfo32]msinfo32file: $msinfo32file "
			$script:SDPdate = $msinfo32file.LastWriteTime
			Write-host "`n[GetOSfromMSinfo32]Node: $NodeName : SDP Date: $script:SDPdate"
			$msinfo32 = Get-Content $msinfo32 -TotalCount 13
			If ($msinfo32){
				$SdpOSbuild = 		$msinfo32[-7]
				$global:SdpOSname = 		$msinfo32[-8];$SdpOSname=$global:SdpOSname.Split(" ",3)[2]
				$global:SdpComputerName = 	$msinfo32[1].Split("")[-1]
				$Systemmodell = 	$msinfo32[-2] #.Split("")[1,2,3]
				$is_Virtual = 		$Systemmodell| Select-String -Pattern ".*Virtual.*" -ErrorAction SilentlyContinue; if ($is_Virtual) {$Virtualized="VM"} else {$Virtualized=""}
				$is_VMware = 		$Systemmodell| Select-String -Pattern ".*VMware.*" -ErrorAction SilentlyContinue; if ($is_VMware) {$Script:Virtualization="VMware"} else {$Script:Virtualization=""}
				$SystemArch = 		$msinfo32[-1] #.Split("")[-1,-2]
				$is_x64 = 			$SystemArch| Select-String -Pattern ".*x64.*" -ErrorAction SilentlyContinue; if ($is_x64) {$Architecture="x64"} else {$Architecture="x86"}
				#_#Write-Output " Node: $SdpComputerName|$SdpOSbuild|$SdpOSname|$Systemmodell|$SystemArch |-> $Virtualized|$Virtualization|$Architecture|"
				Write-Host " Node: $SdpComputerName|$SdpOSbuild|$SdpOSname|$Systemmodell|$SystemArch |-> $Virtualized|$Virtualization|$Architecture|"
			}else{$global:ErrorMsg += "No-Valid-MsI32_txt "}
		}
	}
	Else { # Get OS version of SDP report from msinfo.nfo / may not work for some localized OS
		Write-Verbose "Node: $NodeName Using msinfo32.nfo = $msinfo32 "
		if ($msinfo32file = get-childitem $msinfo32) {
			$script:SDPdate = $msinfo32file.LastWriteTime
			Write-Debug "`nNode: $NodeName : SDP Date: $script:SDPdate"
			[xml]$nfo = Get-Content $msinfo32file
			$summary = $nfo.MSInfo.Category.Data.value # German $nfo.MSInfo.Category.Data.Wert / Italian: Valore
			If ($summary.'#cdata-section') {
				$SdpOSbuild = 		$summary.'#cdata-section'[1]
				$global:SdpOSname = 		$summary.'#cdata-section'[0]
				$global:SdpComputerName = 	$summary.'#cdata-section'[4]
				$Systemmodell = 	$summary.'#cdata-section'[6]
				$is_Virtual = 		$Systemmodell| Select-String -Pattern ".*Virtual.*" -ErrorAction SilentlyContinue; if ($is_Virtual) {$Virtualized="VM"} else {$Virtualized=""}
				$is_VMware = 		$Systemmodell| Select-String -Pattern ".*VMware.*" -ErrorAction SilentlyContinue; if ($is_VMware) {$Script:Virtualization="VMware"} else {$Script:Virtualization=""}
				$SystemArch = 		$summary.'#cdata-section'[7]
				$is_x64 = 			$SystemArch| Select-String -Pattern ".*x64.*" -ErrorAction SilentlyContinue; if ($is_x64) {$Architecture="x64"} else {$Architecture="x86"}
				Write-Host " Node: $SdpOSbuild|$SdpOSname|$SdpComputerName|$Systemmodell|$SystemArch |-> $Virtualized|$Virtualization|$Architecture|"
			}else{
				$global:ErrorMsg += "No-Valid-MsI32_nfo"
				Write-Host -BackgroundColor Black -ForegroundColor Yellow -Object "WARNING: SDP with no valid MSinfo32.txt or English .nfo files"
			}
		}
	}
	if ($SdpOSname -match "Windows 1|Windows 7|Windows 8") {$isClient = $True}
	$global:ErrorMsg += "$Architecture $Virtualized $Virtualization "
	
	### match Build number in SDP report with OS short name
	if("$SdpOSbuild" -match "2600"){$OSshortVer_old="old-XP"}  		# Windows XP
	if("$SdpOSbuild" -match "3790"){$OSshortVer_old="old-2003"}  	# Windows 2003
	if("$SdpOSbuild" -match "6001"){$OSshortVer_old="old-2008-SP1"}	# Windows Vista/2008 SP1
	if("$SdpOSbuild" -match "6002|6003"){$OSshortVer="2008"}  		# Windows Vista/2008 SP2
	if("$SdpOSbuild" -match "7600"){$OSshortVer_old="old-2008R2-RTM"} # Windows 7/2008R2 RTM
	if("$SdpOSbuild" -match "7601"){$OSshortVer="2008R2"} 			# Windows 7/2008R2
	if("$SdpOSbuild" -match "9200"){$OSshortVer="2012"}  			# Windows 8
	if("$SdpOSbuild" -match "9600"){$OSshortVer="2012R2"} 			# Windows 8.1
	if("$SdpOSbuild" -match "10.0.10240"){$OSshortVer="2016"} 		# Windows 10
	if("$SdpOSbuild" -match "10.0.14393"){$OSshortVer="2016RS1"} 	# Windows 10 RS1
	if("$SdpOSbuild" -match "10.0.17763"){$OSshortVer="2016RS5"} 	# Windows 10 RS5
	if("$SdpOSbuild" -match "10.0.18363"){$OSshortVer="201619H2"}	# Windows 10 19H2
	if("$SdpOSbuild" -match "10.0.19041"){$OSshortVer="20162004"} 	# Windows 10 2004 2020 April 2020 Update
	if("$SdpOSbuild" -match "10.0.19042"){$OSshortVer="201620H2"} 	# Windows 10 20H2 October 2020 Update
	if("$SdpOSbuild" -match "10.0.19043"){$OSshortVer="201621H1"} 	# Windows 10 21H1 April 2021 Update
	if("$SdpOSbuild" -match "10.0.19044"){$OSshortVer="201621H2"} 	# Windows 10 21H2 Oct 2021 Update
	if("$SdpOSbuild" -match "10.0.19045"){$OSshortVer="201622H2"} 	# Windows 10 22H2 Oct 2022 Update
	if("$SdpOSbuild" -match "10.0.20348"){$OSshortVer="2022"} 		# Windows Srv 2022
	if("$SdpOSbuild" -match "10.0.20349"){$OSshortVer="2022"} 		# Windows Srv 2022AZ HCI
	if("$SdpOSbuild" -match "10.0.22000"){$OSshortVer="Win11"} 		# Windows 11
	if("$SdpOSbuild" -match "10.0.22621"){$OSshortVer="Win1122H2"}	# Windows 11 22H2 Oct 2022 Update
	if("$SdpOSbuild" -match "10.0.22622"){$OSshortVer="Win1123H1"}	# Windows 11 insider
	Write-Host " OS build: $SdpOSbuild -|OS: $OSshortVer $OSshortVer_old"
	Write-Host " SDP Date:         $($script:SDPdate) / OS-Version: $($OSshortVer) $($OSshortVer_old)" #Write-Verbose
	Write-Host " SDP ComputerName: $SdpComputerName |Build: $SdpOSbuild |OS: $SdpOSname"
	
	$OSshortVer	# return
	EndFunc ($MyInvocation.MyCommand.Name + "(OS build: $SdpOSbuild - $OSVersion $OSVersion_old)")
}

#endregion RFL functions

# only for module .psm1
#Export-ModuleMember -Function * -Cmdlet * -Variable * -Alias *


# SIG # Begin signature block
# MIInogYJKoZIhvcNAQcCoIInkzCCJ48CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCQMPEqoKlieYcV
# DOtS1QSJlP8pK1mDUgZo5ebdigb3iaCCDYUwggYDMIID66ADAgECAhMzAAADTU6R
# phoosHiPAAAAAANNMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjMwMzE2MTg0MzI4WhcNMjQwMzE0MTg0MzI4WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDUKPcKGVa6cboGQU03ONbUKyl4WpH6Q2Xo9cP3RhXTOa6C6THltd2RfnjlUQG+
# Mwoy93iGmGKEMF/jyO2XdiwMP427j90C/PMY/d5vY31sx+udtbif7GCJ7jJ1vLzd
# j28zV4r0FGG6yEv+tUNelTIsFmmSb0FUiJtU4r5sfCThvg8dI/F9Hh6xMZoVti+k
# bVla+hlG8bf4s00VTw4uAZhjGTFCYFRytKJ3/mteg2qnwvHDOgV7QSdV5dWdd0+x
# zcuG0qgd3oCCAjH8ZmjmowkHUe4dUmbcZfXsgWlOfc6DG7JS+DeJak1DvabamYqH
# g1AUeZ0+skpkwrKwXTFwBRltAgMBAAGjggGCMIIBfjAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUId2Img2Sp05U6XI04jli2KohL+8w
# VAYDVR0RBE0wS6RJMEcxLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJh
# dGlvbnMgTGltaXRlZDEWMBQGA1UEBRMNMjMwMDEyKzUwMDUxNzAfBgNVHSMEGDAW
# gBRIbmTlUAXTgqoXNzcitW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8v
# d3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIw
# MTEtMDctMDguY3JsMGEGCCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDEx
# XzIwMTEtMDctMDguY3J0MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIB
# ACMET8WuzLrDwexuTUZe9v2xrW8WGUPRQVmyJ1b/BzKYBZ5aU4Qvh5LzZe9jOExD
# YUlKb/Y73lqIIfUcEO/6W3b+7t1P9m9M1xPrZv5cfnSCguooPDq4rQe/iCdNDwHT
# 6XYW6yetxTJMOo4tUDbSS0YiZr7Mab2wkjgNFa0jRFheS9daTS1oJ/z5bNlGinxq
# 2v8azSP/GcH/t8eTrHQfcax3WbPELoGHIbryrSUaOCphsnCNUqUN5FbEMlat5MuY
# 94rGMJnq1IEd6S8ngK6C8E9SWpGEO3NDa0NlAViorpGfI0NYIbdynyOB846aWAjN
# fgThIcdzdWFvAl/6ktWXLETn8u/lYQyWGmul3yz+w06puIPD9p4KPiWBkCesKDHv
# XLrT3BbLZ8dKqSOV8DtzLFAfc9qAsNiG8EoathluJBsbyFbpebadKlErFidAX8KE
# usk8htHqiSkNxydamL/tKfx3V/vDAoQE59ysv4r3pE+zdyfMairvkFNNw7cPn1kH
# Gcww9dFSY2QwAxhMzmoM0G+M+YvBnBu5wjfxNrMRilRbxM6Cj9hKFh0YTwba6M7z
# ntHHpX3d+nabjFm/TnMRROOgIXJzYbzKKaO2g1kWeyG2QtvIR147zlrbQD4X10Ab
# rRg9CpwW7xYxywezj+iNAc+QmFzR94dzJkEPUSCJPsTFMIIHejCCBWKgAwIBAgIK
# YQ6Q0gAAAAAAAzANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlm
# aWNhdGUgQXV0aG9yaXR5IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEw
# OTA5WjB+MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYD
# VQQDEx9NaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG
# 9w0BAQEFAAOCAg8AMIICCgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+la
# UKq4BjgaBEm6f8MMHt03a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc
# 6Whe0t+bU7IKLMOv2akrrnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4D
# dato88tt8zpcoRb0RrrgOGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+
# lD3v++MrWhAfTVYoonpy4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nk
# kDstrjNYxbc+/jLTswM9sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6
# A4aN91/w0FK/jJSHvMAhdCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmd
# X4jiJV3TIUs+UsS1Vz8kA/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL
# 5zmhD+kjSbwYuER8ReTBw3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zd
# sGbiwZeBe+3W7UvnSSmnEyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3
# T8HhhUSJxAlMxdSlQy90lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS
# 4NaIjAsCAwEAAaOCAe0wggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRI
# bmTlUAXTgqoXNzcitW2oynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTAL
# BgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBD
# uRQFTuHqp8cx0SOJNDBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jv
# c29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3JsMF4GCCsGAQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3J0MIGfBgNVHSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEF
# BQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1h
# cnljcHMuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkA
# YwB5AF8AcwB0AGEAdABlAG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn
# 8oalmOBUeRou09h0ZyKbC5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7
# v0epo/Np22O/IjWll11lhJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0b
# pdS1HXeUOeLpZMlEPXh6I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/
# KmtYSWMfCWluWpiW5IP0wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvy
# CInWH8MyGOLwxS3OW560STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBp
# mLJZiWhub6e3dMNABQamASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJi
# hsMdYzaXht/a8/jyFqGaJ+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYb
# BL7fQccOKO7eZS/sl/ahXJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbS
# oqKfenoi+kiVH6v7RyOA9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sL
# gOppO6/8MO0ETI7f33VtY5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtX
# cVZOSEXAQsmbdlsKgEhr/Xmfwb1tbWrJUnMTDXpQzTGCGXMwghlvAgEBMIGVMH4x
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01p
# Y3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTECEzMAAANNTpGmGiiweI8AAAAA
# A00wDQYJYIZIAWUDBAIBBQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQw
# HAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIJJs
# vplxftnrq9nvdeSlJYhbHRXxnRM/s8DTNqS7vCMlMEIGCisGAQQBgjcCAQwxNDAy
# oBSAEgBNAGkAYwByAG8AcwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20wDQYJKoZIhvcNAQEBBQAEggEATV1JFf9NaZPEKF3459dhkGSFQzEOLeIOxVQA
# 8CogcRgbv3bsAyEQIXebTDroE3mORPv73CIPZr9wX8infElMtJ7M65+2HLzyxO4z
# PGLaYNNBUT450jXReLxISxe7Apc1Li8KdM1xC0ATcxcDJ46uwLKZbLEwu/QF2LUB
# OjsliZgUue4+dtq4M8m4ffE2Y10rcAI2uxPlqFnNrBTT+ozAKowgDsZE/oNFhowE
# iWUATu3BvbUixPboovFgmiuqFOS4h9tPg6kOw2BRyMn96IXkjMjrvZR80GoSnXnj
# MFxj485aaw2MHtG7/v23E2p+iIv3rr8G/krPhTzUaAL94KYDR6GCFv0wghb5Bgor
# BgEEAYI3AwMBMYIW6TCCFuUGCSqGSIb3DQEHAqCCFtYwghbSAgEDMQ8wDQYJYIZI
# AWUDBAIBBQAwggFRBgsqhkiG9w0BCRABBKCCAUAEggE8MIIBOAIBAQYKKwYBBAGE
# WQoDATAxMA0GCWCGSAFlAwQCAQUABCAuLpDY1E3qZ+w5CD4BZo1onRO7mR4yYYD6
# +YKHNFyO1wIGZIr6hLS9GBMyMDIzMDcwNTE5NDYzMC41NTJaMASAAgH0oIHQpIHN
# MIHKMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQL
# ExxNaWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25zMSYwJAYDVQQLEx1UaGFsZXMg
# VFNTIEVTTjpERDhDLUUzMzctMkZBRTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUt
# U3RhbXAgU2VydmljZaCCEVQwggcMMIIE9KADAgECAhMzAAABxQPNzSGh9O85AAEA
# AAHFMA0GCSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEw
# MB4XDTIyMTEwNDE5MDEzMloXDTI0MDIwMjE5MDEzMlowgcoxCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBBbWVy
# aWNhIE9wZXJhdGlvbnMxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkREOEMtRTMz
# Ny0yRkFFMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIIC
# IjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAq0hds70eX23J7pappaKXRhz+
# TT7JJ3OvVf3+N8fNpxRs5jY4hEv3BV/w5EWXbZdO4m3xj01lTI/xDkq+ytjuiPe8
# xGXsZxDntv7L1EzMd5jISqJ+eYu8kgV056mqs8dBo55xZPPPcxf5u19zn04aMQF5
# PXV/C4ZLSjFa9IFNcribdOm3lGW1rQRFa2jUsup6gv634q5UwH09WGGu0z89Rbtb
# yM55vmBgWV8ed6bZCZrcoYIjML8FRTvGlznqm6HtwZdXMwKHT3a/kLUSPiGAsrIg
# Ezz7NpBpeOsgs9TrwyWTZBNbBwyIACmQ34j+uR4et2hZk+NH49KhEJyYD2+dOIaD
# GB2EUNFSYcy1MkgtZt1eRqBB0m+YPYz7HjocPykKYNQZ7Tv+zglOffCiax1jOb0u
# 6IYC5X1Jr8AwTcsaDyu3qAhx8cFQN9DDgiVZw+URFZ8oyoDk6sIV1nx5zZLy+hNt
# akePX9S7Y8n1qWfAjoXPE6K0/dbTw87EOJL/BlJGcKoFTytr0zPg/MNJSb6f2a/w
# DkXoGCGWJiQrGTxjOP+R96/nIIG05eE1Lpky2FOdYMPB4DhW7tBdZautepTTuShm
# gn+GKER8AoA1gSSk1EC5ZX4cppVngJpblMBu8r/tChfHVdXviY6hDShHwQCmZqZe
# bgSYHnHl4urE+4K6ZC8CAwEAAaOCATYwggEyMB0GA1UdDgQWBBRU6rs4v1mxNYG/
# rtpLwrVwek0FazAfBgNVHSMEGDAWgBSfpxVdAF5iXYP05dJlpxtTNRnpcjBfBgNV
# HR8EWDBWMFSgUqBQhk5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2Ny
# bC9NaWNyb3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIwMjAxMCgxKS5jcmwwbAYI
# KwYBBQUHAQEEYDBeMFwGCCsGAQUFBzAChlBodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NlcnRzL01pY3Jvc29mdCUyMFRpbWUtU3RhbXAlMjBQQ0ElMjAy
# MDEwKDEpLmNydDAMBgNVHRMBAf8EAjAAMBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0G
# CSqGSIb3DQEBCwUAA4ICAQCMqN58frMHOScciK+Cdnr6dK8fTsgQDeZ9bvQjCuxN
# IJZJ92+xpeKRCf3Xq47qdRykkKUnZC6dHhLwt1fhwyiy/LfdVQ9yf1hYZ/RpTS+z
# 0hnaoK+P/IDAiUNm32NXLhDBu0P4Sb/uCV4jOuNUcmJhppBQgQVhFx/57JYk1LCd
# jIee//GrcfbkQtiYob9Oa93DSjbsD1jqaicEnkclUN/mEm9ZsnCnA1+/OQDp/8Q4
# cPfH94LM4J6X0NtNBeVywvWH0wuMaOJzHgDLCeJUkFE9HE8sBDVedmj6zPJAI+7o
# zLjYqw7i4RFbiStfWZSGjwt+lLJQZRWUCcT3aHYvTo1YWDZskohWg77w9fF2QbiO
# 9DfnqoZ7QozHi7RiPpbjgkJMAhrhpeTf/at2e9+HYkKObUmgPArH1Wjivwm1d7PY
# WsarL7u5qZuk36Gb1mETS1oA2XX3+C3rgtzRohP89qZVf79lVvjmg34NtICK/pMk
# 99SButghtipFSMQdbXUnS2oeLt9cKuv1MJu+gJ83qXTNkQ2QqhxtNRvbE9QqmqJQ
# w5VW/4SZze1pPXxyOTO5yDq+iRIUubqeQzmUcCkiyNuCLHWh8OLCI5mIOC1iLtVD
# f2lw9eWropwu5SDJtT/ZwqIU1qb2U+NjkNcj1hbODBRELaTTWd91RJiUI9ncJkGg
# /jCCB3EwggVZoAMCAQICEzMAAAAVxedrngKbSZkAAAAAABUwDQYJKoZIhvcNAQEL
# BQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xMjAwBgNV
# BAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmljYXRlIEF1dGhvcml0eSAyMDEwMB4X
# DTIxMDkzMDE4MjIyNVoXDTMwMDkzMDE4MzIyNVowfDELMAkGA1UEBhMCVVMxEzAR
# BgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1p
# Y3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3Rh
# bXAgUENBIDIwMTAwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDk4aZM
# 57RyIQt5osvXJHm9DtWC0/3unAcH0qlsTnXIyjVX9gF/bErg4r25PhdgM/9cT8dm
# 95VTcVrifkpa/rg2Z4VGIwy1jRPPdzLAEBjoYH1qUoNEt6aORmsHFPPFdvWGUNzB
# RMhxXFExN6AKOG6N7dcP2CZTfDlhAnrEqv1yaa8dq6z2Nr41JmTamDu6GnszrYBb
# fowQHJ1S/rboYiXcag/PXfT+jlPP1uyFVk3v3byNpOORj7I5LFGc6XBpDco2LXCO
# Mcg1KL3jtIckw+DJj361VI/c+gVVmG1oO5pGve2krnopN6zL64NF50ZuyjLVwIYw
# XE8s4mKyzbnijYjklqwBSru+cakXW2dg3viSkR4dPf0gz3N9QZpGdc3EXzTdEonW
# /aUgfX782Z5F37ZyL9t9X4C626p+Nuw2TPYrbqgSUei/BQOj0XOmTTd0lBw0gg/w
# EPK3Rxjtp+iZfD9M269ewvPV2HM9Q07BMzlMjgK8QmguEOqEUUbi0b1qGFphAXPK
# Z6Je1yh2AuIzGHLXpyDwwvoSCtdjbwzJNmSLW6CmgyFdXzB0kZSU2LlQ+QuJYfM2
# BjUYhEfb3BvR/bLUHMVr9lxSUV0S2yW6r1AFemzFER1y7435UsSFF5PAPBXbGjfH
# CBUYP3irRbb1Hode2o+eFnJpxq57t7c+auIurQIDAQABo4IB3TCCAdkwEgYJKwYB
# BAGCNxUBBAUCAwEAATAjBgkrBgEEAYI3FQIEFgQUKqdS/mTEmr6CkTxGNSnPEP8v
# BO4wHQYDVR0OBBYEFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMFwGA1UdIARVMFMwUQYM
# KwYBBAGCN0yDfQEBMEEwPwYIKwYBBQUHAgEWM2h0dHA6Ly93d3cubWljcm9zb2Z0
# LmNvbS9wa2lvcHMvRG9jcy9SZXBvc2l0b3J5Lmh0bTATBgNVHSUEDDAKBggrBgEF
# BQcDCDAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvXzpoYxDBW
# BgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYIKwYBBQUH
# AQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtp
# L2NlcnRzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNydDANBgkqhkiG9w0BAQsF
# AAOCAgEAnVV9/Cqt4SwfZwExJFvhnnJL/Klv6lwUtj5OR2R4sQaTlz0xM7U518Jx
# Nj/aZGx80HU5bbsPMeTCj/ts0aGUGCLu6WZnOlNN3Zi6th542DYunKmCVgADsAW+
# iehp4LoJ7nvfam++Kctu2D9IdQHZGN5tggz1bSNU5HhTdSRXud2f8449xvNo32X2
# pFaq95W2KFUn0CS9QKC/GbYSEhFdPSfgQJY4rPf5KYnDvBewVIVCs/wMnosZiefw
# C2qBwoEZQhlSdYo2wh3DYXMuLGt7bj8sCXgU6ZGyqVvfSaN0DLzskYDSPeZKPmY7
# T7uG+jIa2Zb0j/aRAfbOxnT99kxybxCrdTDFNLB62FD+CljdQDzHVG2dY3RILLFO
# Ry3BFARxv2T5JL5zbcqOCb2zAVdJVGTZc9d/HltEAY5aGZFrDZ+kKNxnGSgkujhL
# mm77IVRrakURR6nxt67I6IleT53S0Ex2tVdUCbFpAUR+fKFhbHP+CrvsQWY9af3L
# wUFJfn6Tvsv4O+S3Fb+0zj6lMVGEvL8CwYKiexcdFYmNcP7ntdAoGokLjzbaukz5
# m/8K6TT4JDVnK+ANuOaMmdbhIurwJ0I9JZTmdHRbatGePu1+oDEzfbzL6Xu/OHBE
# 0ZDxyKs6ijoIYn/ZcGNTTY3ugm2lBRDBcQZqELQdVTNYs6FwZvKhggLLMIICNAIB
# ATCB+KGB0KSBzTCByjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0aW9uczEmMCQGA1UE
# CxMdVGhhbGVzIFRTUyBFU046REQ4Qy1FMzM3LTJGQUUxJTAjBgNVBAMTHE1pY3Jv
# c29mdCBUaW1lLVN0YW1wIFNlcnZpY2WiIwoBATAHBgUrDgMCGgMVACEAGvYXZJK7
# cUo62+LvEYQEx7/noIGDMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldh
# c2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBD
# b3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIw
# MTAwDQYJKoZIhvcNAQEFBQACBQDoT9Q6MCIYDzIwMjMwNzA1MTkzNjI2WhgPMjAy
# MzA3MDYxOTM2MjZaMHQwOgYKKwYBBAGEWQoEATEsMCowCgIFAOhP1DoCAQAwBwIB
# AAICHxkwBwIBAAICELkwCgIFAOhRJboCAQAwNgYKKwYBBAGEWQoEAjEoMCYwDAYK
# KwYBBAGEWQoDAqAKMAgCAQACAwehIKEKMAgCAQACAwGGoDANBgkqhkiG9w0BAQUF
# AAOBgQCLVVUPk3qg9GCD0QxLPeZWOJ7Q7kIJtZmDi/vuQrjXP7RtJcuMW2dFJdNI
# E3nawNcCjM2InLlt2UFdcoXJfyOrTUw1+2r+SE7gCOxyj1+TzHyhvlYvEsdEvbvw
# QE5UHmO70/FZFlyGJRcFXeSGiw1f6WERvpyqWJyYWfkiXdGvBzGCBA0wggQJAgEB
# MIGTMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAABxQPNzSGh9O85
# AAEAAAHFMA0GCWCGSAFlAwQCAQUAoIIBSjAaBgkqhkiG9w0BCQMxDQYLKoZIhvcN
# AQkQAQQwLwYJKoZIhvcNAQkEMSIEIKd4mUJfcHd35QcbqvyNQUXfVatlDRCwunZi
# ZuTzo1jfMIH6BgsqhkiG9w0BCRACLzGB6jCB5zCB5DCBvQQgGQGxkfYkd0wK+V09
# wO0sO+sm8gAMyj5EuKPqvNQ/fLEwgZgwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEG
# A1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWlj
# cm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFt
# cCBQQ0EgMjAxMAITMwAAAcUDzc0hofTvOQABAAABxTAiBCApw56xb4z4OqyG+n2w
# 7OPGvgSCnXpS/vDp63Cy7vO9ezANBgkqhkiG9w0BAQsFAASCAgAW5RU61nM80s9h
# k0tAPUMq822hSNmYzmnXTy9fvgNLQs1Al4EPmRKLHcWUgXE44M5zHZ6XjT4bpWQh
# 2JRoEiSomhSRmEMBCPb5YFGnlxH0DNqKMAPCYcqjB4Z9xWwGIp1EBucpeu+jWX42
# yoOWHUaB14MK7w0H+K0sG9nLX1pxE5oU0b7VGDxf1MGkXA+SP8tw2iCugKjpUHB1
# t/88vF7uk8HVYidJiRQ5fYQxiN8Xo2ldaKgVWrnHKV8GZCCAzCJANE9FsHKZqMSh
# O7+jkSphUt+68wCjYvqIzfAyRDFUaUy7zd10ym0nRMTPvVz8ircVcaOjC97+bpGU
# o54Ry59cHHwApB8FG1AM+vPEfHCuWTpNitBmSVOfszroVK8Gk8QpCBvt7MFj7//J
# 8jd7D7ha4pigB4mazh1aHJG3uzd6YH5cPmHKkviVE1baYp0ucoCTzmH2yiKgd7Iv
# efjLsRO19ghXafSuaoQe/3j8UGM/YQ65aBy/yhtLzxKjii9uvbGOiw0/boa8NFa4
# ZKIYBvAFUX6LqfnU5lOcxireCSeaCWidvWhM3Z66ZB56fSsQF8p126Ei8NA4fTSB
# tQZfbqX1zF1kDYnhTCR4zRfgXCI2Rx/VwSrG2HlwMgRCJpD9Mm5/VYKFNUHeLToH
# N7pkYe0wvSPVFbK6BMSZZ6eRST/ysw==
# SIG # End signature block
