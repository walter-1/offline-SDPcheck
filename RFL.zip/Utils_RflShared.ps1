# ******************************************* RFL ***********************************************
# File: Utils_RflShared.ps1
# Version 1.0
# Date:  
# Description:  Utility Script to load common functions for RFL.
# last edit by: waltere 
# ***********************************************************************************************


##########################
## Set Variables        ##
##########################
$verDatePsm1 = "2023.06.07.0"
#$ComputerName = $Env:computername
#$UserOSVersion = [Environment]::OSVersion.Version

##########################
## Function Definitions ##
##########################

#region Logging functions
Function global:EnterFunc([String]$FunctionName){
	Write-Verbose "---> Enter $FunctionName"
}
Function global:EnterFuncDbg([String]$FunctionName){	# enter with callstack info
	$CallStack = Get-PSCallStack
	$CallerInfo = $CallStack[1]
	$2ndCallerInfo = $CallStack[$Index+1]
	$3rdCallerInfo = $CallStack[$Index+2]
#write-host "1-2-3: $CallerInfo $2ndCallerInfo $3ndCallerInfo"
	# LogMessage() is called from wrapper function like LogInfo() and EnterFunc(). In this case, we show caller of the wrapper function.
	If($CallerInfo.FunctionName -notlike "*LogException" -and ($CallerInfo.FunctionName -like "global:Log*" -or $CallerInfo.FunctionName -like "*EnterFunc*" -or $CallerInfo.FunctionName -like "*EndFunc" -or $CallerInfo.FunctionName -like "DoGetVersion")){
		$CallerInfo = $2ndCallerInfo # Set actual function name calling LogInfo/LogWarn/LogError
		If($CallerInfo.FunctionName -like "*LogException"){
			$CallerInfo = $3rdCallerInfo
		}
	}
	$FuncName = $CallerInfo.FunctionName.Replace("global:","")
	If($CallerInfo.FunctionName -like '<ScriptBlock>'){ #-eq
		 $FuncName = 'Main'
	}Else{
		$FuncName = $CallerInfo.FunctionName
	}
	EnterFunc ("$FuncName" + " (Caller - $($FuncName):$($CallerInfo.ScriptLineNumber))")
}
Function global:EndFunc([String]$FunctionName){
	Write-Verbose "<--- End $FunctionName"
}

Function global:WriteLine ([string]$line,[string]$ForegroundColor, [switch]$NoNewLine){
	# SYNOPSIS: writes the actual output - used by other Logging Functions
	if($Script:ScriptMode){
	  if($NoNewLine) {
		$Script:Trace += "$line"
	  }
	  else {
		$Script:Trace += "$line`r`n"
	  }
	  Set-Content -Path $script:LogPath -Value $Script:Trace
	}
	if($Script:HostMode){
	  $Params = @{
		NoNewLine    = $NoNewLine -eq $true
		ForegroundColor = if($ForegroundColor) {$ForegroundColor} else {"White"}
	  }
	  Write-Host $line @Params
	}
}

Function global:WriteInfo([string]$message,[switch]$WaitForResult,[string[]]$AdditionalStringArray,[string]$AdditionalMultilineString){
	# SYNOPSIS: handles informational logs
	if($WaitForResult){
	  WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)$message" -NoNewline
	}
	else{
	  WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)$message"
	}
	if($AdditionalStringArray){
	  foreach ($String in $AdditionalStringArray){
		WriteLine "          $("`t" * $script:LogLevel)`t$String"
	  }
	}
	if($AdditionalMultilineString){
	  foreach ($String in ($AdditionalMultilineString -split "`r`n" | Where-Object {$_ -ne ""})){
		WriteLine "          $("`t" * $script:LogLevel)`t$String"
	  }
	}
}

Function global:WriteResult([string]$message,[switch]$Pass,[switch]$Success){
	# SYNOPSIS: writes results - should be used after -WaitForResult in WriteInfo
	if($Pass){
	  WriteLine " - Pass" -ForegroundColor Cyan
	  if($message){
		WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)`t$message" -ForegroundColor Cyan
	  }
	}
	if($Success){
	  WriteLine " - Success" -ForegroundColor Green
	  if($message){
		WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)`t$message" -ForegroundColor Green
	  }
	}
}

Function global:WriteInfoHighlighted([string]$message,[string[]]$AdditionalStringArray,[string]$AdditionalMultilineString){
	# SYNOPSIS: write highlighted info
	WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)$message" -ForegroundColor Cyan
	if($AdditionalStringArray){
	  foreach ($String in $AdditionalStringArray){
		WriteLine "[$(Get-Date -Format hh:mm:ss)]     $("`t" * $script:LogLevel)`t$String" -ForegroundColor Cyan
	  }
	}
	if($AdditionalMultilineString){
	  foreach ($String in ($AdditionalMultilineString -split "`r`n" | Where-Object {$_ -ne ""})){
		WriteLine "[$(Get-Date -Format hh:mm:ss)]     $("`t" * $script:LogLevel)`t$String" -ForegroundColor Cyan
	  }
	}
}

Function global:WriteWarning([string]$message,[string[]]$AdditionalStringArray,[string]$AdditionalMultilineString){
	# SYNOPSIS: write warning logs
	WriteLine "[$(Get-Date -Format hh:mm:ss)] WARNING: $("`t" * $script:LogLevel)$message" -ForegroundColor Magenta
	if($AdditionalStringArray){
	  foreach ($String in $AdditionalStringArray){
		WriteLine "[$(Get-Date -Format hh:mm:ss)]     $("`t" * $script:LogLevel)`t$String" -ForegroundColor Magenta
	  }
	}
	if($AdditionalMultilineString){
	  foreach ($String in ($AdditionalMultilineString -split "`r`n" | Where-Object {$_ -ne ""})){
		WriteLine "[$(Get-Date -Format hh:mm:ss)]     $("`t" * $script:LogLevel)`t$String" -ForegroundColor Magenta
	  }
	}
}

Function global:WriteError([string]$message){
	# SYNOPSIS: logs errors
	WriteLine ""
	WriteLine "[$(Get-Date -Format hh:mm:ss)] ERROR:  $("`t`t" * $script:LogLevel)$message" -ForegroundColor Red
}

Function global:WriteErrorAndExit($message){
	# SYNOPSIS: logs errors and terminates script
	WriteLine "[$(Get-Date -Format hh:mm:ss)] ERROR:  $("`t" * $script:LogLevel)$message" -ForegroundColor Red
	Write-Host "Press any key to continue ..."
	$host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") | OUT-NULL
	$HOST.UI.RawUI.Flushinputbuffer()
	Throw "Terminating Error"
}

Function global:ExitWithCode ($Ecode) {
	# set ErrorLevel to be picked up by invoking CMD script
	if ( $UseExitCode ) {
		Write-Verbose "[ExitWithCode] Return Code: $Ecode"
		#error.clear()	# clear script errors
		exit $Ecode
		}
}
Function global:VersionInt($verString){
	EnterFunc $MyInvocation.MyCommand.Name
	$verSplit = $verString.Split([char]0x0a, [char]0x0d, '.')
	$vFull = 0; $i = 0; $vNum = 256 * 256 * 256
	while ($vNum -gt 0) { $vFull += [int] $verSplit[$i] * $vNum; $vNum = $vNum / 256; $i++ };
	EndFunc ($MyInvocation.MyCommand.Name + "($vFull)")
	return $vFull
}
Function global:CheckVersion ($verCurrent){	
	EnterFunc ($MyInvocation.MyCommand.Name + "(verCurrent: $verCurrent)")
  if ( -Not $noVersionChk.IsPresent){
	# automated version checking. When launched, the script will warn if a newer version is available online and recommend to download it. 
	# Internet access is required and the repository to be reachable, for the version check to be successful. It will not automatically download the new version; this will be up to the user to do.
	#$RFLReleaseServer = "cesdiagtools.blob.core.windows.net"
	$UpdateSource = "cesdiagtools"
	Write-Host -ForegroundColor Gray "[CheckVersion] Checking if a new version is available on https://aka.ms/getRFL"
	Try{
		$checkConn = FwTestConnWebSite $RFLReleaseServer # FwTestConnWebSite could throw an exception
	}Catch{
		Write-Host -ForegroundColor Magenta "Connectivity to $RFLReleaseServer failed."
		$checkConn = $False
	}
	if ( $checkConn -eq "True") {
		try
			{
				$WebClient = New-Object System.Net.WebClient
				[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
				$verNew = $WebClient.DownloadString('https://cesdiagtools.blob.core.windows.net/windows/RFL.ver')
				$verNew = $verNew.TrimEnd([char]0x0a, [char]0x0d)
				[long] $lNew = VersionInt($verNew)
				[long] $lCur = VersionInt($verCurrent)
				if($lNew -gt $lCur) {
					Write-Host -ForegroundColor Magenta ("A newer version is available: v" + $verNew + " (you are currently on v"+$verCurrent+"). `n For best results, download and use the latest version from https://aka.ms/getRFL")
					$Script:fUpToDate = $False
					$Script:RFLVerOnline = $lNew 
					Write-Host -ForegroundColor Yellow "*** trying auto-update..."
					UpdateRFL
					Write-Host -ForegroundColor Yellow "*** Note: results will only be accurate at next run! ***"
				}
				else {
					Write-Host  ("You are running the latest RFL version (v"+$verCurrent+")") -ForegroundColor Green
					$Script:fUpToDate = $True
				}
			}
		catch
			{
				WriteWarning ("Unable to check RFL script version online... (local version: v"+$verCurrent+")" + $_)
				WriteInfo "For best results, always use the latest version from https://aka.ms/getRFL"
			}
	}Else{
		WriteWarning ("Unable to contact MS tools store: $RFLReleaseServer (local version: v" +$verCurrent+ ")")
		WriteInfo "For best results, always use the latest version from https://aka.ms/getRFL"
	}
	EndFunc $MyInvocation.MyCommand.Name
  }else{ WriteInfo "skipping online version check (-noVersionChk)"}
}
Function global:CheckVersionGitHub ($verCurrent){	
	# deprecated
	EnterFunc ($MyInvocation.MyCommand.Name + "(verCurrent: $verCurrent)")
  if (-Not $noVersionChk.IsPresent){
	# automated version checking. When launched, the script will warn if a newer version is available online and recommend to download it. 
	# Internet access is required and the repository to be reachable, for the version check to be successful. It will NOT automatically download the new version; this will be up to the user to do.
#	$RFLReleaseServer = "api.Github.com"
	$UpdateSource = "GitHub"
	Try{
		$checkConn = FwTestConnWebSite $RFLReleaseServer # FwTestConnWebSite could throw an exception
	}Catch{
		Write-Host -ForegroundColor Magenta "Connectivity to $RFLReleaseServer failed."
		$checkConn = $False
	}
	if ( $checkConn -eq "True") {
		try	{
			Write-Debug "[$($MyInvocation.MyCommand.Name)] try Invoke-WebRequest "
			# GitHub: Get web content and convert from JSON
			[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
			try { $web_content = Invoke-WebRequest -Uri $RFL_release_url -UseBasicParsing | ConvertFrom-Json } catch { "`n$(Get-Date -UFormat "%D %R:%S")*** Failure during RFL update. Exception Message:`n $($_.Exception.Message)" | Out-File $RflUpdLogfile -Append }
			if ($web_content.tag_name) {
				[version]$expected_latest_RFL_version = $web_content.tag_name.replace("v","")
				$verNew = $expected_latest_RFL_version
				write-verbose "[$($MyInvocation.MyCommand.Name)] $UpdateSource Version of '$RFL_release_url': --> $verNew"
				
				$installedRFLver = New-Object System.Version($verCurrent)
				$expectedVersion = New-Object System.Version($expected_latest_RFL_version)
				if ($($($installedRFLver).CompareTo($($expectedVersion))) -eq 0) { 		# If versions match, display message
						"`n $(Get-Date -UFormat "%D %R:%S")[$($MyInvocation.MyCommand.Name)] [Info] Latest RFL version $expectedVersion is installed. " | Out-File $RflUpdLogfile -Append
				}
				elseif ($($installedRFLver.CompareTo($expectedVersion)) -lt 0) {	# if installed current version is lower than latest $UpdateSource Release version
						"`n $(Get-Date -UFormat "%D %R:%S")[Action: $RFL_action -[Warning] Actually installed RFL version $installedRFLver is outdated - please run $ScriptFolder\RFL_update-script.ps1] " | Out-File $RflUpdLogfile -Append
						Write-Host -ForegroundColor red "[$($MyInvocation.MyCommand.Name)] [Warning] Actually installed RFL version $installedRFLver is outdated!`n - please run $ScriptFolder\RFL_update-script.ps1"
						Write-Host -ForegroundColor cyan "[$($MyInvocation.MyCommand.Name)] [Info] Latest available version on Github is: $expectedVersion `n Trying AutoUpdate now..."
						Write-Host -ForegroundColor Magenta "*** Note: results will only be accurate at next run! ***"
						& $ScriptFolder\RFL_update-script.ps1
				}
				else{
					"`n $(Get-Date -UFormat "%D %R:%S")[[Info] installedRFLver $installedRFLver -newer than- expectedVersion $expectedVersion] " | Out-File $RflUpdLogfile -Append
					Write-host "[$($MyInvocation.MyCommand.Name)] installedRFLver $installedRFLver -newer than- expectedVersion $expectedVersion"
					}
				Write-verbose "[$($MyInvocation.MyCommand.Name)] installedRFLver $installedRFLver - expectedVersion $expectedVersion"

				if($expectedVersion -gt $installedRFLver) {
					WriteWarning (" A newer version is available: v"+$verNew+" (you are currently on v"+$verCurrent+"). For best results, download and use the latest version from https://aka.ms/getRFL")
					$Script:fUpToDate = $False
				}else {
					write-verbose " [$($MyInvocation.MyCommand.Name)] verNew $verNewt - verCurrent $verCurrent"
					Write-Host -ForegroundColor Green  ("[$($MyInvocation.MyCommand.Name)] You are running the latest version (v"+$verCurrent+")")
					$Script:fUpToDate = $True
				}
				#return $expected_latest_RFL_version
			}else { 
				Write-Host -ForegroundColor Red "[$($MyInvocation.MyCommand.Name)] [ERROR] cannot securely access $RflReleaseServer. Please download https://aka.ms/getRFL"
				"`n $(GGet-Date -UFormat "%D %R:%S") [ERROR] cannot securely access $RflReleaseServer. Please download https://aka.ms/getRFL" | Out-File $RflUpdLogfile -Append
				$script:ChkFailed=$TRUE
				return 2022.0.0.0
			}
		}catch{
				WriteWarning ("[$($MyInvocation.MyCommand.Name)] Unable to check RFL script version online... (local version: v"+$verCurrent+")" + $_)
				WriteInfo "[$($MyInvocation.MyCommand.Name)] For best results, always use the latest version from https://aka.ms/getRFL"
		}
	}Else{
		WriteWarning ("[$($MyInvocation.MyCommand.Name)] Unable to contact MS tools store: $RFLReleaseServer (local version: v" +$verCurrent+ ")")
		WriteInfo "[$($MyInvocation.MyCommand.Name)] For best results, always use the latest version from https://aka.ms/getRFL"
	}
  }
  EndFunc ($MyInvocation.MyCommand.Name + "(fUpToDate: $Script:fUpToDate)")
}
#endregion Logging functions

#region RFL functions
function GetOSfromMSinfo32 ($SDPPath,$NodeName){
	# Return: $OSshortVer of SDP report
	EnterFunc ($MyInvocation.MyCommand.Name + "(NodeName: $NodeName)")
	### Validate user input of expanded SDP report and identify the number of msinfo32.txt files and the names of the computers $NodeNames (in Cluster Report)
	$msinfo32 = $SDPPath + $NodeName + '*msinfo*.txt' # Try .txt
	If (-NOT (Test-Path $msinfo32)) {
	    Write-Verbose "[GetOSfromMSinfo32]** $SDPPath without *msinfo32.txt"
	    $msinfo32 = $SDPPath + $NodeName + '*msinfo*.nfo' # Try .nfo
	}

	### Get OS version of SDP report from msinfo.txt
	If ("$msinfo32" -match ".txt"){
	    Write-Verbose "[GetOSfromMSinfo32]Node: $NodeName Using msinfo32.txt = $msinfo32 "
	    #Read-in content from Msinfo file
	    if ($msinfo32file = get-childitem $msinfo32) {
			Write-Debug "[GetOSfromMSinfo32]msinfo32file: $msinfo32file "
			$script:SDPdate = $msinfo32file.LastWriteTime
			Write-host "`n[GetOSfromMSinfo32]Node: $NodeName : SDP Date: $script:SDPdate"
			$msinfo32 = Get-Content $msinfo32 -TotalCount 13
			If ($msinfo32){
				$SdpOSbuild = 		$msinfo32[-7]
				$global:SdpOSname = 		$msinfo32[-8];$SdpOSname=$global:SdpOSname.Split(" ",3)[2]
				$global:SdpComputerName = 	$msinfo32[1].Split("")[-1]
				$Systemmodell = 	$msinfo32[-2] #.Split("")[1,2,3]
				$is_Virtual = 		$Systemmodell| Select-String -Pattern ".*Virtual.*" -ErrorAction SilentlyContinue; if ($is_Virtual) {$Virtualized="VM"} else {$Virtualized=""}
				$is_VMware = 		$Systemmodell| Select-String -Pattern ".*VMware.*" -ErrorAction SilentlyContinue; if ($is_VMware) {$Script:Virtualization="VMware"} else {$Script:Virtualization=""}
				$SystemArch = 		$msinfo32[-1] #.Split("")[-1,-2]
				$is_x64 = 			$SystemArch| Select-String -Pattern ".*x64.*" -ErrorAction SilentlyContinue; if ($is_x64) {$Architecture="x64"} else {$Architecture="x86"}
				#_#Write-Output " Node: $SdpComputerName|$SdpOSbuild|$SdpOSname|$Systemmodell|$SystemArch |-> $Virtualized|$Virtualization|$Architecture|"
				Write-Host " Node: $SdpComputerName|$SdpOSbuild|$SdpOSname|$Systemmodell|$SystemArch |-> $Virtualized|$Virtualization|$Architecture|"
			}else{$global:ErrorMsg += "No-Valid-MsI32_txt "}
		}
	}
	Else { # Get OS version of SDP report from msinfo.nfo / may not work for some localized OS
		Write-Verbose "Node: $NodeName Using msinfo32.nfo = $msinfo32 "
		if ($msinfo32file = get-childitem $msinfo32) {
			$script:SDPdate = $msinfo32file.LastWriteTime
			Write-Debug "`nNode: $NodeName : SDP Date: $script:SDPdate"
			[xml]$nfo = Get-Content $msinfo32file
			$summary = $nfo.MSInfo.Category.Data.value # German $nfo.MSInfo.Category.Data.Wert / Italian: Valore
			If ($summary.'#cdata-section') {
				$SdpOSbuild = 		$summary.'#cdata-section'[1]
				$global:SdpOSname = 		$summary.'#cdata-section'[0]
				$global:SdpComputerName = 	$summary.'#cdata-section'[4]
				$Systemmodell = 	$summary.'#cdata-section'[6]
				$is_Virtual = 		$Systemmodell| Select-String -Pattern ".*Virtual.*" -ErrorAction SilentlyContinue; if ($is_Virtual) {$Virtualized="VM"} else {$Virtualized=""}
				$is_VMware = 		$Systemmodell| Select-String -Pattern ".*VMware.*" -ErrorAction SilentlyContinue; if ($is_VMware) {$Script:Virtualization="VMware"} else {$Script:Virtualization=""}
				$SystemArch = 		$summary.'#cdata-section'[7]
				$is_x64 = 			$SystemArch| Select-String -Pattern ".*x64.*" -ErrorAction SilentlyContinue; if ($is_x64) {$Architecture="x64"} else {$Architecture="x86"}
				Write-Host " Node: $SdpOSbuild|$SdpOSname|$SdpComputerName|$Systemmodell|$SystemArch |-> $Virtualized|$Virtualization|$Architecture|"
			}else{
				$global:ErrorMsg += "No-Valid-MsI32_nfo"
				Write-Host -BackgroundColor Black -ForegroundColor Yellow -Object "WARNING: SDP with no valid MSinfo32.txt or English .nfo files"
			}
		}
	}
	if ($SdpOSname -match "Windows 1|Windows 7|Windows 8") {$isClient = $True}
	$global:ErrorMsg += "$Architecture $Virtualized $Virtualization "
	
	### match Build number in SDP report with OS short name
	if("$SdpOSbuild" -match "2600"){$OSshortVer_old="old-XP"}  		# Windows XP
	if("$SdpOSbuild" -match "3790"){$OSshortVer_old="old-2003"}  	# Windows 2003
	if("$SdpOSbuild" -match "6001"){$OSshortVer_old="old-2008-SP1"}	# Windows Vista/2008 SP1
	if("$SdpOSbuild" -match "6002|6003"){$OSshortVer="2008"}  		# Windows Vista/2008 SP2
	if("$SdpOSbuild" -match "7600"){$OSshortVer_old="old-2008R2-RTM"} # Windows 7/2008R2 RTM
	if("$SdpOSbuild" -match "7601"){$OSshortVer="2008R2"} 			# Windows 7/2008R2
	if("$SdpOSbuild" -match "9200"){$OSshortVer="2012"}  			# Windows 8
	if("$SdpOSbuild" -match "9600"){$OSshortVer="2012R2"} 			# Windows 8.1
	if("$SdpOSbuild" -match "10.0.10240"){$OSshortVer="2016"} 		# Windows 10
	if("$SdpOSbuild" -match "10.0.14393"){$OSshortVer="2016RS1"} 	# Windows 10 RS1
	if("$SdpOSbuild" -match "10.0.17763"){$OSshortVer="2016RS5"} 	# Windows 10 RS5
	if("$SdpOSbuild" -match "10.0.18363"){$OSshortVer="201619H2"}	# Windows 10 19H2
	if("$SdpOSbuild" -match "10.0.19041"){$OSshortVer="20162004"} 	# Windows 10 2004 2020 April 2020 Update
	if("$SdpOSbuild" -match "10.0.19042"){$OSshortVer="201620H2"} 	# Windows 10 20H2 October 2020 Update
	if("$SdpOSbuild" -match "10.0.19043"){$OSshortVer="201621H1"} 	# Windows 10 21H1 April 2021 Update
	if("$SdpOSbuild" -match "10.0.19044"){$OSshortVer="201621H2"} 	# Windows 10 21H2 Oct 2021 Update
	if("$SdpOSbuild" -match "10.0.19045"){$OSshortVer="201622H2"} 	# Windows 10 22H2 Oct 2022 Update
	if("$SdpOSbuild" -match "10.0.20348"){$OSshortVer="2022"} 		# Windows Srv 2022
	if("$SdpOSbuild" -match "10.0.20349"){$OSshortVer="2022"} 		# Windows Srv 2022AZ HCI
	if("$SdpOSbuild" -match "10.0.22000"){$OSshortVer="Win11"} 		# Windows 11
	if("$SdpOSbuild" -match "10.0.22621"){$OSshortVer="Win1122H2"}	# Windows 11 22H2 Oct 2022 Update
	if("$SdpOSbuild" -match "10.0.22622"){$OSshortVer="Win1123H1"}	# Windows 11 insider
	Write-Host " OS build: $SdpOSbuild -|OS: $OSshortVer $OSshortVer_old"
	Write-Host " SDP Date:         $($script:SDPdate) / OS-Version: $($OSshortVer) $($OSshortVer_old)" #Write-Verbose
	Write-Host " SDP ComputerName: $SdpComputerName |Build: $SdpOSbuild |OS: $SdpOSname"
	
	$OSshortVer	# return
	EndFunc ($MyInvocation.MyCommand.Name + "(OS build: $SdpOSbuild - $OSVersion $OSVersion_old)")
}

#endregion RFL functions

# only for module .psm1
#Export-ModuleMember -Function * -Cmdlet * -Variable * -Alias *


# SIG # Begin signature block
# MIInvwYJKoZIhvcNAQcCoIInsDCCJ6wCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCQMPEqoKlieYcV
# DOtS1QSJlP8pK1mDUgZo5ebdigb3iaCCDXYwggX0MIID3KADAgECAhMzAAADTrU8
# esGEb+srAAAAAANOMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjMwMzE2MTg0MzI5WhcNMjQwMzE0MTg0MzI5WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDdCKiNI6IBFWuvJUmf6WdOJqZmIwYs5G7AJD5UbcL6tsC+EBPDbr36pFGo1bsU
# p53nRyFYnncoMg8FK0d8jLlw0lgexDDr7gicf2zOBFWqfv/nSLwzJFNP5W03DF/1
# 1oZ12rSFqGlm+O46cRjTDFBpMRCZZGddZlRBjivby0eI1VgTD1TvAdfBYQe82fhm
# WQkYR/lWmAK+vW/1+bO7jHaxXTNCxLIBW07F8PBjUcwFxxyfbe2mHB4h1L4U0Ofa
# +HX/aREQ7SqYZz59sXM2ySOfvYyIjnqSO80NGBaz5DvzIG88J0+BNhOu2jl6Dfcq
# jYQs1H/PMSQIK6E7lXDXSpXzAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUnMc7Zn/ukKBsBiWkwdNfsN5pdwAw
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzUwMDUxNjAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAD21v9pHoLdBSNlFAjmk
# mx4XxOZAPsVxxXbDyQv1+kGDe9XpgBnT1lXnx7JDpFMKBwAyIwdInmvhK9pGBa31
# TyeL3p7R2s0L8SABPPRJHAEk4NHpBXxHjm4TKjezAbSqqbgsy10Y7KApy+9UrKa2
# kGmsuASsk95PVm5vem7OmTs42vm0BJUU+JPQLg8Y/sdj3TtSfLYYZAaJwTAIgi7d
# hzn5hatLo7Dhz+4T+MrFd+6LUa2U3zr97QwzDthx+RP9/RZnur4inzSQsG5DCVIM
# pA1l2NWEA3KAca0tI2l6hQNYsaKL1kefdfHCrPxEry8onJjyGGv9YKoLv6AOO7Oh
# JEmbQlz/xksYG2N/JSOJ+QqYpGTEuYFYVWain7He6jgb41JbpOGKDdE/b+V2q/gX
# UgFe2gdwTpCDsvh8SMRoq1/BNXcr7iTAU38Vgr83iVtPYmFhZOVM0ULp/kKTVoir
# IpP2KCxT4OekOctt8grYnhJ16QMjmMv5o53hjNFXOxigkQWYzUO+6w50g0FAeFa8
# 5ugCCB6lXEk21FFB1FdIHpjSQf+LP/W2OV/HfhC3uTPgKbRtXo83TZYEudooyZ/A
# Vu08sibZ3MkGOJORLERNwKm2G7oqdOv4Qj8Z0JrGgMzj46NFKAxkLSpE5oHQYP1H
# tPx1lPfD7iNSbJsP6LiUHXH1MIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGZ8wghmbAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAANOtTx6wYRv6ysAAAAAA04wDQYJYIZIAWUDBAIB
# BQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIJJsvplxftnrq9nvdeSlJYhb
# HRXxnRM/s8DTNqS7vCMlMEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEB
# BQAEggEAUetnJumAqMGHBjQ79yGa7KI6HoI2XxgdI0FqAgtc4rMGH6OvTkq+FziX
# M3Wq3pkZEdVqaXn4M2ArZExK3d1Nm5rzWyS2ZsQRWq32LVkVYKYkjQzwKGjjhlu+
# pRGshaWnAgpgC/NArmc0iTYOrs8ZFtVOCGo+1/a0T7szqP1dJt1ysmmzSDAizfT4
# kL8H4O7GHrURK4/R0JCgLAECFw6gFYE0bh+ptXseInP2BnIsL9TwzokfH1moShtP
# KBz7tq4YZC5/Iuurw9x1pIux0MBIZ0Ca5uPs9YHrN8utxg7IFdBgSyfjS4E2z8WN
# YlKltBr5z0L2m5downU338NNHnLdbaGCFykwghclBgorBgEEAYI3AwMBMYIXFTCC
# FxEGCSqGSIb3DQEHAqCCFwIwghb+AgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFZBgsq
# hkiG9w0BCRABBKCCAUgEggFEMIIBQAIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFl
# AwQCAQUABCAdrM59S6YuuAB+f46mZkuILAz/EmPFMATORqHlwG+pGQIGZGzxP/4W
# GBMyMDIzMDYxNDE1NTkxNy41MzRaMASAAgH0oIHYpIHVMIHSMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJl
# bGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNO
# OjA4NDItNEJFNi1DMjlBMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNloIIReDCCBycwggUPoAMCAQICEzMAAAGybkADf26plJIAAQAAAbIwDQYJ
# KoZIhvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjIw
# OTIwMjAyMjAxWhcNMjMxMjE0MjAyMjAxWjCB0jELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IElyZWxhbmQgT3Bl
# cmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjowODQyLTRC
# RTYtQzI5QTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZTCC
# AiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAMqiZTIde/lQ4rC+Bml5f/Wu
# q/xKTxrfbG23HofmQ+qZAN4GyO73PF3y9OAfpt7Qf2jcldWOGUB+HzBuwllYyP3f
# x4MY8zvuAuB37FvoytnNC2DKnVrVlHOVcGUL9CnmhDNMA2/nskjIf2IoiG9J0qLY
# r8duvHdQJ9Li2Pq9guySb9mvUL60ogslCO9gkh6FiEDwMrwUr8Wja6jFpUTny8tg
# 0N0cnCN2w4fKkp5qZcbUYFYicLSb/6A7pHCtX6xnjqwhmJoib3vkKJyVxbuFLRhV
# XxH95b0LHeNhifn3jvo2j+/4QV10jEpXVW+iC9BsTtR69xvTjU51ZgP7BR4YDEWq
# 7JsylSOv5B5THTDXRf184URzFhTyb8OZQKY7mqMh7c8J8w1sEM4XDUF2UZNy829N
# VCzG2tfdEXZaHxF8RmxpQYBxyhZwY1rotuIS+gfN2eq+hkAT3ipGn8/KmDwDtzAb
# nfuXjApgeZqwgcYJ8pDJ+y/xU6ouzJz1Bve5TTihkiA7wQsQe6R60Zk9dPdNzw0M
# K5niRzuQZAt4GI96FhjhlUWcUZOCkv/JXM/OGu/rgSplYwdmPLzzfDtXyuy/GCU5
# I4l08g6iifXypMgoYkkceOAAz4vx1x0BOnZWfI3fSwqNUvoN7ncTT+MB4Vpvf1QB
# ppjBAQUuvui6eCG0MCVNAgMBAAGjggFJMIIBRTAdBgNVHQ4EFgQUmfIngFzZEZlP
# kjDOVluBSDDaanEwHwYDVR0jBBgwFoAUn6cVXQBeYl2D9OXSZacbUzUZ6XIwXwYD
# VR0fBFgwVjBUoFKgUIZOaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9j
# cmwvTWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3JsMGwG
# CCsGAQUFBwEBBGAwXjBcBggrBgEFBQcwAoZQaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNyb3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIw
# MjAxMCgxKS5jcnQwDAYDVR0TAQH/BAIwADAWBgNVHSUBAf8EDDAKBggrBgEFBQcD
# CDAOBgNVHQ8BAf8EBAMCB4AwDQYJKoZIhvcNAQELBQADggIBANxHtu3FzIabaDbW
# qswdKBlAhKXRCN+5CSMiv2TYa4i2QuWIm+99piwAhDhADfbqor1zyLi95Y6GQnvI
# WUgdeC7oL1ZtZye92zYK+EIfwYZmhS+CH4infAzUvscHZF3wlrJUfPUIDGVP0lCY
# Vse9mguvG0dqkY4ayQPEHOvJubgZZaOdg/N8dInd6fGeOc+0DoGzB+LieObJ2Q0A
# tEt3XN3iX8Cp6+dZTX8xwE/LvhRwPpb/+nKshO7TVuvenwdTwqB/LT6CNPaElwFe
# KxKrqRTPMbHeg+i+KnBLfwmhEXsMg2s1QX7JIxfvT96md0eiMjiMEO22LbOzmLMN
# d3LINowAnRBAJtX+3/e390B9sMGMHp+a1V+hgs62AopBl0p/00li30DN5wEQ5If3
# 5Zk7b/T6pEx6rJUDYCti7zCbikjKTanBnOc99zGMlej5X+fC/k5ExUCrOs3/VzGR
# CZt5LvVQSdWqq/QMzTEmim4sbzASK9imEkjNtZZyvC1CsUcD1voFktld4mKMjE+u
# DEV3IddD+DrRk94nVzNPSuZXewfVOnXHSeqG7xM3V7fl2aL4v1OhL2+JwO1Tx3B0
# irO1O9qbNdJk355bntd1RSVKgM22KFBHnoL7Js7pRhBiaKmVTQGoOb+j1Qa7q+ci
# xGo48Vh9k35BDsJS/DLoXFSPDl4mMIIHcTCCBVmgAwIBAgITMwAAABXF52ueAptJ
# mQAAAAAAFTANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNh
# dGUgQXV0aG9yaXR5IDIwMTAwHhcNMjEwOTMwMTgyMjI1WhcNMzAwOTMwMTgzMjI1
# WjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQD
# Ex1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCCAiIwDQYJKoZIhvcNAQEB
# BQADggIPADCCAgoCggIBAOThpkzntHIhC3miy9ckeb0O1YLT/e6cBwfSqWxOdcjK
# NVf2AX9sSuDivbk+F2Az/1xPx2b3lVNxWuJ+Slr+uDZnhUYjDLWNE893MsAQGOhg
# fWpSg0S3po5GawcU88V29YZQ3MFEyHFcUTE3oAo4bo3t1w/YJlN8OWECesSq/XJp
# rx2rrPY2vjUmZNqYO7oaezOtgFt+jBAcnVL+tuhiJdxqD89d9P6OU8/W7IVWTe/d
# vI2k45GPsjksUZzpcGkNyjYtcI4xyDUoveO0hyTD4MmPfrVUj9z6BVWYbWg7mka9
# 7aSueik3rMvrg0XnRm7KMtXAhjBcTyziYrLNueKNiOSWrAFKu75xqRdbZ2De+JKR
# Hh09/SDPc31BmkZ1zcRfNN0Sidb9pSB9fvzZnkXftnIv231fgLrbqn427DZM9itu
# qBJR6L8FA6PRc6ZNN3SUHDSCD/AQ8rdHGO2n6Jl8P0zbr17C89XYcz1DTsEzOUyO
# ArxCaC4Q6oRRRuLRvWoYWmEBc8pnol7XKHYC4jMYctenIPDC+hIK12NvDMk2ZItb
# oKaDIV1fMHSRlJTYuVD5C4lh8zYGNRiER9vcG9H9stQcxWv2XFJRXRLbJbqvUAV6
# bMURHXLvjflSxIUXk8A8FdsaN8cIFRg/eKtFtvUeh17aj54WcmnGrnu3tz5q4i6t
# AgMBAAGjggHdMIIB2TASBgkrBgEEAYI3FQEEBQIDAQABMCMGCSsGAQQBgjcVAgQW
# BBQqp1L+ZMSavoKRPEY1Kc8Q/y8E7jAdBgNVHQ4EFgQUn6cVXQBeYl2D9OXSZacb
# UzUZ6XIwXAYDVR0gBFUwUzBRBgwrBgEEAYI3TIN9AQEwQTA/BggrBgEFBQcCARYz
# aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9Eb2NzL1JlcG9zaXRvcnku
# aHRtMBMGA1UdJQQMMAoGCCsGAQUFBwMIMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIA
# QwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFNX2
# VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwu
# bWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEw
# LTA2LTIzLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93
# d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYt
# MjMuY3J0MA0GCSqGSIb3DQEBCwUAA4ICAQCdVX38Kq3hLB9nATEkW+Geckv8qW/q
# XBS2Pk5HZHixBpOXPTEztTnXwnE2P9pkbHzQdTltuw8x5MKP+2zRoZQYIu7pZmc6
# U03dmLq2HnjYNi6cqYJWAAOwBb6J6Gngugnue99qb74py27YP0h1AdkY3m2CDPVt
# I1TkeFN1JFe53Z/zjj3G82jfZfakVqr3lbYoVSfQJL1AoL8ZthISEV09J+BAljis
# 9/kpicO8F7BUhUKz/AyeixmJ5/ALaoHCgRlCGVJ1ijbCHcNhcy4sa3tuPywJeBTp
# kbKpW99Jo3QMvOyRgNI95ko+ZjtPu4b6MhrZlvSP9pEB9s7GdP32THJvEKt1MMU0
# sHrYUP4KWN1APMdUbZ1jdEgssU5HLcEUBHG/ZPkkvnNtyo4JvbMBV0lUZNlz138e
# W0QBjloZkWsNn6Qo3GcZKCS6OEuabvshVGtqRRFHqfG3rsjoiV5PndLQTHa1V1QJ
# sWkBRH58oWFsc/4Ku+xBZj1p/cvBQUl+fpO+y/g75LcVv7TOPqUxUYS8vwLBgqJ7
# Fx0ViY1w/ue10CgaiQuPNtq6TPmb/wrpNPgkNWcr4A245oyZ1uEi6vAnQj0llOZ0
# dFtq0Z4+7X6gMTN9vMvpe784cETRkPHIqzqKOghif9lwY1NNje6CbaUFEMFxBmoQ
# tB1VM1izoXBm8qGCAtQwggI9AgEBMIIBAKGB2KSB1TCB0jELMAkGA1UEBhMCVVMx
# EzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoT
# FU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IElyZWxh
# bmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjow
# ODQyLTRCRTYtQzI5QTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2Vy
# dmljZaIjCgEBMAcGBSsOAwIaAxUAjhJ+EeySRfn2KCNsjn9cF9AUSTqggYMwgYCk
# fjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQD
# Ex1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUFAAIF
# AOgzxSIwIhgPMjAyMzA2MTQxMjQ4MzRaGA8yMDIzMDYxNTEyNDgzNFowdDA6Bgor
# BgEEAYRZCgQBMSwwKjAKAgUA6DPFIgIBADAHAgEAAgIFBDAHAgEAAgI+RjAKAgUA
# 6DUWogIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAowCAIBAAID
# B6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBAAAL0VbMN4wo8kNPjOEk
# BCaPzeDRl03PzdddegZQ/E+ZsFg1evVjPTlfE5pY5apTrBwezhkwkyIQ/mKfa7j8
# 5OUhUoIdeuIvyqoKoktkvi49q11N8z1E4cR3hRztT91hPD7Q63Rs/IXHRgejWP8O
# Sv1RK1sV3OLGoofh3eHhOP+GMYIEDTCCBAkCAQEwgZMwfDELMAkGA1UEBhMCVVMx
# EzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoT
# FU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUt
# U3RhbXAgUENBIDIwMTACEzMAAAGybkADf26plJIAAQAAAbIwDQYJYIZIAWUDBAIB
# BQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0BCQQx
# IgQgMqnFBNPcJDYNNcsqm4I+fVV6tvR5rgrWjWqM0Q9czVIwgfoGCyqGSIb3DQEJ
# EAIvMYHqMIHnMIHkMIG9BCBTeM485+E+t4PEVieUoFKX7PVyLo/nzu+htJPCG04+
# NTCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAw
# DgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24x
# JjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAABsm5A
# A39uqZSSAAEAAAGyMCIEIB7KttD70C0Wyo/rkm3uLuHVImh+QjKIMxd/0AL+Cd+0
# MA0GCSqGSIb3DQEBCwUABIICAI1UxYb4O8UNxE/B/6cJxAgvF8+JG0ZlDr8xi0xv
# UO/JqU7E9AGyouU4V1ixRYprnC4bA3qISE7B8cp3ZzzkxokfSsiHy0wLxxy2dGb9
# 21kJ1KrpVUiL2SBMri5lJPT2gGGWZvGmmRAQIdVRFcYPQ883bB6HPuS9JG6hzKLg
# kRK2d9JvV+gBmmOQCiX9mfCmwCKbgT8vIKsE51wyuMAAXfU9APoOFEOLg5xCRi+b
# 4lu4NL7SuFTRgcDc+BgIkaIg5kJkgy9KcQCTKDfgYU3yuHp/kLYGtI8FKp9242eL
# mtTK+zFNUuklTybGhPzv5pIB18hc7/CaG4BgoDOChMwm+g6hW92+UeR0gMYUN9XD
# IQL1Ws4F1qf6gNLEBFO7/YoUIxSxLH3M4jA7Rs10/DhPJRGm34RYplCmOQh62s0j
# aW6itD3SamCA1PeJPtk9aVV8u17QS5R8s7pLbOMoe4eSb3LZY1zbVu6wzjadaXki
# IBPT/6DNKDANCcOJTwvTVaLg6WHKRF/x02lQCN5kA2FU4iAH78j9ZVZvlX/mDHzN
# zFbM7dtcXm2QvrJEQhLNYlGOnu9bOfhJJBLNxqIVWBS2xg/bNhZFc0uMQ2tby0Mi
# EMjBzey8gqSgS5KQXK/30CM83T7mucnteo88NrZ+b1SUx22LBQ49ax0Mr3mobHoa
# rRHI
# SIG # End signature block
