# ******************************************* RFL ***********************************************
# File: Utils_RflShared.ps1
# Version 1.0
# Date: 2023-04-15
# Description:  Utility Script to load common functions for RFL.
# last edit by: waltere 
# ***********************************************************************************************


##########################
## Set Variables        ##
##########################
$verDatePsm1 = "2023.04.15.0"
#$ComputerName = $Env:computername
#$UserOSVersion = [Environment]::OSVersion.Version

##########################
## Function Definitions ##
##########################

#region Logging functions
Function RflEnterFunc([String]$FunctionName){
	Write-Verbose "---> Enter $FunctionName"
}
Function RflEnterFuncDbg([String]$FunctionName){	# enter with callstack info
	$CallStack = Get-PSCallStack
	$CallerInfo = $CallStack[1]
	$2ndCallerInfo = $CallStack[$Index+1]
	$3rdCallerInfo = $CallStack[$Index+2]
#write-host "1-2-3: $CallerInfo $2ndCallerInfo $3ndCallerInfo"
	# LogMessage() is called from wrapper function like LogInfo() and EnterFunc(). In this case, we show caller of the wrapper function.
	If($CallerInfo.FunctionName -notlike "*LogException" -and ($CallerInfo.FunctionName -like "global:Log*" -or $CallerInfo.FunctionName -like "*EnterFunc*" -or $CallerInfo.FunctionName -like "*EndFunc" -or $CallerInfo.FunctionName -like "DoGetVersion")){
		$CallerInfo = $2ndCallerInfo # Set actual function name calling LogInfo/LogWarn/LogError
		If($CallerInfo.FunctionName -like "*LogException"){
			$CallerInfo = $3rdCallerInfo
		}
	}
	$FuncName = $CallerInfo.FunctionName.Replace("global:","")
	If($CallerInfo.FunctionName -like '<ScriptBlock>'){ #-eq
		 $FuncName = 'Main'
	}Else{
		$FuncName = $CallerInfo.FunctionName
	}
	RflEnterFunc ("$FuncName" + " (Caller - $($FuncName):$($CallerInfo.ScriptLineNumber))")
}
Function RflEndFunc([String]$FunctionName){
	Write-Verbose "<--- End $FunctionName"
}

Function WriteLine ([string]$line,[string]$ForegroundColor, [switch]$NoNewLine){
	# SYNOPSIS: writes the actual output - used by other Logging Functions
	if($Script:ScriptMode){
	  if($NoNewLine) {
		$Script:Trace += "$line"
	  }
	  else {
		$Script:Trace += "$line`r`n"
	  }
	  Set-Content -Path $script:LogPath -Value $Script:Trace
	}
	if($Script:HostMode){
	  $Params = @{
		NoNewLine    = $NoNewLine -eq $true
		ForegroundColor = if($ForegroundColor) {$ForegroundColor} else {"White"}
	  }
	  Write-Host $line @Params
	}
}

Function WriteInfo([string]$message,[switch]$WaitForResult,[string[]]$AdditionalStringArray,[string]$AdditionalMultilineString){
	# SYNOPSIS: handles informational logs
	if($WaitForResult){
	  WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)$message" -NoNewline
	}
	else{
	  WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)$message"
	}
	if($AdditionalStringArray){
	  foreach ($String in $AdditionalStringArray){
		WriteLine "          $("`t" * $script:LogLevel)`t$String"
	  }
	}
	if($AdditionalMultilineString){
	  foreach ($String in ($AdditionalMultilineString -split "`r`n" | Where-Object {$_ -ne ""})){
		WriteLine "          $("`t" * $script:LogLevel)`t$String"
	  }
	}
}

Function WriteResult([string]$message,[switch]$Pass,[switch]$Success){
	# SYNOPSIS: writes results - should be used after -WaitForResult in WriteInfo
	if($Pass){
	  WriteLine " - Pass" -ForegroundColor Cyan
	  if($message){
		WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)`t$message" -ForegroundColor Cyan
	  }
	}
	if($Success){
	  WriteLine " - Success" -ForegroundColor Green
	  if($message){
		WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)`t$message" -ForegroundColor Green
	  }
	}
}

Function WriteInfoHighlighted([string]$message,[string[]]$AdditionalStringArray,[string]$AdditionalMultilineString){
	# SYNOPSIS: write highlighted info
	WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)$message" -ForegroundColor Cyan
	if($AdditionalStringArray){
	  foreach ($String in $AdditionalStringArray){
		WriteLine "[$(Get-Date -Format hh:mm:ss)]     $("`t" * $script:LogLevel)`t$String" -ForegroundColor Cyan
	  }
	}
	if($AdditionalMultilineString){
	  foreach ($String in ($AdditionalMultilineString -split "`r`n" | Where-Object {$_ -ne ""})){
		WriteLine "[$(Get-Date -Format hh:mm:ss)]     $("`t" * $script:LogLevel)`t$String" -ForegroundColor Cyan
	  }
	}
}

Function WriteWarning([string]$message,[string[]]$AdditionalStringArray,[string]$AdditionalMultilineString){
	# SYNOPSIS: write warning logs
	WriteLine "[$(Get-Date -Format hh:mm:ss)] WARNING: $("`t" * $script:LogLevel)$message" -ForegroundColor Yellow
	if($AdditionalStringArray){
	  foreach ($String in $AdditionalStringArray){
		WriteLine "[$(Get-Date -Format hh:mm:ss)]     $("`t" * $script:LogLevel)`t$String" -ForegroundColor Yellow
	  }
	}
	if($AdditionalMultilineString){
	  foreach ($String in ($AdditionalMultilineString -split "`r`n" | Where-Object {$_ -ne ""})){
		WriteLine "[$(Get-Date -Format hh:mm:ss)]     $("`t" * $script:LogLevel)`t$String" -ForegroundColor Yellow
	  }
	}
}

Function WriteError([string]$message){
	# SYNOPSIS: logs errors
	WriteLine ""
	WriteLine "[$(Get-Date -Format hh:mm:ss)] ERROR:  $("`t`t" * $script:LogLevel)$message" -ForegroundColor Red
}

Function WriteErrorAndExit($message){
	# SYNOPSIS: logs errors and terminates script
	WriteLine "[$(Get-Date -Format hh:mm:ss)] ERROR:  $("`t" * $script:LogLevel)$message" -ForegroundColor Red
	Write-Host "Press any key to continue ..."
	$host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") | OUT-NULL
	$HOST.UI.RawUI.Flushinputbuffer()
	Throw "Terminating Error"
}

Function ExitWithCode ($Ecode) {
	# set ErrorLevel to be picked up by invoking CMD script
	if ( $UseExitCode ) {
		Write-Verbose "[Update] Return Code: $Ecode"
		#error.clear()	# clear script errors
		exit $Ecode
		}
}
#endregion Logging functions

#region RFL functions
function GetOSfromMSinfo32 ($SDPPath,$NodeName){
	# Return: $OSshortVer of SDP report
	RflEnterFunc ($MyInvocation.MyCommand.Name + "(NodeName: $NodeName)")
	### Validate user input of expanded SDP report and identify the number of msinfo32.txt files and the names of the computers $NodeNames (in Cluster Report)
	$msinfo32 = $SDPPath + $NodeName + '*msinfo*.txt' # Try .txt
	If (-NOT (Test-Path $msinfo32)) {
	    Write-Verbose "[GetOSfromMSinfo32]** $SDPPath without *msinfo32.txt"
	    $msinfo32 = $SDPPath + $NodeName + '*msinfo*.nfo' # Try .nfo
	}

	### Get OS version of SDP report from msinfo.txt
	If ("$msinfo32" -match ".txt"){
	    Write-Verbose "[GetOSfromMSinfo32]Node: $NodeName Using msinfo32.txt = $msinfo32 "
	    #Read-in content from Msinfo file
	    if ($msinfo32file = get-childitem $msinfo32) {
			Write-Debug "[GetOSfromMSinfo32]msinfo32file: $msinfo32file "
			$script:SDPdate = $msinfo32file.LastWriteTime
			Write-host "`n[GetOSfromMSinfo32]Node: $NodeName : SDP Date: $script:SDPdate"
			$msinfo32 = Get-Content $msinfo32 -TotalCount 13
			If ($msinfo32){
				$SdpOSbuild = 		$msinfo32[-7]
				$global:SdpOSname = 		$msinfo32[-8];$SdpOSname=$global:SdpOSname.Split(" ",3)[2]
				$global:SdpComputerName = 	$msinfo32[1].Split("")[-1]
				$Systemmodell = 	$msinfo32[-2] #.Split("")[1,2,3]
				$is_Virtual = 		$Systemmodell| Select-String -Pattern ".*Virtual.*" -ErrorAction SilentlyContinue; if ($is_Virtual) {$Virtualized="VM"} else {$Virtualized=""}
				$is_VMware = 		$Systemmodell| Select-String -Pattern ".*VMware.*" -ErrorAction SilentlyContinue; if ($is_VMware) {$Script:Virtualization="VMware"} else {$Script:Virtualization=""}
				$SystemArch = 		$msinfo32[-1] #.Split("")[-1,-2]
				$is_x64 = 			$SystemArch| Select-String -Pattern ".*x64.*" -ErrorAction SilentlyContinue; if ($is_x64) {$Architecture="x64"} else {$Architecture="x86"}
				#_#Write-Output " Node: $SdpComputerName|$SdpOSbuild|$SdpOSname|$Systemmodell|$SystemArch |-> $Virtualized|$Virtualization|$Architecture|"
				Write-Host " Node: $SdpComputerName|$SdpOSbuild|$SdpOSname|$Systemmodell|$SystemArch |-> $Virtualized|$Virtualization|$Architecture|"
			}else{$global:ErrorMsg += "No-Valid-MsI32_txt "}
		}
	}
	Else { # Get OS version of SDP report from msinfo.nfo / may not work for some localized OS
		Write-Verbose "Node: $NodeName Using msinfo32.nfo = $msinfo32 "
		if ($msinfo32file = get-childitem $msinfo32) {
			$script:SDPdate = $msinfo32file.LastWriteTime
			Write-Debug "`nNode: $NodeName : SDP Date: $script:SDPdate"
			[xml]$nfo = Get-Content $msinfo32file
			$summary = $nfo.MSInfo.Category.Data.value # German $nfo.MSInfo.Category.Data.Wert / Italian: Valore
			If ($summary.'#cdata-section') {
				$SdpOSbuild = 		$summary.'#cdata-section'[1]
				$global:SdpOSname = 		$summary.'#cdata-section'[0]
				$global:SdpComputerName = 	$summary.'#cdata-section'[4]
				$Systemmodell = 	$summary.'#cdata-section'[6]
				$is_Virtual = 		$Systemmodell| Select-String -Pattern ".*Virtual.*" -ErrorAction SilentlyContinue; if ($is_Virtual) {$Virtualized="VM"} else {$Virtualized=""}
				$is_VMware = 		$Systemmodell| Select-String -Pattern ".*VMware.*" -ErrorAction SilentlyContinue; if ($is_VMware) {$Script:Virtualization="VMware"} else {$Script:Virtualization=""}
				$SystemArch = 		$summary.'#cdata-section'[7]
				$is_x64 = 			$SystemArch| Select-String -Pattern ".*x64.*" -ErrorAction SilentlyContinue; if ($is_x64) {$Architecture="x64"} else {$Architecture="x86"}
				Write-Host " Node: $SdpOSbuild|$SdpOSname|$SdpComputerName|$Systemmodell|$SystemArch |-> $Virtualized|$Virtualization|$Architecture|"
			}else{
				$global:ErrorMsg += "No-Valid-MsI32_nfo"
				Write-Host -BackgroundColor Black -ForegroundColor Yellow -Object "WARNING: SDP with no valid MSinfo32.txt or English .nfo files"
			}
		}
	}
	if ($SdpOSname -match "Windows 1|Windows 7|Windows 8") {$isClient = $True}
	$global:ErrorMsg += "$Architecture $Virtualized $Virtualization "
	
	### match Build number in SDP report with OS short name
	if("$SdpOSbuild" -match "2600"){$OSshortVer_old="old-XP"}  		# Windows XP
	if("$SdpOSbuild" -match "3790"){$OSshortVer_old="old-2003"}  	# Windows 2003
	if("$SdpOSbuild" -match "6001"){$OSshortVer_old="old-2008-SP1"}	# Windows Vista/2008 SP1
	if("$SdpOSbuild" -match "6002|6003"){$OSshortVer="2008"}  		# Windows Vista/2008 SP2
	if("$SdpOSbuild" -match "7600"){$OSshortVer_old="old-2008R2-RTM"} # Windows 7/2008R2 RTM
	if("$SdpOSbuild" -match "7601"){$OSshortVer="2008R2"} 			# Windows 7/2008R2
	if("$SdpOSbuild" -match "9200"){$OSshortVer="2012"}  			# Windows 8
	if("$SdpOSbuild" -match "9600"){$OSshortVer="2012R2"} 			# Windows 8.1
	if("$SdpOSbuild" -match "10.0.10240"){$OSshortVer="2016"} 		# Windows 10
	if("$SdpOSbuild" -match "10.0.14393"){$OSshortVer="2016RS1"} 	# Windows 10 RS1
	if("$SdpOSbuild" -match "10.0.17763"){$OSshortVer="2016RS5"} 	# Windows 10 RS5
	if("$SdpOSbuild" -match "10.0.18363"){$OSshortVer="201619H2"}	# Windows 10 19H2
	if("$SdpOSbuild" -match "10.0.19041"){$OSshortVer="20162004"} 	# Windows 10 2004 2020 April 2020 Update
	if("$SdpOSbuild" -match "10.0.19042"){$OSshortVer="201620H2"} 	# Windows 10 20H2 October 2020 Update
	if("$SdpOSbuild" -match "10.0.19043"){$OSshortVer="201621H1"} 	# Windows 10 21H1 April 2021 Update
	if("$SdpOSbuild" -match "10.0.19044"){$OSshortVer="201621H2"} 	# Windows 10 21H2 Oct 2021 Update
	if("$SdpOSbuild" -match "10.0.19045"){$OSshortVer="201622H2"} 	# Windows 10 22H2 Oct 2022 Update
	if("$SdpOSbuild" -match "10.0.20348"){$OSshortVer="2022"} 		# Windows Srv 2022
	if("$SdpOSbuild" -match "10.0.20349"){$OSshortVer="2022"} 		# Windows Srv 2022AZ HCI
	if("$SdpOSbuild" -match "10.0.22000"){$OSshortVer="Win11"} 		# Windows 11
	if("$SdpOSbuild" -match "10.0.22621"){$OSshortVer="Win1122H2"}	# Windows 11 22H2 Oct 2022 Update
	if("$SdpOSbuild" -match "10.0.22622"){$OSshortVer="Win1123H1"}	# Windows 11 insider
	Write-Host " OS build: $SdpOSbuild -|OS: $OSshortVer $OSshortVer_old"
	Write-Host " SDP Date:         $($script:SDPdate) / OS-Version: $($OSshortVer) $($OSshortVer_old)" #Write-Verbose
	Write-Host " SDP ComputerName: $SdpComputerName |Build: $SdpOSbuild |OS: $SdpOSname"
	
	$OSshortVer	# return
	RflEndFunc ($MyInvocation.MyCommand.Name + "(OS build: $SdpOSbuild - $OSVersion $OSVersion_old)")
}

#endregion RFL functions

# only for module .psm1
#Export-ModuleMember -Function * -Cmdlet * -Variable * -Alias *


# SIG # Begin signature block
# MIInwQYJKoZIhvcNAQcCoIInsjCCJ64CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDdWk6ovqDVMCdS
# FNAJKT68SeU+O5SBNwnYJggIu+O4E6CCDXYwggX0MIID3KADAgECAhMzAAACy7d1
# OfsCcUI2AAAAAALLMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjIwNTEyMjA0NTU5WhcNMjMwNTExMjA0NTU5WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC3sN0WcdGpGXPZIb5iNfFB0xZ8rnJvYnxD6Uf2BHXglpbTEfoe+mO//oLWkRxA
# wppditsSVOD0oglKbtnh9Wp2DARLcxbGaW4YanOWSB1LyLRpHnnQ5POlh2U5trg4
# 3gQjvlNZlQB3lL+zrPtbNvMA7E0Wkmo+Z6YFnsf7aek+KGzaGboAeFO4uKZjQXY5
# RmMzE70Bwaz7hvA05jDURdRKH0i/1yK96TDuP7JyRFLOvA3UXNWz00R9w7ppMDcN
# lXtrmbPigv3xE9FfpfmJRtiOZQKd73K72Wujmj6/Su3+DBTpOq7NgdntW2lJfX3X
# a6oe4F9Pk9xRhkwHsk7Ju9E/AgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUrg/nt/gj+BBLd1jZWYhok7v5/w4w
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzQ3MDUyODAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAJL5t6pVjIRlQ8j4dAFJ
# ZnMke3rRHeQDOPFxswM47HRvgQa2E1jea2aYiMk1WmdqWnYw1bal4IzRlSVf4czf
# zx2vjOIOiaGllW2ByHkfKApngOzJmAQ8F15xSHPRvNMmvpC3PFLvKMf3y5SyPJxh
# 922TTq0q5epJv1SgZDWlUlHL/Ex1nX8kzBRhHvc6D6F5la+oAO4A3o/ZC05OOgm4
# EJxZP9MqUi5iid2dw4Jg/HvtDpCcLj1GLIhCDaebKegajCJlMhhxnDXrGFLJfX8j
# 7k7LUvrZDsQniJZ3D66K+3SZTLhvwK7dMGVFuUUJUfDifrlCTjKG9mxsPDllfyck
# 4zGnRZv8Jw9RgE1zAghnU14L0vVUNOzi/4bE7wIsiRyIcCcVoXRneBA3n/frLXvd
# jDsbb2lpGu78+s1zbO5N0bhHWq4j5WMutrspBxEhqG2PSBjC5Ypi+jhtfu3+x76N
# mBvsyKuxx9+Hm/ALnlzKxr4KyMR3/z4IRMzA1QyppNk65Ui+jB14g+w4vole33M1
# pVqVckrmSebUkmjnCshCiH12IFgHZF7gRwE4YZrJ7QjxZeoZqHaKsQLRMp653beB
# fHfeva9zJPhBSdVcCW7x9q0c2HVPLJHX9YCUU714I+qtLpDGrdbZxD9mikPqL/To
# /1lDZ0ch8FtePhME7houuoPcMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGaEwghmdAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAALLt3U5+wJxQjYAAAAAAsswDQYJYIZIAWUDBAIB
# BQCggbAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIBqDs44ieRbTCAMvNuXPpkwk
# nEfsrzXvd1BOkY2ChhXNMEQGCisGAQQBgjcCAQwxNjA0oBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEcgBpodHRwczovL3d3dy5taWNyb3NvZnQuY29tIDANBgkqhkiG9w0B
# AQEFAASCAQBKGewiV6x+uMyHKtAXJj28ms4MXze+9mIJ5z/5AhWt2ntqKlE8Z29q
# HMVHT6Xf1FhdGVyeMw+flejtcIlNwm72u7rGhRkSy6JMd5OImBSvtUE4cSFqLknf
# yF/aVW34SJusXkrD8iKYfQRE8gVsuRHS1xKgvXCQNiiNygK7T8KVYTfesVVAoZsg
# kI86xUzgoxCufEJGxN0J/nl4GteoZ0LmVI2emi4YjkeSfW+cjCzR0JBEaBjfozdc
# +xbI1ZA7x2OPFqfMYYu5FoAh5B3XIEejOonNz3xAXTYDw52oS+8ugJY/MFI3Zu4a
# 501sP+INvyDOkqzlv8QtE6HIp6i7P7ppoYIXKTCCFyUGCisGAQQBgjcDAwExghcV
# MIIXEQYJKoZIhvcNAQcCoIIXAjCCFv4CAQMxDzANBglghkgBZQMEAgEFADCCAVkG
# CyqGSIb3DQEJEAEEoIIBSASCAUQwggFAAgEBBgorBgEEAYRZCgMBMDEwDQYJYIZI
# AWUDBAIBBQAEIBYrIsAe8JOMwpENk4sA8a51LjYNCKIwCnhYU/MRrBTiAgZkGwoN
# 6E0YEzIwMjMwNDE3MDY0NTE4LjgwOFowBIACAfSggdikgdUwgdIxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJ
# cmVsYW5kIE9wZXJhdGlvbnMgTGltaXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBF
# U046M0JENC00QjgwLTY5QzMxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1w
# IFNlcnZpY2WgghF4MIIHJzCCBQ+gAwIBAgITMwAAAbT7gAhEBdIt+gABAAABtDAN
# BgkqhkiG9w0BAQsFADB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3Rv
# bjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0
# aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0y
# MjA5MjAyMDIyMDlaFw0yMzEyMTQyMDIyMDlaMIHSMQswCQYDVQQGEwJVUzETMBEG
# A1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWlj
# cm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJlbGFuZCBP
# cGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjNCRDQt
# NEI4MC02OUMzMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNl
# MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAtEemnmUHMkIfvOiu27K8
# 6ZbwWhksGwV72Dl1uGdqr2pKm+mfzoT+Yngkq9aLEf+XDtADyA+2KIZU0iO8WG79
# eJjzz29flZpBKbKg8xl2P3O9drleuQw3TnNfNN4+QIgjMXpE3txPF7M7IRLKZMiO
# t3FfkFWVmiXJAA7E3OIwJgphg09th3Tvzp8MT8+HOtG3bdrRd/y2u8VrQsQTLZiV
# wTZ6qDYKNT8PQZl7xFrSSO3QzXa91LipZnYOl3siGJDCee1Ba7X1i13dQFHxKl5F
# f4JzDduOBZ85e2VrpyFy1a3ayGUzBrIw59jhMbjIw9YVcQt9kUWntyCmNk15WybC
# S+hXpEDDLVj1X5W9snmoW1qu03+unprQjWQaVuO7BfcvQdNVdyKSqAeKy1eT2Hcc
# 5n1aAVeXFm6sbVJmZzPQEQR3Jr7W8YcTjkqC5hT2qrYuIcYGOf3Pj4OqdXm1Qqhu
# wtskxviv7yy3Z+PxJpxKx+2e6zGRaoQmIlLfg/a42XNVHTf6Wzr5k7Q1w7v0uA/s
# FsgyKmI7HzKHX08xDDSmJooXA5btD6B0lx/Lqs6Qb4KthnA7N2IEdJ5sjMIhyHZw
# Br7fzDskU/+Sgp2UnfqrN1Vda/gb+pmlbJwi8MphvElYzjT7PZK2Dm4eorcjx7T2
# QVe3EIelLuGbxzybblZoRTkCAwEAAaOCAUkwggFFMB0GA1UdDgQWBBTLRIXl8ZS4
# Opy7Eii3Tt44zDLZfjAfBgNVHSMEGDAWgBSfpxVdAF5iXYP05dJlpxtTNRnpcjBf
# BgNVHR8EWDBWMFSgUqBQhk5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3Bz
# L2NybC9NaWNyb3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIwMjAxMCgxKS5jcmww
# bAYIKwYBBQUHAQEEYDBeMFwGCCsGAQUFBzAChlBodHRwOi8vd3d3Lm1pY3Jvc29m
# dC5jb20vcGtpb3BzL2NlcnRzL01pY3Jvc29mdCUyMFRpbWUtU3RhbXAlMjBQQ0El
# MjAyMDEwKDEpLmNydDAMBgNVHRMBAf8EAjAAMBYGA1UdJQEB/wQMMAoGCCsGAQUF
# BwMIMA4GA1UdDwEB/wQEAwIHgDANBgkqhkiG9w0BAQsFAAOCAgEAEtEPBYwpt4Ji
# oSq0joGzwqYX6SoNH7YbqpgArdlnrdt6u3ukKREluKEVqS2XajXxx0UkXGc4Xi9d
# p2bSxpuyQnTkq+IQwkg7p1dKrwAa2vdmaNzz3mrSaeUEu40yCThHwquQkweoG4eq
# RRZe19OtVSmDDNC3ZQ6Ig0qz79vivXgy5dFWk4npxA5LxSGR4wBaXaIuVhoEa06v
# d/9/2YsQ99bCiR7SxJRt1XrQ5kJGHUi0Fhgz158qvXgfmq7qNqfqfTSmsQRrtbe4
# Zv/X+qPo/l6ae+SrLkcjRfr0ONV0vFVuNKx6Cb90D5LgNpc9x8V/qIHEr+JXbWXW
# 6mARVVqNQCmXlVHjTBjhcXwSmadR1OotcN/sKp2EOM9JPYr86O9Y/JAZC9zug9ql
# jKTroZTfYA7LIdcmPr69u1FSD/6ivL6HRHZd/k2EL7FtZwzNcRRdFF/VgpkOxHIf
# qvjXambwoMoT+vtGTtqgoruhhSk0bM1F/pBpi/nPZtVNLGTNaK8Wt6kscbC9G6f0
# 9gz/wBBJOBmvTLPOOT/3taCGSoJoDABWnK+De5pie4KX8BxxKQbJvxz7vRsVJ5R6
# mGx+Bvav5AjsxvZZw6eQmkI0vPRckxL9TCVCfWS0uyIKmyo6TdosnbBO/osre7r0
# jS9AH8spEqVlhFcpQNfOg/CvdS2xNVMwggdxMIIFWaADAgECAhMzAAAAFcXna54C
# m0mZAAAAAAAVMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZp
# Y2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0yMTA5MzAxODIyMjVaFw0zMDA5MzAxODMy
# MjVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIICIjANBgkqhkiG9w0B
# AQEFAAOCAg8AMIICCgKCAgEA5OGmTOe0ciELeaLL1yR5vQ7VgtP97pwHB9KpbE51
# yMo1V/YBf2xK4OK9uT4XYDP/XE/HZveVU3Fa4n5KWv64NmeFRiMMtY0Tz3cywBAY
# 6GB9alKDRLemjkZrBxTzxXb1hlDcwUTIcVxRMTegCjhuje3XD9gmU3w5YQJ6xKr9
# cmmvHaus9ja+NSZk2pg7uhp7M62AW36MEBydUv626GIl3GoPz130/o5Tz9bshVZN
# 7928jaTjkY+yOSxRnOlwaQ3KNi1wjjHINSi947SHJMPgyY9+tVSP3PoFVZhtaDua
# Rr3tpK56KTesy+uDRedGbsoy1cCGMFxPLOJiss254o2I5JasAUq7vnGpF1tnYN74
# kpEeHT39IM9zfUGaRnXNxF803RKJ1v2lIH1+/NmeRd+2ci/bfV+AutuqfjbsNkz2
# K26oElHovwUDo9Fzpk03dJQcNIIP8BDyt0cY7afomXw/TNuvXsLz1dhzPUNOwTM5
# TI4CvEJoLhDqhFFG4tG9ahhaYQFzymeiXtcodgLiMxhy16cg8ML6EgrXY28MyTZk
# i1ugpoMhXV8wdJGUlNi5UPkLiWHzNgY1GIRH29wb0f2y1BzFa/ZcUlFdEtsluq9Q
# BXpsxREdcu+N+VLEhReTwDwV2xo3xwgVGD94q0W29R6HXtqPnhZyacaue7e3Pmri
# Lq0CAwEAAaOCAd0wggHZMBIGCSsGAQQBgjcVAQQFAgMBAAEwIwYJKwYBBAGCNxUC
# BBYEFCqnUv5kxJq+gpE8RjUpzxD/LwTuMB0GA1UdDgQWBBSfpxVdAF5iXYP05dJl
# pxtTNRnpcjBcBgNVHSAEVTBTMFEGDCsGAQQBgjdMg30BATBBMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL0RvY3MvUmVwb3NpdG9y
# eS5odG0wEwYDVR0lBAwwCgYIKwYBBQUHAwgwGQYJKwYBBAGCNxQCBAweCgBTAHUA
# YgBDAEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB/wQFMAMBAf8wHwYDVR0jBBgwFoAU
# 1fZWy4/oolxiaNE9lJBb186aGMQwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2Ny
# bC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljUm9vQ2VyQXV0XzIw
# MTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXRfMjAxMC0w
# Ni0yMy5jcnQwDQYJKoZIhvcNAQELBQADggIBAJ1VffwqreEsH2cBMSRb4Z5yS/yp
# b+pcFLY+TkdkeLEGk5c9MTO1OdfCcTY/2mRsfNB1OW27DzHkwo/7bNGhlBgi7ulm
# ZzpTTd2YurYeeNg2LpypglYAA7AFvonoaeC6Ce5732pvvinLbtg/SHUB2RjebYIM
# 9W0jVOR4U3UkV7ndn/OOPcbzaN9l9qRWqveVtihVJ9AkvUCgvxm2EhIRXT0n4ECW
# OKz3+SmJw7wXsFSFQrP8DJ6LGYnn8AtqgcKBGUIZUnWKNsIdw2FzLixre24/LAl4
# FOmRsqlb30mjdAy87JGA0j3mSj5mO0+7hvoyGtmW9I/2kQH2zsZ0/fZMcm8Qq3Uw
# xTSwethQ/gpY3UA8x1RtnWN0SCyxTkctwRQEcb9k+SS+c23Kjgm9swFXSVRk2XPX
# fx5bRAGOWhmRaw2fpCjcZxkoJLo4S5pu+yFUa2pFEUep8beuyOiJXk+d0tBMdrVX
# VAmxaQFEfnyhYWxz/gq77EFmPWn9y8FBSX5+k77L+DvktxW/tM4+pTFRhLy/AsGC
# onsXHRWJjXD+57XQKBqJC4822rpM+Zv/Cuk0+CQ1ZyvgDbjmjJnW4SLq8CdCPSWU
# 5nR0W2rRnj7tfqAxM328y+l7vzhwRNGQ8cirOoo6CGJ/2XBjU02N7oJtpQUQwXEG
# ahC0HVUzWLOhcGbyoYIC1DCCAj0CAQEwggEAoYHYpIHVMIHSMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJl
# bGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNO
# OjNCRDQtNEI4MC02OUMzMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQBlnNiQ85uX9nN4KRJt/gHkJx4JCKCBgzCB
# gKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0GCSqGSIb3DQEBBQUA
# AgUA5+ckrzAiGA8yMDIzMDQxNzA5NTE0M1oYDzIwMjMwNDE4MDk1MTQzWjB0MDoG
# CisGAQQBhFkKBAExLDAqMAoCBQDn5ySvAgEAMAcCAQACAhjXMAcCAQACAhFbMAoC
# BQDn6HYvAgEAMDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEA
# AgMHoSChCjAIAgEAAgMBhqAwDQYJKoZIhvcNAQEFBQADgYEAEQ1JWBlpHJK2GV0n
# sNVlJ3CNkOZnnKhghZHfe8q9TVmCdHbwuZAT31STV9YU0SRFW6BRoqhmI/WnNkG7
# bUaOqhJowP8acf0wu9aYrb/uviqtlAjjBY+4OZrxfCE6PMLVOwv1xLJQGI80P3PF
# y8Pi0tUH/nem/rXZ+nAuqg3UaXUxggQNMIIECQIBATCBkzB8MQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGlt
# ZS1TdGFtcCBQQ0EgMjAxMAITMwAAAbT7gAhEBdIt+gABAAABtDANBglghkgBZQME
# AgEFAKCCAUowGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJ
# BDEiBCA5hJss8xR69IOhxgiSh1195ai2X9RnDEg13SXFurSNWjCB+gYLKoZIhvcN
# AQkQAi8xgeowgecwgeQwgb0EINPI93vmozBwBlFxvfr/rElreFPR4ux7vXKx2ni3
# AfcGMIGYMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAG0
# +4AIRAXSLfoAAQAAAbQwIgQgpG3xIZh6r6YmlfSKCOQyuU35ri5KCFYrU2GMbxTl
# JnYwDQYJKoZIhvcNAQELBQAEggIAGPCZT5LVgyo7NeoAIbdZzGXlqIafVt+NL5e5
# q6EqDVqfAL//fopbzzxPgXwQtmuZ/rdDZA83qOIvqG0hKU8NDPf5Gy4MQDhato+E
# UEagE6P1pe0rGo53S/hBX+Zpril38uWn/v3hpSWv8CGm0K2E4XMiEb+kJ+2V44+U
# 3pdvsm8BE7CABZSswcNebciifwND7Cv1rHIkhp8rCRulcUdkeP4LxIgmaI0IosYF
# wKDwHwNdozul0x1vCdxbXa5P9cdwkiVMM5qQVLqRAKqGn1gwVVA1ZFmFh/AkoBhl
# akctVBw8MPKpyzOpItwrmjG1VY64i8DKyCMCgy8Bl/fE9e0Ll8pIs+hE0+0v1ISt
# w1t7b2LbyIcB9n7U8I62RC+jJA5KMvqpLfQ4NFROQobDQfW/Ixuyhqj1jeWZBIfA
# J28W6QaPoTJZn3JM65YQ4U/w5pj0yKdwvuNhBuewTEiDP2n19ew1QgffXwwvDgJB
# Z3Sxsyk2t/Au6uomML7ZRX+LGqdqmNEg8OI11qmpR7TpZTodTk9FX30GmtQ4A7s3
# Em8ANGhFU6sNIXYaVtZnmVxgeGoHm/mhC17pQcrUPzGNT/tr06FxAA2em4/KXsOE
# 0WtjAa3tF8sILD85u9P2rCzSD2r15o3z038knu7PHeu6vxj0iqC7tAX9SGJImJr6
# XSb3FAk=
# SIG # End signature block
