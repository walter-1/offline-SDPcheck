# Name: get-RFL-alias.ps1
<# Script to establish alias names for all RFL helper scripts
Help: get-help \\emeacssdfs\netpod\rfl\get-RFL-alias.ps1 -detailed
last edit by: waltere 2022-10-13
File Name: get-RFL-alias.ps1

VERSION and AUTHORs:
    Ver 1.00 - 15.10.2016
	Walter Eder	- waltere@microsoft.com ; Vincent Douhet <vidou@microsoft.com>

### set and show alias names for all RFL helper scripts, using PowerShell Alias in order to avoid remember the full UNC path

HISTORY
	2016-10-16 v1.00

#>

<#
.SYNOPSIS
File Name: get-RFL-alias.ps1
The script allows to set RFL script alias'es either using
 Method 1 - to set *RFL* alias names only for this PS session
or
 Method 2 - to import *RFL* alias names permanently into your PS Profile

.DESCRIPTION
This script helps to use the RFL scripts by alias, avoid remember the full UNC path.
You can use the command "get-command *RFL*" or "get-alias *RFL*" to check for defined alias.
Running the script will define the following list of alias:

Alias				PS Script
"RFL-check-RegistryKeyNames"	"\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\check-RegistryKeyNames.ps1"
"RFL-check-csv_Tech_Path"		"\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\check-rfl-csv_Tech_Path.ps1"
"RFL-check-csv_MultiTech_Path"	"\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\check-rfl-csv_MultiTech_Path.ps1"
"RFL-get-latest-binary-version"	"\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\get-latest-binary-version.ps1"
"RFL-get-MiniSDP"			"\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\get-MiniSDP.ps1"
"RFL-get-pma"			"\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\get-pma.ps1"
"RFL-get-events"			"\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\get-events.ps1"
"RFL-get-PStatSum"			"\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\get-PStatSum.ps1"
"RFL-get-update-RFLShellExt"	"\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\get-update-RFLShellExt.ps1"
"RFL-get-version-RFLShellExt"	"\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\get-version-RFLShellExt.ps1 -verbose"
"RFL-get-ShellExtension"		"\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\Rfl-Check_ShellExtension_FQDN_PMA.reg"
"RFL-get-alias"			"\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\get-RFL-alias.ps1"

.EXAMPLE
Usage:
Example 1, to set *RFL* alias names only for this PS session, use Method 1 enter Y, hit <RET> or N for Method 2
\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\get-RFL-alias.ps1

.LINK
email: waltere@microsoft.com
#>

$verDateScript = "2022.10.13.0"
$UsrOSVersion = [Environment]::OSVersion.Version.ToString(3)
$SdpComputerName = $env:computername
$CheckDate = (Get-Date).ToUniversalTime().ToString("yy-MM-dd_HH-mm-ss")
	$ScriptFolder = Split-Path $MyInvocation.MyCommand.Path -Parent
	$SDPcheckINI = (Get-content -Path "$ScriptFolder\_SDPcheck.ini")
	$InOfflineMode 	= (($SDPcheckINI[1] -split " ")[2]).trim("""")	# set $True for outsourcer or when not connected to MS network - offline-SDPcheck
	#$RFLroot = (($SDPcheckINI[2] -split " ")[2]).trim("""")	# "\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\" -or- "\\localhost\ToolsShare\rfl\"
	if ($InOfflineMode -match "False") {
		$StatsServer = (($SDPcheckINI[4] -split " ")[2]).trim("""")
		if (Test-Connection -ComputerName $StatsServer -Quiet -Count 1) {[bool]$Stats=$True} else {[bool]$Stats=$False}
	} else { 
		$Stats = $False
	}

if ($Stats) {
	$StatsServerPath="\\$StatsServer\RFLstats$\RFL\scripts\Stats\"
	$CountInvFil = $StatsServerPath +'count_RFLalias.dat'
	$CountInvFil2 = $CountInvFil +'.us'
	#increment at start of script
	 ($j=[int32](Get-Content $CountInvFil -TotalCount 1 -ErrorAction SilentlyContinue)) |out-null
	 (++$j) | Set-Content $CountInvFil -ErrorAction SilentlyContinue
}

$ScriptBeginTimeStamp = Get-Date

[string[]]$RFLsetAlias=@"
# RFL Alias File
# Exported by : waltere
# Date/Time : Sunday, October 16, 2016 00:15:00
set-alias RFL-get-latest-binary-version \\emeacssdfs\netpod\rfl\get-latest-binary-version.ps1 -Scope Global -Description 'RFL family script'
set-alias RFL-get-MiniSDP \\emeacssdfs\netpod\rfl\get-MiniSDP.ps1 -Scope Global -Description 'RFL family script'
set-alias RFL-get-pma \\emeacssdfs\netpod\rfl\get-pma.ps1 -Scope Global -Description 'RFL family script'
set-alias RFL-get-events \\emeacssdfs\netpod\rfl\get-events.ps1 -Scope Global -Description 'RFL family script'
set-alias RFL-check-RegistryKeyNames \\emeacssdfs\netpod\rfl\check-RegistryKeyNames.ps1 -Scope Global -Description 'RFL family script'
set-alias RFL-check-csv_Tech_Path \\emeacssdfs\netpod\rfl\check-rfl-csv_Tech_Path.ps1 -Scope Global -Description 'RFL family script'
set-alias RFL-check-csv_MultiTech_Path \\emeacssdfs\netpod\rfl\check-rfl-csv_MultiTech_Path.ps1 -Scope Global -Description 'RFL family script'
set-alias RFL-get-PStatSum \\emeacssdfs\netpod\rfl\get-PStatSum.ps1 -Scope Global -Description 'RFL family script'
set-alias RFL-get-update-RFLShellExt \\emeacssdfs\netpod\rfl\get-update-RFLShellExt.ps1 -Scope Global -Description 'RFL family script'
set-alias RFL-get-version-RFLShellExt \\emeacssdfs\netpod\rfl\get-version-RFLShellExt.ps1 -Scope Global -Description 'RFL family script'
set-alias RFL-get-ShellExtension \\emeacssdfs\netpod\rfl\Rfl-Check_ShellExtension_FQDN_PMA.reg -Scope Global -Description 'RFL family script'
set-alias RFL-get-alias \\emeacssdfs\netpod\rfl\get-RFL-alias.ps1 -Scope Global -Description 'RFL family script'
"@

Write-host "You can use
 Method 1 - to set *RFL* alias names only for this PS session
 Method 2 - to import *RFL* alias names permanently into your PS Profile"

Write-host "`n.. checking for already defined RFL aliases: get-command *RFL*"
$defined_RFL_aliases = get-command *RFL*
get-command *RFL*

###Method 0
#$UserInput = Read-Host 'Method 0: Do you want to set *RFL* alias names for this PS session [Y|N]'
#if ($UserInput0 -match 'n') {Write-Host " ...ending the Method 0 per User Input: $UserInput0 "; break}
#else {foreach ($line in $RFLsetAlias){& "$line"} }
#Write-host "`n.. running: get-command *RFL*"
#get-command *RFL*


###Method 1
if (-not $defined_RFL_aliases) {
 $SessionAlias = Read-Host 'Method 1: Do you want to import *RFL* alias names for this PS session [Y|N]'
 if (($SessionAlias -match 'n') -or ($SessionAlias -eq '')) {Write-Host " ...ending the Method 1 per User Input: '$SessionAlias' " }
 if ($SessionAlias -match 'y') {Import-Alias -Path \\emeacssdfs\netpod\rfl\alias-RFL.txt -Scope Global}
 get-alias rfl*
}
else {Write-Host " ...Method 1 skipped: already defined RFL aliases, see: get-command *RFL*"}

###Method 2
#ToDo: only do this step if no entry in profile$ exists
if (-not $defined_RFL_aliases) {
 $ProfileAlias = Read-Host 'Method 2: Do you want to import *RFL* alias names permanently into your PS Profile [Y|N]'
 if (($ProfileAlias -match 'n') -or ($ProfileAlias -eq '')) {Write-Host " ...ending the Method 2 per User Input: '$ProfileAlias' " }
 if ($ProfileAlias -match 'y') { Write-host "Method 2: `n.. running: Add-Content -Path $Profile -Value 'RFLsetAlias'"
			   Add-Content -Path $Profile -Value $RFLsetAlias }
 }
else {Write-Host " ...Method 2 skipped: already defined RFL aliases, see: get-command *RFL*"}

# Write-host "`n.. Export-Alias -Name RFL* -Path "$Env:Temp\alias.ps1" -As Script"
#Example 4: Export aliases as a script
# Export-Alias -Path "$Env:Temp\alias.ps1" -As Script
# Write-host "`n.. Add-Content -Path $Profile -Value (Get-Content $Env:Temp\alias.ps1)"
# Add-Content -Path $Profile -Value (Get-Content $Env:Temp\alias.ps1)
# $S = New-PSSession -ComputerName Server01
# Invoke-Command -Session $S -FilePath $Env:Temp\alias.ps1

Write-host "`n
 'get-alias rfl* ' or 'get-command rfl* ' shows all alias currently defined.
`n For detailed help on a specific script, type for example
 get-help \\emeacssdfs\netpod\rfl\get-latest-binary-version.ps1 -detailed"

$ScriptEndTimeStamp = Get-Date
$Duration = $(New-TimeSpan -Start $ScriptBeginTimeStamp -End $ScriptEndTimeStamp)
Write-Host -BackgroundColor Gray -ForegroundColor Black -Object "`n$(Get-Date -UFormat "%R") Done on this PC $($SdpComputerName); script version v$verDateScript took $($Duration)"

### Stats
If ($Stats){
 ([string]$j + " ;$CheckDate; $UsrOSVersion; " + [System.Security.Principal.WindowsIdentity]::GetCurrent().Name) + "; $($SdpComputerName)" + "; $($Duration)" + "; $ProfileAlias" | Out-File $CountInvFil2 -Append -Encoding UTF8 -ErrorAction SilentlyContinue
}



# SIG # Begin signature block
# MIInmAYJKoZIhvcNAQcCoIIniTCCJ4UCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDVHIXyiNoQndL/
# pREF5vuklkuzoC7r3YXcsnNzskp7MKCCDXYwggX0MIID3KADAgECAhMzAAACy7d1
# OfsCcUI2AAAAAALLMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjIwNTEyMjA0NTU5WhcNMjMwNTExMjA0NTU5WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC3sN0WcdGpGXPZIb5iNfFB0xZ8rnJvYnxD6Uf2BHXglpbTEfoe+mO//oLWkRxA
# wppditsSVOD0oglKbtnh9Wp2DARLcxbGaW4YanOWSB1LyLRpHnnQ5POlh2U5trg4
# 3gQjvlNZlQB3lL+zrPtbNvMA7E0Wkmo+Z6YFnsf7aek+KGzaGboAeFO4uKZjQXY5
# RmMzE70Bwaz7hvA05jDURdRKH0i/1yK96TDuP7JyRFLOvA3UXNWz00R9w7ppMDcN
# lXtrmbPigv3xE9FfpfmJRtiOZQKd73K72Wujmj6/Su3+DBTpOq7NgdntW2lJfX3X
# a6oe4F9Pk9xRhkwHsk7Ju9E/AgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUrg/nt/gj+BBLd1jZWYhok7v5/w4w
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzQ3MDUyODAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAJL5t6pVjIRlQ8j4dAFJ
# ZnMke3rRHeQDOPFxswM47HRvgQa2E1jea2aYiMk1WmdqWnYw1bal4IzRlSVf4czf
# zx2vjOIOiaGllW2ByHkfKApngOzJmAQ8F15xSHPRvNMmvpC3PFLvKMf3y5SyPJxh
# 922TTq0q5epJv1SgZDWlUlHL/Ex1nX8kzBRhHvc6D6F5la+oAO4A3o/ZC05OOgm4
# EJxZP9MqUi5iid2dw4Jg/HvtDpCcLj1GLIhCDaebKegajCJlMhhxnDXrGFLJfX8j
# 7k7LUvrZDsQniJZ3D66K+3SZTLhvwK7dMGVFuUUJUfDifrlCTjKG9mxsPDllfyck
# 4zGnRZv8Jw9RgE1zAghnU14L0vVUNOzi/4bE7wIsiRyIcCcVoXRneBA3n/frLXvd
# jDsbb2lpGu78+s1zbO5N0bhHWq4j5WMutrspBxEhqG2PSBjC5Ypi+jhtfu3+x76N
# mBvsyKuxx9+Hm/ALnlzKxr4KyMR3/z4IRMzA1QyppNk65Ui+jB14g+w4vole33M1
# pVqVckrmSebUkmjnCshCiH12IFgHZF7gRwE4YZrJ7QjxZeoZqHaKsQLRMp653beB
# fHfeva9zJPhBSdVcCW7x9q0c2HVPLJHX9YCUU714I+qtLpDGrdbZxD9mikPqL/To
# /1lDZ0ch8FtePhME7houuoPcMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGXgwghl0AgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAALLt3U5+wJxQjYAAAAAAsswDQYJYIZIAWUDBAIB
# BQCggbAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIHVtpxpWiQd9sjyQ/irgAq/X
# aQmYqjUKTKUR5aWoI95KMEQGCisGAQQBgjcCAQwxNjA0oBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEcgBpodHRwczovL3d3dy5taWNyb3NvZnQuY29tIDANBgkqhkiG9w0B
# AQEFAASCAQA21IMjFsIyMZALkRupmQxk2Cjri5ef2KdZT1fma1YZa8l1CApR50PR
# qOlTKm/qQT1MN3IOVilwsZcp6E1fMcF+mqq0WkQ/EqFo6cQzfMDWiJBngQSrsETc
# /915qBUp2zy4oVQSRBkuiKmdLYpv/lVXMc2zsU6N4ma0eSFPIhnMw9G0xXuCGGB0
# Pbz4p8Q7DWLR1wqNmcbrMpm1dIB2BVYNdOblxV+YhJtO78NEdjvyDep336pUrlLo
# REwt6z5Oh/P3Q8JmUoHlyB1Ci0NdkoIaOALk3hARwPreEPyMOmMBlcouXWpyRFfw
# kg3vZ596KlWoImLicOwwrxVN5CLU59UtoYIXADCCFvwGCisGAQQBgjcDAwExghbs
# MIIW6AYJKoZIhvcNAQcCoIIW2TCCFtUCAQMxDzANBglghkgBZQMEAgEFADCCAVEG
# CyqGSIb3DQEJEAEEoIIBQASCATwwggE4AgEBBgorBgEEAYRZCgMBMDEwDQYJYIZI
# AWUDBAIBBQAEIJNkPBCcMSAgnzv4aFFUimi1mT5oHkCLLgNb/hsEdSJVAgZjmwb1
# J/EYEzIwMjMwMTAyMTcxNTUxLjk4M1owBIACAfSggdCkgc0wgcoxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBB
# bWVyaWNhIE9wZXJhdGlvbnMxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjhBODIt
# RTM0Ri05RERBMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNl
# oIIRVzCCBwwwggT0oAMCAQICEzMAAAHC+n2HDlRTRyQAAQAAAcIwDQYJKoZIhvcN
# AQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQG
# A1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjIxMTA0MTkw
# MTI4WhcNMjQwMjAyMTkwMTI4WjCByjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldh
# c2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBD
# b3Jwb3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0aW9u
# czEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046OEE4Mi1FMzRGLTlEREExJTAjBgNV
# BAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQC18Qm88o5IWfel62n3Byjb39SgmYMPIemaalGu5FVY
# EXfsHLSe+uzNJw5X8r4u8dZZYLhL1yZ7g/rcSY2HFM3+TYKA+ci3+wN6nIAJKTJr
# i6SpzWxPYj7RSh3TGPL0rb6MsfxQ1v28zfIf+8JidolJSqC2plSXLzamBhIHq0N5
# khhxCg6FMj4zUeFHGbG3xFoApmcOdeAt2SGchgMmtGRAGkiBqG0TG1O46SZWnbLx
# gKgU9pSFQPYlPqE+IMPuoPsDvs8ukXMPZAWY17NPxoceEqxUG4kws9dk7WTXiPT+
# TrwNka2zVgG0Z6Bc2TK+RdKAILG3dDxYXyVoFdsOeEdoMsGEI4FplDyOpwVTHxkl
# JdDyxu8SeZYVmaAz3cH0/8lMVMXqoFUUwN39XQ8FtFALZNy1kfht+/6PJa9k54XP
# nKW08tHFSoGO/gochomAGFTae0zDgfSGmbgHuzosvGROyMuxqOMIkjw+IqL+Y8pg
# RF2ZHK8Uvz9gD892qQjBZaDZOPm3K60YW19VH7oZtwJWGKOPLuXui3Fr/BhVJfro
# ujRqVpOGNz66iNXAfimwv4DWq9tYMH2zCgqVrbR5m5vDt/MKkV7qqz74bTWyy3VJ
# oDQYabO5AJ3ThR7V4fcMVENk+w35pa8DjnlCZ31kksZe6qcGjgFfBXF1Zk2Pr5vg
# /wIDAQABo4IBNjCCATIwHQYDVR0OBBYEFEaxiHvpXjVpQJFcT1a8P76wh8ZqMB8G
# A1UdIwQYMBaAFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMF8GA1UdHwRYMFYwVKBSoFCG
# Tmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY3Jvc29mdCUy
# MFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEpLmNybDBsBggrBgEFBQcBAQRgMF4w
# XAYIKwYBBQUHMAKGUGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY2Vy
# dHMvTWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3J0MAwG
# A1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZIhvcNAQELBQAD
# ggIBABF27d0KRwss99onetHUzsP2NYe+d59+SZe8Ugm2rEcZYzWioCH5urGkjsdn
# PYx42GHUKj4T0Bps6CP3hKnWx5fF1YhIn2VEZoABbMDzvdpMHf9KPC4apupC4C9T
# MEUI7jRQn1qelq+Smr/ScOotvtcjkf6eyaMXK7zKpfU8yadvizV9tz8XfSKNoBLO
# on6nmuuBhbAOgyKEzlsXRjSuJeKHATt5NKFqT8TBzFGYbeH45P47Hwo4u4urAUWX
# WyJN5AKn5hK3gnW1ZdqmoYkOUJtivdHPz6vJNLwKhkBTS9IcI5ByrXZOHzWntCUd
# m/1xNEOFmDZNXKDwbHdfqaSk05dvnpBSiEjdKff1ZAnCMOfvgnRpVgxqLyZjr9Y6
# 6sowoS5I2EKJ6LRMrry85juwfRcQFadFJtV595K0Oj3hQhRVPB3YeYER9jyR+vKn
# dGUD0DgW99S8McxoX0G29T+krp3UJ0obb1XRY3e5XN9gRMmhGmMtgUarQy8rpBUy
# a43GTdsJF+PVpxJZ57XhQaOCXFbC/I580l7enFw0U53weHKn13gCVAZUs2i1oW+i
# mA8t4nBRPd2XlVoACEzC8gWarCx99DL3eaiuumtye/vivmDd6MLf01ikUSjL6qbM
# tbWMVrVpcTZdv8pnDbJrCqV1KnQe7hUSSMbEU1z4DO0hRbCZMIIHcTCCBVmgAwIB
# AgITMwAAABXF52ueAptJmQAAAAAAFTANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0
# IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTAwHhcNMjEwOTMwMTgyMjI1
# WhcNMzAwOTMwMTgzMjI1WjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGlu
# Z3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBv
# cmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCC
# AiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAOThpkzntHIhC3miy9ckeb0O
# 1YLT/e6cBwfSqWxOdcjKNVf2AX9sSuDivbk+F2Az/1xPx2b3lVNxWuJ+Slr+uDZn
# hUYjDLWNE893MsAQGOhgfWpSg0S3po5GawcU88V29YZQ3MFEyHFcUTE3oAo4bo3t
# 1w/YJlN8OWECesSq/XJprx2rrPY2vjUmZNqYO7oaezOtgFt+jBAcnVL+tuhiJdxq
# D89d9P6OU8/W7IVWTe/dvI2k45GPsjksUZzpcGkNyjYtcI4xyDUoveO0hyTD4MmP
# frVUj9z6BVWYbWg7mka97aSueik3rMvrg0XnRm7KMtXAhjBcTyziYrLNueKNiOSW
# rAFKu75xqRdbZ2De+JKRHh09/SDPc31BmkZ1zcRfNN0Sidb9pSB9fvzZnkXftnIv
# 231fgLrbqn427DZM9ituqBJR6L8FA6PRc6ZNN3SUHDSCD/AQ8rdHGO2n6Jl8P0zb
# r17C89XYcz1DTsEzOUyOArxCaC4Q6oRRRuLRvWoYWmEBc8pnol7XKHYC4jMYcten
# IPDC+hIK12NvDMk2ZItboKaDIV1fMHSRlJTYuVD5C4lh8zYGNRiER9vcG9H9stQc
# xWv2XFJRXRLbJbqvUAV6bMURHXLvjflSxIUXk8A8FdsaN8cIFRg/eKtFtvUeh17a
# j54WcmnGrnu3tz5q4i6tAgMBAAGjggHdMIIB2TASBgkrBgEEAYI3FQEEBQIDAQAB
# MCMGCSsGAQQBgjcVAgQWBBQqp1L+ZMSavoKRPEY1Kc8Q/y8E7jAdBgNVHQ4EFgQU
# n6cVXQBeYl2D9OXSZacbUzUZ6XIwXAYDVR0gBFUwUzBRBgwrBgEEAYI3TIN9AQEw
# QTA/BggrBgEFBQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9E
# b2NzL1JlcG9zaXRvcnkuaHRtMBMGA1UdJQQMMAoGCCsGAQUFBwMIMBkGCSsGAQQB
# gjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/
# MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1UdHwRPME0wS6BJ
# oEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01p
# Y1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYB
# BQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljUm9v
# Q2VyQXV0XzIwMTAtMDYtMjMuY3J0MA0GCSqGSIb3DQEBCwUAA4ICAQCdVX38Kq3h
# LB9nATEkW+Geckv8qW/qXBS2Pk5HZHixBpOXPTEztTnXwnE2P9pkbHzQdTltuw8x
# 5MKP+2zRoZQYIu7pZmc6U03dmLq2HnjYNi6cqYJWAAOwBb6J6Gngugnue99qb74p
# y27YP0h1AdkY3m2CDPVtI1TkeFN1JFe53Z/zjj3G82jfZfakVqr3lbYoVSfQJL1A
# oL8ZthISEV09J+BAljis9/kpicO8F7BUhUKz/AyeixmJ5/ALaoHCgRlCGVJ1ijbC
# HcNhcy4sa3tuPywJeBTpkbKpW99Jo3QMvOyRgNI95ko+ZjtPu4b6MhrZlvSP9pEB
# 9s7GdP32THJvEKt1MMU0sHrYUP4KWN1APMdUbZ1jdEgssU5HLcEUBHG/ZPkkvnNt
# yo4JvbMBV0lUZNlz138eW0QBjloZkWsNn6Qo3GcZKCS6OEuabvshVGtqRRFHqfG3
# rsjoiV5PndLQTHa1V1QJsWkBRH58oWFsc/4Ku+xBZj1p/cvBQUl+fpO+y/g75LcV
# v7TOPqUxUYS8vwLBgqJ7Fx0ViY1w/ue10CgaiQuPNtq6TPmb/wrpNPgkNWcr4A24
# 5oyZ1uEi6vAnQj0llOZ0dFtq0Z4+7X6gMTN9vMvpe784cETRkPHIqzqKOghif9lw
# Y1NNje6CbaUFEMFxBmoQtB1VM1izoXBm8qGCAs4wggI3AgEBMIH4oYHQpIHNMIHK
# MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQLExxN
# aWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25zMSYwJAYDVQQLEx1UaGFsZXMgVFNT
# IEVTTjo4QTgyLUUzNEYtOUREQTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3Rh
# bXAgU2VydmljZaIjCgEBMAcGBSsOAwIaAxUAynU3VUuE8y9ZcShl+YXhqlmWdFSg
# gYMwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYw
# JAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0B
# AQUFAAIFAOddQDUwIhgPMjAyMzAxMDIxOTM2MjFaGA8yMDIzMDEwMzE5MzYyMVow
# dzA9BgorBgEEAYRZCgQBMS8wLTAKAgUA511ANQIBADAKAgEAAgIbMgIB/zAHAgEA
# AgIR3TAKAgUA516RtQIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMC
# oAowCAIBAAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBAEqbk8nG
# ZvQwvyR3lCcbQsOfF3V00h4y7Ubdvbndv3wmOasZVpWmj8yI2Kepk0JNOzei8cYV
# svmifvpGSI4YGje56sCS5Gkdy4bqapaMEUP/OpFNbcdWa7ER1G0z7qS+PXoOP/hy
# qbwXO6rtg3XP2yDbJ8Dn4sTsvQeUUJcjjSaxMYIEDTCCBAkCAQEwgZMwfDELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9z
# b2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAHC+n2HDlRTRyQAAQAAAcIwDQYJ
# YIZIAWUDBAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkq
# hkiG9w0BCQQxIgQgtzoyRqXcAuivSdRPWDWf7F6L80o6dGJJXUrOh5belOYwgfoG
# CyqGSIb3DQEJEAIvMYHqMIHnMIHkMIG9BCDKk2Bbx+mwxXnuvQXlt5S6IRU5V7gF
# 2Zo757byYYNQFjCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEw
# AhMzAAABwvp9hw5UU0ckAAEAAAHCMCIEIJxwgFHZ5CDUE2gexGSvkX1TTnGMFtYm
# NtsAT767HsFHMA0GCSqGSIb3DQEBCwUABIICAEFEeb273QvU38MLjwcCLrlR3YOt
# AB6HhRDN0KvJucKpT8Rq73uTqzbqxTDSDZclU98Drbi5GzbuQd0qWm+4wOUn9cjU
# wntiYvONJG2g6za1xah5xClp2EVfiyCIepUbyc5500Ysv0LFVgNV08LNGuErFmE3
# aZXMf8XFxutfmCuaD/hnMITIgQwyQONhkVIbTu5LcyozOEouyDRSltfpDJiF3g4B
# PYpMAKCtNfeCOKwagrryJ2oRIkwdLhMKc79FNuag6noOmx8NnXGl9dQxLrV1W8GL
# aF5HFg8wVVSO/qXgsiOKb+dmff6tXQc9ex1x1dTe/+FfMBJp3/nyr7ebfn6HOf3Q
# rCW2zbLrVz1b6JrAzZp4vQkFpEFYBEI7IRuZDS+E7ME3kWtb0eGRWU78jAxwLEzr
# 6dhY1n+po+gLvyCD9fjSD2QS/Tee1/vScLPE1yvetkjTYOGHQ8r/5YLLK/CVOQp8
# c/gTRlb/yZTWH7/khBfYEavrm5YtlenQP580FaUKfuMXrM8NZjEM7leYGJ0QcPrl
# 7f4DQZVA39TNVZqE/7WqnMYce8rD1pll6b3cJsuNCoTuas0/cu3hdJokrEJM1059
# PsNx/8oI+nsMLzESsGEuO6qb7qFX6HWLsxTEiS8/0EYUPb803qnfSF0H68a95CHh
# 6OanLxoxfWn+x4sk
# SIG # End signature block
