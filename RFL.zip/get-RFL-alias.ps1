# Name: get-RFL-alias.ps1
<# Script to establish alias names for all RFL helper scripts
Help: get-help \\emeacssdfs\netpod\rfl\get-RFL-alias.ps1 -detailed
last edit by: waltere 2022-09-14
File Name: get-RFL-alias.ps1

VERSION and AUTHORs:
    Ver 1.00 - 15.10.2016
	Walter Eder	- waltere@microsoft.com ; Vincent Douhet <vidou@microsoft.com>

### set and show alias names for all RFL helper scripts, using PowerShell Alias in order to avoid remember the full UNC path

HISTORY
	2016-10-16 v1.00

#>

<#
.SYNOPSIS
File Name: get-RFL-alias.ps1
The script allows to set RFL script alias'es either using
 Method 1 - to set *RFL* alias names only for this PS session
or
 Method 2 - to import *RFL* alias names permanently into your PS Profile

.DESCRIPTION
This script helps to use the RFL scripts by alias, avoid remember the full UNC path.
You can use the command "get-command *RFL*" or "get-alias *RFL*" to check for defined alias.
Running the script will define the following list of alias:

Alias				PS Script
"RFL-check-RegistryKeyNames"	"\\emeacssdfs.europe.corp.microsoft.com\netpod\rfl\check-RegistryKeyNames.ps1"
"RFL-check-csv_Tech_Path"		"\\emeacssdfs.europe.corp.microsoft.com\netpod\rfl\check-rfl-csv_Tech_Path.ps1"
"RFL-check-csv_MultiTech_Path"	"\\emeacssdfs.europe.corp.microsoft.com\netpod\rfl\check-rfl-csv_MultiTech_Path.ps1"
"RFL-get-latest-binary-version"	"\\emeacssdfs.europe.corp.microsoft.com\netpod\rfl\get-latest-binary-version.ps1"
"RFL-get-MiniSDP"			"\\emeacssdfs.europe.corp.microsoft.com\netpod\rfl\get-MiniSDP.ps1"
"RFL-get-pma"			"\\emeacssdfs.europe.corp.microsoft.com\netpod\rfl\get-pma.ps1"
"RFL-get-events"			"\\emeacssdfs.europe.corp.microsoft.com\netpod\rfl\get-events.ps1"
"RFL-get-PStatSum"			"\\emeacssdfs.europe.corp.microsoft.com\netpod\rfl\get-PStatSum.ps1"
"RFL-get-update-RFLShellExt"	"\\emeacssdfs.europe.corp.microsoft.com\netpod\rfl\get-update-RFLShellExt.ps1"
"RFL-get-version-RFLShellExt"	"\\emeacssdfs.europe.corp.microsoft.com\netpod\rfl\get-version-RFLShellExt.ps1 -verbose"
"RFL-get-ShellExtension"		"\\emeacssdfs.europe.corp.microsoft.com\netpod\rfl\Rfl-Check_ShellExtension_FQDN_PMA.reg"
"RFL-get-alias"			"\\emeacssdfs.europe.corp.microsoft.com\netpod\rfl\get-RFL-alias.ps1"

.EXAMPLE
Usage:
Example 1, to set *RFL* alias names only for this PS session, use Method 1 enter Y, hit <RET> or N for Method 2
\\emeacssdfs.europe.corp.microsoft.com\netpod\rfl\get-RFL-alias.ps1

.LINK
email: waltere@microsoft.com
#>

$verDateScript = "2022.09.14.0"
$UsrOSVersion = [Environment]::OSVersion.Version.ToString(3)
$SdpComputerName = $env:computername
$CheckDate = (Get-Date).ToUniversalTime().ToString("yy-MM-dd_HH-mm-ss")
	$InOfflineMode 	= ((( Get-content -Path "$ScriptFolder\version_SDPcheck.dat")[1] -split " ")[2]).trim("""")	# set $True for outsourcer or when not connected to MS network - offline-SDPcheck
	#$RFLroot = ((( Get-content -Path "$ScriptFolder\version_SDPcheck.dat")[2] -split " ")[2]).trim("""")	# "\\emeacssdfs.europe.corp.microsoft.com\netpod\rfl\" -or- "\\localhost\ToolsShare\rfl\"
	if ($InOfflineMode -match "False") {
		$StatsServer = ((( Get-content -Path "$ScriptFolder\version_SDPcheck.dat")[4] -split " ")[2]).trim("""")
		if (Test-Connection -ComputerName $StatsServer -Quiet -Count 1) {[bool]$Stats=$True} else {[bool]$Stats=$False}
	} else { 
		$Stats = $False
	}

if ($Stats) {
	$StatsServerPath="\\$StatsServer\netpod\tools\RFL\"
	$CountInvFil = $StatsServerPath +'count_RFLalias.dat'
	$CountInvFil2 = $CountInvFil +'.us'
	#increment at start of script
	 ($j=[int32](Get-Content $CountInvFil -TotalCount 1 -ErrorAction SilentlyContinue)) |out-null
	 (++$j) | Set-Content $CountInvFil -ErrorAction SilentlyContinue
}

$ScriptBeginTimeStamp = Get-Date

[string[]]$RFLsetAlias=@"
# RFL Alias File
# Exported by : waltere
# Date/Time : Sunday, October 16, 2016 00:15:00
set-alias RFL-get-latest-binary-version \\emeacssdfs\netpod\rfl\get-latest-binary-version.ps1 -Scope Global -Description 'RFL family script'
set-alias RFL-get-MiniSDP \\emeacssdfs\netpod\rfl\get-MiniSDP.ps1 -Scope Global -Description 'RFL family script'
set-alias RFL-get-pma \\emeacssdfs\netpod\rfl\get-pma.ps1 -Scope Global -Description 'RFL family script'
set-alias RFL-get-events \\emeacssdfs\netpod\rfl\get-events.ps1 -Scope Global -Description 'RFL family script'
set-alias RFL-check-RegistryKeyNames \\emeacssdfs\netpod\rfl\check-RegistryKeyNames.ps1 -Scope Global -Description 'RFL family script'
set-alias RFL-check-csv_Tech_Path \\emeacssdfs\netpod\rfl\check-rfl-csv_Tech_Path.ps1 -Scope Global -Description 'RFL family script'
set-alias RFL-check-csv_MultiTech_Path \\emeacssdfs\netpod\rfl\check-rfl-csv_MultiTech_Path.ps1 -Scope Global -Description 'RFL family script'
set-alias RFL-get-PStatSum \\emeacssdfs\netpod\rfl\get-PStatSum.ps1 -Scope Global -Description 'RFL family script'
set-alias RFL-get-update-RFLShellExt \\emeacssdfs\netpod\rfl\get-update-RFLShellExt.ps1 -Scope Global -Description 'RFL family script'
set-alias RFL-get-version-RFLShellExt \\emeacssdfs\netpod\rfl\get-version-RFLShellExt.ps1 -Scope Global -Description 'RFL family script'
set-alias RFL-get-ShellExtension \\emeacssdfs\netpod\rfl\Rfl-Check_ShellExtension_FQDN_PMA.reg -Scope Global -Description 'RFL family script'
set-alias RFL-get-alias \\emeacssdfs\netpod\rfl\get-RFL-alias.ps1 -Scope Global -Description 'RFL family script'
"@

Write-host "You can use
 Method 1 - to set *RFL* alias names only for this PS session
 Method 2 - to import *RFL* alias names permanently into your PS Profile"

Write-host "`n.. checking for already defined RFL aliases: get-command *RFL*"
$defined_RFL_aliases = get-command *RFL*
get-command *RFL*

###Method 0
#$UserInput = Read-Host 'Method 0: Do you want to set *RFL* alias names for this PS session [Y|N]'
#if ($UserInput0 -match 'n') {Write-Host " ...ending the Method 0 per User Input: $UserInput0 "; break}
#else {foreach ($line in $RFLsetAlias){& "$line"} }
#Write-host "`n.. running: get-command *RFL*"
#get-command *RFL*


###Method 1
if (-not $defined_RFL_aliases) {
 $SessionAlias = Read-Host 'Method 1: Do you want to import *RFL* alias names for this PS session [Y|N]'
 if (($SessionAlias -match 'n') -or ($SessionAlias -eq '')) {Write-Host " ...ending the Method 1 per User Input: '$SessionAlias' " }
 if ($SessionAlias -match 'y') {Import-Alias -Path \\emeacssdfs\netpod\rfl\alias-RFL.txt -Scope Global}
 get-alias rfl*
}
else {Write-Host " ...Method 1 skipped: already defined RFL aliases, see: get-command *RFL*"}

###Method 2
#ToDo: only do this step if no entry in profile$ exists
if (-not $defined_RFL_aliases) {
 $ProfileAlias = Read-Host 'Method 2: Do you want to import *RFL* alias names permanently into your PS Profile [Y|N]'
 if (($ProfileAlias -match 'n') -or ($ProfileAlias -eq '')) {Write-Host " ...ending the Method 2 per User Input: '$ProfileAlias' " }
 if ($ProfileAlias -match 'y') { Write-host "Method 2: `n.. running: Add-Content -Path $Profile -Value 'RFLsetAlias'"
			   Add-Content -Path $Profile -Value $RFLsetAlias }
 }
else {Write-Host " ...Method 2 skipped: already defined RFL aliases, see: get-command *RFL*"}

# Write-host "`n.. Export-Alias -Name RFL* -Path "$Env:Temp\alias.ps1" -As Script"
#Example 4: Export aliases as a script
# Export-Alias -Path "$Env:Temp\alias.ps1" -As Script
# Write-host "`n.. Add-Content -Path $Profile -Value (Get-Content $Env:Temp\alias.ps1)"
# Add-Content -Path $Profile -Value (Get-Content $Env:Temp\alias.ps1)
# $S = New-PSSession -ComputerName Server01
# Invoke-Command -Session $S -FilePath $Env:Temp\alias.ps1

Write-host "`n
 'get-alias rfl* ' or 'get-command rfl* ' shows all alias currently defined.
`n For detailed help on a specific script, type for example
 get-help \\emeacssdfs\netpod\rfl\get-latest-binary-version.ps1 -detailed"

$ScriptEndTimeStamp = Get-Date
$Duration = $(New-TimeSpan -Start $ScriptBeginTimeStamp -End $ScriptEndTimeStamp)
Write-Host -BackgroundColor Gray -ForegroundColor Black -Object "`n$(Get-Date -UFormat "%R") Done on this PC $($SdpComputerName); script version v$verDateScript took $($Duration)"

### Stats
If ($Stats){
 ([string]$j + " ;$CheckDate; $UsrOSVersion; " + [System.Security.Principal.WindowsIdentity]::GetCurrent().Name) + "; $($SdpComputerName)" + "; $($Duration)" + "; $ProfileAlias" | Out-File $CountInvFil2 -Append -Encoding UTF8 -ErrorAction SilentlyContinue
}

