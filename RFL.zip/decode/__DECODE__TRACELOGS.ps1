﻿
#
# PowerShell conversion of the CPRNT decode batch files written by tonyga
# Conversion by jakehr
#

#### PARAMETERS AND CONSTANTS #####

param (
        [Parameter(Mandatory=$true)]
        [string]$TARGET_PATH,
        [switch]$recurse = $false
      )


##### CONSTANTS #####

# path to tracemft
[string]$SCRIPT:TRACE_TOOLS_PATH = "\\cpr-web.northamerica.corp.microsoft.com\cprnt\tools\Tracing\Tools\$ENV:PROCESSOR_ARCHITECTURE"

# path to the ETL web parser used for WinHTTP/WebIO parsing
[string]$SCRIPT:WINHTTP_TOOL_PATH = '\\cpr-web.northamerica.corp.microsoft.com\cprnt\tools\WebETLParser'

# root path to the TMF files
[string]$SCRIPT:ROOT_TMF_PATH = '\\cpr-web.northamerica.corp.microsoft.com\cprnt\tools\Tracing\TMF'

# the current build number of the public Windows 10 edition
[int]$SCRIPT:current10RlsBuild = 16299
#[int]$SCRIPT:current10RlsBuild = 14393



##### FUNCTIONS #####

function Get-OsVerEtl 
{
    
    param ($file)

    # get the Windows build number from the ETL
    $bytes = Get-Content "$($file.FullName)" -Encoding byte -TotalCount 116
    $byte = $bytes[112..116]

    [int]$build = "0x$('{0:X}' -f $byte[1])$('{0:X}' -f $byte[0])"

    # get the OS major/minor version number based on the build
    switch -regex ($build) {
        9600 {  
                [int]$osMaj = 6
                [int]$osMin = 3
            }

        7601 {  
                [int]$osMaj = 6
                [int]$osMin = 1
            }

        "1\d{4}" {  
                [int]$osMaj = 10
                [int]$osMin = 0
            }

        9200 {  
                [int]$osMaj = 6
                [int]$osMin = 2
            }

        6002 {  
                [int]$osMaj = 6
                [int]$osMin = 0
            }

        2600 {  
                [int]$osMaj = 5
                [int]$osMin = 1
            }

        3790 {  
                [int]$osMaj = 5
                [int]$osMin = 1
            }
        default {
                $osMaj = $null
                $osMin = $null
                }
    }

    # try to get OS version from osInfo, if checking the ETL failed
    $isOsinfo = Test-Path "$($file.DirectoryName)\osinfo.txt" -EA SilentlyContinue
    if ($isOsinfo -and !$osMaj) {
        $osVer = Get-Content "$($file.DirectoryName)\osinfo.txt" | Where-Object {$_ -match "^OS Version:.*$"} | ForEach-Object {($_ -Replace "\s+",'').Split(':')[-1]}
        [int]$osMaj = $osVer.Split('.')[0]
        [int]$osMin = $osVer.Split('.')[1]

        $osName = Get-Content "$($file.DirectoryName)\osinfo.txt" | Where-Object {$_ -match "OS Name:.*$"} | ForEach-Object {($_.Split(':')[-1]).Trim(' ')}
    }

    # look for version file
    $isVersion = Test-Path "$($file.DirectoryName)\version.txt" -EA SilentlyContinue
    if ($isVersion -and !$osMaj) {
        $osVer = Get-Content "$($file.DirectoryName)\version.txt" | Where-Object {$_ -match "CurrentVersion    REG_SZ"} | ForEach-Object {($_ -Replace "\s+",' ').Trim(' ').Split(' ')[-1]}
        [int]$osMaj = $osVer.Split('.')[0]
        [int]$osMin = $osVer.Split('.')[1]

        $osName = Get-Content "$($file.DirectoryName)\version.txt" | Where-Object {$_ -match "ProductName    REG_SZ"} | ForEach-Object {($_ -Replace "\s+",' ').Trim(' ').SubString(19)}
    }

    #Write-Host "$osMaj`.$osMin"

    switch ($osMaj) {
        5  {
            switch -Regex ($osMin) {
                0 {$OS = "Windows2000"}
                "1|2" {
                    if ($osName) {
                        if ($osName -match "WindowsXP") {
                            $OS = "WindowsXP"
                        } else {
                            $OS = "Windows2003"
                        }
                    } else {
                        $OS = "Windows2003"
                    }
                }
            }
            break
        }
        6  {
            switch ($osMin) {
                0 {$OS = "Windows2008-Vista"}
                1 {$OS = "Windows2008R2-Win7"}
                2 {$OS = "Windows8"}
                3 {$OS = "Windows81"}
            }
            break
        }
        10 {
            if ($build -gt $SCRIPT:current10RlsBuild)
            {
                $OS = "Windows10\Beta"
            }
            else{
                $OS = "Windows10"
            }
            
            break
        }
        default {$OS = "unknown"}

    }

    # return the TMF path. Use Win10 path when the actual ETL path was undetected.
    if (!$OS -or $OS -eq "unknown") {
        return "\\cpr-web.northamerica.corp.microsoft.com\cprnt\tools\Tracing\TMF\Windows10"
    } else {
        return "\\cpr-web.northamerica.corp.microsoft.com\cprnt\tools\Tracing\TMF\$OS"
    }
}


function Convert-ETL
{
    param (
        # file object, mandatory, accepts pipeline
        [Parameter(Mandatory=$true,
        ValueFromPipeline=$true,
        Position=0)]
        [System.IO.FileSystemInfo]
        $file,
        # location of the TMF files
        [Parameter(Mandatory=$true,
        ValueFromPipeline=$true,
        Position=0)]
        [string]
        $TRACE_FORMAT_SEARCH_PATH
    )
    Push-Location $SCRIPT:TRACE_TOOLS_PATH

    # Always convert report.etl with NETSH
    
    if ($file.Name -eq "report.etl") {
    
        netsh trace convert "$($file.FullName)" "$($file.FullName)-formatted.log" TMFPATH=$TRACE_FORMAT_SEARCH_PATH overwrite=yes 
        Pop-Location
        return;
    }    
    
    
    # look for tracefmt, fall back to netsh trace convert if it fails
    $isTraceFmtFnd = Test-Path .\tracefmt.exe
    if ($isTraceFmtFnd) {
        .\tracefmt.exe "$($file.FullName)" -o "$($file.FullName)-formatted.log" -p $TRACE_FORMAT_SEARCH_PATH -v
    }
    else 
    {
        netsh trace convert "$($file.FullName)" "$($file.FullName)-formatted.log" TMFPATH=$TRACE_FORMAT_SEARCH_PATH overwrite=yes 
    }

    Pop-Location
}

function Decode-ETL 
{

    param ($file)

    # get the TMF path
    $TRACE_FORMAT_SEARCH_PATH = Get-OsVerEtl $file
    if ($TRACE_FORMAT_SEARCH_PATH -eq $false) {
        Write-Verbose "OS could not be detected. Using the Windows 10 TMF path."
        $TRACE_FORMAT_SEARCH_PATH = "\\cpr-web.northamerica.corp.microsoft.com\cprnt\tools\Tracing\TMF\Windows10"
    }
    
    Write-Host -ForegroundColor Green "format: $TRACE_FORMAT_SEARCH_PATH"

    
    # make sure $file is a file object and not a string
    if ($file -is [string]) {
        $file = Get-Item $file
    }

    # make sure the file exists
    if (!(Test-Path "$($file.FullName)")) {
        Write-Error "File not found: $($file.FullName)"
        return
    }

    # push the file directory
    Push-Location $($file.Directory)

    #
    # First correlate packetcapture.etl
    #

    if ($file.Name -eq "packetcapture.etl") {
        
        # add -tmp to file name
        Rename-Item $file packetcapture.etl-tmp.etl

        # correlate the trace, with no convert, since these are just packets
        netsh trace correlate input="$($file.Directory)\packetcapture.etl-tmp.etl" output="$($file.FullName)" overwrite=yes    

        # delete the tmp file
        $null = Remove-Item packetcapture.etl-tmp.etl -Force

        # return to main
        return
    }

    #
    # Correlate then Format the winhttp/webio log
    # 
  
    if ($file.Name -eq "nettrace-winhttp-webio.etl") {

        # correlate the ETL
        Rename-Item $file nettrace-winhttp-webio.etl-tmp.etl    

        # use netsh trace convert\correlation for this part
        netsh trace correlate "$($file.Directory)\nettrace-winhttp-webio.etl-tmp.etl" output="$($file.FullName)" overwrite=yes    
        netsh trace convert input="$($file.FullName)" output="$($file.Directory)\$($file.Name)-formatted.log" dump=TXT overwrite=yes tmfpath=$TRACE_FORMAT_SEARCH_PATH

        # remove the tmp file
        $null = Remove-Item nettrace-winhttp-webio.etl-tmp.etl -Force

        #
        # Pull out the HTTP send/receive headers from the log
        #

        #
        # Netsh format inserts strange characters that confuses findstr, so using PowerShell to grep out the send/receive HTTP headers (wininet & winhttp)
        #
        # Call Select-String to parse the file 
        # Only grab the Line (_.Line) member from the MatchInfo objects returned and write to file.
        #

        Select-String -path .\nettrace-winhttp-webio.etl-formatted.log -Pattern "Sending Headers|Received Headers|HTTP Request Headers|HTTP Response Headers" -AllMatches | ForEach-Object {$_.Line} | Out-File .\nettrace-winhttp-webio-HEADERS.log

        #
        # Do more analysis of the WinHTTP log.  From toolbox, http://toolbox/WebETLParser 
        #

        Push-Location $SCRIPT:WINHTTP_TOOL_PATH\$ENV:processor_architecture
        .\ParseWebEtl.exe -parse "$($file.FullName)" "$($file.Directory)\nettrace-winhttp-webio.etl-analysis.xml" "$($file.Directory)\nettrace-winhttp-webio.etl-ANALYSIS.html"
        Pop-Location

        # escape back to main
        return
    }

    #
    # handle/decode NETSH trace files, correlate then dump as text
    # 
    
    if ($file.Name -eq "report.etl") {
        # rename to tmp
        Rename-Item $file report.etl-tmp.etl    

        # correlate
        netsh trace correlate input="$($file.Directory)\report.etl-tmp.etl" output="$($file.FullName)" overwrite=yes    

        # del tmp
        $null = Remove-Item report.etl-tmp.etl -Force   
    
        # decode
        #netsh trace convert input="$($file.FullName)" output="$($file.FullName)-formatted.log" dump=TXT overwrite=yes tmfpath="$TRACE_FORMAT_SEARCH_PATH"
        Convert-ETL -file $file -TRACE_FORMAT_SEARCH_PATH $TRACE_FORMAT_SEARCH_PATH
        
    
        Pop-Location

        # return to main
        return
    }

    #
    # Format the ETL file
    #    

    Push-Location "$($file.Directory)"
    
    # removing correlation, shouldn't be needed at this stage
    
    # create tmp
    # Rename-Item "$($file.Name)" "$($file.Name)`-tmp.etl"

    # correlate the trace
    # netsh trace correlate input="$($file.Name)`-tmp.etl" output="$($file.FullName)" overwrite=yes    

    # convert the ETL
    Convert-ETL -file $file -TRACE_FORMAT_SEARCH_PATH $TRACE_FORMAT_SEARCH_PATH

    # remove the tmp
    # $null = Remove-Item "$($file.Name)`-tmp.etl" -Force

    Pop-Location


    #
    # Split CSC events out to its own file.
    #

    if ($file.name -eq "fsum.etl") {
        if (Test-Path "$($file.FullName)-formatted.log") {
                Rename-Item "$($file.FullName)-formatted.log" fsum.etl-formatted.log-tmp.log
            }
        # Delete the file else we just append to it.
        if (Test-Path "$($file.FullName)-CSC-formatted.log") { $null = Remove-Item "$($file.FullName)-CSC-formatted.log" -Force}
    
        #findstr  /i   /c:"[CscDclUm]" /c:[cscui] /c:[CscNetApi] /c:[cscapi] /c:[cscum] /c:[csc] %1-formatted.log-tmp.log >>%1-CSC-formatted.log
        Select-String -path "$($file.FullName)-formatted.log-tmp.log" -Pattern "\bCscDclUm\b|\bcscui\b|\bCscNetApi\b|\bcscapi\b|\bcscum\b|\bcsc\b" -AllMatches | ForEach-Object {$_.Line} | Out-File -FilePath "$($file.FullName)-CSC-formatted.log" -Force

        #findstr /v /i /c:"[CscDclUm]" /c:[cscui] /c:[CscNetApi] /c:[cscapi] /c:[cscum] /c:[csc] %1-formatted.log-tmp.log >>%1-formatted.log    
        Select-String -path "$($file.FullName)-formatted.log-tmp.log" -NotMatch -Pattern "\bCscDclUm\b|\bcscui\b|\bCscNetApi\b|\bcscapi\b|\bcscum\b|\bcsc\b" -AllMatches | ForEach-Object {$_.Line} | Out-File -FilePath "$($file.FullName)-formatted.log" -Force
        #$FmtLog | Out-File -FilePath "$($file.FullName)-formatted.log" -Force

        $null = Remove-Item "$($file.FullName)-formatted.log-tmp.log"

    }
    Pop-Location
} # end Decode-ETL




#### Controls the column format of the parsed ETL ####
# This adds additional information to the decoded log file.
IF ($ENV:_ETL_BRIEF -eq $null) {
    
    # 
    # Format string below translates to
    # [CPUNumber]ProcessID.ThreadID::SystemTime [MessageGUIDFriendlyName] Filename_LineNumber FunctionName
    #     %9         %8        %3       %4               %1                   %2                 %!FUNC! 
    # See http://msdn.microsoft.com/en-us/library/ff553941.aspx

    $ENV:TRACE_FORMAT_PREFIX = '[%9!d!] %8!04X!.%3!04X!::%4!s! [%1!s!] %2!s! %!FUNC! - '

    # 
    # putting this here just for reference, this is basically every option you can have for the prefix.
    # 
    # SET TRACE_FORMAT_PREFIX=%%9!d! %%8!04d!.%%3!04d! %%4!s! [%%7!d!] [%%1!7s!] [%%!LEVEL!] [%%!COMPNAME!] [%%!SUBCOMP!] [%%!FLAGS!] [%%5!s!] [%%6!s!] %%2!14s! - [%%!FUNC!^(^)]-    

} ELSE {

        # Brief output
        $ENV:TRACE_FORMAT_PREFIX = '[%9!d!] %8!04X!.%3!04X!::%4!s! [%1!s!] -  '
}




#
# If passed in path has a trailing \, and the path -ne '.\', remove it ( i.e. user passed in .\ or c:\case\)
#

if ($TARGET_PATH -ne '.\' -and $TARGET_PATH[-1] -eq '\')
{
    $TARGET_PATH = $TARGET_PATH.TrimEnd("\")
}


#
#  Parse input and send file(s) off to decode function
#   

# convert the string path to a path object
$file = Get-Item $TARGET_PATH -EA SilentlyContinue

# make sure the path/object is found, abort if not
if (!$file)
{
    Write-Error "File or directory not found: $TARGET_PATH"
    Start-Sleep 3
    exit
}


# test if the object is a container (i.e. a directory)
if ($file.PSIsContainer) {
    # search for ETL files based on whether recurse was set or not
    if ($recurse) {
        [array]$isFileFnd = Get-ChildItem $file -Filter "*.etl" -Recurse -EA SilentlyContinue
    } else {
        [array]$isFileFnd = Get-ChildItem $file -Filter "*.etl" -EA SilentlyContinue
    }

    # decode all ETL's found
    if ($isFileFnd)
    {
        $isFileFnd | ForEach-Object {Decode-ETL -file $_}
    # or error out if there are no ETL's
    } else {
        Write-Error "No ETL files found in $TARGET_PATH"
        Start-Sleep 3
        exit
    }
# decode if an ETL was passed and the file extension is ETL
} else {
    # make sure the file extension is ETL
    if ($file.Extension -eq ".etl")
    {
        Decode-ETL -file $file
    } else {
        Write-Error "The file extension must be ETL."
        Start-Sleep 3
        exit
    }   
}