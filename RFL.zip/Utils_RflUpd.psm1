# ******************************************* RFL ***********************************************
# File: Utils_RflUpd.psm1
# Version 1.0
# Date: 2022-09-08
# Description:  Utility Script to load common functions for RFL.
# last edit by: waltere 2022-09-14
# ***********************************************************************************************


##########################
## Variables            ##
##########################
$verDatePsm1 = "2022.09.14.0"
#$ComputerName = $Env:computername
#$OSVersion = [Environment]::OSVersion.Version
$ScriptFolder 	= Split-Path $MyInvocation.MyCommand.Path -Parent
$global:RFLReleaseServer = "api.Github.com"
$global:RFL_release_url  = "https://api.github.com/repos/walter-1/offline-SDPcheck/releases"
$script:LogLevel = 0
$RflUpdLogfile = $ScriptFolder + "\_RFL_Update-Log.txt"

##########################
## Function Definitions ##
##########################

#region ::::: [Logging Functions] -------------------------------------------------#
Function global:RflEnterFunc([String]$FunctionName){
	Write-Verbose "---> Enter $FunctionName"
}

Function global:RflEndFunc([String]$FunctionName){
	Write-Verbose "<--- End $FunctionName"
}

Function global:WriteLine ([string]$line,[string]$ForegroundColor, [switch]$NoNewLine){
	# SYNOPSIS: writes the actual output - used by other Logging Functions
	if($Script:ScriptMode){
	  if($NoNewLine) {
		$Script:Trace += "$line"
	  }
	  else {
		$Script:Trace += "$line`r`n"
	  }
	  Set-Content -Path $script:LogPath -Value $Script:Trace
	}
	if($Script:HostMode){
	  $Params = @{
		NoNewLine    = $NoNewLine -eq $true
		ForegroundColor = if($ForegroundColor) {$ForegroundColor} else {"White"}
	  }
	  Write-Host $line @Params
	}
}

Function global:WriteInfo([string]$message,[switch]$WaitForResult,[string[]]$AdditionalStringArray,[string]$AdditionalMultilineString){
	# SYNOPSIS: handles informational logs
	if($WaitForResult){
	  WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)$message" -NoNewline
	}
	else{
	  WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)$message"
	}
	if($AdditionalStringArray){
	  foreach ($String in $AdditionalStringArray){
		WriteLine "          $("`t" * $script:LogLevel)`t$String"
	  }
	}
	if($AdditionalMultilineString){
	  foreach ($String in ($AdditionalMultilineString -split "`r`n" | Where-Object {$_ -ne ""})){
		WriteLine "          $("`t" * $script:LogLevel)`t$String"
	  }
	}
}

Function global:WriteResult([string]$message,[switch]$Pass,[switch]$Success){
	# SYNOPSIS: writes results - should be used after -WaitForResult in WriteInfo
	if($Pass){
	  WriteLine " - Pass" -ForegroundColor Cyan
	  if($message){
		WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)`t$message" -ForegroundColor Cyan
	  }
	}
	if($Success){
	  WriteLine " - Success" -ForegroundColor Green
	  if($message){
		WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)`t$message" -ForegroundColor Green
	  }
	}
}

Function global:WriteInfoHighlighted([string]$message,[string[]]$AdditionalStringArray,[string]$AdditionalMultilineString){
	# SYNOPSIS: write highlighted info
	WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)$message" -ForegroundColor Cyan
	if($AdditionalStringArray){
	  foreach ($String in $AdditionalStringArray){
		WriteLine "[$(Get-Date -Format hh:mm:ss)]     $("`t" * $script:LogLevel)`t$String" -ForegroundColor Cyan
	  }
	}
	if($AdditionalMultilineString){
	  foreach ($String in ($AdditionalMultilineString -split "`r`n" | Where-Object {$_ -ne ""})){
		WriteLine "[$(Get-Date -Format hh:mm:ss)]     $("`t" * $script:LogLevel)`t$String" -ForegroundColor Cyan
	  }
	}
}

Function global:WriteWarning([string]$message,[string[]]$AdditionalStringArray,[string]$AdditionalMultilineString){
	# SYNOPSIS: write warning logs
	WriteLine "[$(Get-Date -Format hh:mm:ss)] WARNING: $("`t" * $script:LogLevel)$message" -ForegroundColor Magenta
	if($AdditionalStringArray){
	  foreach ($String in $AdditionalStringArray){
		WriteLine "[$(Get-Date -Format hh:mm:ss)]     $("`t" * $script:LogLevel)`t$String" -ForegroundColor Magenta
	  }
	}
	if($AdditionalMultilineString){
	  foreach ($String in ($AdditionalMultilineString -split "`r`n" | Where-Object {$_ -ne ""})){
		WriteLine "[$(Get-Date -Format hh:mm:ss)]     $("`t" * $script:LogLevel)`t$String" -ForegroundColor Magenta
	  }
	}
}

Function global:WriteError([string]$message){
	# SYNOPSIS: logs errors
	WriteLine ""
	WriteLine "[$(Get-Date -Format hh:mm:ss)] ERROR:  $("`t`t" * $script:LogLevel)$message" -ForegroundColor Red
}

Function global:WriteErrorAndExit($message){
	# SYNOPSIS: logs errors and terminates script
	WriteLine "[$(Get-Date -Format hh:mm:ss)] ERROR:  $("`t" * $script:LogLevel)$message" -ForegroundColor Red
	Write-Host "Press any key to continue ..."
	$host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") | OUT-NULL
	$HOST.UI.RawUI.Flushinputbuffer()
	Throw "Terminating Error"
}
#endregion ::::: [Logging Functions] ----------------------------------------------#

#region ::::: [RFL Functions] -----------------------------------------------------#
Function global:ExitWithCode ($Ecode) {
	# set ErrorLevel to be picked up by invoking CMD script
	if ( $UseExitCode ) {
		Write-Verbose "[Update] Return Code: $Ecode"
		#error.clear()	# clear script errors
		exit $Ecode
		}
}

Function global:get_local_RFL_version {
	<#
	.SYNOPSIS
		Function returns current version locally from version_SDPcheck.dat
	#>
	param($type="current")
	RflEnterFunc ($MyInvocation.MyCommand.Name + "(type: $type)")
	$script:verDateRFL 	= ((( Get-content -Path "$ScriptFolder\version_SDPcheck.dat")[0] -split " ")[2]).trim("""")
	Write-verbose "[get_local_RFL_version] verDateRFL= $script:verDateRFL"
	RflEndFunc ($MyInvocation.MyCommand.Name + "(local verDateRFL: $script:verDateRFL)")
	return [version]$script:verDateRFL
}

Function global:get_latest_RFL_version {
	<#
	.SYNOPSIS
		Function will get latest version from CesdiagTools/GitHub Release page
	.LINK
		https://github.com/walter-1/offline-SDPcheck/releases
		https://cesdiagtools.blob.core.windows.net/windows/RFL.zip
	#>
	param($RFL_release_url)
	RflEnterFunc ($MyInvocation.MyCommand.Name + "(URL: $RFL_release_url)" )
		if ($UpdMode -match 'Online') {
		RflEndFunc ($MyInvocation.MyCommand.Name + "(verOnline=$verOnline)" )
		return $verOnline # = RFL.ver
	} else {
		# GitHub: Get web content and convert from JSON
		[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
		try { $web_content = Invoke-WebRequest -Uri $RFL_release_url -UseBasicParsing | ConvertFrom-Json } catch { "`n*** Failure during RFL update. Exception Message:`n $($_.Exception.Message)" | Out-File $RflUpdLogfile -Append }
		if ($web_content.tag_name) {
			[version]$script:expected_latest_RFL_version = $web_content.tag_name.replace("v","")
			write-verbose "$UpdateSource Version of '$RFL_release_url': --> $script:expected_latest_RFL_version"
			RflEndFunc ($MyInvocation.MyCommand.Name + "(expected_latest_RFL_version: $script:expected_latest_RFL_version)" )
			return $script:expected_latest_RFL_version
		}
		else 
		{ Write-Host -ForegroundColor Red "[ERROR] cannot securely access $RFLReleaseServer. Please download https://aka.ms/getRFL"
			"`n $(GGet-Date -UFormat "%D %R:%S") [ERROR] cannot securely access $RFLReleaseServer. Please download https://aka.ms/getRFL" | Out-File $RflUpdLogfile -Append
			$script:ChkFailed=$TRUE
			RflEndFunc ($MyInvocation.MyCommand.Name + "(ChkFailed=$TRUE)" )
			return 2022.0.0.0
		}
	}
	RflEndFunc $MyInvocation.MyCommand.Name
}

Function global:DownloadFileFromGitHubRelease {
	param(
		$action = "download", 
		$file, 
		$installedRFLver,
		$RFL_path)
		
	RflEnterFunc ($MyInvocation.MyCommand.Name + "(action: $action $file)")
	# Download latest RFL release from CesdiagTools/GitHub
	$repo = "walter-1/offline-SDPcheck"
	$releases = "https://api.github.com/repos/$repo/releases"
	#Determining latest release , Set TLS to 1.2
	[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
	$tag = (Invoke-WebRequest $releases -UseBasicParsing | ConvertFrom-Json)[0].tag_name
	$downloadURL = "https://github.com/$repo/releases/download/$tag/$file"
	Write-Verbose "downloadURL: $downloadURL"
	$name = $file.Split(".")[0]
	$zip = "$name-$tag.zip"
	$TmpDir = "$name-$tag"
	Write-Verbose "Name: $name - Zip: $zip - Dir: $TmpDir - Tag/version: $tag"
	
	#_# faster Start-BitsTransfer $downloadURL -Destination $zip # is not allowed for GitHub
	Write-Host ".. Secure download of latest release: $downloadURL"
	[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
	Invoke-WebRequest $downloadURL -OutFile $zip

	if ($action -match "download") {
		Write-Host -ForegroundColor Green "[Info] Downloaded version to folder: $RFL_path$RFL_file"
		}
	if ($action -match "update") {
		#save current Rfl-Check_ShellExtension.reg and expand
		 #Write-Host "... saving a copy of current installed check-rfl-csv_Tech_Path.ps1 to $($RFL_path + "check-rfl-csv_Tech_Path.ps1_v" + $installedRFLver)"
		 #Copy-Item ($RFL_path + "check-rfl-csv_Tech_Path.ps1") ($RFL_path + "check-rfl-csv_Tech_Path.ps1_v" + $installedRFLver) -Force -ErrorAction SilentlyContinue
		 Write-Host "... saving a copy of current Rfl-Check_ShellExtension.reg to $($RFL_path + "Rfl-Check_ShellExtension.reg_backup")"
		 Copy-Item ($RFL_path + "Rfl-Check_ShellExtension.reg") ($RFL_path + "Rfl-Check_ShellExtension.reg_backup") -Force -ErrorAction SilentlyContinue
		Write-Host "[Expand-Archive] Extracting release files from $zip"
		Expand-Archive  -Path $zip -DestinationPath $ENV:temp\$TmpDir -Force
		Write-Host ".. Cleaning up .."
		Write-Verbose "Cleaning up target dir: Remove-Item $name -Recurse"
		Write-Verbose "Copying from temp dir: $ENV:temp\$TmpDir to target dir: $RFL_path"
		Copy-Item $ENV:temp\$TmpDir\* -Destination $RFL_path -Recurse -Force
		Write-Verbose "Removing temp file: $zip and folder $TmpDir"
		Remove-Item $zip -Force
		Write-Verbose "Remove-Item $ENV:temp\$TmpDir -Recurse"
		Remove-Item $ENV:temp\$TmpDir -Recurse -Force -ErrorAction SilentlyContinue
		Write-Host -ForegroundColor Green "[Info] Updated with latest RFL version $script:expected_latest_RFL_version"
	}
	RflEndFunc $MyInvocation.MyCommand.Name
}

Function global:DownloadRFLZipFromCesdiagRelease {
	param(
		$file	# RFL.zip or RFLLite.zip
	)
	RflEnterFunc ($MyInvocation.MyCommand.Name + "(file: $file)")
	switch ($file) {
        "RFL.zip"  	{ $downloadURL = $RFL_release_url + "/RFL.zip" }
        "RFL_DB.zip" { $downloadURL = $RFL_release_url + "/RFL_DB.zip"  }
	}
	
	# faster Start-BitsTransfer
	Write-Host ".. Secure download of latest release: $downloadURL"
	Start-BitsTransfer $downloadURL -Destination "$ENV:temp\RFL_download.zip"
	#save current Rfl-Check_ShellExtension.reg and expand
	 #Write-Host "... saving a copy of current installed check-rfl-csv_Tech_Path.ps1 to $($RFL_path + "check-rfl-csv_Tech_Path.ps1_v" + $installedRFLver)"
	 #Copy-Item ($RFL_path + "check-rfl-csv_Tech_Path.ps1") ($RFL_path + "check-rfl-csv_Tech_Path.ps1_v" + $installedRFLver) -Force -ErrorAction SilentlyContinue
  	 Write-Host "... saving a copy of current Rfl-Check_ShellExtension.reg to $($RFL_path + "Rfl-Check_ShellExtension.reg_backup")"
	 Copy-Item ($RFL_path + "Rfl-Check_ShellExtension.reg") ($RFL_path + "Rfl-Check_ShellExtension.reg_backup") -Force -ErrorAction SilentlyContinue
	Write-Host "[Expand-Archive] Extracting release files from $ENV:temp\RFL_download.zip"
	expand-archive -LiteralPath "$ENV:temp\RFL_download.zip" -DestinationPath $RFL_path -force
	#ToDo
	RflEndFunc $MyInvocation.MyCommand.Name
}

Function global:FwTestTCPport{
  <#  # original name: Test-PSOnePort
      .SYNOPSIS
      Tests a network port on a remote computer

      .DESCRIPTION
      Tests whether a port on a remote computer is responding.

      .EXAMPLE
      FwTestTCPport -ComputerName 127.0.0.1 -Port 4000 -Timeout 1000 
      Tests whether port 4000 on the local computer is responding, 
      and waits a maximum of 1000 milliseconds

      .EXAMPLE
      FwTestTCPport -ComputerName 127.0.0.1 -Port 4000 -Timeout 1000 -Count 30 -Delay 2000
      Tests 30 times whether port 4000 on the local computer is responding, 
      and waits a maximum of 1000 milliseconds inbetween each test

      .EXAMPLE
      FwTestTCPport -ComputerName 127.0.0.1 -Port 4000 -Timeout 1000 -Count 0 -Delay 2000 -ExitOnSuccess
      Continuously tests whether port 4000 on the local computer is responding, 
      waits a maximum of 1000 milliseconds inbetween each test, 
      and exits as soon as the port is responding

      .LINK
      https://powershell.one/tricks/network/porttest
  #>
  param
  (
    [Parameter(Mandatory=$True)]
    [string]$ComputerName,
    # port number to test
    [Parameter(Mandatory=$True)]
    [int]$Port,
    # timeout in milliseconds
    [int]$Timeout = 500,
    # number of tries. A value of 0 indicates countinuous testing
    [int][ValidateRange(0,1000)]
    $Count = 1,
    # delay (in milliseconds) inbetween continuous tests
    $Delay = 2000,
    # when enabled, function returns as soon as port is available
    [Switch]$ExitOnSuccess
  )
  RflEnterFunc ($MyInvocation.MyCommand.Name + "(port: $Port)")
  $ok = $false
  $c = 0
  $isOnline = $false
  $continuous = $Count -eq 0 -or $Count -gt 1
  try
  {
    do
    {
      $c++
      if ($c -gt $Count -and !$continuous) { 
        # count exceeded
        break
      }
      $start = Get-Date
      $tcpobject = [system.Net.Sockets.TcpClient]::new()
      $connect = $tcpobject.BeginConnect($computername,$port,$null,$null) 
      $wait = $connect.AsyncWaitHandle.WaitOne($timeout,$false) 
      if(!$wait) { 
        # no response from port
        $tcpobject.Close()
        $tcpobject.Dispose()
        Write-Verbose "Port $Port is not responding..."
        if ($continuous) { Write-Host '.' -NoNewline }
      } else { 
        try { 
          # port is reachable
          if ($continuous) { Write-Host '!' -NoNewline }
          [void]$tcpobject.EndConnect($connect)
          $tcpobject.Close()
          $tcpobject.Dispose()
          $isOnline = $true
          if ($ExitOnSuccess)
          {
            $ok = $true
            $delay = 0
          }
        }
        catch { 
          # access to port restricted
          throw "You do not have permission to contact port $Port."
        } 
      } 
      $stop = Get-Date
      $timeUsed = ($stop - $start).TotalMilliseconds
      $currentDelay = $Delay - $timeUsed
      if ($currentDelay -gt 100)
      {
        Start-Sleep -Milliseconds $currentDelay
      }
    } until ($ok)
  }
  finally
  {
    # dispose objects to free memory
    if ($tcpobject)
    {
      $tcpobject.Close()
      $tcpobject.Dispose()
    }
  }
  if ($continuous) { Write-Host }
  RflEndFunc ($MyInvocation.MyCommand.Name + "($isOnline)")
  return $isOnline
}

Function global:FwTestConnWebSite{
	# Purpose: check internet connectivity to WebSite
	# Results: True = machine has internet connectivity, False = no internet connectivity
		#_#$checkConn = Test-NetConnection -ComputerName $WebSite -CommonTCPPort HTTP -InformationLevel "Quiet"
	param
	(
		[string]$WebSite = "cesdiagtools.blob.core.windows.net"
	)
	RflEnterFunc ($MyInvocation.MyCommand.Name + "(site: $WebSite)")
	$checkConn =$False
	if ($WebSite) {
		try {
			$checkConn = FwTestTCPport -ComputerName $WebSite -Port 80 -Timeout 900 
			}
        catch { LogError "[FwTestConnWebSite] WebSite to test is: $WebSite - checkConn: $checkConn"}
	} else { LogError "[FwTestConnWebSite] WebSite to test is: NULL "}
	RflEndFunc ($MyInvocation.MyCommand.Name + "($checkConn)")
	return $checkConn
}
#endregion ::::: [RFL Functions] --------------------------------------------------#

Export-ModuleMember -Function * -Cmdlet * -Variable * -Alias *

