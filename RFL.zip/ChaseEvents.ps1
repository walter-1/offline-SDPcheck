<# File Name: ChaseEvents.ps1
	last edit by: waltere 2022-09-14
	Objective: This script will parse all the system event logs in the SDP folder, looking for the ID you're looking for
	supplied by Willy Moselhy (IBS) <v-waalmo@microsoft.com> & sergeg@microsoft.com
#>

<#
.SYNOPSIS
The script will parse all the system event logs in the SDP folder, looking for the ID you're looking for.

SYNTAX: .\ChaseEvents.ps1 -EventId [ID or comma separated list] -EventLevel [Critical|Error|Warning|Information|Verbose] -SDPPath [full-path-to-expanded-SDP-report]

.DESCRIPTION
The script will parse all the system event logs in the SDP folder, looking for the ID you're looking for.
It is mandatory to provide either EventId or EventLevel"
Note: You can give one of them or both, but none will stop.

Output file with table of nodes will be located in same folder with name !PStat_Sum_Compared.txt

If you experience PS error '...is not digitally signed.' run the command:
 Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned

.PARAMETER ShowCommand
 This switch will cause the script to display a popup for manual choices

.EXAMPLE
 ChaseEvents.ps1 -EventId 5120 -Format YMDH -Days 7 -SDPPath \\MyPC\temp\SDPs\ClusterReports
 This command will look for event IDs 5120 that happened in the last 7 days in all the system event logs of the SDP folder.

.EXAMPLE
 ChaseEvents.ps1 -EventID 5120 -Format YMDH -Days 7 -Verbosity Verbose -SDPPath C:\SDPs\ClusterReports -HostMode
 Same as above but will add the CSV that had an error and its error code
 This command will show logging on the screen

.EXAMPLE
 ChaseEvents.ps1 -EventId 1069,1146 -Format YMD -Days 30 -SDPPath C:\SDPs\ClusterReports -ScriptMode
 Will look for event IDs 1069 & 1146 that happened in the last month
 This command will show script processing in log file xxx.log

.EXAMPLE
 ChaseEvents.ps1 -EventLevel Critical -Format YMD -SDPPath C:\SDPs\ClusterReports
 Will look for all the critical events that were logged

 .EXAMPLE
 ChaseEvents.ps1 -Help -SDPPath .
 Will show more script specific help options

.LINK
 \emeacssdfs.europe.corp.microsoft.com\netpod\rfl\ChaseEvents.ps1
 v-waalmo@microsoft.com ; sergeg@microsoft.com ; waltere@microsoft.com
 #>

PARAM (
	[Parameter(Mandatory = $true,Position=0,HelpMessage='Choose a writable SDP folder location, i.e. C:\SR\SDP-report\ ')]
	[String] $SDPPath,			# Path to SDP result folder
	[string[]]$EventId = "6005", 	# The EventId we're looking for
	[ValidateSet("Critical", "Error", "Warning", "Information", "Verbose")][string[]]$EventLevel, # We can also filter by level
	[int]$Days, 					# The history in Days we want to read
	[switch]$Help, 					# Show the help
	[ValidateSet("YMD", "YMDH", "YMDHM", "YMDHMS", "YMDHMSm")][string]$TimeFormat, # This is the level of precision we want
	[switch]$VerboseOutput, 		# Used for verbose debugging output
	[ValidateSet("Minimal", "Standard", "Verbose")][string]$Verbosity = "Minimal", # To display detail information
	[switch]$Multiline, 			# Switch to choose to have events on multiline
	[switch]$ShowCommand = $false,	# Switch to use Show-Command
	[switch]$HostMode  = $false,	#This tells the logging functions to show logging on the screen
	[switch]$ScriptMode = $false,	#This tells the logging functions to show logging into log file
	[switch]$UseExitCode= $true   #This will cause the script to close after the error is logged if an error occurs.
)

#region BEGIN
BEGIN {
	$verDateScript = "2022.09.14.0"
	$ScriptFolder = Split-Path $MyInvocation.MyCommand.Path -Parent
	# Load Common Library
	  Remove-Module Utils_RflShared -ErrorAction Ignore
	  Import-Module $ScriptFolder\Utils_RflShared.psm1 -DisableNameChecking
	$ScriptBeginTimeStamp = Get-Date
	# This saves the starting ErrorActionPreference and then sets it to 'Stop'.
	$startErrorActionPreference = $errorActionPreference
	$errorActionPreference = 'Stop'
	# This gets the current path and name of the script.
	$invocation = (Get-Variable MyInvocation).Value
	$scriptPath = Split-Path $invocation.MyCommand.Path
	$scriptName = $invocation.MyCommand.Name
	Write-Host "Running `"$scriptPath\$scriptName`"..." -BackgroundColor Black -ForegroundColor Green

	### Trail SDPPath with \ and allow path with space character
	if ($SDPPath.EndsWith("\")){$SDPPath="$SDPPath"}
	else {$SDPPath="$SDPPath" +"\"}
	If (-NOT (Test-Path $SDPPath -PathType 'Container')){Throw "$($SDPPath) is not a valid folder"}

#region: ###### customization section of script, logging configuration ########################
	$SDPcheckINI = (Get-content -Path "$ScriptFolder\version_SDPcheck.dat")
	$InOfflineMode 	= (($SDPcheckINI[1] -split " ")[2]).trim("""")	# set $True for outsourcer or when not connected to MS network - offline-SDPcheck
	if ($InOfflineMode -match "False") {
		$StatsServer = (($SDPcheckINI[4] -split " ")[2]).trim("""")
		if (Test-Connection -ComputerName $StatsServer -Quiet -Count 1) {[bool]$Stats=$True} else {[bool]$Stats=$False}
	} else { 
		$Stats = $False
	}
	$ErrorActionPreference = "Continue" #"Stop"
	$LogLevel = 0
	if ($Stats) {
		$StatsServerPath="\\$StatsServer\netpod\RFL\scripts\Stats\"
		$CountInvFil = $StatsServerPath +'countChaseEvt.dat'
		$CountInvFil2 = $CountInvFil +'.us'
	}
	$LogPath = $SDPPath + "_" +$scriptName +".log"
#endregion: ###### customization section
	$CheckDate = (Get-Date).ToUniversalTime().ToString("yy-MM-dd_HH-mm-ss")

	Set-Variable -Name ErrorMsgPS -Scope Script -Force
	If ($Stats) { #increment at start of script
	 ($j=[int32](Get-Content $CountInvFil -TotalCount 1 -ErrorAction SilentlyContinue)) |out-null
	 (++$j) | Set-Content $CountInvFil -ErrorAction SilentlyContinue
	}
	If ($PSBoundParameters['Debug']) { $DebugPreference='Continue'}

#region FUNCTION DEFINITIONS
	# ::::: FUNCTIONS :::::
	#
	#  Show_Help()              : Shows the help
	#  Check_Arguments()        : Check if either EventID or EventLevel is mentionned
	#  Check_TimeFormat()       : Check if the output format is supported
	#  Check_Set_Delay()        : Set the history used if set
	#  Build_Query()            : Build the XML Query according to the arguments provided
	#  GetEventFromCellString() : Export the EventID from a string
	#  GetEventCountFromCellString() : Export the number of occurences from a string
	#  Get_Detail()             : Get additional information from the event
#endregion FUNCTION DEFINITIONS

#region: Helper function
  function Show_Help() {
    Write-Host "Chase-Events.ps1 (v$verDateScript )`n" -ForegroundColor Yellow
    Write-Host "Put the script in your SDP report output and run it with the following switches"
    Write-Host "It will parse all the system event logs in the current folder, looking for the ID you're looking for`n"
    Write-Host "In each column you have the EventID and the number of time it's been logged"
    write-host " -help    : Shows this help"
    write-host " -Days    : Number of days you want to go back (if not set, we'll go as far as the event log goes)"
    write-host " -EventID  : Choose one or several events to filter. For example -EventID 5120 or -EventID 1069,1146,1135 *"
    write-host " -EventLevel : Choose one or several Levels to filter. For example -EventLevel Critical or -EventLevel Critical,Error *"
    write-host "        Accepted values are Critical, Error, Warning, Information, Verbose"
    write-host " -TimeFormat : The output format you want to display"
    write-host "        - YMD (Default) : An output of only Year-Month-Day"
    write-host "        - YMDH        : An output of only Year-Month-Day Hour"
    write-host "        - YMDHM       : An output of only Year-Month-Day Hour:Minute"
    write-host "        - YMDHMS      : An output of only Year-Month-Day Hour:Minute:Second"
    write-host "        - YMDHMm      : An output of only Year-Month-Day Hour:Minute:Second.Millisecond"
    write-host " -Verbosity : The table can display different level data"
    write-host "        - Minimal (Default) : Just counts the occurence of events with no detail on the event"
    write-host "        - Standard     : Adds a detail on the event (often the 1rst parameter)"
    write-host "        - Verbose      : Adds details on the event`n"
    write-host " -Multiline : Gives the possibility to split the events details in multiple lines"
    write-host "        Default Value is unset : All the data are appended to the same line"
    write-host " Notes : "
    write-host "  - If the path of the current folder contains `[ or `] the script will fail"
    write-host "   Powershell apparently does not like these characters`n"
    write-host "  * It is mandatory to provide either EventId or EventLevel"
    write-host "   You can give one of them or both, but none will stop.`n"
    write-host " Examples:`n"
    write-host "  .\Chase-Several-Events.ps1 -EventId 5120 -Format YMDH -Days 7"
    write-host "    Will look for event IDs 5120 that happened in the last 7 days in all the"
    write-host "    system event logs of the current folder`n"
    write-host "  .\Chase-Several-Events.ps1 -EventID 5120 -Format YMDH -Days 7 -Verbosity Verbose"
    write-host "    Same as above but will add the CSV that had an error and its error code`n"
    write-host "  .\Chase-Several-Events.ps1 -EventId 1069,1146 -Format YMD -Days 30"
    write-host "    Will look for event IDs 1069 & 1146 that happened in the last month`n"
    write-host "  .\Chase-Several-Events.ps1 -EventLevel Critical -Format YMD"
    write-host "    Will look for all the critical events that were logged`n"
    Write-Host "Run this tool from a machine with Powershell 5.1 or above (Win10 is fine)"
    write-host " (`$Host to know the version you're running on)."
    Write-Host ""
    break
  }
#endregion Helper function

#region: Script Functions
  function Check_Arguments() {
    if (!$EventId -and !$EventLevel) {
      Write-Host "Either EventId or EventLevel is mandatory"
      Write-Host "Run with -Help for more information`n"
      Break
    }
  }
  function Check_TimeFormat() {

    if ($TimeFormat) {
      if (($TimeFormat -notmatch "YMD") -and ($TimeFormat -notmatch "YMDH") -and ($TimeFormat -notmatch "YMDHM") -and ($TimeFormat -notmatch "YMDHMS") -and ($TimeFormat -notmatch "YMDHMSm")) {
        Write-Host "Bad output format. Must be either YMD, YMDH or YMDHM"
        Write-Host "Run -help for more information"
        break
      }
    }
  }
  function Check_Set_Delay() {
    # ----- 1 day = 86400000 milliseconds
    [long]$Delay_1D = 86400000
    if (-not $Days) {
      $Global:Ever = $true
    }
    else {
      $Global:Ever = $false
      $Global:Delay = $Delay_1D * $Days
    }
  }
  function Build_Query() {

    # ----- Very convenient way to have tables of everything
    #    indexed with everything
    $EventLevelToString = @{}
    $EventLevelToString['Critical'] = "Level=1"
    $EventLevelToString['Error'] = "Level=2"
    $EventLevelToString['Warning'] = "Level=3"
    $EventLevelToString['Information'] = "Level=4 or Level=0"
    $EventLevelToString['Verbose'] = "Level=5"

    # ----- Build the Event ID's list
    if ($EventId.Count -ne 0) {
      $StrListOfEvents = "EventID=" + $EventId[0]
      for ($i = 1; $i -lt $EventId.Count; $i++) {
        $StrListOfEvents += " or EventID=" + $EventId[$i]
      }
      $StrListOfEvents = "(" + $StrListOfEvents + ")"
    }
    else {
      $StrListOfEvents = "(no id)"
    }
    # ----- Build the Event Level's list
    if ($EventLevel.Count -ne 0) {
      $StrListOfLevels = $EventLevelToString[$EventLevel[0]]
      for ($i = 1; $i -lt $EventLevel.Count; $i++) {
        $StrListOfLevels += " or " + $EventLevelToString[$EventLevel[$i]]
      }
      $StrListOfLevels = "(" + $StrListOfLevels + ")"
    }
    else {
      $StrListOfLevels = "(no level)"
    }
    # ----- Build the ID + Level string
    if ($EventId -and $EventLevel) {
      $StrFilter = $StrListOfEvents + " and " + $StrListOfLevels
    }
    elseif ($EventId -and !$EventLevel) {
      $StrFilter = $StrListOfEvents
    }
    elseif (!$EventId -and $EventLevel) {
      $StrFilter = $StrListOfLevels
    }
    else {
      $StrFilter = "Ouelou!"
    }
    # Build the XML Query
    if ($Ever) {
      $Global:Query = "<QueryList><Query><Select>*[System[" + $StrFilter + "]]</Select></Query></QueryList>"
    }
    else {
      $Global:Query = "<QueryList><Query><Select>*[System[" + $StrFilter + " and TimeCreated[timediff(@SystemTime) &lt;= $Delay]]]</Select></Query></QueryList>"
    }
  }
  function GetEventFromCellString([string]$String) {
    return $String.split('()')[0]
  }
  function GetEventCountFromCellString([string]$String) {
    return [convert]::ToInt32($String.split('()')[1], 10)
  }
  function Pause() {
    Read-Host 'Press Enter to continue...' | Out-Null
  }
  function Get_Detail(
	[System.Diagnostics.Eventing.Reader.EventRecord]$EventRecord,
    [string]$OutputLevel) 
	{
    #  $OutputLevel reflects the $Output argument
    #  It can be "Minimal", "Standard" or "Verbose"

    if ($Multiline) {
      $Sep = "`n"
    }
    else {
      $Sep = '|'
    }
    # write-host "Id:"$EventRecord.Id -ForegroundColor Yellow
    if ($OutputLevel -eq "Minimal") {
      $Result = ""
    }
    else {
      switch ($EventRecord.Id) {
        "1069" {
          # ----- Resource Failed - WS16
          #    Properties[0]: ResourceName
          #    Properties[1]: ResourceGroup
          #    Properties[2]: ResTypeDll
          if ($OutputLevel -eq "Standard") {
            $Result = $EventRecord.Properties[0].Value
          }
          else {
            $Result = $EventRecord.Properties[0].Value + $Sep + $EventRecord.Properties[1].Value + $Sep + $EventRecord.Properties[2].Value
          }
          break
        }
        "1135" {
          # ----- Connection loss with a node - Get the node name
          $Result = $EventRecord.Properties[0].Value
          break
        }
        "1177" {
          # ----- Cluster Service is shutting down - Nothing in the event but the name of the current node
          $Result = $EventRecord.Properties[0].Value
          break
        }
        "1146" {
          # ----- RHS Deadlock - Nothing in the event but the name of the current node
          $Result = $EventRecord.Properties[0].Value
          break
        }
        "1230" {
          # ----- Cluster resource Timeout - For WS16
          #    Properties[0]: ResourceName
          #    Properties[1]: ResourceType
          #    Properties[2]: ResTypeDll
          if ($OutputLevel -eq "Standard") {
            $Result = $EventRecord.Properties[0].Value
          }
          else {
            $Result = $EventRecord.Properties[0].Value + $Sep + $EventRecord.Properties[1].Value + $Sep + $EventRecord.Properties[2].Value
          }
          break
        }
        "1564" {
          # ----- Failed to arbitrate for the file share
          #    Properties[0]: ResourceName
          #    Properties[1]: ShareName
          #    Properties[2]: BinaryParameterLength
          #    Properties[3]: BinaryData
          if ($OutputLevel -eq "Standard") {
            $Result = $EventRecord.Properties[0].Value
          }
          else {
            $Result = $EventRecord.Properties[0].Value + $Sep + $EventRecord.Properties[1].Value
          }
          break
        }
        "5120" {
          # ----- CSV entered a paused state - For WS16:
          #    Properties[0]: VolumeName (Volume5, Volume3, etc.)
          #    Properties[1]: ResourceName (Cluster Disk 7, Cluster Disk 1, etc.)
          #    Properties[2]: ErrorCode (STATUS_CONNECTION_DISCONNECTED, STATUS_NO_SUCH_DEVICE, etc.)
          #    Properties[3]: DiskDeviceNumber : a number
          #    Properties[4]: DiskDeviceGuid : a GUID
          if ($OutputLevel -eq "Standard") {
            $Result = $EventRecord.Properties[1].Value
          }
          else {
            $Result = $EventRecord.Properties[1].Value + $Sep + $EventRecord.Properties[2].Value
          }
          break
        }
        "5142" {
          # ----- CSV No longer accessible
          #    Properties[0] : VolumeName (Volume5, Volume3, etc.)
          #    Properties[1] : ResourceName (Cluster Disk 7, Cluster Disk 1, etc.)
          #    Properties[2] : ErrorCode (1460, etc.)
          #    Properties[3] : ReasonCode (UnmapReasonCsvFsStateTransitionTimeout, etc.)
          #    Properties[4] : DiskDeviceNumber : a number
          #    Properties[5] : DiskDeviceGUID : a GUID if any
          if ($OutputLevel -eq "Standard") {
            $Result = $EventRecord.Properties[1].Value
          }
          else {
            $Result = $EventRecord.Properties[1].Value + $Sep + $EventRecord.Properties[2].Value + $Sep + $EventRecord.Properties[3].Value
          }
          break
        }
        "6008" {
          # ----- Unexpected Reboot
          #    Properties[0] : Time
          #    Properties[1] : Date
          $Result = $EventRecord.Properties[1].Value + ' ' + $EventRecord.Properties[0].Value
          break
        }
        "6013" {
          # ----- System Uptime
          #    Properties[4] : Time in seconds
          $TSpan = $EventRecord.Properties[4].Value
          $Result = "d{0} {1}h{2}m{3}s" -f [timespan]::fromseconds($TSpan).Days , [timespan]::fromseconds($TSpan).Hours , [timespan]::fromseconds($TSpan).Minutes , [timespan]::fromseconds($TSpan).Seconds
          break
        }
        "41" {
          # ----- It can contain a BSOD in the first paramerer (but the value is in decimal)
          #    Properties[0] : "0" or BSOD if any
          if ($EventRecord.Properties[0].Value -eq "0") {
            $Result = '-'
          }
          else {
            $Result = 'BSOD 0x{0:X}' -f $EventRecord.Properties[0].Value
          }
          break
        }
        "1001" {
          # ----- Bugcheck
          #    Properties[0] : The BSOD
          $Result = $EventRecord.Properties[0].Value
          break
        }
        "7036" {
          # ----- Status changed for a service
          #    Properties[0] : Service Name
          #    Properties[1] : Status
          if ($OutputLevel -eq "Standard") {
            $Result = $EventRecord.Properties[0].Value
          }
          else {
            $Result = $EventRecord.Properties[0].Value + $Sep + $EventRecord.Properties[1].Value
          }
          break
        }
        default {
          $Result = $EventRecord.Properties[0].Value
          break
        }
      }
    }
    return $Result
  } #end function Get_Detail


  function ChaseEvents {
  Param(
    [string[]]$EventId, # The EventId we're looking for
    [ValidateSet("Critical", "Error", "Warning", "Information", "Verbose")][string[]]$EventLevel, # We can also filter by level
    [int]$Days, # The history in Days we want to read
    [switch]$Help, # Show the help
    [ValidateSet("YMD", "YMDH", "YMDHM", "YMDHMS", "YMDHMSm")][string]$TimeFormat, # This is the level of precision we want
    [switch]$VerboseOutput, # Used for verbose debugging output
    [ValidateSet("Minimal", "Standard", "Verbose")][string]$Verbosity = "Minimal", # To display detail information
    [switch] $Multiline # Switch to choose to have events on multiline
  )

  # ::::: MAIN :::::
  #
  #  1. Parses the arguments
  #  2. Generates the query
  #  3. Runs the query
  #  4. Saves the output in a CSV
  #  5. Exports the output in a grid-view
  #

  # ::::: NEXT VERSION SHOULD INCLUDE :::::
  #  - Export to a real Excel file
  #    - Add some colors
  #    - Add a dialog that shows the entire event content when selecting an event
  #
  #  - For any suggestions, contact sergeg@microsoft.com

  # Show Help if asked - Includes a break
  if ($Help) {
    Show_Help
  }

  # EventId is mandatory - Breaks if missing
  # Check_EventId
  Check_Arguments

  # Check if the output format is set then correctly - breaks if not set correctly
  Check_TimeFormat

  # Check if an history is asked, then set the variables according
  $Global:Ever = $false
  $Global:Delay = 0
  Check_Set_Delay

  # Generating the query
  Build_Query

  # Create the output file
  #$CurrentDir = [System.IO.Path]::GetDirectoryName($myInvocation.MyCommand.Definition)
  if ($EventId.Count -eq 1) { $FileName = $EventId[0]}
  else { $FileName = "Events" }
  $OutputFile = $Script:SDPPath + $FileName + ".csv"

  # Display the query to be run
  Write-Host "Running this query:" -ForegroundColor Yellow
  Write-Host " "$Query

  # Build a class that will be used by the list of events
  # The Class works only starting powershell 5.1
  # It gives the possibility to easily build a list of stuctured elements
  # using a constructor we define
  #

  class Event {
    [string]$C_NodeName
    [string]$C_Date
    [string]$C_EventID
    [string]$C_Detail
    Event([string]$NodeName, [string]$Date, [string]$ID, [string]$Detail) {
      $this.C_NodeName = $NodeName
      $this.C_Date = $Date
      if ($Detail) {
        $this.C_Detail = $Detail
        $this.C_EventID = $ID + "[" + $Detail + "]"
      }
      else {
        $this.C_EventID = $ID
      }
    }
  }

  $ListOfEvents = @()
  $NodesList = @()

  # Browse and parse the system event logs in the current folder
  # We rely on the naming convention so
  # we're looking for "*System*.evtx" files
  #

  write-host "Events found per node (time for a coffee break)..." -ForegroundColor Yellow
  Get-ChildItem -Path $Script:SDPPath -Recurse | Where-Object Name -like "*System*evtx" | ForEach-Object {

    # Build the list of the nodes
    # Read the first event of each evtx file, get the MachineName field and build the list
    #

    $ServerName = (Get-WinEvent -MaxEvents 1 -Path $_.FullName).MachineName.Split('.')[0]

    if ($ServerName -notin $NodesList) {
      $NodesList += $ServerName
    }

    # Collect the events and build the list
    write-host " "$ServerName": " -NoNewline
    $EventsFound = Get-WinEvent -Path $_.FullName -FilterXPath $Query -ErrorAction SilentlyContinue

    if ($EventsFound.count -eq 0) {
      write-host "none"
    }
    else {
      write-host $EventsFound.count

      $EventsFound | ForEach-Object {

        if ($_.TimeCreated.Month -lt 10) { $Month = "0" + $_.TimeCreated.Month } else { $Month = $_.TimeCreated.Month }
        if ($_.TimeCreated.Day -lt 10) { $Day = "0" + $_.TimeCreated.Day } else { $Day = $_.TimeCreated.Day }
        if ($_.TimeCreated.Hour -lt 10) { $Hour = "0" + $_.TimeCreated.Hour } else { $Hour = $_.TimeCreated.Hour }
        if ($_.TimeCreated.Minute -lt 10) { $Minute = "0" + $_.TimeCreated.Minute } else { $Minute = $_.TimeCreated.Minute }
        if ($_.TimeCreated.Second -lt 10) { $Second = "0" + $_.TimeCreated.Second } else { $Second = $_.TimeCreated.Second }
        if ($_.TimeCreated.Millisecond -lt 10) {
          $Millisecond = "00" + $_.TimeCreated.Millisecond
        }
        elseif ($_.TimeCreated.Millisecond -lt 100) {
          $Millisecond = "0" + $_.TimeCreated.Millisecond
        }
        else {
          $Millisecond = $_.TimeCreated.Millisecond
        }

        # TimeFomrat can be : "YMD","YMDH","YMDHM","YMDHMS","YMDHMSm"
        if (!$TimeFormat -or $TimeFormat -eq "YMDHMS") {
          $Date = ("{0} {1} {2}-{3}:{4}:{5}" -f $_.TimeCreated.Year, $Month, $Day, $Hour, $Minute, $Second)
        }
        elseif ($TimeFormat -eq "YMD") {
          $Date = ("{0} {1} {2}" -f $_.TimeCreated.Year, $Month, $Day)
        }
        elseif ($TimeFormat -eq "YMDH") {
          $Date = ("{0} {1} {2}-{3}" -f $_.TimeCreated.Year, $Month, $Day, $Hour)
        }
        elseif ($TimeFormat -eq "YMDHM") {
          $Date = ("{0} {1} {2}-{3}:{4}" -f $_.TimeCreated.Year, $Month, $Day, $Hour, $Minute)
        }
        else {
          $Date = ("{0} {1} {2}-{3}:{4}:{5}.{6}" -f $_.TimeCreated.Year, $Month, $Day, $Hour, $Minute, $Second, $Millisecond)
        }

        # $Verbosity can be either "Minimal", "Standard" or "Verbose"
        if ($Verbosity -eq "Minimal") {
          $ListOfEvents += [Event]::New($ServerName, $Date, $_.ID, $null)
        }
        else {
          $EventDetail = Get_Detail $_ $Verbosity
          $ListOfEvents += [Event]::New($ServerName, $Date, $_.ID, $EventDetail)
        }
      }
    }
  }

  # Arranging the nodes list by alphabetical order
  # <IMPROVEMENTS>
  #  In a clustering content, add the node number in ()
  #  This should be possible by loading the registry hive availavle in an SDP Report
  # </IMPROVEMENTS>

  # Ordering the list of nodes
  $NodesList = $NodesList | Sort-Object

  # Ordering events per date and group per date
  $ListOfEvents = $ListOfEvents | Sort-Object C_Date -Descending

  if ($ListOfEvents.Count -eq 0) {
    Write-Host "Nothing to display, but the result is saved."
  }
  else {
    # ----- Creation of an Excel sheet

    $excel = New-Object -ComObject Excel.Application
    $excel.Visible = $false
    $workbook = $excel.Workbooks.Add()
    $Sheet = $workbook.worksheets.Item(1)

    if ($EventId.Count -eq 1) {
      $Sheet.Name = $EventId[0]
    }
    else {
      $Sheet.Name = "Events"
    }

    # ----- Build the list of columns

    $Sheet.Cells.Item(1, 1) = "Date Time"
    for ($Column = 0; $Column -lt $NodesList.Count; $Column++) {
      $Sheet.Cells.Item(1, $Column + 2) = $NodesList[$Column]
    }

    # ----- NodesToColumn allows to get the column name from the node name
    $NodesToColumn = @{}
    for ($i = 0; $i -lt $NodesList.Count; $i++) {
      $NodesToColumn[$NodesList[$i]] = $i + 2
    }

    # Fill the tables with the data
    <#
    The EventsList is already ordered by Date

    Each cell contains either nothing, or an EventID with the number of occurences it's been logged at the same time
    For example: "1234(7)" means that seven 1234 events have been logged at the same time by the same node

    For each event : Look for the date in the first column of the table
    - If no date in the table matches the date of the event
      - Add a new line to the table and set the date to the first column
      - Add the EventID to Cell corresponding to the new date and the node
    - Else
      - If the cell corresponding to the Node and the Date is empty
        - Add the EventId to the cell with an occurence counte set to 1
      - Else (The cell is not empty)
        - If the Cell contains the same EventID : Increment the count by 1
        - Else (the Cell contains a different EventID) :
          - Add a new line to the table and set the date to the first column
          - Add the EventID to Cell corresponding to the new date and the node
  #>

    Write-Host "Building the table (time for a second coffee break)..." -ForegroundColor Yellow
    # --- Browse the events list

    $index = 0
    $ListOfEvents | ForEach-Object {
      $index++
      $ThisEvent = $_
      if ($VerboseOutput) {
        write-host "Handling event"$index" : " -NoNewline -ForegroundColor Yellow
        $ThisEvent
      }

      # ============================= Looking for a date in the table that matches the event date

      # ----- Define the Date column
      #    Better to reset the date range for each new event as I don't know
      #    if 'EntireColumn' is really entire or stops at the last used row
      #
      $DateRange = $Sheet.Range("A1").EntireColumn

      # ----- Look for the dates in the first column
      #    $CorrespondingDates is the list of rows containing a matching date
      #
      $CorrespondingDates = $null
      $CorrespondingDates = @()
      $DateFound = $false

      $TargetDate = $DateRange.Find($ThisEvent.C_Date)
      if ($null -ne $TargetDate) {
        $DateFound = $true
        $FirstDateFound = $TargetDate
        Do {
          $CorrespondingDates += [convert]::ToInt32($TargetDate.row, 10)
          $TargetDate = $DateRange.FindNext($TargetDate)
        }While (( $null -ne $TargetDate) -and ($TargetDate.AddressLocal() -ne $FirstDateFound.AddressLocal()))
      }

      # ========================= We haven't found any line with the same date : Create a new one
      #
      if ($DateFound -eq $false) {

        # ----- Add a new line a the end of the table
        #    We add it at the end because $ListOfEvents is already sorted by date
        $LastUsedLine = $Sheet.UsedRange.Rows.Count

        # Add the date to the following row
        $Sheet.Cells.Item($LastUsedLine + 1, 1) = $ThisEvent.C_Date

        # Add EventId to the cell that corresponds to the node, and give it a count of (1) as it is the first occurence
        $Sheet.Cells.Item($LastUsedLine + 1, $NodesToColumn[$ThisEvent.C_NodeName]) = $ThisEvent.C_EventID + "(1)"
      }

      # ====================================== We have found at least one line with the same date
      #
      else {

        # ------------------------------------ If We find only one matching date (the easy one)
        # ----- We check if the event corresponds
        #    - If the cell is empty : Add the new event with count(1)
        #    - If the cell is not empty : Check the content
        #      - If the event corresponds : Increment the count
        #      - If the event does not correspond : Add a new row
        #

        if ($CorrespondingDates.count -eq 1) {

          # ----- Read the cell
          $TheCellRow = [convert]::ToInt32($CorrespondingDates[0], 10)
          $TheCellCol = [convert]::ToInt32($NodesToColumn[$ThisEvent.C_NodeName], 10)
          $CellContent = $Sheet.Cells.Item($TheCellRow, $TheCellCol).text

          # ----- The cell is empty : Add the event
          if ($CellContent -eq "") { # an empty cell is not $null but ""
            $NewCellValue = $ThisEvent.C_EventID + "(1)"
            $Sheet.Cells.Item($TheCellRow, $TheCellCol) = $NewCellValue
          }
          # ----- The cell is not empty : Check the content
          #    - If the EventId is the same : Increment the count
          #    - If the EventId is different : Add a new row
          else {
            # ----- Get the Event Part
            $EventInTheCell = GetEventFromCellString($CellContent)

            # ----- The cell contains the same EventId : Increment the count
            if ($EventInTheCell -eq $ThisEvent.C_EventID) {
              $TheCellRow = [convert]::ToInt32($CorrespondingDates[0], 10)
              $TheCellCol = [convert]::ToInt32($NodesToColumn[$ThisEvent.C_NodeName], 10)

              [int32]$EventsCount = GetEventCountFromCellString($CellContent)
              $EventsCount += 1

              [string]$strEventCount = "(" + [convert]::ToString($EventsCount) + ")"
              $NewCellValue = $ThisEvent.C_EventID + $strEventCount

              $Sheet.Cells.Item($TheCellRow, $TheCellCol) = $NewCellValue
            }
            # ------ The Cell contains a different EventId : Create a new row and fill the date & cell
            else {
              # Get the last row of the table
              $LastUsedLine = $Sheet.UsedRange.Rows.Count

              # Add a new row, then fill it with the new data
              $NewRow = $LastUsedLine + 1
              $Sheet.Cells.Item($NewRow, 1) = $ThisEvent.C_Date
              $Sheet.Cells.Item($NewRow, $TheCellCol) = $ThisEvent.C_EventID + "(1)"
            }
          }
        } # End of block "One matching date"

        # --------------------------------------------------- If We find several matching dates
        # ----- We check if one of them matches the event
        #    - If one of them matches the event : Increment the count
        #    - If none of them matches the event
        #      - If one of them is empty : Add the date
        #      - If none is empty : Add a line
        #  Recall:
        #   $CorrespondingDates @()   : Contains the list of the rows with the same date
        #   $ThisEvent         : Contains the current event
        #     C_Date
        #     C_EventId
        #     C_NodeName
        #   $Sheet.Cells.Item()     :
        #   $Sheet.Cells.Item().text  : Content of the Cell
        #

        else {

          # ----- Check if one of the cells matches the event
          $TheCellCol = [convert]::ToInt32($NodesToColumn[$ThisEvent.C_NodeName], 10)
          $MatchFound = $false
          $MatchingRow = 0
          $EmptyRows = @()

          # ----- We use a for loop instead of a ForEach-Object because
          #    break would leave the program instead of the only block
          for ( $i = 0 ; $i -lt $CorrespondingDates.count; $i++) {
            $TheCellRow = $CorrespondingDates[$i]
            $CellContent = $Sheet.Cells.Item($TheCellRow, $TheCellCol).text
            $EventInTheCell = GetEventFromCellString($CellContent)

            # --- If the cell is empty, add it to a list of empty cells
            #   We'll use the first of them to add the EventId if don't catch a matching Event Id
            if ($EventInTheCell -eq "") {
              $EmptyRows += $CorrespondingDates[$i]
            }
            elseif ($EventInTheCell -eq $ThisEvent.C_EventID) {
              $MatchingRow = $TheCellRow
              $MatchFound = $true
              break
            }
          }

          # ----- If we find one, we increment the count
          #    No need to read back the cell content : It's been read in the above look
          #    No need to reset the cell column : It's been set at the top of the block
          #    We're using the $MatchinRow as TheCellRow because it's been set in the above loop
          if ($MatchFound -eq $true) {
            [int32]$EventsCount = GetEventCountFromCellString($CellContent)
            $EventsCount += 1
            [string]$strEventCount = "(" + [convert]::ToString($EventsCount) + ")"
            $NewCellValue = $ThisEvent.C_EventID + $strEventCount
            $Sheet.Cells.Item($MatchingRow, $TheCellCol) = $NewCellValue
          }
          # ----- No match found : We must know there is an empty space
          #    - If there is an empty cell : Update this cell
          #    - If there is no empty cell and no matching event : Create a new row
          else {
            # ----- There is an empty cell : Set the cell with the EventId
            if ($EmptyRows.count -ne 0) {
              $NewCellValue = $ThisEvent.C_EventID + "(1)"
              $TheCellRow = [convert]::ToInt32($EmptyRows[0], 10)
              $Sheet.Cells.Item($TheCellRow, $TheCellCol) = $NewCellValue
            }
            # ------ There is neither empty cell nor matching event : Add a new line
            else {
              $LastUsedLine = $Sheet.UsedRange.Rows.Count
              $NewRow = $LastUsedLine + 1
              $Sheet.Cells.Item($NewRow, 1) = $ThisEvent.C_Date
              $Sheet.Cells.Item($NewRow, $TheCellCol) = $ThisEvent.C_EventID + "(1)"
            }
          }
        } # End of block "Several matching dates"
      } # End of block "At least one line with the same event is found"
    } # End of $ListOfEvents loop
  } # End if block" ListOfEvents -ne 0"

  # Save the Excel file quit Excel
  $Sheet.SaveAs($OutputFile, 6)
  $excel.Quit()

  # Display the output file using a GridView
  # The output file is still available as a CSV
  write-host "The result is stored in: " -ForegroundColor Yellow -NoNewline
  Write-Host $OutputFile

  Write-Host "Exporting the result in a grid-view" -ForegroundColor Yellow
  Import-Csv $OutputFile | Out-GridView -Title $FileName
	} #end of function ChaseEvents
  }
#endregion Script Functions
#endregion BEGIN

PROCESS {
  try {
		#region: MAIN :::::
		WriteInfo -message "Starting '$scriptName' on $(Get-Date)"
		if($ShowCommand){
			$Command = Show-Command ChaseEvents -PassThru
			Invoke-Expression -Command $Command
			#exit
		}
		else{
			$Splatting = @{}
			if($EventId) {$Splatting.Add("EventID",$EventID)}
			if($EventLevel) {$Splatting.Add("EventLevel",$EventLevel)}
			if($Days)  {$Splatting.Add("Days",$Days)}
			if($Help)  {$Splatting.Add("Help",$Help)}
			if($TimeFormat)  {$Splatting.Add("TimeFormat",$TimeFormat)}
			if($VerboseOutput)  {$Splatting.Add("VerboseOutput",$VerboseOutput)}
			if($Verbosity)  {$Splatting.Add("Verbosity",$Verbosity)}
			if($Multiline)  {$Splatting.Add("Multiline",$Multiline)}

			ChaseEvents @Splatting
		}

		$ScriptEndTimeStamp = Get-Date
		$LogLevel = 0
		$Duration = $(New-TimeSpan -Start $ScriptBeginTimeStamp -End $ScriptEndTimeStamp)
		WriteInfo -message "Script $scriptName v$verDateScript execution finished. Duration: $Duration"
		#endregion: MAIN
  } catch {
    $errorMessage = "$scriptName caught an exception on $($ENV:COMPUTERNAME):"
    $errorMessage += "`n" + "`n"
    $errorMessage += "Exception Type: $($_.Exception.GetType().FullName)"
    $errorMessage += "`n" + "`n"
    $errorMessage += "Exception Message: $($_.Exception.Message)"

    Write-Error $errorMessage -ErrorAction Continue
		<# Log error
				Write-Verbose "Logging the script's error..."
		# Log error - EventLog
				#An event log source needs to be preconfigured to use this.
				Write-EventLog `
					-EventId $AlertNumber `
					-LogName $LogName `
					-Source $EventSource `
					-Message $errorMessage `
					-EntryType Error
		# Log error - Email
				# This will attempt to send an immediate alert about the error.
				# The EventLog also needs to log the error because this one may not be sent.
				#use Send-MailMessage
		#>
    Start-Sleep -Seconds 3
    Write-Debug $errorMessage
    if ( $UseExitCode ) {
			$error.clear()	# clear script errors
      exit 1
    } #end UseExitCode
  } #end Catch
} #end PROCESS

END {
  # This resets the ErrorActionPreference to the starting value.
  $errorActionPreference = $startErrorActionPreference

	### Stats
	If ($Stats) { #increment at start of script
		"$j" + " ;$CheckDate" + "; $OSVersion; " + ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name) + "; $($Duration)" + "; $NodeCnt" + "; $SDPPath" + "; $ErrorMsgPS" + "; v$verDateScript " | Out-File $CountInvFil2 -Append -Encoding UTF8 -ErrorAction SilentlyContinue
	}
}

#region :comments & ToDo's
<# ::::: CHASE-SEVERAL-EVENTS :::::
#
v-waalmo edits:
1) Add parameter to show-command by converting the script to a function
2) Add parameter SDPPath
3)
#  Merges the events we ask for in several columns
#  v1.3 : Added handling of events 41, 1001, 6008 & 6013
#     Added the -Multiline switch to decide wether to write all the events data
#     in one line or split it into multiple lines
#  v1.2 : Fixed a bug in the way we look for the system event logs
#
#  Improvements in vNext :
#  - Write to an Excel file instead of csv to add colors and more sophisticated outputs
#>
#endregion :comments & ToDo's


# SIG # Begin signature block
# MIInrgYJKoZIhvcNAQcCoIInnzCCJ5sCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDoXeroJ3YDuCbU
# R4gIkXUEJIiYZY1O5ZpyHHxEpTMO8aCCDXYwggX0MIID3KADAgECAhMzAAACy7d1
# OfsCcUI2AAAAAALLMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjIwNTEyMjA0NTU5WhcNMjMwNTExMjA0NTU5WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC3sN0WcdGpGXPZIb5iNfFB0xZ8rnJvYnxD6Uf2BHXglpbTEfoe+mO//oLWkRxA
# wppditsSVOD0oglKbtnh9Wp2DARLcxbGaW4YanOWSB1LyLRpHnnQ5POlh2U5trg4
# 3gQjvlNZlQB3lL+zrPtbNvMA7E0Wkmo+Z6YFnsf7aek+KGzaGboAeFO4uKZjQXY5
# RmMzE70Bwaz7hvA05jDURdRKH0i/1yK96TDuP7JyRFLOvA3UXNWz00R9w7ppMDcN
# lXtrmbPigv3xE9FfpfmJRtiOZQKd73K72Wujmj6/Su3+DBTpOq7NgdntW2lJfX3X
# a6oe4F9Pk9xRhkwHsk7Ju9E/AgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUrg/nt/gj+BBLd1jZWYhok7v5/w4w
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzQ3MDUyODAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAJL5t6pVjIRlQ8j4dAFJ
# ZnMke3rRHeQDOPFxswM47HRvgQa2E1jea2aYiMk1WmdqWnYw1bal4IzRlSVf4czf
# zx2vjOIOiaGllW2ByHkfKApngOzJmAQ8F15xSHPRvNMmvpC3PFLvKMf3y5SyPJxh
# 922TTq0q5epJv1SgZDWlUlHL/Ex1nX8kzBRhHvc6D6F5la+oAO4A3o/ZC05OOgm4
# EJxZP9MqUi5iid2dw4Jg/HvtDpCcLj1GLIhCDaebKegajCJlMhhxnDXrGFLJfX8j
# 7k7LUvrZDsQniJZ3D66K+3SZTLhvwK7dMGVFuUUJUfDifrlCTjKG9mxsPDllfyck
# 4zGnRZv8Jw9RgE1zAghnU14L0vVUNOzi/4bE7wIsiRyIcCcVoXRneBA3n/frLXvd
# jDsbb2lpGu78+s1zbO5N0bhHWq4j5WMutrspBxEhqG2PSBjC5Ypi+jhtfu3+x76N
# mBvsyKuxx9+Hm/ALnlzKxr4KyMR3/z4IRMzA1QyppNk65Ui+jB14g+w4vole33M1
# pVqVckrmSebUkmjnCshCiH12IFgHZF7gRwE4YZrJ7QjxZeoZqHaKsQLRMp653beB
# fHfeva9zJPhBSdVcCW7x9q0c2HVPLJHX9YCUU714I+qtLpDGrdbZxD9mikPqL/To
# /1lDZ0ch8FtePhME7houuoPcMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGY4wghmKAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAALLt3U5+wJxQjYAAAAAAsswDQYJYIZIAWUDBAIB
# BQCggbAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIImgW0hB504lMSmriQlW1rU6
# kmjqZA2YSZX1g1LS6rAXMEQGCisGAQQBgjcCAQwxNjA0oBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEcgBpodHRwczovL3d3dy5taWNyb3NvZnQuY29tIDANBgkqhkiG9w0B
# AQEFAASCAQCSHWGHRmJUBBZH0xTWCGqDUsvHAa1IO86bCpQBfudcU/GdGDZlBU5m
# 1GddrLCD7aJVtCTIa+hfU9BRaO2KdObwT3fg6hzL3oAqkrVVUoCy13l70KpSN6ld
# IxGX45phL+0KRULTN1TdOsrj38RDst0zR6sHnnL0C5S2o67OzKZJb5frkdCX6F8H
# 5CB9jI9og3qwZAgjfaFikm/Qfz9tHT2CTHJ6WPdzXFYtL3Ps2bZWOcCKPTuOHGlK
# McseO671YFY3/LVyUdXSFkQTigIeSvgXHq+UbcmPI/65vgH3gaAKGatjrzmQMZEU
# 7oTuPs02v+EoAoFpDzi9X2i+zl2FZ8hQoYIXFjCCFxIGCisGAQQBgjcDAwExghcC
# MIIW/gYJKoZIhvcNAQcCoIIW7zCCFusCAQMxDzANBglghkgBZQMEAgEFADCCAVkG
# CyqGSIb3DQEJEAEEoIIBSASCAUQwggFAAgEBBgorBgEEAYRZCgMBMDEwDQYJYIZI
# AWUDBAIBBQAEICmCaw9yEv6Ysy5rSEP4Tkvaa9o/ZhLJbkqwLryvH1dpAgZjEWCu
# nUsYEzIwMjIwOTE0MTAyNTIyLjMwNFowBIACAfSggdikgdUwgdIxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJ
# cmVsYW5kIE9wZXJhdGlvbnMgTGltaXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBF
# U046MkFENC00QjkyLUZBMDExJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1w
# IFNlcnZpY2WgghFlMIIHFDCCBPygAwIBAgITMwAAAYZ45RmJ+CRLzAABAAABhjAN
# BgkqhkiG9w0BAQsFADB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3Rv
# bjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0
# aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0y
# MTEwMjgxOTI3MzlaFw0yMzAxMjYxOTI3MzlaMIHSMQswCQYDVQQGEwJVUzETMBEG
# A1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWlj
# cm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJlbGFuZCBP
# cGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjJBRDQt
# NEI5Mi1GQTAxMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNl
# MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAwI3G2Wpv6B4IjAfrgfJp
# ndPOPYO1Yd8+vlfoIxMW3gdCDT+zIbafg14pOu0t0ekUQx60p7PadH4OjnqNIE1q
# 6ldH9ntj1gIdl4Hq4rdEHTZ6JFdE24DSbVoqqR+R4Iw4w3GPbfc2Q3kfyyFyj+DO
# hmCWw/FZiTVTlT4bdejyAW6r/Jn4fr3xLjbvhITatr36VyyzgQ0Y4Wr73H3gUcLj
# Yu0qiHutDDb6+p+yDBGmKFznOW8wVt7D+u2VEJoE6JlK0EpVLZusdSzhecuUwJXx
# b2uygAZXlsa/fHlwW9YnlBqMHJ+im9HuK5X4x8/5B5dkuIoX5lWGjFMbD2A6Lu/P
# mUB4hK0CF5G1YaUtBrME73DAKkypk7SEm3BlJXwY/GrVoXWYUGEHyfrkLkws0RoE
# MpoIEgebZNKqjRynRJgR4fPCKrEhwEiTTAc4DXGci4HHOm64EQ1g/SDHMFqIKVSx
# oUbkGbdKNKHhmahuIrAy4we9s7rZJskveZYZiDmtAtBt/gQojxbZ1vO9C11Sthkr
# mkkTMLQf9cDzlVEBeu6KmHX2Sze6ggne3I4cy/5IULnHZ3rM4ZpJc0s2KpGLHaVr
# EQy4x/mAn4yaYfgeH3MEAWkVjy/qTDh6cDCF/gyz3TaQDtvFnAK70LqtbEvBPdBp
# eCG/hk9l0laYzwiyyGY/HqMCAwEAAaOCATYwggEyMB0GA1UdDgQWBBQZtqNFA+9m
# dEu/h33UhHMN6whcLjAfBgNVHSMEGDAWgBSfpxVdAF5iXYP05dJlpxtTNRnpcjBf
# BgNVHR8EWDBWMFSgUqBQhk5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3Bz
# L2NybC9NaWNyb3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIwMjAxMCgxKS5jcmww
# bAYIKwYBBQUHAQEEYDBeMFwGCCsGAQUFBzAChlBodHRwOi8vd3d3Lm1pY3Jvc29m
# dC5jb20vcGtpb3BzL2NlcnRzL01pY3Jvc29mdCUyMFRpbWUtU3RhbXAlMjBQQ0El
# MjAyMDEwKDEpLmNydDAMBgNVHRMBAf8EAjAAMBMGA1UdJQQMMAoGCCsGAQUFBwMI
# MA0GCSqGSIb3DQEBCwUAA4ICAQDD7mehJY3fTHKC4hj+wBWB8544uaJiMMIHnhK9
# ONTM7VraTYzx0U/TcLJ6gxw1tRzM5uu8kswJNlHNp7RedsAiwviVQZV9AL8IbZRL
# JTwNehCwk+BVcY2gh3ZGZmx8uatPZrRueyhhTTD2PvFVLrfwh2liDG/dEPNIHTKj
# 79DlEcPIWoOCUp7p0ORMwQ95kVaibpX89pvjhPl2Fm0CBO3pXXJg0bydpQ5dDDTv
# /qb0+WYF/vNVEU/MoMEQqlUWWuXECTqx6TayJuLJ6uU7K5QyTkQ/l24IhGjDzf5A
# EZOrINYzkWVyNfUOpIxnKsWTBN2ijpZ/Tun5qrmo9vNIDT0lobgnulae17NaEO9o
# iEJJH1tQ353dhuRi+A00PR781iYlzF5JU1DrEfEyNx8CWgERi90LKsYghZBCDjQ3
# DiJjfUZLqONeHrJfcmhz5/bfm8+aAaUPpZFeP0g0Iond6XNk4YiYbWPFoofc0Lwc
# qSALtuIAyz6f3d+UaZZsp41U4hCIoGj6hoDIuU839bo/mZ/AgESwGxIXs0gZU6A+
# 2qIUe60QdA969wWSzucKOisng9HCSZLF1dqc3QUawr0C0U41784Ko9vckAG3akwY
# uVGcs6hM/SqEhoe9jHwe4Xp81CrTB1l9+EIdukCbP0kyzx0WZzteeiDN5rdiiQR9
# mBJuljCCB3EwggVZoAMCAQICEzMAAAAVxedrngKbSZkAAAAAABUwDQYJKoZIhvcN
# AQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xMjAw
# BgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmljYXRlIEF1dGhvcml0eSAyMDEw
# MB4XDTIxMDkzMDE4MjIyNVoXDTMwMDkzMDE4MzIyNVowfDELMAkGA1UEBhMCVVMx
# EzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoT
# FU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUt
# U3RhbXAgUENBIDIwMTAwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDk
# 4aZM57RyIQt5osvXJHm9DtWC0/3unAcH0qlsTnXIyjVX9gF/bErg4r25PhdgM/9c
# T8dm95VTcVrifkpa/rg2Z4VGIwy1jRPPdzLAEBjoYH1qUoNEt6aORmsHFPPFdvWG
# UNzBRMhxXFExN6AKOG6N7dcP2CZTfDlhAnrEqv1yaa8dq6z2Nr41JmTamDu6Gnsz
# rYBbfowQHJ1S/rboYiXcag/PXfT+jlPP1uyFVk3v3byNpOORj7I5LFGc6XBpDco2
# LXCOMcg1KL3jtIckw+DJj361VI/c+gVVmG1oO5pGve2krnopN6zL64NF50ZuyjLV
# wIYwXE8s4mKyzbnijYjklqwBSru+cakXW2dg3viSkR4dPf0gz3N9QZpGdc3EXzTd
# EonW/aUgfX782Z5F37ZyL9t9X4C626p+Nuw2TPYrbqgSUei/BQOj0XOmTTd0lBw0
# gg/wEPK3Rxjtp+iZfD9M269ewvPV2HM9Q07BMzlMjgK8QmguEOqEUUbi0b1qGFph
# AXPKZ6Je1yh2AuIzGHLXpyDwwvoSCtdjbwzJNmSLW6CmgyFdXzB0kZSU2LlQ+QuJ
# YfM2BjUYhEfb3BvR/bLUHMVr9lxSUV0S2yW6r1AFemzFER1y7435UsSFF5PAPBXb
# GjfHCBUYP3irRbb1Hode2o+eFnJpxq57t7c+auIurQIDAQABo4IB3TCCAdkwEgYJ
# KwYBBAGCNxUBBAUCAwEAATAjBgkrBgEEAYI3FQIEFgQUKqdS/mTEmr6CkTxGNSnP
# EP8vBO4wHQYDVR0OBBYEFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMFwGA1UdIARVMFMw
# UQYMKwYBBAGCN0yDfQEBMEEwPwYIKwYBBQUHAgEWM2h0dHA6Ly93d3cubWljcm9z
# b2Z0LmNvbS9wa2lvcHMvRG9jcy9SZXBvc2l0b3J5Lmh0bTATBgNVHSUEDDAKBggr
# BgEFBQcDCDAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYw
# DwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvXzpoY
# xDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtp
# L2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYIKwYB
# BQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20v
# cGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNydDANBgkqhkiG9w0B
# AQsFAAOCAgEAnVV9/Cqt4SwfZwExJFvhnnJL/Klv6lwUtj5OR2R4sQaTlz0xM7U5
# 18JxNj/aZGx80HU5bbsPMeTCj/ts0aGUGCLu6WZnOlNN3Zi6th542DYunKmCVgAD
# sAW+iehp4LoJ7nvfam++Kctu2D9IdQHZGN5tggz1bSNU5HhTdSRXud2f8449xvNo
# 32X2pFaq95W2KFUn0CS9QKC/GbYSEhFdPSfgQJY4rPf5KYnDvBewVIVCs/wMnosZ
# iefwC2qBwoEZQhlSdYo2wh3DYXMuLGt7bj8sCXgU6ZGyqVvfSaN0DLzskYDSPeZK
# PmY7T7uG+jIa2Zb0j/aRAfbOxnT99kxybxCrdTDFNLB62FD+CljdQDzHVG2dY3RI
# LLFORy3BFARxv2T5JL5zbcqOCb2zAVdJVGTZc9d/HltEAY5aGZFrDZ+kKNxnGSgk
# ujhLmm77IVRrakURR6nxt67I6IleT53S0Ex2tVdUCbFpAUR+fKFhbHP+CrvsQWY9
# af3LwUFJfn6Tvsv4O+S3Fb+0zj6lMVGEvL8CwYKiexcdFYmNcP7ntdAoGokLjzba
# ukz5m/8K6TT4JDVnK+ANuOaMmdbhIurwJ0I9JZTmdHRbatGePu1+oDEzfbzL6Xu/
# OHBE0ZDxyKs6ijoIYn/ZcGNTTY3ugm2lBRDBcQZqELQdVTNYs6FwZvKhggLUMIIC
# PQIBATCCAQChgdikgdUwgdIxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJhdGlvbnMgTGlt
# aXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046MkFENC00QjkyLUZBMDExJTAj
# BgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2WiIwoBATAHBgUrDgMC
# GgMVAAGu2DRzWkKljmXySX1korHL4fMnoIGDMIGApH4wfDELMAkGA1UEBhMCVVMx
# EzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoT
# FU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUt
# U3RhbXAgUENBIDIwMTAwDQYJKoZIhvcNAQEFBQACBQDmy7CSMCIYDzIwMjIwOTE0
# MDk0NDUwWhgPMjAyMjA5MTUwOTQ0NTBaMHQwOgYKKwYBBAGEWQoEATEsMCowCgIF
# AObLsJICAQAwBwIBAAICDkkwBwIBAAICE8EwCgIFAObNAhICAQAwNgYKKwYBBAGE
# WQoEAjEoMCYwDAYKKwYBBAGEWQoDAqAKMAgCAQACAwehIKEKMAgCAQACAwGGoDAN
# BgkqhkiG9w0BAQUFAAOBgQBNI4zUDL5VqmFFxoCvmJ3o0mkgAqU9q4Z4Fk2YXnoX
# iQDtmPXGlIJidntBJUr2aYQB1+TYH1GQrfwSnpAjWHGspZfco8mCXIXpTbDmo8JR
# U00tMc0m1zpMR4aBf75X8J55nUegHk2+E9rW+J0wixq4FNMNpv+DhlRPwZHIVkG/
# vzGCBA0wggQJAgEBMIGTMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMz
# AAABhnjlGYn4JEvMAAEAAAGGMA0GCWCGSAFlAwQCAQUAoIIBSjAaBgkqhkiG9w0B
# CQMxDQYLKoZIhvcNAQkQAQQwLwYJKoZIhvcNAQkEMSIEILn56KUdtzpt623yGsjZ
# mor8s6NSok/Q2UaEKs74V6d3MIH6BgsqhkiG9w0BCRACLzGB6jCB5zCB5DCBvQQg
# GpmI4LIsCFTGiYyfRAR7m7Fa2guxVNIw17mcAiq8Qn4wgZgwgYCkfjB8MQswCQYD
# VQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEe
# MBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3Nv
# ZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAAYZ45RmJ+CRLzAABAAABhjAiBCDV
# //+UWrSThAKbFqoJwCrOyO8Tnfg+iz0iyqZWSxTNoTANBgkqhkiG9w0BAQsFAASC
# AgBVNmh/qgBy7mu7t4M7OVg4oAELZFhB/Q925UA2dADyN9BOWyFKg2IzouHebHox
# wBQ+8YCatw9VSkIW0zlIEicaNCaNP8J3fnD4dsN8rhvyhxiWba1UVj4nw2GQKH49
# 6qlsVeJNR5Dw84GqBOmtKmGwM9dY6VKVL5kjpp0aPhTc0NXUdRZWWhwOGmwzDrEQ
# w2fZp6g3PZv55NOJFj3SlkAZZrmV2pSS+K0FFhyGEGXIzGTAiU+ntgpNgouRUHq3
# QludfdiJqau464jw/IL/lHlAOwm7+kkCBxHuZ4B1zpaegQ8FjG6SJ4FvSxOVNoTZ
# 7wG6jnlyb/yLAbmgR2hVKBLY6yT7c8yENHSsoEpISrcikPN3j9nU87KAADZ54mN8
# nLR69d1Ea2XM1TlaMQFjJNFsMOyuU3zmmbIALmRtXSMx8EDWZ5jNe6Oq1kyzbtUX
# TSywnYrJMjYcDDFlclxj8MpDlIk35C3btywno/9DsXTWT+lOV5XSLAVv5rlSk+Lv
# 8JUvrMbQ9ZQ2UQ2JJq9xWsr+k0DuxzlGg3uT78OsHKEqAAix3QQgdt2QfSOwo0eX
# 2GwjLCy4ZHKXZNXZ2oJbO5h9PqmWSox5U3potnsHh/QK2WyKV2dFNTpb8Tchljf6
# iioanDqjJs1LQf/2AU5wUILQvzR92oA/AJDKpWd+BWJi3g==
# SIG # End signature block
