<# File Name: ChaseEvents.ps1
	last edit by: waltere
	Objective: This script will parse all the system event logs in the SDP folder, looking for the ID you're looking for
	supplied by Willy Moselhy (IBS) <v-waalmo@microsoft.com> & sergeg@microsoft.com
#>

<#
.SYNOPSIS
The script will parse all the system event logs in the SDP folder, looking for the ID you're looking for.

SYNTAX: .\ChaseEvents.ps1 -EventId [ID or comma separated list] -EventLevel [Critical|Error|Warning|Information|Verbose] -SDPPath [full-path-to-expanded-SDP-report]

.DESCRIPTION
The script will parse all the system event logs in the SDP folder, looking for the ID you're looking for.
It is mandatory to provide either EventId or EventLevel"
Note: You can give one of them or both, but none will stop.

Output file with table of nodes will be located in same folder with name !PStat_Sum_Compared.txt

If you experience PS error '...is not digitally signed.' run the command:
 Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned

.PARAMETER ShowCommand
 This switch will cause the script to display a popup for manual choices

.EXAMPLE
 ChaseEvents.ps1 -EventId 5120 -Format YMDH -Days 7 -SDPPath \\MyPC\temp\SDPs\ClusterReports
 This command will look for event IDs 5120 that happened in the last 7 days in all the system event logs of the SDP folder.

.EXAMPLE
 ChaseEvents.ps1 -EventID 5120 -Format YMDH -Days 7 -Verbosity Verbose -SDPPath C:\SDPs\ClusterReports -HostMode
 Same as above but will add the CSV that had an error and its error code
 This command will show logging on the screen

.EXAMPLE
 ChaseEvents.ps1 -EventId 1069,1146 -Format YMD -Days 30 -SDPPath C:\SDPs\ClusterReports -ScriptMode
 Will look for event IDs 1069 & 1146 that happened in the last month
 This command will show script processing in log file xxx.log

.EXAMPLE
 ChaseEvents.ps1 -EventLevel Critical -Format YMD -SDPPath C:\SDPs\ClusterReports
 Will look for all the critical events that were logged

 .EXAMPLE
 ChaseEvents.ps1 -Help -SDPPath .
 Will show more script specific help options

.LINK
 \emeacssdfs.europe.corp.microsoft.com\netpod\rfl\ChaseEvents.ps1
 v-waalmo@microsoft.com ; sergeg@microsoft.com ; waltere@microsoft.com
 #>

[CmdletBinding()]
PARAM (
	[Parameter(Mandatory = $true,Position=0,HelpMessage='Choose a writable SDP folder location, i.e. C:\SR\SDP-report\ ')]
	[String] $SDPPath,			# Path to SDP result folder
	[string[]]$EventId = "6005", 	# The EventId we're looking for
	[ValidateSet("Critical", "Error", "Warning", "Information", "Verbose")][string[]]$EventLevel, # We can also filter by level
	[int]$Days, 					# The history in Days we want to read
	[switch]$Help, 					# Show the help
	[ValidateSet("YMD", "YMDH", "YMDHM", "YMDHMS", "YMDHMSm")][string]$TimeFormat, # This is the level of precision we want
	[switch]$VerboseOutput, 		# Used for verbose debugging output
	[ValidateSet("Minimal", "Standard", "Verbose")][string]$Verbosity = "Minimal", # To display detail information
	[switch]$Multiline, 			# Switch to choose to have events on multiline
	[switch]$ShowCommand = $false,	# Switch to use Show-Command
	[switch]$HostMode  = $false,	#This tells the logging functions to show logging on the screen
	[switch]$ScriptMode = $false,	#This tells the logging functions to show logging into log file
	[switch]$UseExitCode= $true   #This will cause the script to close after the error is logged if an error occurs.
)

#region BEGIN
BEGIN {
	$verDateScript = "2023.02.09.0"
	$ScriptFolder = Split-Path $MyInvocation.MyCommand.Path -Parent
	# Load Common Library:
	. $ScriptFolder\Utils_RflShared.ps1

	$ScriptBeginTimeStamp = Get-Date
	# This saves the starting ErrorActionPreference and then sets it to 'Stop'.
	$startErrorActionPreference = $errorActionPreference
	$errorActionPreference = 'Stop'
	# This gets the current path and name of the script.
	$invocation = (Get-Variable MyInvocation).Value
	$scriptPath = Split-Path $invocation.MyCommand.Path
	$scriptName = $invocation.MyCommand.Name
	Write-Host "Running `"$scriptPath\$scriptName`"..." -BackgroundColor Black -ForegroundColor Green

	### Trail SDPPath with \ and allow path with space character
	if ($SDPPath.EndsWith("\")){$SDPPath="$SDPPath"}
	else {$SDPPath="$SDPPath" +"\"}
	If (-NOT (Test-Path $SDPPath -PathType 'Container')){Throw "$($SDPPath) is not a valid folder"}

#region: ###### customization section of script, logging configuration ########################
	$SDPcheckINI = (Get-content -Path "$ScriptFolder\_SDPcheck.ini")
	$InOfflineMode 	= (($SDPcheckINI[1] -split " ")[2]).trim("""")	# set $True for outsourcer or when not connected to MS network - offline-SDPcheck
	if ($InOfflineMode -match "False") {
		$StatsServer = (($SDPcheckINI[5] -split " ")[2]).trim("""")
		if (Test-Connection -ComputerName $StatsServer -Quiet -Count 1) {[bool]$Stats=$True} else {[bool]$Stats=$False}
	} else { 
		$Stats = $False
	}
	$ErrorActionPreference = "Continue" #"Stop"
	$LogLevel = 0
	if ($Stats) {
		$StatsServerPath="\\$StatsServer\RFLstats$\RFL\scripts\Stats\"
		$CountInvFil = $StatsServerPath +'countChaseEvt.dat'
		$CountInvFil2 = $CountInvFil +'.us'
	}
	$LogPath = $SDPPath + "_" +$scriptName +".log"
#endregion: ###### customization section
	$CheckDate = (Get-Date).ToUniversalTime().ToString("yy-MM-dd_HH-mm-ss")

	Set-Variable -Name ErrorMsgPS -Scope Script -Force
	If ($Stats) { #increment at start of script
	 ($j=[int32](Get-Content $CountInvFil -TotalCount 1 -ErrorAction SilentlyContinue)) |out-null
	 Try {(++$j) | Set-Content $CountInvFil -ErrorAction SilentlyContinue} Catch { }
	}
	If ($PSBoundParameters['Debug']) { $DebugPreference='Continue'}

#region FUNCTION DEFINITIONS
	# ::::: FUNCTIONS :::::
	#
	#  Show_Help()              : Shows the help
	#  Check_Arguments()        : Check if either EventID or EventLevel is mentionned
	#  Check_TimeFormat()       : Check if the output format is supported
	#  Check_Set_Delay()        : Set the history used if set
	#  Build_Query()            : Build the XML Query according to the arguments provided
	#  GetEventFromCellString() : Export the EventID from a string
	#  GetEventCountFromCellString() : Export the number of occurences from a string
	#  Get_Detail()             : Get additional information from the event
#endregion FUNCTION DEFINITIONS

#region: Helper function
  function Show_Help() {
    Write-Host "Chase-Events.ps1 (v$verDateScript )`n" -ForegroundColor Yellow
    Write-Host "Put the script in your SDP report output and run it with the following switches"
    Write-Host "It will parse all the system event logs in the current folder, looking for the ID you're looking for`n"
    Write-Host "In each column you have the EventID and the number of time it's been logged"
    write-host " -help    : Shows this help"
    write-host " -Days    : Number of days you want to go back (if not set, we'll go as far as the event log goes)"
    write-host " -EventID  : Choose one or several events to filter. For example -EventID 5120 or -EventID 1069,1146,1135 *"
    write-host " -EventLevel : Choose one or several Levels to filter. For example -EventLevel Critical or -EventLevel Critical,Error *"
    write-host "        Accepted values are Critical, Error, Warning, Information, Verbose"
    write-host " -TimeFormat : The output format you want to display"
    write-host "        - YMD (Default) : An output of only Year-Month-Day"
    write-host "        - YMDH        : An output of only Year-Month-Day Hour"
    write-host "        - YMDHM       : An output of only Year-Month-Day Hour:Minute"
    write-host "        - YMDHMS      : An output of only Year-Month-Day Hour:Minute:Second"
    write-host "        - YMDHMm      : An output of only Year-Month-Day Hour:Minute:Second.Millisecond"
    write-host " -Verbosity : The table can display different level data"
    write-host "        - Minimal (Default) : Just counts the occurence of events with no detail on the event"
    write-host "        - Standard     : Adds a detail on the event (often the 1rst parameter)"
    write-host "        - Verbose      : Adds details on the event`n"
    write-host " -Multiline : Gives the possibility to split the events details in multiple lines"
    write-host "        Default Value is unset : All the data are appended to the same line"
    write-host " Notes : "
    write-host "  - If the path of the current folder contains `[ or `] the script will fail"
    write-host "   Powershell apparently does not like these characters`n"
    write-host "  * It is mandatory to provide either EventId or EventLevel"
    write-host "   You can give one of them or both, but none will stop.`n"
    write-host " Examples:`n"
    write-host "  .\Chase-Several-Events.ps1 -EventId 5120 -Format YMDH -Days 7"
    write-host "    Will look for event IDs 5120 that happened in the last 7 days in all the"
    write-host "    system event logs of the current folder`n"
    write-host "  .\Chase-Several-Events.ps1 -EventID 5120 -Format YMDH -Days 7 -Verbosity Verbose"
    write-host "    Same as above but will add the CSV that had an error and its error code`n"
    write-host "  .\Chase-Several-Events.ps1 -EventId 1069,1146 -Format YMD -Days 30"
    write-host "    Will look for event IDs 1069 & 1146 that happened in the last month`n"
    write-host "  .\Chase-Several-Events.ps1 -EventLevel Critical -Format YMD"
    write-host "    Will look for all the critical events that were logged`n"
    Write-Host "Run this tool from a machine with Powershell 5.1 or above (Win10 is fine)"
    write-host " (`$Host to know the version you're running on)."
    Write-Host ""
    break
  }
#endregion Helper function

#region: Script Functions
  function Check_Arguments() {
    if (!$EventId -and !$EventLevel) {
      Write-Host "Either EventId or EventLevel is mandatory"
      Write-Host "Run with -Help for more information`n"
      Break
    }
  }
  function Check_TimeFormat() {

    if ($TimeFormat) {
      if (($TimeFormat -notmatch "YMD") -and ($TimeFormat -notmatch "YMDH") -and ($TimeFormat -notmatch "YMDHM") -and ($TimeFormat -notmatch "YMDHMS") -and ($TimeFormat -notmatch "YMDHMSm")) {
        Write-Host "Bad output format. Must be either YMD, YMDH or YMDHM"
        Write-Host "Run -help for more information"
        break
      }
    }
  }
  function Check_Set_Delay() {
    # ----- 1 day = 86400000 milliseconds
    [long]$Delay_1D = 86400000
    if (-not $Days) {
      $Global:Ever = $true
    }
    else {
      $Global:Ever = $false
      $Global:Delay = $Delay_1D * $Days
    }
  }
  function Build_Query() {

    # ----- Very convenient way to have tables of everything
    #    indexed with everything
    $EventLevelToString = @{}
    $EventLevelToString['Critical'] = "Level=1"
    $EventLevelToString['Error'] = "Level=2"
    $EventLevelToString['Warning'] = "Level=3"
    $EventLevelToString['Information'] = "Level=4 or Level=0"
    $EventLevelToString['Verbose'] = "Level=5"

    # ----- Build the Event ID's list
    if ($EventId.Count -ne 0) {
      $StrListOfEvents = "EventID=" + $EventId[0]
      for ($i = 1; $i -lt $EventId.Count; $i++) {
        $StrListOfEvents += " or EventID=" + $EventId[$i]
      }
      $StrListOfEvents = "(" + $StrListOfEvents + ")"
    }
    else {
      $StrListOfEvents = "(no id)"
    }
    # ----- Build the Event Level's list
    if ($EventLevel.Count -ne 0) {
      $StrListOfLevels = $EventLevelToString[$EventLevel[0]]
      for ($i = 1; $i -lt $EventLevel.Count; $i++) {
        $StrListOfLevels += " or " + $EventLevelToString[$EventLevel[$i]]
      }
      $StrListOfLevels = "(" + $StrListOfLevels + ")"
    }
    else {
      $StrListOfLevels = "(no level)"
    }
    # ----- Build the ID + Level string
    if ($EventId -and $EventLevel) {
      $StrFilter = $StrListOfEvents + " and " + $StrListOfLevels
    }
    elseif ($EventId -and !$EventLevel) {
      $StrFilter = $StrListOfEvents
    }
    elseif (!$EventId -and $EventLevel) {
      $StrFilter = $StrListOfLevels
    }
    else {
      $StrFilter = "Ouelou!"
    }
    # Build the XML Query
    if ($Ever) {
      $Global:Query = "<QueryList><Query><Select>*[System[" + $StrFilter + "]]</Select></Query></QueryList>"
    }
    else {
      $Global:Query = "<QueryList><Query><Select>*[System[" + $StrFilter + " and TimeCreated[timediff(@SystemTime) &lt;= $Delay]]]</Select></Query></QueryList>"
    }
  }
  function GetEventFromCellString([string]$String) {
    return $String.split('()')[0]
  }
  function GetEventCountFromCellString([string]$String) {
    return [convert]::ToInt32($String.split('()')[1], 10)
  }
  function Pause() {
    Read-Host 'Press Enter to continue...' | Out-Null
  }
  function Get_Detail(
	[System.Diagnostics.Eventing.Reader.EventRecord]$EventRecord,
    [string]$OutputLevel) 
	{
    #  $OutputLevel reflects the $Output argument
    #  It can be "Minimal", "Standard" or "Verbose"

    if ($Multiline) {
      $Sep = "`n"
    }
    else {
      $Sep = '|'
    }
    # write-host "Id:"$EventRecord.Id -ForegroundColor Yellow
    if ($OutputLevel -eq "Minimal") {
      $Result = ""
    }
    else {
      switch ($EventRecord.Id) {
        "1069" {
          # ----- Resource Failed - WS16
          #    Properties[0]: ResourceName
          #    Properties[1]: ResourceGroup
          #    Properties[2]: ResTypeDll
          if ($OutputLevel -eq "Standard") {
            $Result = $EventRecord.Properties[0].Value
          }
          else {
            $Result = $EventRecord.Properties[0].Value + $Sep + $EventRecord.Properties[1].Value + $Sep + $EventRecord.Properties[2].Value
          }
          break
        }
        "1135" {
          # ----- Connection loss with a node - Get the node name
          $Result = $EventRecord.Properties[0].Value
          break
        }
        "1177" {
          # ----- Cluster Service is shutting down - Nothing in the event but the name of the current node
          $Result = $EventRecord.Properties[0].Value
          break
        }
        "1146" {
          # ----- RHS Deadlock - Nothing in the event but the name of the current node
          $Result = $EventRecord.Properties[0].Value
          break
        }
        "1230" {
          # ----- Cluster resource Timeout - For WS16
          #    Properties[0]: ResourceName
          #    Properties[1]: ResourceType
          #    Properties[2]: ResTypeDll
          if ($OutputLevel -eq "Standard") {
            $Result = $EventRecord.Properties[0].Value
          }
          else {
            $Result = $EventRecord.Properties[0].Value + $Sep + $EventRecord.Properties[1].Value + $Sep + $EventRecord.Properties[2].Value
          }
          break
        }
        "1564" {
          # ----- Failed to arbitrate for the file share
          #    Properties[0]: ResourceName
          #    Properties[1]: ShareName
          #    Properties[2]: BinaryParameterLength
          #    Properties[3]: BinaryData
          if ($OutputLevel -eq "Standard") {
            $Result = $EventRecord.Properties[0].Value
          }
          else {
            $Result = $EventRecord.Properties[0].Value + $Sep + $EventRecord.Properties[1].Value
          }
          break
        }
        "5120" {
          # ----- CSV entered a paused state - For WS16:
          #    Properties[0]: VolumeName (Volume5, Volume3, etc.)
          #    Properties[1]: ResourceName (Cluster Disk 7, Cluster Disk 1, etc.)
          #    Properties[2]: ErrorCode (STATUS_CONNECTION_DISCONNECTED, STATUS_NO_SUCH_DEVICE, etc.)
          #    Properties[3]: DiskDeviceNumber : a number
          #    Properties[4]: DiskDeviceGuid : a GUID
          if ($OutputLevel -eq "Standard") {
            $Result = $EventRecord.Properties[1].Value
          }
          else {
            $Result = $EventRecord.Properties[1].Value + $Sep + $EventRecord.Properties[2].Value
          }
          break
        }
        "5142" {
          # ----- CSV No longer accessible
          #    Properties[0] : VolumeName (Volume5, Volume3, etc.)
          #    Properties[1] : ResourceName (Cluster Disk 7, Cluster Disk 1, etc.)
          #    Properties[2] : ErrorCode (1460, etc.)
          #    Properties[3] : ReasonCode (UnmapReasonCsvFsStateTransitionTimeout, etc.)
          #    Properties[4] : DiskDeviceNumber : a number
          #    Properties[5] : DiskDeviceGUID : a GUID if any
          if ($OutputLevel -eq "Standard") {
            $Result = $EventRecord.Properties[1].Value
          }
          else {
            $Result = $EventRecord.Properties[1].Value + $Sep + $EventRecord.Properties[2].Value + $Sep + $EventRecord.Properties[3].Value
          }
          break
        }
        "6008" {
          # ----- Unexpected Reboot
          #    Properties[0] : Time
          #    Properties[1] : Date
          $Result = $EventRecord.Properties[1].Value + ' ' + $EventRecord.Properties[0].Value
          break
        }
        "6013" {
          # ----- System Uptime
          #    Properties[4] : Time in seconds
          $TSpan = $EventRecord.Properties[4].Value
          $Result = "d{0} {1}h{2}m{3}s" -f [timespan]::fromseconds($TSpan).Days , [timespan]::fromseconds($TSpan).Hours , [timespan]::fromseconds($TSpan).Minutes , [timespan]::fromseconds($TSpan).Seconds
          break
        }
        "41" {
          # ----- It can contain a BSOD in the first paramerer (but the value is in decimal)
          #    Properties[0] : "0" or BSOD if any
          if ($EventRecord.Properties[0].Value -eq "0") {
            $Result = '-'
          }
          else {
            $Result = 'BSOD 0x{0:X}' -f $EventRecord.Properties[0].Value
          }
          break
        }
        "1001" {
          # ----- Bugcheck
          #    Properties[0] : The BSOD
          $Result = $EventRecord.Properties[0].Value
          break
        }
        "7036" {
          # ----- Status changed for a service
          #    Properties[0] : Service Name
          #    Properties[1] : Status
          if ($OutputLevel -eq "Standard") {
            $Result = $EventRecord.Properties[0].Value
          }
          else {
            $Result = $EventRecord.Properties[0].Value + $Sep + $EventRecord.Properties[1].Value
          }
          break
        }
        default {
          $Result = $EventRecord.Properties[0].Value
          break
        }
      }
    }
    return $Result
  } #end function Get_Detail


  function ChaseEvents {
  Param(
    [string[]]$EventId, # The EventId we're looking for
    [ValidateSet("Critical", "Error", "Warning", "Information", "Verbose")][string[]]$EventLevel, # We can also filter by level
    [int]$Days, # The history in Days we want to read
    [switch]$Help, # Show the help
    [ValidateSet("YMD", "YMDH", "YMDHM", "YMDHMS", "YMDHMSm")][string]$TimeFormat, # This is the level of precision we want
    [switch]$VerboseOutput, # Used for verbose debugging output
    [ValidateSet("Minimal", "Standard", "Verbose")][string]$Verbosity = "Minimal", # To display detail information
    [switch] $Multiline # Switch to choose to have events on multiline
  )

  # ::::: MAIN :::::
  #
  #  1. Parses the arguments
  #  2. Generates the query
  #  3. Runs the query
  #  4. Saves the output in a CSV
  #  5. Exports the output in a grid-view
  #

  # ::::: NEXT VERSION SHOULD INCLUDE :::::
  #  - Export to a real Excel file
  #    - Add some colors
  #    - Add a dialog that shows the entire event content when selecting an event
  #
  #  - For any suggestions, contact sergeg@microsoft.com

  # Show Help if asked - Includes a break
  if ($Help) {
    Show_Help
  }

  # EventId is mandatory - Breaks if missing
  # Check_EventId
  Check_Arguments

  # Check if the output format is set then correctly - breaks if not set correctly
  Check_TimeFormat

  # Check if an history is asked, then set the variables according
  $Global:Ever = $false
  $Global:Delay = 0
  Check_Set_Delay

  # Generating the query
  Build_Query

  # Create the output file
  #$CurrentDir = [System.IO.Path]::GetDirectoryName($myInvocation.MyCommand.Definition)
  if ($EventId.Count -eq 1) { $FileName = $EventId[0]}
  else { $FileName = "Events" }
  $OutputFile = $Script:SDPPath + $FileName + ".csv"

  # Display the query to be run
  Write-Host "Running this query:" -ForegroundColor Yellow
  Write-Host " "$Query

  # Build a class that will be used by the list of events
  # The Class works only starting powershell 5.1
  # It gives the possibility to easily build a list of stuctured elements
  # using a constructor we define
  #

  class Event {
    [string]$C_NodeName
    [string]$C_Date
    [string]$C_EventID
    [string]$C_Detail
    Event([string]$NodeName, [string]$Date, [string]$ID, [string]$Detail) {
      $this.C_NodeName = $NodeName
      $this.C_Date = $Date
      if ($Detail) {
        $this.C_Detail = $Detail
        $this.C_EventID = $ID + "[" + $Detail + "]"
      }
      else {
        $this.C_EventID = $ID
      }
    }
  }

  $ListOfEvents = @()
  $NodesList = @()

  # Browse and parse the system event logs in the current folder
  # We rely on the naming convention so
  # we're looking for "*System*.evtx" files
  #

  write-host "Events found per node (time for a coffee break)..." -ForegroundColor Yellow
  Get-ChildItem -Path $Script:SDPPath -Recurse | Where-Object Name -like "*System*evtx" | ForEach-Object {

    # Build the list of the nodes
    # Read the first event of each evtx file, get the MachineName field and build the list
    #

    $ServerName = (Get-WinEvent -MaxEvents 1 -Path $_.FullName).MachineName.Split('.')[0]

    if ($ServerName -notin $NodesList) {
      $NodesList += $ServerName
    }

    # Collect the events and build the list
    write-host " "$ServerName": " -NoNewline
    $EventsFound = Get-WinEvent -Path $_.FullName -FilterXPath $Query -ErrorAction SilentlyContinue

    if ($EventsFound.count -eq 0) {
      write-host "none"
    }
    else {
      write-host $EventsFound.count

      $EventsFound | ForEach-Object {

        if ($_.TimeCreated.Month -lt 10) { $Month = "0" + $_.TimeCreated.Month } else { $Month = $_.TimeCreated.Month }
        if ($_.TimeCreated.Day -lt 10) { $Day = "0" + $_.TimeCreated.Day } else { $Day = $_.TimeCreated.Day }
        if ($_.TimeCreated.Hour -lt 10) { $Hour = "0" + $_.TimeCreated.Hour } else { $Hour = $_.TimeCreated.Hour }
        if ($_.TimeCreated.Minute -lt 10) { $Minute = "0" + $_.TimeCreated.Minute } else { $Minute = $_.TimeCreated.Minute }
        if ($_.TimeCreated.Second -lt 10) { $Second = "0" + $_.TimeCreated.Second } else { $Second = $_.TimeCreated.Second }
        if ($_.TimeCreated.Millisecond -lt 10) {
          $Millisecond = "00" + $_.TimeCreated.Millisecond
        }
        elseif ($_.TimeCreated.Millisecond -lt 100) {
          $Millisecond = "0" + $_.TimeCreated.Millisecond
        }
        else {
          $Millisecond = $_.TimeCreated.Millisecond
        }

        # TimeFomrat can be : "YMD","YMDH","YMDHM","YMDHMS","YMDHMSm"
        if (!$TimeFormat -or $TimeFormat -eq "YMDHMS") {
          $Date = ("{0} {1} {2}-{3}:{4}:{5}" -f $_.TimeCreated.Year, $Month, $Day, $Hour, $Minute, $Second)
        }
        elseif ($TimeFormat -eq "YMD") {
          $Date = ("{0} {1} {2}" -f $_.TimeCreated.Year, $Month, $Day)
        }
        elseif ($TimeFormat -eq "YMDH") {
          $Date = ("{0} {1} {2}-{3}" -f $_.TimeCreated.Year, $Month, $Day, $Hour)
        }
        elseif ($TimeFormat -eq "YMDHM") {
          $Date = ("{0} {1} {2}-{3}:{4}" -f $_.TimeCreated.Year, $Month, $Day, $Hour, $Minute)
        }
        else {
          $Date = ("{0} {1} {2}-{3}:{4}:{5}.{6}" -f $_.TimeCreated.Year, $Month, $Day, $Hour, $Minute, $Second, $Millisecond)
        }

        # $Verbosity can be either "Minimal", "Standard" or "Verbose"
        if ($Verbosity -eq "Minimal") {
          $ListOfEvents += [Event]::New($ServerName, $Date, $_.ID, $null)
        }
        else {
          $EventDetail = Get_Detail $_ $Verbosity
          $ListOfEvents += [Event]::New($ServerName, $Date, $_.ID, $EventDetail)
        }
      }
    }
  }

  # Arranging the nodes list by alphabetical order
  # <IMPROVEMENTS>
  #  In a clustering content, add the node number in ()
  #  This should be possible by loading the registry hive availavle in an SDP Report
  # </IMPROVEMENTS>

  # Ordering the list of nodes
  $NodesList = $NodesList | Sort-Object

  # Ordering events per date and group per date
  $ListOfEvents = $ListOfEvents | Sort-Object C_Date -Descending

  if ($ListOfEvents.Count -eq 0) {
    Write-Host "Nothing to display, but the result is saved."
  }
  else {
    # ----- Creation of an Excel sheet

    $excel = New-Object -ComObject Excel.Application
    $excel.Visible = $false
    $workbook = $excel.Workbooks.Add()
    $Sheet = $workbook.worksheets.Item(1)

    if ($EventId.Count -eq 1) {
      $Sheet.Name = $EventId[0]
    }
    else {
      $Sheet.Name = "Events"
    }

    # ----- Build the list of columns

    $Sheet.Cells.Item(1, 1) = "Date Time"
    for ($Column = 0; $Column -lt $NodesList.Count; $Column++) {
      $Sheet.Cells.Item(1, $Column + 2) = $NodesList[$Column]
    }

    # ----- NodesToColumn allows to get the column name from the node name
    $NodesToColumn = @{}
    for ($i = 0; $i -lt $NodesList.Count; $i++) {
      $NodesToColumn[$NodesList[$i]] = $i + 2
    }

    # Fill the tables with the data
    <#
    The EventsList is already ordered by Date

    Each cell contains either nothing, or an EventID with the number of occurences it's been logged at the same time
    For example: "1234(7)" means that seven 1234 events have been logged at the same time by the same node

    For each event : Look for the date in the first column of the table
    - If no date in the table matches the date of the event
      - Add a new line to the table and set the date to the first column
      - Add the EventID to Cell corresponding to the new date and the node
    - Else
      - If the cell corresponding to the Node and the Date is empty
        - Add the EventId to the cell with an occurence counte set to 1
      - Else (The cell is not empty)
        - If the Cell contains the same EventID : Increment the count by 1
        - Else (the Cell contains a different EventID) :
          - Add a new line to the table and set the date to the first column
          - Add the EventID to Cell corresponding to the new date and the node
  #>

    Write-Host "Building the table (time for a second coffee break)..." -ForegroundColor Yellow
    # --- Browse the events list

    $index = 0
    $ListOfEvents | ForEach-Object {
      $index++
      $ThisEvent = $_
      if ($VerboseOutput) {
        write-host "Handling event"$index" : " -NoNewline -ForegroundColor Yellow
        $ThisEvent
      }

      # ============================= Looking for a date in the table that matches the event date

      # ----- Define the Date column
      #    Better to reset the date range for each new event as I don't know
      #    if 'EntireColumn' is really entire or stops at the last used row
      #
      $DateRange = $Sheet.Range("A1").EntireColumn

      # ----- Look for the dates in the first column
      #    $CorrespondingDates is the list of rows containing a matching date
      #
      $CorrespondingDates = $null
      $CorrespondingDates = @()
      $DateFound = $false

      $TargetDate = $DateRange.Find($ThisEvent.C_Date)
      if ($null -ne $TargetDate) {
        $DateFound = $true
        $FirstDateFound = $TargetDate
        Do {
          $CorrespondingDates += [convert]::ToInt32($TargetDate.row, 10)
          $TargetDate = $DateRange.FindNext($TargetDate)
        }While (( $null -ne $TargetDate) -and ($TargetDate.AddressLocal() -ne $FirstDateFound.AddressLocal()))
      }

      # ========================= We haven't found any line with the same date : Create a new one
      #
      if ($DateFound -eq $false) {

        # ----- Add a new line a the end of the table
        #    We add it at the end because $ListOfEvents is already sorted by date
        $LastUsedLine = $Sheet.UsedRange.Rows.Count

        # Add the date to the following row
        $Sheet.Cells.Item($LastUsedLine + 1, 1) = $ThisEvent.C_Date

        # Add EventId to the cell that corresponds to the node, and give it a count of (1) as it is the first occurence
        $Sheet.Cells.Item($LastUsedLine + 1, $NodesToColumn[$ThisEvent.C_NodeName]) = $ThisEvent.C_EventID + "(1)"
      }

      # ====================================== We have found at least one line with the same date
      #
      else {

        # ------------------------------------ If We find only one matching date (the easy one)
        # ----- We check if the event corresponds
        #    - If the cell is empty : Add the new event with count(1)
        #    - If the cell is not empty : Check the content
        #      - If the event corresponds : Increment the count
        #      - If the event does not correspond : Add a new row
        #

        if ($CorrespondingDates.count -eq 1) {

          # ----- Read the cell
          $TheCellRow = [convert]::ToInt32($CorrespondingDates[0], 10)
          $TheCellCol = [convert]::ToInt32($NodesToColumn[$ThisEvent.C_NodeName], 10)
          $CellContent = $Sheet.Cells.Item($TheCellRow, $TheCellCol).text

          # ----- The cell is empty : Add the event
          if ($CellContent -eq "") { # an empty cell is not $null but ""
            $NewCellValue = $ThisEvent.C_EventID + "(1)"
            $Sheet.Cells.Item($TheCellRow, $TheCellCol) = $NewCellValue
          }
          # ----- The cell is not empty : Check the content
          #    - If the EventId is the same : Increment the count
          #    - If the EventId is different : Add a new row
          else {
            # ----- Get the Event Part
            $EventInTheCell = GetEventFromCellString($CellContent)

            # ----- The cell contains the same EventId : Increment the count
            if ($EventInTheCell -eq $ThisEvent.C_EventID) {
              $TheCellRow = [convert]::ToInt32($CorrespondingDates[0], 10)
              $TheCellCol = [convert]::ToInt32($NodesToColumn[$ThisEvent.C_NodeName], 10)

              [int32]$EventsCount = GetEventCountFromCellString($CellContent)
              $EventsCount += 1

              [string]$strEventCount = "(" + [convert]::ToString($EventsCount) + ")"
              $NewCellValue = $ThisEvent.C_EventID + $strEventCount

              $Sheet.Cells.Item($TheCellRow, $TheCellCol) = $NewCellValue
            }
            # ------ The Cell contains a different EventId : Create a new row and fill the date & cell
            else {
              # Get the last row of the table
              $LastUsedLine = $Sheet.UsedRange.Rows.Count

              # Add a new row, then fill it with the new data
              $NewRow = $LastUsedLine + 1
              $Sheet.Cells.Item($NewRow, 1) = $ThisEvent.C_Date
              $Sheet.Cells.Item($NewRow, $TheCellCol) = $ThisEvent.C_EventID + "(1)"
            }
          }
        } # End of block "One matching date"

        # --------------------------------------------------- If We find several matching dates
        # ----- We check if one of them matches the event
        #    - If one of them matches the event : Increment the count
        #    - If none of them matches the event
        #      - If one of them is empty : Add the date
        #      - If none is empty : Add a line
        #  Recall:
        #   $CorrespondingDates @()   : Contains the list of the rows with the same date
        #   $ThisEvent         : Contains the current event
        #     C_Date
        #     C_EventId
        #     C_NodeName
        #   $Sheet.Cells.Item()     :
        #   $Sheet.Cells.Item().text  : Content of the Cell
        #

        else {

          # ----- Check if one of the cells matches the event
          $TheCellCol = [convert]::ToInt32($NodesToColumn[$ThisEvent.C_NodeName], 10)
          $MatchFound = $false
          $MatchingRow = 0
          $EmptyRows = @()

          # ----- We use a for loop instead of a ForEach-Object because
          #    break would leave the program instead of the only block
          for ( $i = 0 ; $i -lt $CorrespondingDates.count; $i++) {
            $TheCellRow = $CorrespondingDates[$i]
            $CellContent = $Sheet.Cells.Item($TheCellRow, $TheCellCol).text
            $EventInTheCell = GetEventFromCellString($CellContent)

            # --- If the cell is empty, add it to a list of empty cells
            #   We'll use the first of them to add the EventId if don't catch a matching Event Id
            if ($EventInTheCell -eq "") {
              $EmptyRows += $CorrespondingDates[$i]
            }
            elseif ($EventInTheCell -eq $ThisEvent.C_EventID) {
              $MatchingRow = $TheCellRow
              $MatchFound = $true
              break
            }
          }

          # ----- If we find one, we increment the count
          #    No need to read back the cell content : It's been read in the above look
          #    No need to reset the cell column : It's been set at the top of the block
          #    We're using the $MatchinRow as TheCellRow because it's been set in the above loop
          if ($MatchFound -eq $true) {
            [int32]$EventsCount = GetEventCountFromCellString($CellContent)
            $EventsCount += 1
            [string]$strEventCount = "(" + [convert]::ToString($EventsCount) + ")"
            $NewCellValue = $ThisEvent.C_EventID + $strEventCount
            $Sheet.Cells.Item($MatchingRow, $TheCellCol) = $NewCellValue
          }
          # ----- No match found : We must know there is an empty space
          #    - If there is an empty cell : Update this cell
          #    - If there is no empty cell and no matching event : Create a new row
          else {
            # ----- There is an empty cell : Set the cell with the EventId
            if ($EmptyRows.count -ne 0) {
              $NewCellValue = $ThisEvent.C_EventID + "(1)"
              $TheCellRow = [convert]::ToInt32($EmptyRows[0], 10)
              $Sheet.Cells.Item($TheCellRow, $TheCellCol) = $NewCellValue
            }
            # ------ There is neither empty cell nor matching event : Add a new line
            else {
              $LastUsedLine = $Sheet.UsedRange.Rows.Count
              $NewRow = $LastUsedLine + 1
              $Sheet.Cells.Item($NewRow, 1) = $ThisEvent.C_Date
              $Sheet.Cells.Item($NewRow, $TheCellCol) = $ThisEvent.C_EventID + "(1)"
            }
          }
        } # End of block "Several matching dates"
      } # End of block "At least one line with the same event is found"
    } # End of $ListOfEvents loop
  } # End if block" ListOfEvents -ne 0"

  # Save the Excel file quit Excel
  $Sheet.SaveAs($OutputFile, 6)
  $excel.Quit()

  # Display the output file using a GridView
  # The output file is still available as a CSV
  write-host "The result is stored in: " -ForegroundColor Yellow -NoNewline
  Write-Host $OutputFile

  Write-Host "Exporting the result in a grid-view" -ForegroundColor Yellow
  Import-Csv $OutputFile | Out-GridView -Title $FileName
	} #end of function ChaseEvents
  }
#endregion Script Functions
#endregion BEGIN

PROCESS {
  try {
		#region: MAIN :::::
		WriteInfo -message "Starting '$scriptName' on $(Get-Date)"
		if($ShowCommand){
			$Command = Show-Command ChaseEvents -PassThru
			Invoke-Expression -Command $Command
			#exit
		}
		else{
			$Splatting = @{}
			if($EventId) {$Splatting.Add("EventID",$EventID)}
			if($EventLevel) {$Splatting.Add("EventLevel",$EventLevel)}
			if($Days)  {$Splatting.Add("Days",$Days)}
			if($Help)  {$Splatting.Add("Help",$Help)}
			if($TimeFormat)  {$Splatting.Add("TimeFormat",$TimeFormat)}
			if($VerboseOutput)  {$Splatting.Add("VerboseOutput",$VerboseOutput)}
			if($Verbosity)  {$Splatting.Add("Verbosity",$Verbosity)}
			if($Multiline)  {$Splatting.Add("Multiline",$Multiline)}

			ChaseEvents @Splatting
		}

		$ScriptEndTimeStamp = Get-Date
		$LogLevel = 0
		$Duration = $(New-TimeSpan -Start $ScriptBeginTimeStamp -End $ScriptEndTimeStamp)
		WriteInfo -message "Script $scriptName v$verDateScript execution finished. Duration: $Duration"
		#endregion: MAIN
  } catch {
    $errorMessage = "$scriptName caught an exception on $($ENV:COMPUTERNAME):"
    $errorMessage += "`n" + "`n"
    $errorMessage += "Exception Type: $($_.Exception.GetType().FullName)"
    $errorMessage += "`n" + "`n"
    $errorMessage += "Exception Message: $($_.Exception.Message)"

    Write-Error $errorMessage -ErrorAction Continue
		<# Log error
				Write-Verbose "Logging the script's error..."
		# Log error - EventLog
				#An event log source needs to be preconfigured to use this.
				Write-EventLog `
					-EventId $AlertNumber `
					-LogName $LogName `
					-Source $EventSource `
					-Message $errorMessage `
					-EntryType Error
		# Log error - Email
				# This will attempt to send an immediate alert about the error.
				# The EventLog also needs to log the error because this one may not be sent.
				#use Send-MailMessage
		#>
    Start-Sleep -Seconds 3
    Write-Debug $errorMessage
    if ( $UseExitCode ) {
			$error.clear()	# clear script errors
      exit 1
    } #end UseExitCode
  } #end Catch
} #end PROCESS

END {
  # This resets the ErrorActionPreference to the starting value.
  $errorActionPreference = $startErrorActionPreference

	### Stats
	If ($Stats) { #increment at start of script
		Try {"$j" + " ;$CheckDate" + "; $OSVersion; " + ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name) + "; $($Duration)" + "; $NodeCnt" + "; $SDPPath" + "; $ErrorMsgPS" + "; v$verDateScript " | Out-File $CountInvFil2 -Append -Encoding UTF8 -ErrorAction SilentlyContinue} Catch { }
	}
}

#region :comments & ToDo's
<# ::::: CHASE-SEVERAL-EVENTS :::::
#
v-waalmo edits:
1) Add parameter to show-command by converting the script to a function
2) Add parameter SDPPath
3)
#  Merges the events we ask for in several columns
#  v1.3 : Added handling of events 41, 1001, 6008 & 6013
#     Added the -Multiline switch to decide wether to write all the events data
#     in one line or split it into multiple lines
#  v1.2 : Fixed a bug in the way we look for the system event logs
#
#  Improvements in vNext :
#  - Write to an Excel file instead of csv to add colors and more sophisticated outputs
#>
#endregion :comments & ToDo's



# SIG # Begin signature block
# MIInogYJKoZIhvcNAQcCoIInkzCCJ48CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCDRBtzwM5Oabu5
# Qy3qVUOffiyVAxTQ6x6VmI/plHsobaCCDYUwggYDMIID66ADAgECAhMzAAADTU6R
# phoosHiPAAAAAANNMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjMwMzE2MTg0MzI4WhcNMjQwMzE0MTg0MzI4WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDUKPcKGVa6cboGQU03ONbUKyl4WpH6Q2Xo9cP3RhXTOa6C6THltd2RfnjlUQG+
# Mwoy93iGmGKEMF/jyO2XdiwMP427j90C/PMY/d5vY31sx+udtbif7GCJ7jJ1vLzd
# j28zV4r0FGG6yEv+tUNelTIsFmmSb0FUiJtU4r5sfCThvg8dI/F9Hh6xMZoVti+k
# bVla+hlG8bf4s00VTw4uAZhjGTFCYFRytKJ3/mteg2qnwvHDOgV7QSdV5dWdd0+x
# zcuG0qgd3oCCAjH8ZmjmowkHUe4dUmbcZfXsgWlOfc6DG7JS+DeJak1DvabamYqH
# g1AUeZ0+skpkwrKwXTFwBRltAgMBAAGjggGCMIIBfjAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUId2Img2Sp05U6XI04jli2KohL+8w
# VAYDVR0RBE0wS6RJMEcxLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJh
# dGlvbnMgTGltaXRlZDEWMBQGA1UEBRMNMjMwMDEyKzUwMDUxNzAfBgNVHSMEGDAW
# gBRIbmTlUAXTgqoXNzcitW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8v
# d3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIw
# MTEtMDctMDguY3JsMGEGCCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDEx
# XzIwMTEtMDctMDguY3J0MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIB
# ACMET8WuzLrDwexuTUZe9v2xrW8WGUPRQVmyJ1b/BzKYBZ5aU4Qvh5LzZe9jOExD
# YUlKb/Y73lqIIfUcEO/6W3b+7t1P9m9M1xPrZv5cfnSCguooPDq4rQe/iCdNDwHT
# 6XYW6yetxTJMOo4tUDbSS0YiZr7Mab2wkjgNFa0jRFheS9daTS1oJ/z5bNlGinxq
# 2v8azSP/GcH/t8eTrHQfcax3WbPELoGHIbryrSUaOCphsnCNUqUN5FbEMlat5MuY
# 94rGMJnq1IEd6S8ngK6C8E9SWpGEO3NDa0NlAViorpGfI0NYIbdynyOB846aWAjN
# fgThIcdzdWFvAl/6ktWXLETn8u/lYQyWGmul3yz+w06puIPD9p4KPiWBkCesKDHv
# XLrT3BbLZ8dKqSOV8DtzLFAfc9qAsNiG8EoathluJBsbyFbpebadKlErFidAX8KE
# usk8htHqiSkNxydamL/tKfx3V/vDAoQE59ysv4r3pE+zdyfMairvkFNNw7cPn1kH
# Gcww9dFSY2QwAxhMzmoM0G+M+YvBnBu5wjfxNrMRilRbxM6Cj9hKFh0YTwba6M7z
# ntHHpX3d+nabjFm/TnMRROOgIXJzYbzKKaO2g1kWeyG2QtvIR147zlrbQD4X10Ab
# rRg9CpwW7xYxywezj+iNAc+QmFzR94dzJkEPUSCJPsTFMIIHejCCBWKgAwIBAgIK
# YQ6Q0gAAAAAAAzANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlm
# aWNhdGUgQXV0aG9yaXR5IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEw
# OTA5WjB+MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYD
# VQQDEx9NaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG
# 9w0BAQEFAAOCAg8AMIICCgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+la
# UKq4BjgaBEm6f8MMHt03a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc
# 6Whe0t+bU7IKLMOv2akrrnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4D
# dato88tt8zpcoRb0RrrgOGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+
# lD3v++MrWhAfTVYoonpy4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nk
# kDstrjNYxbc+/jLTswM9sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6
# A4aN91/w0FK/jJSHvMAhdCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmd
# X4jiJV3TIUs+UsS1Vz8kA/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL
# 5zmhD+kjSbwYuER8ReTBw3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zd
# sGbiwZeBe+3W7UvnSSmnEyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3
# T8HhhUSJxAlMxdSlQy90lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS
# 4NaIjAsCAwEAAaOCAe0wggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRI
# bmTlUAXTgqoXNzcitW2oynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTAL
# BgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBD
# uRQFTuHqp8cx0SOJNDBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jv
# c29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3JsMF4GCCsGAQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3J0MIGfBgNVHSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEF
# BQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1h
# cnljcHMuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkA
# YwB5AF8AcwB0AGEAdABlAG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn
# 8oalmOBUeRou09h0ZyKbC5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7
# v0epo/Np22O/IjWll11lhJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0b
# pdS1HXeUOeLpZMlEPXh6I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/
# KmtYSWMfCWluWpiW5IP0wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvy
# CInWH8MyGOLwxS3OW560STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBp
# mLJZiWhub6e3dMNABQamASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJi
# hsMdYzaXht/a8/jyFqGaJ+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYb
# BL7fQccOKO7eZS/sl/ahXJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbS
# oqKfenoi+kiVH6v7RyOA9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sL
# gOppO6/8MO0ETI7f33VtY5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtX
# cVZOSEXAQsmbdlsKgEhr/Xmfwb1tbWrJUnMTDXpQzTGCGXMwghlvAgEBMIGVMH4x
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01p
# Y3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTECEzMAAANNTpGmGiiweI8AAAAA
# A00wDQYJYIZIAWUDBAIBBQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQw
# HAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIM+e
# oNXiOLdgzhQrBJIxoru9AxVE7bq/+08w0i3xxqVxMEIGCisGAQQBgjcCAQwxNDAy
# oBSAEgBNAGkAYwByAG8AcwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20wDQYJKoZIhvcNAQEBBQAEggEAS4197nrrm7VLDygOYwGnRcam7xoW1fU9kb0m
# 0nyTLeDvj4gjUiYf6fv5nfjXXLPKAAM3jr1pG5Obh9jA1FNfI+yxzC2YK0YaBxxF
# Q+CTyJvVZQAVSWPPqUKi+Khn4GlIRJhnotIjhRdI3i925JHdLeaW2t/qvryPQfE+
# nJvE7JalcP2s2xzJmmnjlY7/SlVocPMTeheUAGg0cxEXIcma4fcLDYNfh5OnYO20
# SRoUh3DilqopwtmXlHcW/0sXU3IZpXdIV2zcXIMOJ8oQj4zEYEOvdB9WrxYrz1j8
# oaIRNS3Zbdz421EujUzQXKW7x83Lv9BvqRxbjOvrzJm6ui8IIKGCFv0wghb5Bgor
# BgEEAYI3AwMBMYIW6TCCFuUGCSqGSIb3DQEHAqCCFtYwghbSAgEDMQ8wDQYJYIZI
# AWUDBAIBBQAwggFRBgsqhkiG9w0BCRABBKCCAUAEggE8MIIBOAIBAQYKKwYBBAGE
# WQoDATAxMA0GCWCGSAFlAwQCAQUABCCZTxMQlI4mgL9E2qUKjpRlL8cH98bG/vPU
# InZav+RWkAIGZItkHEm5GBMyMDIzMDcwNTE5NDYzOS4zMTFaMASAAgH0oIHQpIHN
# MIHKMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQL
# ExxNaWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25zMSYwJAYDVQQLEx1UaGFsZXMg
# VFNTIEVTTjo0OUJDLUUzN0EtMjMzQzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUt
# U3RhbXAgU2VydmljZaCCEVQwggcMMIIE9KADAgECAhMzAAABwFWkjcNkFcVLAAEA
# AAHAMA0GCSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEw
# MB4XDTIyMTEwNDE5MDEyNVoXDTI0MDIwMjE5MDEyNVowgcoxCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBBbWVy
# aWNhIE9wZXJhdGlvbnMxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjQ5QkMtRTM3
# QS0yMzNDMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIIC
# IjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAvO1g+2NhhmBQvlGlCTOMaFw3
# jbIhUdDTqkaQhRpdHVb+huU/0HNhLmoRYvrp7z5vIoL1MPAkVBFWJIkrcG7sSred
# nyZwreY207C9n8XivL9ZBOQeiUeL/TMlJ6VinrcafbhdnkNO5JDlPozC9dGySiub
# ryds5GKtu69D1wNat9DIQl6alFO6pncZK4RIzfv+KzkM7RkY3vHphV0C8EFUpF+l
# ysaGJXFf9QsUUHwj9XKWHfc9BfhLoCReXUzvgrspdFmVnA9ATYXmidSjrshf8A+E
# 0/FpTdhXPI9XXqsZDHBqr7DlYoSCU3lvrVDRu1p5pHHf7s3kM16HpK6arDtY3ai1
# soASmEpv3C2N/y5MDBApDd4SpSkLMa7+6es/daeS7zdH1qdCa2RoJPM6Eh/6YmBf
# ofhfLQofKPJl34ALlZWK5AzVtFRNOXacoj6MAG2dT8Rc5fpKCH1E3n7Zje0dK24Q
# VfSv/YOxw52ECaMLlW5PhHT3ZINNaCmRgcHCTClOKzC2FOr03YBc2zPOW6bIVdXl
# oPmBMVaE+thXqPmANBw0YsncaOkVggjDb5O5VqOp98MklHpJoJI6pk5zAlx8/OtC
# 7FutrdtYNUC6ykXzMAPFuYkWGgx/W7A0itKW8WzYzwO3bAhprwznouGZmRiw2k8p
# en80BzqzdyPvbzTxQsMCAwEAAaOCATYwggEyMB0GA1UdDgQWBBQARMZ480jwpK3P
# 6quVWUEJ0c30hTAfBgNVHSMEGDAWgBSfpxVdAF5iXYP05dJlpxtTNRnpcjBfBgNV
# HR8EWDBWMFSgUqBQhk5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2Ny
# bC9NaWNyb3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIwMjAxMCgxKS5jcmwwbAYI
# KwYBBQUHAQEEYDBeMFwGCCsGAQUFBzAChlBodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NlcnRzL01pY3Jvc29mdCUyMFRpbWUtU3RhbXAlMjBQQ0ElMjAy
# MDEwKDEpLmNydDAMBgNVHRMBAf8EAjAAMBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0G
# CSqGSIb3DQEBCwUAA4ICAQCtTh0EQn16kKQyCeVk9Vc10m6L0EwLRo3ATRouP7Yd
# 2hWeEB2Y4ZF4CJKe9qfXWGJKzV7tMUm6DAsBKYH/nT+8ybI8uJiHGnfnVi6Sh7gF
# jnTpfh1j1T90H/uLeoFjpOn/+eoCoJmorW5Gb2ezlTlo5I0kNAubxtCxqbLizuPN
# Pob8kRAKQgv+4/CC1JmiUFG0uKINlKj9SsHcrWeBBQHX62nNgziIwT44JqHrA02I
# 6cmQAi9BZcsf57OOLpRYlzoPH3x/+ldSySXAmyLq2uSbWtQuD84I/0ZgS/B5L3ew
# qTdiE1KbKX89MW5JqCK/yI/mAIQammAlHPqU9eZZTMPOHQs0XrpCijlk+qyo2JaH
# iySww6nuPqXzU3sEj3VW00YiVSayKEu1IrRzzX3La8qe6OqLTvK/6gu5XdKq7TT8
# 52nB6IP0QM+Budtr4Fbx4/svpKHGpK9/zBuaHHDXX5AoSksh/kSDYKfefQIhIfQJ
# JzoE3X+MimMJrgrwZXltb6j1IL0HY3qCpa03Ghgi0ITzqfkw3Man3G8kB1Ql+SeN
# ciPUj73Kn2veJenGLtT8JkUM9RUi0woO0iuY4tJnYuS+SeqavXUOWqUYVY19FIr1
# PLqpmWkbrO5xKjkyOHoAmLxjNbKjOnkAwft+1G00kulKqzqPbm+Sn+47JsGQFhNG
# bTCCB3EwggVZoAMCAQICEzMAAAAVxedrngKbSZkAAAAAABUwDQYJKoZIhvcNAQEL
# BQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xMjAwBgNV
# BAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmljYXRlIEF1dGhvcml0eSAyMDEwMB4X
# DTIxMDkzMDE4MjIyNVoXDTMwMDkzMDE4MzIyNVowfDELMAkGA1UEBhMCVVMxEzAR
# BgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1p
# Y3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3Rh
# bXAgUENBIDIwMTAwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDk4aZM
# 57RyIQt5osvXJHm9DtWC0/3unAcH0qlsTnXIyjVX9gF/bErg4r25PhdgM/9cT8dm
# 95VTcVrifkpa/rg2Z4VGIwy1jRPPdzLAEBjoYH1qUoNEt6aORmsHFPPFdvWGUNzB
# RMhxXFExN6AKOG6N7dcP2CZTfDlhAnrEqv1yaa8dq6z2Nr41JmTamDu6GnszrYBb
# fowQHJ1S/rboYiXcag/PXfT+jlPP1uyFVk3v3byNpOORj7I5LFGc6XBpDco2LXCO
# Mcg1KL3jtIckw+DJj361VI/c+gVVmG1oO5pGve2krnopN6zL64NF50ZuyjLVwIYw
# XE8s4mKyzbnijYjklqwBSru+cakXW2dg3viSkR4dPf0gz3N9QZpGdc3EXzTdEonW
# /aUgfX782Z5F37ZyL9t9X4C626p+Nuw2TPYrbqgSUei/BQOj0XOmTTd0lBw0gg/w
# EPK3Rxjtp+iZfD9M269ewvPV2HM9Q07BMzlMjgK8QmguEOqEUUbi0b1qGFphAXPK
# Z6Je1yh2AuIzGHLXpyDwwvoSCtdjbwzJNmSLW6CmgyFdXzB0kZSU2LlQ+QuJYfM2
# BjUYhEfb3BvR/bLUHMVr9lxSUV0S2yW6r1AFemzFER1y7435UsSFF5PAPBXbGjfH
# CBUYP3irRbb1Hode2o+eFnJpxq57t7c+auIurQIDAQABo4IB3TCCAdkwEgYJKwYB
# BAGCNxUBBAUCAwEAATAjBgkrBgEEAYI3FQIEFgQUKqdS/mTEmr6CkTxGNSnPEP8v
# BO4wHQYDVR0OBBYEFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMFwGA1UdIARVMFMwUQYM
# KwYBBAGCN0yDfQEBMEEwPwYIKwYBBQUHAgEWM2h0dHA6Ly93d3cubWljcm9zb2Z0
# LmNvbS9wa2lvcHMvRG9jcy9SZXBvc2l0b3J5Lmh0bTATBgNVHSUEDDAKBggrBgEF
# BQcDCDAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvXzpoYxDBW
# BgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYIKwYBBQUH
# AQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtp
# L2NlcnRzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNydDANBgkqhkiG9w0BAQsF
# AAOCAgEAnVV9/Cqt4SwfZwExJFvhnnJL/Klv6lwUtj5OR2R4sQaTlz0xM7U518Jx
# Nj/aZGx80HU5bbsPMeTCj/ts0aGUGCLu6WZnOlNN3Zi6th542DYunKmCVgADsAW+
# iehp4LoJ7nvfam++Kctu2D9IdQHZGN5tggz1bSNU5HhTdSRXud2f8449xvNo32X2
# pFaq95W2KFUn0CS9QKC/GbYSEhFdPSfgQJY4rPf5KYnDvBewVIVCs/wMnosZiefw
# C2qBwoEZQhlSdYo2wh3DYXMuLGt7bj8sCXgU6ZGyqVvfSaN0DLzskYDSPeZKPmY7
# T7uG+jIa2Zb0j/aRAfbOxnT99kxybxCrdTDFNLB62FD+CljdQDzHVG2dY3RILLFO
# Ry3BFARxv2T5JL5zbcqOCb2zAVdJVGTZc9d/HltEAY5aGZFrDZ+kKNxnGSgkujhL
# mm77IVRrakURR6nxt67I6IleT53S0Ex2tVdUCbFpAUR+fKFhbHP+CrvsQWY9af3L
# wUFJfn6Tvsv4O+S3Fb+0zj6lMVGEvL8CwYKiexcdFYmNcP7ntdAoGokLjzbaukz5
# m/8K6TT4JDVnK+ANuOaMmdbhIurwJ0I9JZTmdHRbatGePu1+oDEzfbzL6Xu/OHBE
# 0ZDxyKs6ijoIYn/ZcGNTTY3ugm2lBRDBcQZqELQdVTNYs6FwZvKhggLLMIICNAIB
# ATCB+KGB0KSBzTCByjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0aW9uczEmMCQGA1UE
# CxMdVGhhbGVzIFRTUyBFU046NDlCQy1FMzdBLTIzM0MxJTAjBgNVBAMTHE1pY3Jv
# c29mdCBUaW1lLVN0YW1wIFNlcnZpY2WiIwoBATAHBgUrDgMCGgMVABAQ7ExF19Kk
# wVL1E3Ad8k0Peb6doIGDMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldh
# c2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBD
# b3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIw
# MTAwDQYJKoZIhvcNAQEFBQACBQDoUD4vMCIYDzIwMjMwNzA2MDMwODMxWhgPMjAy
# MzA3MDcwMzA4MzFaMHQwOgYKKwYBBAGEWQoEATEsMCowCgIFAOhQPi8CAQAwBwIB
# AAICBVYwBwIBAAICEeQwCgIFAOhRj68CAQAwNgYKKwYBBAGEWQoEAjEoMCYwDAYK
# KwYBBAGEWQoDAqAKMAgCAQACAwehIKEKMAgCAQACAwGGoDANBgkqhkiG9w0BAQUF
# AAOBgQA9GPEEDPTartFHVI0ngc0ZCDGlO7efCuz2jUQCijcWbayNd/Kw4S6Hm6n5
# EBdl82uMCGqFE/+JQrave6/NhCFP2Iyzgfl+SBFgebWriM8qn0bjRZgq8630nn8o
# 7pNpj+iANe6GY0JgYt+OOSwlPpdy6R4M4SLqGWNRF9x2r+nYFjGCBA0wggQJAgEB
# MIGTMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAABwFWkjcNkFcVL
# AAEAAAHAMA0GCWCGSAFlAwQCAQUAoIIBSjAaBgkqhkiG9w0BCQMxDQYLKoZIhvcN
# AQkQAQQwLwYJKoZIhvcNAQkEMSIEIAKQvtW0QRk6wzl8LEijFtzftdwyeOsynfmH
# X2EnuofmMIH6BgsqhkiG9w0BCRACLzGB6jCB5zCB5DCBvQQgWvFYolIIXME0zK/W
# 6XsCkkYX7lYNb9yA8JxwY04Pk08wgZgwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEG
# A1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWlj
# cm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFt
# cCBQQ0EgMjAxMAITMwAAAcBVpI3DZBXFSwABAAABwDAiBCDc/OJA5e3+KXdaXbpK
# gDzFm+r3KW0z12xZmvLG960keDANBgkqhkiG9w0BAQsFAASCAgAnntug+Ma4jT7/
# JjsVweIEPAEXRCGSnEslVFfgvia9B9ocjKq6CqtM8SIVJT7unZifnGHf4JafozV7
# JHjqdvvR+Wi1vq/JbLsCP4NoCclDxXTtW/LGN/r7zEgRiGhSA8KHFEOvxxZ/FeaU
# OIHQJ8djtginWBSLhR8Pa0LTdK+Wvv5DT4CbJTGJGVDpvEylahJ387SpenwVxAqP
# i+fc2tRxxhUPOPe1TcnoTjK4anYWWCYWguVMkw4/DSKCCnKY9WHyj5MXEjbnOFnr
# gM8Et9o8jcNOuxc3FMGGrEKrjyTTH8DZyZUElbyrlb0I5FTPHWah7sD0GuBS9DcT
# E4xZIQf7BDJZZ9+DhPANk1pZFnnoptTExK0R5eThNnxPS3aJCLVbSnJyXGMpqFwz
# AcxIH+9PsRUERepWlP4STo2ZuHZvSQJWGjCSIH1PCzOhIc5TFemCT6rsg7IxKSpQ
# BLyTEzfVGdC7L23NDQzztaiA7VrTAjt7o+c1oAkoAwZWt499THjwfERj4p1OB7sh
# xweRjsSxTnG+BJMzGe8g3/OxxnISzcpcQh3JXwXv/cSxJpzBy00vhKH7TkuoxH/H
# 6AGpK0qq5Yr6fF0Idi6uLkQ0bl1ECFMicvi/EdgD91FjTZWOKY1oj0nHctIvaw7Q
# ZXCLIH2zwKKWEaEy7BnIpFy5Qeox9g==
# SIG # End signature block
