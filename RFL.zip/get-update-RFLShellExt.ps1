# File: get-update-RFLShellExt.ps1 V2
# last edit by: waltere 2022-10-13

<#
.SYNOPSIS
The script will install or update your current version of the RFL PlugIn on your system to latest version.
The registry file for the latest version of the shell extension is located here: \\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\Rfl-Check_ShellExtension.reg -or- in offline package RFL.zip

SYNTAX: .\get-update-RFLShellExt.ps1 [Check-RFL|Check_RFL_anchor|Check_SDP_anchor]

.DESCRIPTION
The script reads in your current registry RFL information and writes new registry key.
The script tries to run itself in elevated mode and ask user to agree, because REG changes need admin permission.
Note: In case of any error, you still can download to local drive and doubleclick the *.reg file on
   \\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\Rfl-Check_ShellExtension.reg

.PARAMETER SkipAdminCheck
If this switch is present, then the check for administrator privileges will be skipped.

.EXAMPLE
To run the RFL shell PlugIn check and update on UNC path
	\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\get-update-RFLShellExt.ps1

.LINK
Update script: \\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\get-update-RFLShellExt.ps1
ShellExtension: \\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\Rfl-Check_ShellExtension.reg
RFL core team: waltere@microsoft.com

#>

[CmdletBinding()]
PARAM (
	[ValidateSet("Check-RFL","Check_RFL_anchor","Check_SDP_anchor")]
	[parameter(Mandatory=$False,Position=0,HelpMessage='Choose one from: [Check_RFL_anchor|Check_SDP_anchor]')]
	[string]$CheckType = "Check_RFL_anchor"	,
	[parameter(Mandatory=$false)]
	[switch]$SkipAdminCheck = $false,
	[switch]$HostMode  = $false, #This tells the logging functions to show logging on the screen
	[switch]$ScriptMode = $false, #This tells the logging functions to show logging in log file
	[switch]$UseExitCode= $true  #This will cause the script to close after the error is logged if an error occurs.
	)

BEGIN {
	$verDateScript = "2023.02.09.0"
	$ScriptFolder = Split-Path $MyInvocation.MyCommand.Path -Parent
	# Load Common Library:
	. $ScriptFolder\Utils_RflShared.ps1

	# update needs elevation
	Write-Host "[RFLshExt_Update] Checking for elevation... "
	$CurrentUser = New-Object Security.Principal.WindowsPrincipal $([Security.Principal.WindowsIdentity]::GetCurrent())
	if (($CurrentUser.IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)) -eq $false)
	{
		$ArgumentList = "-noprofile -noexit -file `"{0}`" " #-Path `"$scriptPath`" -MaxStage $MaxStage"
		If ($ValidateOnly) { $ArgumentList = $ArgumentList + " -ValidateOnly" }
		If ($SkipValidation) { $ArgumentList = $ArgumentList + " -SkipValidation $SkipValidation" }
		If ($Mode) { $ArgumentList = $ArgumentList + " -Mode $Mode" }
		Write-Host "...elevating in new Admin PS window"
		Start-Process powershell.exe -Verb RunAs -ArgumentList ($ArgumentList -f ($myinvocation.MyCommand.Definition)) #-Wait
		Exit
	}
	# Run your code that needs to be elevated here...
#-------------------------------------------------
	Write-host -BackgroundColor Black -ForegroundColor Gray -Object "[RFLshExt_Update] ...Running now with Admin priv (Elevated)"

	$error.clear()	# clear PS script errors
	# This saves the starting ErrorActionPreference and then sets it to 'Stop'.
	$startErrorActionPreference = $errorActionPreference
	$errorActionPreference = 'Continue' # 'Stop' #
	# This gets the current path and name of the script.
	$invocation = (Get-Variable MyInvocation).Value
	$invocationLine= $($MyInvocation.Line)
	$scriptPath = Split-Path $invocation.MyCommand.Path
	#$ScriptParentPath 	= Split-Path $MyInvocation.MyCommand.Path -Parent
	$scriptName = $invocation.MyCommand.Name
	$UserName  = ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name)
	$UsrOSVersion = [Environment]::OSVersion.Version.ToString(3)
	$CheckDate = (Get-Date).ToUniversalTime().ToString("yy-MM-dd_HH-mm-ss")
	#$Script:PSver = $PSVersionTable.PSVersion.Major
	#Write-Host "Running `"$scriptPath\$scriptName`"..." -BackgroundColor Black -ForegroundColor Green
	Set-Variable -Name ErrorMsg -Scope Script -Force
	[string]$Script:ErrorMsg=""

#region ###### customization section of script, logging configuration ########################
	$SDPcheckINI = (Get-content -Path "$ScriptFolder\_SDPcheck.ini")
	$InOfflineMode 	= (($SDPcheckINI[1] -split " ")[2]).trim("""")	# set $True for outsourcer or when not connected to MS network - offline-SDPcheck
	$ExpectedShellExtVersion = (($SDPcheckINI[6] -split " ")[2]).trim("""")
	$RFLroot = (($SDPcheckINI[2] -split " ")[2]).trim("""")	# "\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\" -or- "\\localhost\ToolsShare\rfl\"
	if ($InOfflineMode -match "False") {
		$StatsServer = (($SDPcheckINI[5] -split " ")[2]).trim("""")
		if (Test-Connection -ComputerName $StatsServer -Quiet -Count 1) {[bool]$Stats=$True} else {[bool]$Stats=$False}
	} else { 
		$Stats = $False
	}
	$OnlyRun_AsAdmin = 0
	$Script:regFile = "$RFLroot\Rfl-Check_ShellExtension.reg"
	$Script:regFileV1remove = "$RFLroot\Rfl-Check_ShellExtension_V1-Remove.reg"
	$Script:regFileV2add = "$RFLroot\Rfl-Check_ShellExtension.reg"
	$Script:regFileV2remove = "$RFLroot\Rfl-Check_ShellExtension_Remove.reg"
	$UsrOSVersion = [Environment]::OSVersion.Version.ToString(3)
	$LogLevel = 0
#endregion: ###### customization section

	if ($Stats) {
		$StatsServerPath="\\$StatsServer\RFLstats$\RFL\scripts\Stats\"
		$CountInvFil = $StatsServerPath +'countRFLshExUpd.dat'
		$CountInvFil2 = $CountInvFil +'.us'
		#increment at start of script
		 ($j=[int32](Get-Content $CountInvFil -TotalCount 1 -ErrorAction SilentlyContinue)) |out-null
		 Try {(++$j) | Set-Content $CountInvFil -ErrorAction SilentlyContinue} Catch { }
	}
	$ErrorThrown = $null

	If ($PSBoundParameters['Debug']) { $DebugPreference='Continue'}
	#ConsoleColor enumeration values: Black DarkBlue DarkGreen DarkCyan DarkRed DarkMagenta DarkYellow Gray DarkGray Blue Green Cyan Red Magenta Yellow White

	Set-Variable -Name ShellExtExists -Scope Script -Force
	Set-Variable -Name ShellExtVersion -Scope Script -Force
	Set-Variable -Name regFile -Scope Script -Force
	$Script:ShellExtVersion ='undefined'

#region: Script Functions

function checkPlugin-RFLShellExt ($CheckType,$ExpectedShellExtVersion) {
	RflEnterFuncDbg $MyInvocation.MyCommand.Name
	Write-host "[RFLshExt_Plugin] Checking for existing ShellExt for $($CheckType) "
	#check if RFLShellExt is installed and 'Version' key exists
	New-PSDrive -Name HKCR -PSProvider Registry -Root HKEY_CLASSES_ROOT |out-null
	$registryPathHKCR = "HKCR:\Directory\shell\$($CheckType)"

	Write-host "[RFLshExt_Plugin] _Checking existing ShellExt in $registryPathHKCR"
	Try { $ErrorActionPreference = "stop"
		$Script:ShellExtExists = (Get-ItemProperty -Path $registryPathHKCR )
		if ($Script:ShellExtExists)	{ Write-host "[RFLshExt_Plugin] __Found ShellExt in $registryPathHKCR" }
	}
	Catch [System.Management.Automation.ItemNotFoundException]
		{ Write-host -BackgroundColor Black -ForegroundColor Yellow -Object "... Simplify: Consider to run Explorer-Extension update in elevated (Run as Administrator) PS cmd, see also _Help.rtf:"
		Write-host -BackgroundColor Black -ForegroundColor Cyan -Object " Powershell -ExecutionPolicy Bypass $RFLroot\get-update-RFLShellExt.ps1"
		Write-host "[RFLshExt_Update] ...RFLshellPlugin not installed - creating it."
		#Write-host "[RFLshExt_Update] ...***please allow registry Version update when UAC prompted***"
		return "[RFLshExt_Update] RegKey $registryPathHKCR itself is missing."
	}
	Finally { $ErrorActionPreference = "Continue" }
	RflEndFunc $MyInvocation.MyCommand.Name
}

function checkVer-RFLShellExt ($CheckType,$ExpectedShellExtVersion) {
	RflEnterFuncDbg $MyInvocation.MyCommand.Name
	Write-host "[RFLshExt_Version] Checking ShellExt Version for $($CheckType) "
	#check if RFLShellExt is installed and 'Version' key exists
	New-PSDrive -Name HKCR -PSProvider Registry -Root HKEY_CLASSES_ROOT |out-null
	$registryPathHKCR = "HKCR:\Directory\shell\$($CheckType)"
	$name = "Version"
	$value = "1.00"
	Write-host "[RFLshExt_Version] _Checking current version in $registryPathHKCR"
	Try { $ErrorActionPreference = "stop"
		$Script:ShellExtVersion = (Get-ItemProperty -Path $registryPathHKCR -Name Version).Version
		if ($Script:ShellExtVersion)	{ Write-host "[RFLshExt_Version] __latest available ShellExtVersion is: $Script:ExpectedShellExtVersion"
			IF ($Script:ShellExtVersion -match $ExpectedShellExtVersion) {
				Write-host "[RFLshExt_Version] __Your RFL ShellExtension version $Script:ShellExtVersion is up-to-date";
				RflEndFunc ($MyInvocation.MyCommand.Name + "($Script:ShellExtVersion _up-to-date)")
				return "$Script:ShellExtVersion _up-to-date"}
			ELSE { if ($Script:ShellExtVersion -lt 1.09) {Write-host -BackgroundColor Black -ForegroundColor Red -Object " Support for this older RFL version will end *soon*, because Server \\muc-vfs-01a will be decommissioned."}
					Write-host -BackgroundColor Yellow -ForegroundColor Black -Object "[RFLshExt_Version] __Your RFL ShellExtension version $Script:ShellExtVersion is outdated!
 .. Consider updating the RFL Shell Explorer Plugin `n $Script:regFileV2add
 To do so, run in ELEVATED (Run as Administrator) PS window the command: "
				Write-host -ForegroundColor Cyan -Object " Powershell -ExecutionPolicy Bypass $RFLroot\get-update-RFLShellExt.ps1"
				RflEndFunc ($MyInvocation.MyCommand.Name + "($Script:ShellExtVersion _outdated)")
				return "$Script:ShellExtVersion _outdated - user_informed"}
		}
	}
	Catch [System.Management.Automation.PSArgumentException]
	{
		if ($Script:ShellExtVersion -lt 1.09) {Write-host -BackgroundColor Black -ForegroundColor Red -Object "Support for this older RFL version will end *soon*, because Server \\muc-vfs-01a will be decommissioned. "}
		Write-host -BackgroundColor Yellow -ForegroundColor Black -Object "[RFLshExt_Version] __Your RFL ShellExtension version $Script:ShellExtVersion is outdated!
 Please update the RFL Shell Extension `n $Script:regFileV2add
 To do so, run in ELEVATED (Run as Administrator) PS window the command: "
		Write-host -BackgroundColor Black -ForegroundColor Cyan -Object " Powershell -ExecutionPolicy Bypass $RFLroot\get-update-RFLShellExt.ps1"
		"[RFLshExt_Version] RegKey $registryPathHKCR Property $name missing."
	}
	Catch [System.Management.Automation.ItemNotFoundException]
	{ Write-host "[RFLshExt_Version] RegKey $registryPathHKCR\Version is missing."
		Write-debug "[RFLshExt_Version] ...RFLshellPlugin not up-to-date"
		Write-debug "[RFLshExt_Version] ...***please allow registry Version update when UAC prompted***"
		"[RFLshExt_Version] RegKey $registryPathHKCR\Version is missing."
	}
	Finally { $ErrorActionPreference = "Continue" }
	RflEndFunc $MyInvocation.MyCommand.Name
}

function CheckForUpdates-RFLShellExt ($CheckType,$ExpectedShellExtVersion) {
	RflEnterFuncDbg $MyInvocation.MyCommand.Name
	if ($OnlyRun_AsAdmin){
		 Write-host "[RFLshExt_ChkUpdates] checking registryPath: $registryPathHKCR\CheckForUpdates"
		 $name = "CheckForUpdates"
		 $value = "1"
		Try { $ErrorActionPreference = "stop"
			$CheckForUpdates = (Get-ItemProperty -Path $registryPathHKCR -Name CheckForUpdates).CheckForUpdates
			if ($CheckForUpdates) {Write-host "[RFLshExt_ChkUpdates] Current CheckForUpdates: $CheckForUpdates"}
			if ($CheckForUpdates -NotMatch "0") {Write-host "[RFLshExt_ChkUpdates] Current ShellExt setting for CheckForUpdates: $CheckForUpdates"}
			else {	Write-host "[RFLshExt_ChkUpdates] CheckForUpdates: '$CheckForUpdates' - .. Consider updating the RFL Shell Explorer Plugin `n $Script:regFileV2add "
				Write-host "[RFLshExt_ChkUpdates] ... keep existing plugin settings because $registryPathHKCR\CheckForUpdates is set to '$CheckForUpdates'"
				break #continue
				}
		 }
		 Catch [System.Management.Automation.PSArgumentException]
		  { "[RFLshExt_ChkUpdates] RegKey $registryPathHKCR Property $name missing."
			 New-ItemProperty -Path $registryPathHKCR -Name $name -Value $value -PropertyType DWORD -Force | Out-Null
		  }
		 Catch [System.Management.Automation.ItemNotFoundException]
		  { "[RFLshExt_ChkUpdates] RegKey $registryPathHKCR itself is missing."
			 Write-host "[RFLshExt_ChkUpdates] ...RFLshellPlugin not installed - creating it"
			 New-Item -Path $registryPathHKCR -Force #| Out-Null
			 New-ItemProperty -Path $registryPathHKCR -Name $name -Value $value -PropertyType DWORD -Force | Out-Null
		 }
		 Finally {
			 "[RFLshExt_ChkUpdates] CheckForUpdates reg: $CheckForUpdates"
			 $ErrorActionPreference = "Continue" }
	 } # end of if ($OnlyRun_AsAdmin)
	 RflEndFunc $MyInvocation.MyCommand.Name
}

function update-ShellExt ($CheckType,$ExpectedShellExtVersion) {
	RflEnterFuncDbg $MyInvocation.MyCommand.Name
	if (!($Script:ShellExtVersion -match $ExpectedShellExtVersion) -and ($CheckForUpdates -NotMatch "0")) {
		write-host "[RFLshExt_Update] ...Outdated Check_RFL ShellExtVersion v$Script:ShellExtVersion"
		Try
		{
		write-host "[RFLshExt_Update] ...removing existing entry Check_RFL v$Script:ShellExtVersion"
		$RegTryRemoveV1 = regedit /s $Script:regFileV1remove
		$RegTryRemoveV2 = regedit /s $Script:regFileV2remove
		write-host "[RFLshExt_Update] ...Importing latest v$ExpectedShellExtVersion $Script:regFile silently"
		$RegTryAdd = regedit /s $Script:regFile
		write-host "[RFLshExt_Update] ...Registry Update result: $RegTryAdd"
		Write-host -BackgroundColor Black -ForegroundColor Green -Object "[RFLshExt_Update] RFLShellExt $CheckType successfully updated"
		"RegImport-done $ExpectedShellExtVersion"
		}
		Catch [System.Security.SecurityException]
			{ "Registry Remove-Item $registryPathHKCR"
			}
		Catch
			{
				Write-Error "[RFLshExt_Update] Aborted. The error was '$($_.Exception.Message)'"
				Write-host -BackgroundColor Black -ForegroundColor Red -Object "[RFLshExt_Update] Aborted by user"
				"Aborted by user."
			}
		Finally
		{
			"$Script:ShellExtVersion RegVersion-not-matched. Prev.Ver: $Script:ShellExtVersion"
		}
	}
	RflEndFunc $MyInvocation.MyCommand.Name
}

function autoupdate-ShellExt ($CheckType,$ExpectedShellExtVersion) {
	RflEnterFuncDbg $MyInvocation.MyCommand.Name
	checkPlugin-RFLShellExt $CheckType $ExpectedShellExtVersion		#call function
	if ($Script:ShellExtExists)	{
		checkVer-RFLShellExt $CheckType $ExpectedShellExtVersion	#call function
	}
	update-ShellExt $CheckType $ExpectedShellExtVersion				#call function
	RflEndFunc $MyInvocation.MyCommand.Name
}

function remove-ShellExt ($RegKey) {
	# SYNOPSIS :
	RflEnterFuncDbg $MyInvocation.MyCommand.Name
	New-PSDrive -Name HKCR -PSProvider Registry -Root HKEY_CLASSES_ROOT |out-null

	Try	{
		write-host "[RFLshExt_Remove] _Trying to remove entry $RegKey"
		Remove-Item $RegKey -Recurse -ErrorAction SilentlyContinue
	}
	Catch [System.Security.SecurityException]
		{ "Registry Remove-Item $RegKey" }
	Catch [System.Management.Automation.ItemNotFoundException]
		{"RegKey $RegKey is missing."}
	Catch
		{
			Write-Error "[RFLshExt_Remove] Aborted. The error was '$($_.Exception.Message)'"
			Write-host -BackgroundColor Black -ForegroundColor Red -Object "[RFLshExt_Remove] Aborted by user"
			"Aborted by user."
		}
	Finally { " _ $RegKey done"}
	RflEndFunc $MyInvocation.MyCommand.Name
}
#endregion: Script Functions
} #end BEGIN

PROCESS {
	try {
		$ScriptBeginTimeStamp = Get-Date
		#region: MAIN :::::

		#for downlevel Plugin V1 with parameter Check-RFL
		if ($CheckType -match "Check-RFL") { $CheckType = "Check_RFL_anchor"}
		Write-host "CheckType: $CheckType "

		### main
		$au = autoupdate-ShellExt $CheckType $ExpectedShellExtVersion		#call function
		$Script:ResultMsg = $au
		Write-verbose "[RFLshExt_Update] AutoUpdate results: $au"
		If (-not $au) {Write-host "[RFLshExt_Update] .. Consider updating the RFL Shell Explorer Plugin $Script:regFile "}
		write-host -BackgroundColor Black -ForegroundColor Green -Object "[RFLshExt_Update] ...done. New RFL ShellExt $ExpectedShellExtVersion plugin should be available in your Windows Explorer context menu for folders right now."
		write-host -ForegroundColor Gray "Note: In case of any error, you still can download to local drive and doubleclick the *.reg file on
			 $($RFLroot)\Rfl-Check_ShellExtension.reg `n"

		#endregion: MAIN :::::
	}
	catch {
		$ErrorThrown = $true
		$errorMessage = "$scriptName caught an exception on $($ENV:COMPUTERNAME):`n`n"
		$errorMessage += "Exception Type: $($_.Exception.GetType().FullName)"
		$errorMessage += "`n`n Exception Message: $($_.Exception.Message)"

		Write-Error $errorMessage -ErrorAction Continue
		Start-Sleep -Seconds 3
		Write-Debug $errorMessage
		if ($UseExitCode) {
			$error.clear()	# clear script errors
			exit 1
		}
  } #end Catch PROCESS
	Finally {
	}
} #end PROCESS

END {
	$ScriptEndTimeStamp = Get-Date
	$Duration = $(New-TimeSpan -Start $ScriptBeginTimeStamp -End $ScriptEndTimeStamp)
	$LogLevel = 0
	Write-host -BackgroundColor Gray -ForegroundColor Black -Object " Script $scriptName v$verDateScript execution finished. Duration: $Duration"
	# This resets the ErrorActionPreference to the value at script start.
	$errorActionPreference = $startErrorActionPreference
	# Stats
	If ($Stats) { #increment at start of script
	 Try {"$j; $CheckDate; $UsrOSVersion; $UserName; $Duration; $Script:ShellExtVersion; $Script:ResultMsg; v$verDateScript ; $env:computername" | Out-File $CountInvFil2 -Append -Encoding UTF8 -ErrorAction SilentlyContinue} Catch { }
	 }
	if($ErrorThrown) {Throw $error[0].Exception.Message}
} #end END

#region: comments
<#
	The top section is comment based help so the Get-Help command will work with the script.
	The [CmdletBinding()] turns on advanced options like the common parameters.
	All sub functions are in the "BEGIN" section.
	My script code goes in the "PROCESS try" block.

VERSION and AUTHOR:
    Walter Eder	- waltere@microsoft.com

HISTORY
	2015-02-02	V1.04
	2016-07-02	- add capability to remove all RFL registry settings, see remove-RFLShellExt.ps1
	2017-04-03	V1.08 (removed platform, re-added VSS in Rfl-Check_ShellExtension_FQDN.reg)
	2017-10-06	v1.11 changed [RFLshExt_Update] to [RFLshExt_Version] + output enhancements
	2017-11-19	v1.13 using PS functions
	2019-02-25	v1.16 implemented RFLShellExtV2 update
	2022-09-08 using Utils_RflShared.psm1 library
	
	ToDo: 	/known issue:
	#https://blogs.msdn.microsoft.com/virtual_pc_guy/2010/09/23/a-self-elevating-powershell-script/


	Hints:
		# Wait for User Input
		Write-host -NoNewLine "Press any key to continue ..."; $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
#-------------------------------------------------
#$error[0] |fl * -force
#Write-Host -NoNewLine "Press any key to continue ...";
#$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
#>
#endregion: comments



# SIG # Begin signature block
# MIInlQYJKoZIhvcNAQcCoIInhjCCJ4ICAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCD73AdWUOp+Nmmy
# kYr4FWp1NRS8/r8aOHX4QmZRBLogMqCCDXYwggX0MIID3KADAgECAhMzAAADTrU8
# esGEb+srAAAAAANOMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjMwMzE2MTg0MzI5WhcNMjQwMzE0MTg0MzI5WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDdCKiNI6IBFWuvJUmf6WdOJqZmIwYs5G7AJD5UbcL6tsC+EBPDbr36pFGo1bsU
# p53nRyFYnncoMg8FK0d8jLlw0lgexDDr7gicf2zOBFWqfv/nSLwzJFNP5W03DF/1
# 1oZ12rSFqGlm+O46cRjTDFBpMRCZZGddZlRBjivby0eI1VgTD1TvAdfBYQe82fhm
# WQkYR/lWmAK+vW/1+bO7jHaxXTNCxLIBW07F8PBjUcwFxxyfbe2mHB4h1L4U0Ofa
# +HX/aREQ7SqYZz59sXM2ySOfvYyIjnqSO80NGBaz5DvzIG88J0+BNhOu2jl6Dfcq
# jYQs1H/PMSQIK6E7lXDXSpXzAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUnMc7Zn/ukKBsBiWkwdNfsN5pdwAw
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzUwMDUxNjAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAD21v9pHoLdBSNlFAjmk
# mx4XxOZAPsVxxXbDyQv1+kGDe9XpgBnT1lXnx7JDpFMKBwAyIwdInmvhK9pGBa31
# TyeL3p7R2s0L8SABPPRJHAEk4NHpBXxHjm4TKjezAbSqqbgsy10Y7KApy+9UrKa2
# kGmsuASsk95PVm5vem7OmTs42vm0BJUU+JPQLg8Y/sdj3TtSfLYYZAaJwTAIgi7d
# hzn5hatLo7Dhz+4T+MrFd+6LUa2U3zr97QwzDthx+RP9/RZnur4inzSQsG5DCVIM
# pA1l2NWEA3KAca0tI2l6hQNYsaKL1kefdfHCrPxEry8onJjyGGv9YKoLv6AOO7Oh
# JEmbQlz/xksYG2N/JSOJ+QqYpGTEuYFYVWain7He6jgb41JbpOGKDdE/b+V2q/gX
# UgFe2gdwTpCDsvh8SMRoq1/BNXcr7iTAU38Vgr83iVtPYmFhZOVM0ULp/kKTVoir
# IpP2KCxT4OekOctt8grYnhJ16QMjmMv5o53hjNFXOxigkQWYzUO+6w50g0FAeFa8
# 5ugCCB6lXEk21FFB1FdIHpjSQf+LP/W2OV/HfhC3uTPgKbRtXo83TZYEudooyZ/A
# Vu08sibZ3MkGOJORLERNwKm2G7oqdOv4Qj8Z0JrGgMzj46NFKAxkLSpE5oHQYP1H
# tPx1lPfD7iNSbJsP6LiUHXH1MIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGXUwghlxAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAANOtTx6wYRv6ysAAAAAA04wDQYJYIZIAWUDBAIB
# BQCggbAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEILa1+JQ2eRSK6YbUSMGCPC/B
# 3k7fN6+Pa9shsNBy6V4cMEQGCisGAQQBgjcCAQwxNjA0oBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEcgBpodHRwczovL3d3dy5taWNyb3NvZnQuY29tIDANBgkqhkiG9w0B
# AQEFAASCAQAJQemtsFIREQKtId6wMjHChW3jqiNjox1v+uv736wLOLODBvFfK11L
# EU1qEI1mzflEWnAxAlrAWjSlwDH3DFptwHzk6hSZbPv9kQM1BpjXEn2tbbInZb98
# k59Cgt/Vzrsob/eZH42PiAQUKHLt8OUp8yjDhqf3ENu6DA5BCENgbFn6AFduHXM+
# pPVZaK3tjrZ5DkOO3sbpcqpXWMatc4LrCE5OeBaBN7hYoQtaARMBC/WUlkLnk+/0
# K+s/FUAhX16bcRXjCYjLVUQ9usVeEHrQKBu8qJ6So+2w2qJTTE2hdf3Prif4IWlv
# AGtWe983sIZX6U5ARcpl68D+YkBpPfJhoYIW/TCCFvkGCisGAQQBgjcDAwExghbp
# MIIW5QYJKoZIhvcNAQcCoIIW1jCCFtICAQMxDzANBglghkgBZQMEAgEFADCCAVEG
# CyqGSIb3DQEJEAEEoIIBQASCATwwggE4AgEBBgorBgEEAYRZCgMBMDEwDQYJYIZI
# AWUDBAIBBQAEIGJyTVIniw3SOECbMz1AVYYYHXe66e8Sl1Xs/kSxozNwAgZkbNiF
# Ve8YEzIwMjMwNjA1MTgyNTU0LjIzM1owBIACAfSggdCkgc0wgcoxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBB
# bWVyaWNhIE9wZXJhdGlvbnMxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkFFMkMt
# RTMyQi0xQUZDMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNl
# oIIRVDCCBwwwggT0oAMCAQICEzMAAAG/3265BBVSKFgAAQAAAb8wDQYJKoZIhvcN
# AQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQG
# A1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjIxMTA0MTkw
# MTI0WhcNMjQwMjAyMTkwMTI0WjCByjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldh
# c2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBD
# b3Jwb3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0aW9u
# czEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046QUUyQy1FMzJCLTFBRkMxJTAjBgNV
# BAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQC4TGHSfVTEozMG+Q8d6vjuevIPhQrYZXLVfps5UL6E
# tWEOWwhZDW5f/1rwhEjfNej/LWhMO6P6skfJfg5lCfjYTSK7vHqzA+8zfjMg5I+f
# yWCdbMYQCxG3P3MGstb37jD9iFaVcjyG9zui+q6m4vdNe17wFuY05QNIv467ZsF8
# 5sbOwffJj8EQu+rA7Xcpn1nU7EppyeqrW70T1GFqL3RJOiDbaVHYxVFLHnkUeL96
# adkD8gq+wC0QfYromaA7JDv+YNCtY0QDmuhSOFCotDDX/fDP8Ii9z34U/FfZ3FHS
# e+9h7lUuq/xD31w6Q7rPpXiy0YPIUO47wLC2JK8ILdCs466ACXfdo8P1hmzDLBZG
# T5gbIsj4XD6QIJRjqHWo6NOPmCXPR6yZ2ze57jlZojaEj26wWiszyDL//m0NlePQ
# opTUHEDTjGl8TL3VFlRtzql0C8SSlis3aOWleEy9MPumB1jLGRVJpZm/uRannL02
# NY/8JMMZdMLoNaIZxfA9A7rpB1U1bG6IZ2l89oRSdZdwqcNW5rWSEEDE7ib3CD/W
# ozp/sfBd/+keJ8x6P6oHtJRk6IlJxf7UeZ9+ZlEAWIldLSpQOTRkBlbehfbEvKXT
# Tjh4cjtj3kY9rDw6VJN42I0AqX4zIfk5qJ+xS7JUc5/iuysT5nIC5L170RGq7kf/
# XQIDAQABo4IBNjCCATIwHQYDVR0OBBYEFFUCiVRPd5XfAr/4u5//BrAI8xinMB8G
# A1UdIwQYMBaAFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMF8GA1UdHwRYMFYwVKBSoFCG
# Tmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY3Jvc29mdCUy
# MFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEpLmNybDBsBggrBgEFBQcBAQRgMF4w
# XAYIKwYBBQUHMAKGUGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY2Vy
# dHMvTWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3J0MAwG
# A1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZIhvcNAQELBQAD
# ggIBACMJES+NPrJfAlh2+QVSpMYaHpGLMBj5yK4HpQ4FSbTKqrlAL7mkIRr1ZIy9
# tQbPEMIQUGAP3eBYaeSLJhwcJrOWBkr4TtbG0jds/74VvhElmJYuj8gL2FfXaEJl
# nBhcgZXML0FUBw3H/OwWoj/27y79uEaMMc9p3jsLg5A0IeuQ2rMZjFvgZCro+zDq
# jtwS3LcxTcl3i7MFrNoWE9G+YF9Kf5R93qlM1kuAhf0GOsuZluVz93YsgC6sSvlb
# b1Z9blExEgRnM71Noyv/PN2Zb9xXpV1oNPKDLmDg7dRdp23UOtpSmfmNwPXRNVY2
# fLP+lp6V4eiOsYIKSyp7Gl6UyRSyJg/Qdf2kVSA2CVZTXSvXATMXBkz1pfZGqrd8
# VGs3eC7y0Jf4fWcorYChtbW+awotMfo/JfUuTK9HBOPjlrWlp4chHxMbObf6JjvC
# kLUwe7OoCoB0N5ohV1WVyHzTtUkniEOK97oCI5AJX0zCJTKF/m/g/yNMah/wKqMN
# vc+cuU1KcWbYEWExnfmg1MSixzfsZkdJwzzeFM3UTjzWwtgmuuGFx21zI0HrSO4y
# OoZQPq5D/sNsy+2/3e0WPlaPFWEwKSRjroQRiCl8Us4JvaeAklYW4kIgawKIN8PE
# bAThFVgCegXOhrY59KqKNiDZ2t1l+mm1FG8rEywDO7ejGRL9MIIHcTCCBVmgAwIB
# AgITMwAAABXF52ueAptJmQAAAAAAFTANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0
# IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTAwHhcNMjEwOTMwMTgyMjI1
# WhcNMzAwOTMwMTgzMjI1WjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGlu
# Z3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBv
# cmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCC
# AiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAOThpkzntHIhC3miy9ckeb0O
# 1YLT/e6cBwfSqWxOdcjKNVf2AX9sSuDivbk+F2Az/1xPx2b3lVNxWuJ+Slr+uDZn
# hUYjDLWNE893MsAQGOhgfWpSg0S3po5GawcU88V29YZQ3MFEyHFcUTE3oAo4bo3t
# 1w/YJlN8OWECesSq/XJprx2rrPY2vjUmZNqYO7oaezOtgFt+jBAcnVL+tuhiJdxq
# D89d9P6OU8/W7IVWTe/dvI2k45GPsjksUZzpcGkNyjYtcI4xyDUoveO0hyTD4MmP
# frVUj9z6BVWYbWg7mka97aSueik3rMvrg0XnRm7KMtXAhjBcTyziYrLNueKNiOSW
# rAFKu75xqRdbZ2De+JKRHh09/SDPc31BmkZ1zcRfNN0Sidb9pSB9fvzZnkXftnIv
# 231fgLrbqn427DZM9ituqBJR6L8FA6PRc6ZNN3SUHDSCD/AQ8rdHGO2n6Jl8P0zb
# r17C89XYcz1DTsEzOUyOArxCaC4Q6oRRRuLRvWoYWmEBc8pnol7XKHYC4jMYcten
# IPDC+hIK12NvDMk2ZItboKaDIV1fMHSRlJTYuVD5C4lh8zYGNRiER9vcG9H9stQc
# xWv2XFJRXRLbJbqvUAV6bMURHXLvjflSxIUXk8A8FdsaN8cIFRg/eKtFtvUeh17a
# j54WcmnGrnu3tz5q4i6tAgMBAAGjggHdMIIB2TASBgkrBgEEAYI3FQEEBQIDAQAB
# MCMGCSsGAQQBgjcVAgQWBBQqp1L+ZMSavoKRPEY1Kc8Q/y8E7jAdBgNVHQ4EFgQU
# n6cVXQBeYl2D9OXSZacbUzUZ6XIwXAYDVR0gBFUwUzBRBgwrBgEEAYI3TIN9AQEw
# QTA/BggrBgEFBQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9E
# b2NzL1JlcG9zaXRvcnkuaHRtMBMGA1UdJQQMMAoGCCsGAQUFBwMIMBkGCSsGAQQB
# gjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/
# MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1UdHwRPME0wS6BJ
# oEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01p
# Y1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYB
# BQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljUm9v
# Q2VyQXV0XzIwMTAtMDYtMjMuY3J0MA0GCSqGSIb3DQEBCwUAA4ICAQCdVX38Kq3h
# LB9nATEkW+Geckv8qW/qXBS2Pk5HZHixBpOXPTEztTnXwnE2P9pkbHzQdTltuw8x
# 5MKP+2zRoZQYIu7pZmc6U03dmLq2HnjYNi6cqYJWAAOwBb6J6Gngugnue99qb74p
# y27YP0h1AdkY3m2CDPVtI1TkeFN1JFe53Z/zjj3G82jfZfakVqr3lbYoVSfQJL1A
# oL8ZthISEV09J+BAljis9/kpicO8F7BUhUKz/AyeixmJ5/ALaoHCgRlCGVJ1ijbC
# HcNhcy4sa3tuPywJeBTpkbKpW99Jo3QMvOyRgNI95ko+ZjtPu4b6MhrZlvSP9pEB
# 9s7GdP32THJvEKt1MMU0sHrYUP4KWN1APMdUbZ1jdEgssU5HLcEUBHG/ZPkkvnNt
# yo4JvbMBV0lUZNlz138eW0QBjloZkWsNn6Qo3GcZKCS6OEuabvshVGtqRRFHqfG3
# rsjoiV5PndLQTHa1V1QJsWkBRH58oWFsc/4Ku+xBZj1p/cvBQUl+fpO+y/g75LcV
# v7TOPqUxUYS8vwLBgqJ7Fx0ViY1w/ue10CgaiQuPNtq6TPmb/wrpNPgkNWcr4A24
# 5oyZ1uEi6vAnQj0llOZ0dFtq0Z4+7X6gMTN9vMvpe784cETRkPHIqzqKOghif9lw
# Y1NNje6CbaUFEMFxBmoQtB1VM1izoXBm8qGCAsswggI0AgEBMIH4oYHQpIHNMIHK
# MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQLExxN
# aWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25zMSYwJAYDVQQLEx1UaGFsZXMgVFNT
# IEVTTjpBRTJDLUUzMkItMUFGQzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3Rh
# bXAgU2VydmljZaIjCgEBMAcGBSsOAwIaAxUAOAR34k2unh2m8UoxmL3W3Ft+Jzeg
# gYMwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYw
# JAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0B
# AQUFAAIFAOgoehkwIhgPMjAyMzA2MDUyMzEzMjlaGA8yMDIzMDYwNjIzMTMyOVow
# dDA6BgorBgEEAYRZCgQBMSwwKjAKAgUA6Ch6GQIBADAHAgEAAgIOGTAHAgEAAgIS
# EDAKAgUA6CnLmQIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAow
# CAIBAAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBAFpUZkpo1Yei
# FaP8eJRx3raKBGa9JB/tY0MjPHzm+Iritty7iumCNbsy2CDixfOy54l5yOMi2lJs
# NcJLiHTOuHwWTLMxnCrjf0gfHS0eIprKNjO2qI8cZBcgVL5oP19vD3/ecdFq+df0
# WIJhffKmg/MCPlZ3wZQbQGwrkhC43FBEMYIEDTCCBAkCAQEwgZMwfDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAG/3265BBVSKFgAAQAAAb8wDQYJYIZI
# AWUDBAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG
# 9w0BCQQxIgQg6BAH37JEscbKVgb8y5Fl+hVWytW1HhUZDLU9+v1gXuwwgfoGCyqG
# SIb3DQEJEAIvMYHqMIHnMIHkMIG9BCD9Di1HPrcSJGPgr7X3I1TCiAEg6ynjgIi4
# F+dkcK8FrjCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMz
# AAABv99uuQQVUihYAAEAAAG/MCIEIPQ3tkdEiSyggsBcBHL6rMu4xfz9wDxN2FQp
# 4qEsCUWEMA0GCSqGSIb3DQEBCwUABIICAIbs1HJDrjm1988Dm0ZfhtfHa9xn1sQB
# 24usigYEhv/7ZN+UKnzt2AjhGcrRqc+VJvcIsYooXtYtBE28oY4jOMqnKtM4W7VG
# zZ0xKBwGmmCZ0m4FmY3P2UrMWDMUlE5UwUzpHHSRU81YTV4eeUtNfY3SLwHSVBpT
# UzXSWOqx7ifXM3EN5TgwgYrZ6l8LjB6i0Y7p/vrN6PsMCDtqcE2HEoLittzd8Fwc
# rmGHWc55VspGf0owEu1mJcGvztWylvDs3juaF7paQu8DSx6RWRYEYImyJG/61ZTA
# xgJsSk+QzExOTUw7GHC1D3uHH/a2H42UbzHERabT64WxltrnAsLFlA4+YH/GFm9T
# jAB8pesq1Z17ZZBYTWAvv8UcGwTsg5lbcgdtwzHJ9DQJU/4rjGA1rMmg0VRqz1FN
# WAdxnuAw+8PqY+0bgShedzhP6ff5DsALz2n+HZsDBT59YnervfcaL2yxayGABFzX
# SpZ6nkCsJMZ3Qk2jCqr6yiS5HguQkXqLy929vb0wWrDmFU/AOzw/5vyeiHmB+YSv
# W15y7ICZZv93Z7IVdIVefzSHK98eIdqdt0z8OuFTdurxSV8576s2TBnAEc9Mx00U
# KaGvQcEQ5fSSBRRVeqxr3mTdrayg2XhE31H19k2GJ4RamiUY5fzWbGn3MKDhYviA
# uSt9zesGI/9M
# SIG # End signature block
