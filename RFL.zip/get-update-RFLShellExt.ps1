# File: get-update-RFLShellExt.ps1 V2
# last edit by: waltere 2022-10-13

<#
.SYNOPSIS
The script will install or update your current version of the RFL PlugIn on your system to latest version.
The registry file for the latest version of the shell extension is located here: \\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\Rfl-Check_ShellExtension.reg -or- in offline package RFL.zip

SYNTAX: .\get-update-RFLShellExt.ps1 [Check-RFL|Check_RFL_anchor|Check_SDP_anchor]

.DESCRIPTION
The script reads in your current registry RFL information and writes new registry key.
The script tries to run itself in elevated mode and ask user to agree, because REG changes need admin permission.
Note: In case of any error, you still can download to local drive and doubleclick the *.reg file on
   \\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\Rfl-Check_ShellExtension.reg

.PARAMETER SkipAdminCheck
If this switch is present, then the check for administrator privileges will be skipped.

.EXAMPLE
To run the RFL shell PlugIn check and update on UNC path
	\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\get-update-RFLShellExt.ps1

.LINK
Update script: \\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\get-update-RFLShellExt.ps1
ShellExtension: \\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\Rfl-Check_ShellExtension.reg
RFL core team: waltere@microsoft.com

#>

[CmdletBinding()]
PARAM (
	[ValidateSet("Check-RFL","Check_RFL_anchor","Check_SDP_anchor")]
	[parameter(Mandatory=$False,Position=0,HelpMessage='Choose one from: [Check_RFL_anchor|Check_SDP_anchor]')]
	[string]$CheckType = "Check_RFL_anchor"	,
	[parameter(Mandatory=$false)]
	[switch]$SkipAdminCheck = $false,
	[switch]$HostMode  = $false, #This tells the logging functions to show logging on the screen
	[switch]$ScriptMode = $false, #This tells the logging functions to show logging in log file
	[switch]$UseExitCode= $true  #This will cause the script to close after the error is logged if an error occurs.
	)

BEGIN {
	$verDateScript = "2023.01.07.0"
	$ScriptFolder = Split-Path $MyInvocation.MyCommand.Path -Parent
	# Load Common Library:
	. $ScriptFolder\Utils_RflShared.ps1

	# update needs elevation
	Write-Host "[RFLshExt_Update] Checking for elevation... "
	$CurrentUser = New-Object Security.Principal.WindowsPrincipal $([Security.Principal.WindowsIdentity]::GetCurrent())
	if (($CurrentUser.IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)) -eq $false)
	{
		$ArgumentList = "-noprofile -noexit -file `"{0}`" " #-Path `"$scriptPath`" -MaxStage $MaxStage"
		If ($ValidateOnly) { $ArgumentList = $ArgumentList + " -ValidateOnly" }
		If ($SkipValidation) { $ArgumentList = $ArgumentList + " -SkipValidation $SkipValidation" }
		If ($Mode) { $ArgumentList = $ArgumentList + " -Mode $Mode" }
		Write-Host "...elevating in new Admin PS window"
		Start-Process powershell.exe -Verb RunAs -ArgumentList ($ArgumentList -f ($myinvocation.MyCommand.Definition)) #-Wait
		Exit
	}
	# Run your code that needs to be elevated here...
#-------------------------------------------------
	Write-host -BackgroundColor Black -ForegroundColor Gray -Object "[RFLshExt_Update] ...Running now with Admin priv (Elevated)"

	$error.clear()	# clear PS script errors
	# This saves the starting ErrorActionPreference and then sets it to 'Stop'.
	$startErrorActionPreference = $errorActionPreference
	$errorActionPreference = 'Continue' # 'Stop' #
	# This gets the current path and name of the script.
	$invocation = (Get-Variable MyInvocation).Value
	$invocationLine= $($MyInvocation.Line)
	$scriptPath = Split-Path $invocation.MyCommand.Path
	#$ScriptParentPath 	= Split-Path $MyInvocation.MyCommand.Path -Parent
	$scriptName = $invocation.MyCommand.Name
	$UserName  = ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name)
	$UsrOSVersion = [Environment]::OSVersion.Version.ToString(3)
	$CheckDate = (Get-Date).ToUniversalTime().ToString("yy-MM-dd_HH-mm-ss")
	#$Script:PSver = $PSVersionTable.PSVersion.Major
	#Write-Host "Running `"$scriptPath\$scriptName`"..." -BackgroundColor Black -ForegroundColor Green
	Set-Variable -Name ErrorMsg -Scope Script -Force
	[string]$Script:ErrorMsg=""

#region ###### customization section of script, logging configuration ########################
	$SDPcheckINI = (Get-content -Path "$ScriptFolder\_SDPcheck.ini")
	$InOfflineMode 	= (($SDPcheckINI[1] -split " ")[2]).trim("""")	# set $True for outsourcer or when not connected to MS network - offline-SDPcheck
	$ExpectedShellExtVersion = (($SDPcheckINI[6] -split " ")[2]).trim("""")
	$RFLroot = (($SDPcheckINI[2] -split " ")[2]).trim("""")	# "\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\" -or- "\\localhost\ToolsShare\rfl\"
	if ($InOfflineMode -match "False") {
		$StatsServer = (($SDPcheckINI[4] -split " ")[2]).trim("""")
		if (Test-Connection -ComputerName $StatsServer -Quiet -Count 1) {[bool]$Stats=$True} else {[bool]$Stats=$False}
	} else { 
		$Stats = $False
	}
	$OnlyRun_AsAdmin = 0
	$Script:regFile = "$RFLroot\Rfl-Check_ShellExtension.reg"
	$Script:regFileV1remove = "$RFLroot\Rfl-Check_ShellExtension_V1-Remove.reg"
	$Script:regFileV2add = "$RFLroot\Rfl-Check_ShellExtension.reg"
	$Script:regFileV2remove = "$RFLroot\Rfl-Check_ShellExtension_Remove.reg"
	$UsrOSVersion = [Environment]::OSVersion.Version.ToString(3)
	$LogLevel = 0
#endregion: ###### customization section

	if ($Stats) {
		$StatsServerPath="\\$StatsServer\RFLstats$\RFL\scripts\Stats\"
		$CountInvFil = $StatsServerPath +'countRFLshExUpd.dat'
		$CountInvFil2 = $CountInvFil +'.us'
		#increment at start of script
		 ($j=[int32](Get-Content $CountInvFil -TotalCount 1 -ErrorAction SilentlyContinue)) |out-null
		 (++$j) | Set-Content $CountInvFil -ErrorAction SilentlyContinue
	}
	$ErrorThrown = $null

	If ($PSBoundParameters['Debug']) { $DebugPreference='Continue'}
	#ConsoleColor enumeration values: Black DarkBlue DarkGreen DarkCyan DarkRed DarkMagenta DarkYellow Gray DarkGray Blue Green Cyan Red Magenta Yellow White

	Set-Variable -Name ShellExtExists -Scope Script -Force
	Set-Variable -Name ShellExtVersion -Scope Script -Force
	Set-Variable -Name regFile -Scope Script -Force
	$Script:ShellExtVersion ='undefined'

#region: Script Functions

function checkPlugin-RFLShellExt ($CheckType,$ExpectedShellExtVersion) {
	RflEnterFuncDbg $MyInvocation.MyCommand.Name
	Write-host "[RFLshExt_Plugin] Checking for existing ShellExt for $($CheckType) "
	#check if RFLShellExt is installed and 'Version' key exists
	New-PSDrive -Name HKCR -PSProvider Registry -Root HKEY_CLASSES_ROOT |out-null
	$registryPathHKCR = "HKCR:\Directory\shell\$($CheckType)"

	Write-host "[RFLshExt_Plugin] _Checking existing ShellExt in $registryPathHKCR"
	Try { $ErrorActionPreference = "stop"
		$Script:ShellExtExists = (Get-ItemProperty -Path $registryPathHKCR )
		if ($Script:ShellExtExists)	{ Write-host "[RFLshExt_Plugin] __Found ShellExt in $registryPathHKCR" }
	}
	Catch [System.Management.Automation.ItemNotFoundException]
		{ Write-host -BackgroundColor Black -ForegroundColor Yellow -Object "... Simplify: Consider to run Explorer-Extension update in elevated (Run as Administrator) PS cmd, see also _Help.rtf:"
		Write-host -BackgroundColor Black -ForegroundColor Cyan -Object " Powershell -ExecutionPolicy Bypass $RFLroot\get-update-RFLShellExt.ps1"
		Write-host "[RFLshExt_Update] ...RFLshellPlugin not installed - creating it."
		#Write-host "[RFLshExt_Update] ...***please allow registry Version update when UAC prompted***"
		return "[RFLshExt_Update] RegKey $registryPathHKCR itself is missing."
	}
	Finally { $ErrorActionPreference = "Continue" }
	RflEndFunc $MyInvocation.MyCommand.Name
}

function checkVer-RFLShellExt ($CheckType,$ExpectedShellExtVersion) {
	RflEnterFuncDbg $MyInvocation.MyCommand.Name
	Write-host "[RFLshExt_Version] Checking ShellExt Version for $($CheckType) "
	#check if RFLShellExt is installed and 'Version' key exists
	New-PSDrive -Name HKCR -PSProvider Registry -Root HKEY_CLASSES_ROOT |out-null
	$registryPathHKCR = "HKCR:\Directory\shell\$($CheckType)"
	$name = "Version"
	$value = "1.00"
	Write-host "[RFLshExt_Version] _Checking current version in $registryPathHKCR"
	Try { $ErrorActionPreference = "stop"
		$Script:ShellExtVersion = (Get-ItemProperty -Path $registryPathHKCR -Name Version).Version
		if ($Script:ShellExtVersion)	{ Write-host "[RFLshExt_Version] __latest available ShellExtVersion is: $Script:ExpectedShellExtVersion"
			IF ($Script:ShellExtVersion -match $ExpectedShellExtVersion) {
				Write-host "[RFLshExt_Version] __Your RFL ShellExtension version $Script:ShellExtVersion is up-to-date";
				RflEndFunc ($MyInvocation.MyCommand.Name + "($Script:ShellExtVersion _up-to-date)")
				return "$Script:ShellExtVersion _up-to-date"}
			ELSE { if ($Script:ShellExtVersion -lt 1.09) {Write-host -BackgroundColor Black -ForegroundColor Red -Object " Support for this older RFL version will end *soon*, because Server \\muc-vfs-01a will be decommissioned."}
					Write-host -BackgroundColor Yellow -ForegroundColor Black -Object "[RFLshExt_Version] __Your RFL ShellExtension version $Script:ShellExtVersion is outdated!
 .. Consider updating the RFL Shell Explorer Plugin `n $Script:regFileV2add
 To do so, run in ELEVATED (Run as Administrator) PS window the command: "
				Write-host -ForegroundColor Cyan -Object " Powershell -ExecutionPolicy Bypass $RFLroot\get-update-RFLShellExt.ps1"
				RflEndFunc ($MyInvocation.MyCommand.Name + "($Script:ShellExtVersion _outdated)")
				return "$Script:ShellExtVersion _outdated - user_informed"}
		}
	}
	Catch [System.Management.Automation.PSArgumentException]
	{
		if ($Script:ShellExtVersion -lt 1.09) {Write-host -BackgroundColor Black -ForegroundColor Red -Object "Support for this older RFL version will end *soon*, because Server \\muc-vfs-01a will be decommissioned. "}
		Write-host -BackgroundColor Yellow -ForegroundColor Black -Object "[RFLshExt_Version] __Your RFL ShellExtension version $Script:ShellExtVersion is outdated!
 Please update the RFL Shell Extension `n $Script:regFileV2add
 To do so, run in ELEVATED (Run as Administrator) PS window the command: "
		Write-host -BackgroundColor Black -ForegroundColor Cyan -Object " Powershell -ExecutionPolicy Bypass $RFLroot\get-update-RFLShellExt.ps1"
		"[RFLshExt_Version] RegKey $registryPathHKCR Property $name missing."
	}
	Catch [System.Management.Automation.ItemNotFoundException]
	{ Write-host "[RFLshExt_Version] RegKey $registryPathHKCR\Version is missing."
		Write-debug "[RFLshExt_Version] ...RFLshellPlugin not up-to-date"
		Write-debug "[RFLshExt_Version] ...***please allow registry Version update when UAC prompted***"
		"[RFLshExt_Version] RegKey $registryPathHKCR\Version is missing."
	}
	Finally { $ErrorActionPreference = "Continue" }
	RflEndFunc $MyInvocation.MyCommand.Name
}

function CheckForUpdates-RFLShellExt ($CheckType,$ExpectedShellExtVersion) {
	RflEnterFuncDbg $MyInvocation.MyCommand.Name
	if ($OnlyRun_AsAdmin){
		 Write-host "[RFLshExt_ChkUpdates] checking registryPath: $registryPathHKCR\CheckForUpdates"
		 $name = "CheckForUpdates"
		 $value = "1"
		Try { $ErrorActionPreference = "stop"
			$CheckForUpdates = (Get-ItemProperty -Path $registryPathHKCR -Name CheckForUpdates).CheckForUpdates
			if ($CheckForUpdates) {Write-host "[RFLshExt_ChkUpdates] Current CheckForUpdates: $CheckForUpdates"}
			if ($CheckForUpdates -NotMatch "0") {Write-host "[RFLshExt_ChkUpdates] Current ShellExt setting for CheckForUpdates: $CheckForUpdates"}
			else {	Write-host "[RFLshExt_ChkUpdates] CheckForUpdates: '$CheckForUpdates' - .. Consider updating the RFL Shell Explorer Plugin `n $Script:regFileV2add "
				Write-host "[RFLshExt_ChkUpdates] ... keep existing plugin settings because $registryPathHKCR\CheckForUpdates is set to '$CheckForUpdates'"
				break #continue
				}
		 }
		 Catch [System.Management.Automation.PSArgumentException]
		  { "[RFLshExt_ChkUpdates] RegKey $registryPathHKCR Property $name missing."
			 New-ItemProperty -Path $registryPathHKCR -Name $name -Value $value -PropertyType DWORD -Force | Out-Null
		  }
		 Catch [System.Management.Automation.ItemNotFoundException]
		  { "[RFLshExt_ChkUpdates] RegKey $registryPathHKCR itself is missing."
			 Write-host "[RFLshExt_ChkUpdates] ...RFLshellPlugin not installed - creating it"
			 New-Item -Path $registryPathHKCR -Force #| Out-Null
			 New-ItemProperty -Path $registryPathHKCR -Name $name -Value $value -PropertyType DWORD -Force | Out-Null
		 }
		 Finally {
			 "[RFLshExt_ChkUpdates] CheckForUpdates reg: $CheckForUpdates"
			 $ErrorActionPreference = "Continue" }
	 } # end of if ($OnlyRun_AsAdmin)
	 RflEndFunc $MyInvocation.MyCommand.Name
}

function update-ShellExt ($CheckType,$ExpectedShellExtVersion) {
	RflEnterFuncDbg $MyInvocation.MyCommand.Name
	if (!($Script:ShellExtVersion -match $ExpectedShellExtVersion) -and ($CheckForUpdates -NotMatch "0")) {
		write-host "[RFLshExt_Update] ...Outdated Check_RFL ShellExtVersion v$Script:ShellExtVersion"
		Try
		{
		write-host "[RFLshExt_Update] ...removing existing entry Check_RFL v$Script:ShellExtVersion"
		$RegTryRemoveV1 = regedit /s $Script:regFileV1remove
		$RegTryRemoveV2 = regedit /s $Script:regFileV2remove
		write-host "[RFLshExt_Update] ...Importing latest v$ExpectedShellExtVersion $Script:regFile silently"
		$RegTryAdd = regedit /s $Script:regFile
		write-host "[RFLshExt_Update] ...Registry Update result: $RegTryAdd"
		Write-host -BackgroundColor Black -ForegroundColor Green -Object "[RFLshExt_Update] RFLShellExt $CheckType successfully updated"
		"RegImport-done $ExpectedShellExtVersion"
		}
		Catch [System.Security.SecurityException]
			{ "Registry Remove-Item $registryPathHKCR"
			}
		Catch
			{
				Write-Error "[RFLshExt_Update] Aborted. The error was '$($_.Exception.Message)'"
				Write-host -BackgroundColor Black -ForegroundColor Red -Object "[RFLshExt_Update] Aborted by user"
				"Aborted by user."
			}
		Finally
		{
			"$Script:ShellExtVersion RegVersion-not-matched. Prev.Ver: $Script:ShellExtVersion"
		}
	}
	RflEndFunc $MyInvocation.MyCommand.Name
}

function autoupdate-ShellExt ($CheckType,$ExpectedShellExtVersion) {
	RflEnterFuncDbg $MyInvocation.MyCommand.Name
	checkPlugin-RFLShellExt $CheckType $ExpectedShellExtVersion		#call function
	if ($Script:ShellExtExists)	{
		checkVer-RFLShellExt $CheckType $ExpectedShellExtVersion	#call function
	}
	update-ShellExt $CheckType $ExpectedShellExtVersion				#call function
	RflEndFunc $MyInvocation.MyCommand.Name
}

function remove-ShellExt ($RegKey) {
	# SYNOPSIS :
	RflEnterFuncDbg $MyInvocation.MyCommand.Name
	New-PSDrive -Name HKCR -PSProvider Registry -Root HKEY_CLASSES_ROOT |out-null

	Try	{
		write-host "[RFLshExt_Remove] _Trying to remove entry $RegKey"
		Remove-Item $RegKey -Recurse -ErrorAction SilentlyContinue
	}
	Catch [System.Security.SecurityException]
		{ "Registry Remove-Item $RegKey" }
	Catch [System.Management.Automation.ItemNotFoundException]
		{"RegKey $RegKey is missing."}
	Catch
		{
			Write-Error "[RFLshExt_Remove] Aborted. The error was '$($_.Exception.Message)'"
			Write-host -BackgroundColor Black -ForegroundColor Red -Object "[RFLshExt_Remove] Aborted by user"
			"Aborted by user."
		}
	Finally { " _ $RegKey done"}
	RflEndFunc $MyInvocation.MyCommand.Name
}
#endregion: Script Functions
} #end BEGIN

PROCESS {
	try {
		$ScriptBeginTimeStamp = Get-Date
		#region: MAIN :::::

		#for downlevel Plugin V1 with parameter Check-RFL
		if ($CheckType -match "Check-RFL") { $CheckType = "Check_RFL_anchor"}
		Write-host "CheckType: $CheckType "

		### main
		$au = autoupdate-ShellExt $CheckType $ExpectedShellExtVersion		#call function
		$Script:ResultMsg = $au
		Write-verbose "[RFLshExt_Update] AutoUpdate results: $au"
		If (-not $au) {Write-host "[RFLshExt_Update] .. Consider updating the RFL Shell Explorer Plugin $Script:regFile "}
		write-host -BackgroundColor Black -ForegroundColor Green -Object "[RFLshExt_Update] ...done. New RFL ShellExt $ExpectedShellExtVersion plugin should be available in your Windows Explorer context menu for folders right now."
		write-host -ForegroundColor Gray "Note: In case of any error, you still can download to local drive and doubleclick the *.reg file on
			 $($RFLroot)\Rfl-Check_ShellExtension.reg `n"

		#endregion: MAIN :::::
	}
	catch {
		$ErrorThrown = $true
		$errorMessage = "$scriptName caught an exception on $($ENV:COMPUTERNAME):`n`n"
		$errorMessage += "Exception Type: $($_.Exception.GetType().FullName)"
		$errorMessage += "`n`n Exception Message: $($_.Exception.Message)"

		Write-Error $errorMessage -ErrorAction Continue
		Start-Sleep -Seconds 3
		Write-Debug $errorMessage
		if ($UseExitCode) {
			$error.clear()	# clear script errors
			exit 1
		}
  } #end Catch PROCESS
	Finally {
	}
} #end PROCESS

END {
	$ScriptEndTimeStamp = Get-Date
	$Duration = $(New-TimeSpan -Start $ScriptBeginTimeStamp -End $ScriptEndTimeStamp)
	$LogLevel = 0
	Write-host -BackgroundColor Gray -ForegroundColor Black -Object " Script $scriptName v$verDateScript execution finished. Duration: $Duration"
	# This resets the ErrorActionPreference to the value at script start.
	$errorActionPreference = $startErrorActionPreference
	# Stats
	If ($Stats) { #increment at start of script
	 "$j; $CheckDate; $UsrOSVersion; $UserName; $Duration; $Script:ShellExtVersion; $Script:ResultMsg; v$verDateScript ; $env:computername" | Out-File $CountInvFil2 -Append -Encoding UTF8 -ErrorAction SilentlyContinue
	 }
	if($ErrorThrown) {Throw $error[0].Exception.Message}
} #end END

#region: comments
<#
	The top section is comment based help so the Get-Help command will work with the script.
	The [CmdletBinding()] turns on advanced options like the common parameters.
	All sub functions are in the "BEGIN" section.
	My script code goes in the "PROCESS try" block.

VERSION and AUTHOR:
    Walter Eder	- waltere@microsoft.com

HISTORY
	2015-02-02	V1.04
	2016-07-02	- add capability to remove all RFL registry settings, see remove-RFLShellExt.ps1
	2017-04-03	V1.08 (removed platform, re-added VSS in Rfl-Check_ShellExtension_FQDN.reg)
	2017-10-06	v1.11 changed [RFLshExt_Update] to [RFLshExt_Version] + output enhancements
	2017-11-19	v1.13 using PS functions
	2019-02-25	v1.16 implemented RFLShellExtV2 update
	2022-09-08 using Utils_RflShared.psm1 library
	
	ToDo: 	/known issue:
	#https://blogs.msdn.microsoft.com/virtual_pc_guy/2010/09/23/a-self-elevating-powershell-script/


	Hints:
		# Wait for User Input
		Write-host -NoNewLine "Press any key to continue ..."; $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
#-------------------------------------------------
#$error[0] |fl * -force
#Write-Host -NoNewLine "Press any key to continue ...";
#$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
#>
#endregion: comments



# SIG # Begin signature block
# MIInoQYJKoZIhvcNAQcCoIInkjCCJ44CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDXZ9sJGgSiIwqK
# nhw5amGnUcB0Be+mRKcemJKp6zJnR6CCDXYwggX0MIID3KADAgECAhMzAAACy7d1
# OfsCcUI2AAAAAALLMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjIwNTEyMjA0NTU5WhcNMjMwNTExMjA0NTU5WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC3sN0WcdGpGXPZIb5iNfFB0xZ8rnJvYnxD6Uf2BHXglpbTEfoe+mO//oLWkRxA
# wppditsSVOD0oglKbtnh9Wp2DARLcxbGaW4YanOWSB1LyLRpHnnQ5POlh2U5trg4
# 3gQjvlNZlQB3lL+zrPtbNvMA7E0Wkmo+Z6YFnsf7aek+KGzaGboAeFO4uKZjQXY5
# RmMzE70Bwaz7hvA05jDURdRKH0i/1yK96TDuP7JyRFLOvA3UXNWz00R9w7ppMDcN
# lXtrmbPigv3xE9FfpfmJRtiOZQKd73K72Wujmj6/Su3+DBTpOq7NgdntW2lJfX3X
# a6oe4F9Pk9xRhkwHsk7Ju9E/AgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUrg/nt/gj+BBLd1jZWYhok7v5/w4w
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzQ3MDUyODAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAJL5t6pVjIRlQ8j4dAFJ
# ZnMke3rRHeQDOPFxswM47HRvgQa2E1jea2aYiMk1WmdqWnYw1bal4IzRlSVf4czf
# zx2vjOIOiaGllW2ByHkfKApngOzJmAQ8F15xSHPRvNMmvpC3PFLvKMf3y5SyPJxh
# 922TTq0q5epJv1SgZDWlUlHL/Ex1nX8kzBRhHvc6D6F5la+oAO4A3o/ZC05OOgm4
# EJxZP9MqUi5iid2dw4Jg/HvtDpCcLj1GLIhCDaebKegajCJlMhhxnDXrGFLJfX8j
# 7k7LUvrZDsQniJZ3D66K+3SZTLhvwK7dMGVFuUUJUfDifrlCTjKG9mxsPDllfyck
# 4zGnRZv8Jw9RgE1zAghnU14L0vVUNOzi/4bE7wIsiRyIcCcVoXRneBA3n/frLXvd
# jDsbb2lpGu78+s1zbO5N0bhHWq4j5WMutrspBxEhqG2PSBjC5Ypi+jhtfu3+x76N
# mBvsyKuxx9+Hm/ALnlzKxr4KyMR3/z4IRMzA1QyppNk65Ui+jB14g+w4vole33M1
# pVqVckrmSebUkmjnCshCiH12IFgHZF7gRwE4YZrJ7QjxZeoZqHaKsQLRMp653beB
# fHfeva9zJPhBSdVcCW7x9q0c2HVPLJHX9YCUU714I+qtLpDGrdbZxD9mikPqL/To
# /1lDZ0ch8FtePhME7houuoPcMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGYEwghl9AgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAALLt3U5+wJxQjYAAAAAAsswDQYJYIZIAWUDBAIB
# BQCggbAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIJa5wZK+PQp+s7yWopbBUsXV
# WeCP4+cHHfuARPEFguO/MEQGCisGAQQBgjcCAQwxNjA0oBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEcgBpodHRwczovL3d3dy5taWNyb3NvZnQuY29tIDANBgkqhkiG9w0B
# AQEFAASCAQCxakYarmfGZe14ATnseUtSv53qZkSGa8kF0kKuZ97RY67IcNS6lzdd
# gXwICA/Tw0lA/A9Nqnvm/AQFp7Lg8k9o8G4n7Pttboe8aMfDf3uPsrUvXspSiQ48
# j3IPhBjhKhMTuMFxaH0yhP2CvAvv7KiMsVzoPamBb28Cg2t9Oso8YwRK6hLphiU7
# D7LlMJ8RJmKvxpZ/w+RrS7ElLVfjIzhUao2uoRNGqiiPWMst9OzK1nmb4dTCL9Ok
# pd9twb0jlRrnmxPPCgGFXvlhmKQOKb8Ona9q4RsvN7Iw44B8DQtCWS5Rtkl3e6X0
# dfoUU2dCqI6DW9RchOUBrTQqUME1wgvcoYIXCTCCFwUGCisGAQQBgjcDAwExghb1
# MIIW8QYJKoZIhvcNAQcCoIIW4jCCFt4CAQMxDzANBglghkgBZQMEAgEFADCCAVUG
# CyqGSIb3DQEJEAEEoIIBRASCAUAwggE8AgEBBgorBgEEAYRZCgMBMDEwDQYJYIZI
# AWUDBAIBBQAEIOoPGISqdduhsRvc3iWczOb/9vYYveJKCUgw2hiV4a91AgZjoaFg
# uagYEzIwMjMwMTEwMTM0MDU5LjM2NlowBIACAfSggdSkgdEwgc4xCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1pY3Jvc29mdCBP
# cGVyYXRpb25zIFB1ZXJ0byBSaWNvMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjpD
# NEJELUUzN0YtNUZGQzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2Vy
# dmljZaCCEVwwggcQMIIE+KADAgECAhMzAAABo/uas457hkNPAAEAAAGjMA0GCSqG
# SIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAw
# DgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24x
# JjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTIyMDMw
# MjE4NTExNloXDTIzMDUxMTE4NTExNlowgc4xCzAJBgNVBAYTAlVTMRMwEQYDVQQI
# EwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3Nv
# ZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjpDNEJELUUzN0YtNUZG
# QzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZTCCAiIwDQYJ
# KoZIhvcNAQEBBQADggIPADCCAgoCggIBAO+9TcrLeyoKcCqLbNtz7Nt2JbP1TEzz
# Mhi84gS6YLI7CF6dVSA5I1bFCHcw6ZF2eF8Qiaf0o2XSXf/jp5sgmUYtMbGi4neA
# tWSNK5yht4iyQhBxn0TIQqF+NisiBxW+ehMYWEbFI+7cSdX/dWw+/Y8/Mu9uq3XC
# K5P2G+ZibVwOVH95+IiTGnmocxWgds0qlBpa1rYg3bl8XVe5L2qTUmJBvnQpx2bU
# ru70lt2/HoU5bBbLKAhCPpxy4nmsrdOR3Gv4UbfAmtpQntP758NRPhg1bACH06Fl
# vbIyP8/uRs3x2323daaGpJQYQoZpABg62rFDTJ4+e06tt+xbfvp8M9lo8a1agfxZ
# Q1pIT1VnJdaO98gWMiMW65deFUiUR+WngQVfv2gLsv6o7+Ocpzy6RHZIm6WEGZ9L
# Bt571NfCsx5z0Ilvr6SzN0QbaWJTLIWbXwbUVKYebrXEVFMyhuVGQHesZB+VwV38
# 6hYonMxs0jvM8GpOcx0xLyym42XA99VSpsuivTJg4o8a1ACJbTBVFoEA3VrFSYzO
# dQ6vzXxrxw6i/T138m+XF+yKtAEnhp+UeAMhlw7jP99EAlgGUl0KkcBjTYTz+jEy
# PgKadrU1of5oFi/q9YDlrVv9H4JsVe8GHMOkPTNoB4028j88OEe426BsfcXLki0p
# hPp7irW0AbRdAgMBAAGjggE2MIIBMjAdBgNVHQ4EFgQUUFH7szwmCLHPTS9Bo2ir
# LnJji6owHwYDVR0jBBgwFoAUn6cVXQBeYl2D9OXSZacbUzUZ6XIwXwYDVR0fBFgw
# VjBUoFKgUIZOaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jcmwvTWlj
# cm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3JsMGwGCCsGAQUF
# BwEBBGAwXjBcBggrBgEFBQcwAoZQaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3Br
# aW9wcy9jZXJ0cy9NaWNyb3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIwMjAxMCgx
# KS5jcnQwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEFBQcDCDANBgkqhkiG
# 9w0BAQsFAAOCAgEAWvLep2mXw6iuBxGu0PsstmXI5gLmgPkTKQnjgZlsoeipsta9
# oku0MTVxlHVdcdBbFcVHMLRRkUFIkfKnaclyl5eyj03weD6b/pUfFyDZB8AZpGUX
# hTYLNR8PepM6yD6g+0E1nH0MhOGoE6XFufkbn6eIdNTGuWwBeEr2DNiGhDGlwaUH
# 5ELz3htuyMyWKAgYF28C4iyyhYdvlG9VN6JnC4mc/EIt50BCHp8ZQAk7HC3ROltg
# 1gu5NjGaSVdisai5OJWf6e5sYQdDBNYKXJdiHei1N7K+L5s1vV+C6d3TsF9+ANpi
# oBDAOGnFSYt4P+utW11i37iLLLb926pCL4Ly++GU0wlzYfn7n22RyQmvD11oyiZH
# hmRssDBqsA+nvCVtfnH183Df5oBBVskzZcJTUjCxaagDK7AqB6QA3H7l/2SFeeqf
# X/Dtdle4B+vPV4lq1CCs0A1LB9lmzS0vxoRDusY80DQi10K3SfZK1hyyaj9a8pbZ
# G0BsBp2Nwc4xtODEeBTWoAzF9ko4V6d09uFFpJrLoV+e8cJU/hT3+SlW7dnr5dtY
# vziHTpZuuRv4KU6F3OQzNpHf7cBLpWKRXRjGYdVnAGb8NzW6wWTjZjMCNdCFG7pk
# KLMOGdqPDFdfk+EYE5RSG9yxS76cPfXqRKVtJZScIF64ejnXbFIs5bh8KwEwggdx
# MIIFWaADAgECAhMzAAAAFcXna54Cm0mZAAAAAAAVMA0GCSqGSIb3DQEBCwUAMIGI
# MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylN
# aWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0yMTA5
# MzAxODIyMjVaFw0zMDA5MzAxODMyMjVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQI
# EwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3Nv
# ZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBD
# QSAyMDEwMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA5OGmTOe0ciEL
# eaLL1yR5vQ7VgtP97pwHB9KpbE51yMo1V/YBf2xK4OK9uT4XYDP/XE/HZveVU3Fa
# 4n5KWv64NmeFRiMMtY0Tz3cywBAY6GB9alKDRLemjkZrBxTzxXb1hlDcwUTIcVxR
# MTegCjhuje3XD9gmU3w5YQJ6xKr9cmmvHaus9ja+NSZk2pg7uhp7M62AW36MEByd
# Uv626GIl3GoPz130/o5Tz9bshVZN7928jaTjkY+yOSxRnOlwaQ3KNi1wjjHINSi9
# 47SHJMPgyY9+tVSP3PoFVZhtaDuaRr3tpK56KTesy+uDRedGbsoy1cCGMFxPLOJi
# ss254o2I5JasAUq7vnGpF1tnYN74kpEeHT39IM9zfUGaRnXNxF803RKJ1v2lIH1+
# /NmeRd+2ci/bfV+AutuqfjbsNkz2K26oElHovwUDo9Fzpk03dJQcNIIP8BDyt0cY
# 7afomXw/TNuvXsLz1dhzPUNOwTM5TI4CvEJoLhDqhFFG4tG9ahhaYQFzymeiXtco
# dgLiMxhy16cg8ML6EgrXY28MyTZki1ugpoMhXV8wdJGUlNi5UPkLiWHzNgY1GIRH
# 29wb0f2y1BzFa/ZcUlFdEtsluq9QBXpsxREdcu+N+VLEhReTwDwV2xo3xwgVGD94
# q0W29R6HXtqPnhZyacaue7e3PmriLq0CAwEAAaOCAd0wggHZMBIGCSsGAQQBgjcV
# AQQFAgMBAAEwIwYJKwYBBAGCNxUCBBYEFCqnUv5kxJq+gpE8RjUpzxD/LwTuMB0G
# A1UdDgQWBBSfpxVdAF5iXYP05dJlpxtTNRnpcjBcBgNVHSAEVTBTMFEGDCsGAQQB
# gjdMg30BATBBMD8GCCsGAQUFBwIBFjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20v
# cGtpb3BzL0RvY3MvUmVwb3NpdG9yeS5odG0wEwYDVR0lBAwwCgYIKwYBBQUHAwgw
# GQYJKwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB
# /wQFMAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186aGMQwVgYDVR0f
# BE8wTTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJv
# ZHVjdHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEBBE4w
# TDBKBggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0
# cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwDQYJKoZIhvcNAQELBQADggIB
# AJ1VffwqreEsH2cBMSRb4Z5yS/ypb+pcFLY+TkdkeLEGk5c9MTO1OdfCcTY/2mRs
# fNB1OW27DzHkwo/7bNGhlBgi7ulmZzpTTd2YurYeeNg2LpypglYAA7AFvonoaeC6
# Ce5732pvvinLbtg/SHUB2RjebYIM9W0jVOR4U3UkV7ndn/OOPcbzaN9l9qRWqveV
# tihVJ9AkvUCgvxm2EhIRXT0n4ECWOKz3+SmJw7wXsFSFQrP8DJ6LGYnn8AtqgcKB
# GUIZUnWKNsIdw2FzLixre24/LAl4FOmRsqlb30mjdAy87JGA0j3mSj5mO0+7hvoy
# GtmW9I/2kQH2zsZ0/fZMcm8Qq3UwxTSwethQ/gpY3UA8x1RtnWN0SCyxTkctwRQE
# cb9k+SS+c23Kjgm9swFXSVRk2XPXfx5bRAGOWhmRaw2fpCjcZxkoJLo4S5pu+yFU
# a2pFEUep8beuyOiJXk+d0tBMdrVXVAmxaQFEfnyhYWxz/gq77EFmPWn9y8FBSX5+
# k77L+DvktxW/tM4+pTFRhLy/AsGConsXHRWJjXD+57XQKBqJC4822rpM+Zv/Cuk0
# +CQ1ZyvgDbjmjJnW4SLq8CdCPSWU5nR0W2rRnj7tfqAxM328y+l7vzhwRNGQ8cir
# Ooo6CGJ/2XBjU02N7oJtpQUQwXEGahC0HVUzWLOhcGbyoYICzzCCAjgCAQEwgfyh
# gdSkgdEwgc4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAn
# BgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1ZXJ0byBSaWNvMSYwJAYDVQQL
# Ex1UaGFsZXMgVFNTIEVTTjpDNEJELUUzN0YtNUZGQzElMCMGA1UEAxMcTWljcm9z
# b2Z0IFRpbWUtU3RhbXAgU2VydmljZaIjCgEBMAcGBSsOAwIaAxUAHl/pXkLMAbPa
# pCwa+GXc3SlDDROggYMwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAx
# MDANBgkqhkiG9w0BAQUFAAIFAOdnzwcwIhgPMjAyMzAxMTAxNTQ4MjNaGA8yMDIz
# MDExMTE1NDgyM1owdDA6BgorBgEEAYRZCgQBMSwwKjAKAgUA52fPBwIBADAHAgEA
# AgIRnTAHAgEAAgIRyzAKAgUA52kghwIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgor
# BgEEAYRZCgMCoAowCAIBAAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBBQUA
# A4GBAFu5gM6yHg/bwaRBwsfP/Hf1cnX2ypMCHZMhDw9tS8kNlIfIggCa2gWJ5nvO
# VadGYv+mtpy4iYhy79hc75pexDjNnnSk0sQ3KQoUgtfbZupfanyRcEGD6XCI9Oae
# LoAPZl604wERvTeNVZ6fo7hkCnsoK3d13VR4KD+2NQgTyXteMYIEDTCCBAkCAQEw
# gZMwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UE
# AxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAGj+5qzjnuGQ08A
# AQAAAaMwDQYJYIZIAWUDBAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0B
# CRABBDAvBgkqhkiG9w0BCQQxIgQgzywIazTufcYg2JJP4j/nRrUGRO3wP2i3oSjG
# sUilrKkwgfoGCyqGSIb3DQEJEAIvMYHqMIHnMIHkMIG9BCCM+LiwBnHMMoOd/sgb
# aYxpwvEJlREZl/pTPklz6euN/jCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1w
# IFBDQSAyMDEwAhMzAAABo/uas457hkNPAAEAAAGjMCIEIOMUKnPHhzQFrFuaZClY
# B+JbaEGi4o8i7QIEcTWT2+VoMA0GCSqGSIb3DQEBCwUABIICACDFdbw6iMj31uk/
# 5yjZsJdib8wnwUz5zipkmkh5Dn+iP4ZAjIb+fVJDtybd9p2LSFJtAt4wYW/2/j6h
# HgpIf6kObucwicdkAq/ysY5q9d3BFGpz35GBHDudBc+AUd2OZOM18kJ8Fy0UkwUg
# AyxnRSy4kJ2/grQA0ZO//roWMvzQVh0KCKiurjUt/OLgU8C+7hst2aHfNL5RvcM2
# 4nxCtT1hWugvHEN3Z5c39Mk20PSrHcU/C9gqp1Ba1tBQYO13m1HWIwMYT6tEsEi5
# o6yBSlzeS70AFbTWZRuoDfUFvRD50VVenZu/XlZfiLeVc8Kfs9nkWETfvR2VITQw
# 265ym4/NkEo/tIdOiiGFAkJ9rZQWRGWDNGSDtA5y6+8MxWdNf6vtcDPnRaw4e2tH
# 2ZG8VFujzQzOkvUMPEAlRJAhBoh+5qmFCLr2QKyMt62uuCIi1dFlM0jW5Td8egPM
# yNUVVUiuKPwGHS0xp/rVUhIW/O2a7ciTc0O1hQZytdZo29veVqfuRyoSkHYl7Fbl
# f3Nxh2Aiz/TV3/QDTULcJ4GRTBZxRuMBcWXS7cLt8mfqckHUtcCmyVAQeF5vMsCE
# DxH3t77KVUsyXe6Fg/jQ+wv6w7jaUzfmWSjQ8+E4KPs6cSt+yw6fxIK+DFSZam1d
# kt352a2rYITM7/Dx3gSGCYhhhdKE
# SIG # End signature block
