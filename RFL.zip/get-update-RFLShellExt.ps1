# File: get-update-RFLShellExt.ps1 V2
# last edit by: waltere

<#
.SYNOPSIS
The script will install or update your current version of the RFL PlugIn on your system to latest version.
The registry file for the latest version of the shell extension is located here: \\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\Rfl-Check_ShellExtension.reg -or- in offline package RFL.zip

SYNTAX: .\get-update-RFLShellExt.ps1 [Check-RFL|Check_RFL_anchor|Check_SDP_anchor]

.DESCRIPTION
The script reads in your current registry RFL information and writes new registry key.
The script tries to run itself in elevated mode and ask user to agree, because REG changes need admin permission.
Note: In case of any error, you still can download to local drive and doubleclick the *.reg file on
   \\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\Rfl-Check_ShellExtension.reg

.PARAMETER SkipAdminCheck
If this switch is present, then the check for administrator privileges will be skipped.

.EXAMPLE
To run the RFL shell PlugIn check and update on UNC path
	\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\get-update-RFLShellExt.ps1

.LINK
Update script: \\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\get-update-RFLShellExt.ps1
ShellExtension: \\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\Rfl-Check_ShellExtension.reg
RFL core team: waltere@microsoft.com

#>

[CmdletBinding()]
PARAM (
	[ValidateSet("Check-RFL","Check_RFL_anchor","Check_SDP_anchor")]
	[parameter(Mandatory=$False,Position=0,HelpMessage='Choose one from: [Check_RFL_anchor|Check_SDP_anchor]')]
	[string]$CheckType = "Check_RFL_anchor"	,
	[parameter(Mandatory=$false)]
	[switch]$SkipAdminCheck = $false,
	[switch]$HostMode  = $false, #This tells the logging functions to show logging on the screen
	[switch]$ScriptMode = $false, #This tells the logging functions to show logging in log file
	[switch]$UseExitCode= $true  #This will cause the script to close after the error is logged if an error occurs.
	)

BEGIN {
	$verDateScript = "2023.02.09.0"
	$ScriptFolder = Split-Path $MyInvocation.MyCommand.Path -Parent
	# Load Common Library:
	. $ScriptFolder\Utils_RflShared.ps1

	# update needs elevation
	Write-Host "[RFLshExt_Update] Checking for elevation... "
	$CurrentUser = New-Object Security.Principal.WindowsPrincipal $([Security.Principal.WindowsIdentity]::GetCurrent())
	if (($CurrentUser.IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)) -eq $false)
	{
		$ArgumentList = "-noprofile -noexit -file `"{0}`" " #-Path `"$scriptPath`" -MaxStage $MaxStage"
		If ($ValidateOnly) { $ArgumentList = $ArgumentList + " -ValidateOnly" }
		If ($SkipValidation) { $ArgumentList = $ArgumentList + " -SkipValidation $SkipValidation" }
		If ($Mode) { $ArgumentList = $ArgumentList + " -Mode $Mode" }
		Write-Host "...elevating in new Admin PS window"
		Start-Process powershell.exe -Verb RunAs -ArgumentList ($ArgumentList -f ($myinvocation.MyCommand.Definition)) #-Wait
		Exit
	}
	# Run your code that needs to be elevated here...
#-------------------------------------------------
	Write-host -BackgroundColor Black -ForegroundColor Gray -Object "[RFLshExt_Update] ...Running now with Admin priv (Elevated)"

	$error.clear()	# clear PS script errors
	# This saves the starting ErrorActionPreference and then sets it to 'Stop'.
	$startErrorActionPreference = $errorActionPreference
	$errorActionPreference = 'Continue' # 'Stop' #
	# This gets the current path and name of the script.
	$invocation = (Get-Variable MyInvocation).Value
	$invocationLine= $($MyInvocation.Line)
	$scriptPath = Split-Path $invocation.MyCommand.Path
	#$ScriptParentPath 	= Split-Path $MyInvocation.MyCommand.Path -Parent
	$scriptName = $invocation.MyCommand.Name
	$UserName  = ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name)
	$UsrOSVersion = [Environment]::OSVersion.Version.ToString(3)
	$CheckDate = (Get-Date).ToUniversalTime().ToString("yy-MM-dd_HH-mm-ss")
	#$Script:PSver = $PSVersionTable.PSVersion.Major
	#Write-Host "Running `"$scriptPath\$scriptName`"..." -BackgroundColor Black -ForegroundColor Green
	Set-Variable -Name ErrorMsg -Scope Script -Force
	[string]$Script:ErrorMsg=""

#region ###### customization section of script, logging configuration ########################
	$SDPcheckINI = (Get-content -Path "$ScriptFolder\_SDPcheck.ini")
	$InOfflineMode 	= (($SDPcheckINI[1] -split " ")[2]).trim("""")	# set $True for outsourcer or when not connected to MS network - offline-SDPcheck
	$ExpectedShellExtVersion = (($SDPcheckINI[6] -split " ")[2]).trim("""")
	$RFLroot = (($SDPcheckINI[2] -split " ")[2]).trim("""")	# "\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\" -or- "\\localhost\ToolsShare\rfl\"
	if ($InOfflineMode -match "False") {
		$StatsServer = (($SDPcheckINI[5] -split " ")[2]).trim("""")
		if (Test-Connection -ComputerName $StatsServer -Quiet -Count 1) {[bool]$Stats=$True} else {[bool]$Stats=$False}
	} else { 
		$Stats = $False
	}
	$OnlyRun_AsAdmin = 0
	$Script:regFile = "$RFLroot\Rfl-Check_ShellExtension.reg"
	$Script:regFileV1remove = "$RFLroot\Rfl-Check_ShellExtension_V1-Remove.reg"
	$Script:regFileV2add = "$RFLroot\Rfl-Check_ShellExtension.reg"
	$Script:regFileV2remove = "$RFLroot\Rfl-Check_ShellExtension_Remove.reg"
	$UsrOSVersion = [Environment]::OSVersion.Version.ToString(3)
	$LogLevel = 0
#endregion: ###### customization section

	if ($Stats) {
		$StatsServerPath="\\$StatsServer\RFLstats$\RFL\scripts\Stats\"
		$CountInvFil = $StatsServerPath +'countRFLshExUpd.dat'
		$CountInvFil2 = $CountInvFil +'.us'
		#increment at start of script
		 ($j=[int32](Get-Content $CountInvFil -TotalCount 1 -ErrorAction SilentlyContinue)) |out-null
		 Try {(++$j) | Set-Content $CountInvFil -ErrorAction SilentlyContinue} Catch { }
	}
	$ErrorThrown = $null

	If ($PSBoundParameters['Debug']) { $DebugPreference='Continue'}
	#ConsoleColor enumeration values: Black DarkBlue DarkGreen DarkCyan DarkRed DarkMagenta DarkYellow Gray DarkGray Blue Green Cyan Red Magenta Yellow White

	Set-Variable -Name ShellExtExists -Scope Script -Force
	Set-Variable -Name ShellExtVersion -Scope Script -Force
	Set-Variable -Name regFile -Scope Script -Force
	$Script:ShellExtVersion ='undefined'

#region: Script Functions

function checkPlugin-RFLShellExt ($CheckType,$ExpectedShellExtVersion) {
	EnterFuncDbg $MyInvocation.MyCommand.Name
	Write-host "[RFLshExt_Plugin] Checking for existing ShellExt for $($CheckType) "
	#check if RFLShellExt is installed and 'Version' key exists
	New-PSDrive -Name HKCR -PSProvider Registry -Root HKEY_CLASSES_ROOT |out-null
	$registryPathHKCR = "HKCR:\Directory\shell\$($CheckType)"

	Write-host "[RFLshExt_Plugin] _Checking existing ShellExt in $registryPathHKCR"
	Try { $ErrorActionPreference = "stop"
		$Script:ShellExtExists = (Get-ItemProperty -Path $registryPathHKCR )
		if ($Script:ShellExtExists)	{ Write-host "[RFLshExt_Plugin] __Found ShellExt in $registryPathHKCR" }
	}
	Catch [System.Management.Automation.ItemNotFoundException]
		{ Write-host -BackgroundColor Black -ForegroundColor Yellow -Object "... Simplify: Consider to run Explorer-Extension update in elevated (Run as Administrator) PS cmd, see also _Help.rtf:"
		Write-host -BackgroundColor Black -ForegroundColor Cyan -Object " Powershell -ExecutionPolicy Bypass $RFLroot\get-update-RFLShellExt.ps1"
		Write-host "[RFLshExt_Update] ...RFLshellPlugin not installed - creating it."
		#Write-host "[RFLshExt_Update] ...***please allow registry Version update when UAC prompted***"
		return "[RFLshExt_Update] RegKey $registryPathHKCR itself is missing."
	}
	Finally { $ErrorActionPreference = "Continue" }
	EndFunc $MyInvocation.MyCommand.Name
}

function checkVer-RFLShellExt ($CheckType,$ExpectedShellExtVersion) {
	EnterFuncDbg $MyInvocation.MyCommand.Name
	Write-host "[RFLshExt_Version] Checking ShellExt Version for $($CheckType) "
	#check if RFLShellExt is installed and 'Version' key exists
	New-PSDrive -Name HKCR -PSProvider Registry -Root HKEY_CLASSES_ROOT |out-null
	$registryPathHKCR = "HKCR:\Directory\shell\$($CheckType)"
	$name = "Version"
	$value = "1.00"
	Write-host "[RFLshExt_Version] _Checking current version in $registryPathHKCR"
	Try { $ErrorActionPreference = "stop"
		$Script:ShellExtVersion = (Get-ItemProperty -Path $registryPathHKCR -Name Version).Version
		if ($Script:ShellExtVersion)	{ Write-host "[RFLshExt_Version] __latest available ShellExtVersion is: $Script:ExpectedShellExtVersion"
			IF ($Script:ShellExtVersion -match $ExpectedShellExtVersion) {
				Write-host "[RFLshExt_Version] __Your RFL ShellExtension version $Script:ShellExtVersion is up-to-date";
				EndFunc ($MyInvocation.MyCommand.Name + "($Script:ShellExtVersion _up-to-date)")
				return "$Script:ShellExtVersion _up-to-date"}
			ELSE { if ($Script:ShellExtVersion -lt 1.09) {Write-host -BackgroundColor Black -ForegroundColor Red -Object " Support for this older RFL version will end *soon*, because Server \\muc-vfs-01a will be decommissioned."}
					Write-host -BackgroundColor Yellow -ForegroundColor Black -Object "[RFLshExt_Version] __Your RFL ShellExtension version $Script:ShellExtVersion is outdated!
 .. Consider updating the RFL Shell Explorer Plugin `n $Script:regFileV2add
 To do so, run in ELEVATED (Run as Administrator) PS window the command: "
				Write-host -ForegroundColor Cyan -Object " Powershell -ExecutionPolicy Bypass $RFLroot\get-update-RFLShellExt.ps1"
				EndFunc ($MyInvocation.MyCommand.Name + "($Script:ShellExtVersion _outdated)")
				return "$Script:ShellExtVersion _outdated - user_informed"}
		}
	}
	Catch [System.Management.Automation.PSArgumentException]
	{
		if ($Script:ShellExtVersion -lt 1.09) {Write-host -BackgroundColor Black -ForegroundColor Red -Object "Support for this older RFL version will end *soon*, because Server \\muc-vfs-01a will be decommissioned. "}
		Write-host -BackgroundColor Yellow -ForegroundColor Black -Object "[RFLshExt_Version] __Your RFL ShellExtension version $Script:ShellExtVersion is outdated!
 Please update the RFL Shell Extension `n $Script:regFileV2add
 To do so, run in ELEVATED (Run as Administrator) PS window the command: "
		Write-host -BackgroundColor Black -ForegroundColor Cyan -Object " Powershell -ExecutionPolicy Bypass $RFLroot\get-update-RFLShellExt.ps1"
		"[RFLshExt_Version] RegKey $registryPathHKCR Property $name missing."
	}
	Catch [System.Management.Automation.ItemNotFoundException]
	{ Write-host "[RFLshExt_Version] RegKey $registryPathHKCR\Version is missing."
		Write-debug "[RFLshExt_Version] ...RFLshellPlugin not up-to-date"
		Write-debug "[RFLshExt_Version] ...***please allow registry Version update when UAC prompted***"
		"[RFLshExt_Version] RegKey $registryPathHKCR\Version is missing."
	}
	Finally { $ErrorActionPreference = "Continue" }
	EndFunc $MyInvocation.MyCommand.Name
}

function CheckForUpdates-RFLShellExt ($CheckType,$ExpectedShellExtVersion) {
	EnterFuncDbg $MyInvocation.MyCommand.Name
	if ($OnlyRun_AsAdmin){
		 Write-host "[RFLshExt_ChkUpdates] checking registryPath: $registryPathHKCR\CheckForUpdates"
		 $name = "CheckForUpdates"
		 $value = "1"
		Try { $ErrorActionPreference = "stop"
			$CheckForUpdates = (Get-ItemProperty -Path $registryPathHKCR -Name CheckForUpdates).CheckForUpdates
			if ($CheckForUpdates) {Write-host "[RFLshExt_ChkUpdates] Current CheckForUpdates: $CheckForUpdates"}
			if ($CheckForUpdates -NotMatch "0") {Write-host "[RFLshExt_ChkUpdates] Current ShellExt setting for CheckForUpdates: $CheckForUpdates"}
			else {	Write-host "[RFLshExt_ChkUpdates] CheckForUpdates: '$CheckForUpdates' - .. Consider updating the RFL Shell Explorer Plugin `n $Script:regFileV2add "
				Write-host "[RFLshExt_ChkUpdates] ... keep existing plugin settings because $registryPathHKCR\CheckForUpdates is set to '$CheckForUpdates'"
				break #continue
				}
		 }
		 Catch [System.Management.Automation.PSArgumentException]
		  { "[RFLshExt_ChkUpdates] RegKey $registryPathHKCR Property $name missing."
			 New-ItemProperty -Path $registryPathHKCR -Name $name -Value $value -PropertyType DWORD -Force | Out-Null
		  }
		 Catch [System.Management.Automation.ItemNotFoundException]
		  { "[RFLshExt_ChkUpdates] RegKey $registryPathHKCR itself is missing."
			 Write-host "[RFLshExt_ChkUpdates] ...RFLshellPlugin not installed - creating it"
			 New-Item -Path $registryPathHKCR -Force #| Out-Null
			 New-ItemProperty -Path $registryPathHKCR -Name $name -Value $value -PropertyType DWORD -Force | Out-Null
		 }
		 Finally {
			 "[RFLshExt_ChkUpdates] CheckForUpdates reg: $CheckForUpdates"
			 $ErrorActionPreference = "Continue" }
	 } # end of if ($OnlyRun_AsAdmin)
	 EndFunc $MyInvocation.MyCommand.Name
}

function update-ShellExt ($CheckType,$ExpectedShellExtVersion) {
	EnterFuncDbg $MyInvocation.MyCommand.Name
	if (!($Script:ShellExtVersion -match $ExpectedShellExtVersion) -and ($CheckForUpdates -NotMatch "0")) {
		write-host "[RFLshExt_Update] ...Outdated Check_RFL ShellExtVersion v$Script:ShellExtVersion"
		Try
		{
		write-host "[RFLshExt_Update] ...removing existing entry Check_RFL v$Script:ShellExtVersion"
		$RegTryRemoveV1 = regedit /s $Script:regFileV1remove
		$RegTryRemoveV2 = regedit /s $Script:regFileV2remove
		write-host "[RFLshExt_Update] ...Importing latest v$ExpectedShellExtVersion $Script:regFile silently"
		$RegTryAdd = regedit /s $Script:regFile
		write-host "[RFLshExt_Update] ...Registry Update result: $RegTryAdd"
		Write-host -BackgroundColor Black -ForegroundColor Green -Object "[RFLshExt_Update] RFLShellExt $CheckType successfully updated"
		"RegImport-done $ExpectedShellExtVersion"
		}
		Catch [System.Security.SecurityException]
			{ "Registry Remove-Item $registryPathHKCR"
			}
		Catch
			{
				Write-Error "[RFLshExt_Update] Aborted. The error was '$($_.Exception.Message)'"
				Write-host -BackgroundColor Black -ForegroundColor Red -Object "[RFLshExt_Update] Aborted by user"
				"Aborted by user."
			}
		Finally
		{
			"$Script:ShellExtVersion RegVersion-not-matched. Prev.Ver: $Script:ShellExtVersion"
		}
	}
	EndFunc $MyInvocation.MyCommand.Name
}

function autoupdate-ShellExt ($CheckType,$ExpectedShellExtVersion) {
	EnterFuncDbg $MyInvocation.MyCommand.Name
	checkPlugin-RFLShellExt $CheckType $ExpectedShellExtVersion		#call function
	if ($Script:ShellExtExists)	{
		checkVer-RFLShellExt $CheckType $ExpectedShellExtVersion	#call function
	}
	update-ShellExt $CheckType $ExpectedShellExtVersion				#call function
	EndFunc $MyInvocation.MyCommand.Name
}

function remove-ShellExt ($RegKey) {
	# SYNOPSIS :
	EnterFuncDbg $MyInvocation.MyCommand.Name
	New-PSDrive -Name HKCR -PSProvider Registry -Root HKEY_CLASSES_ROOT |out-null

	Try	{
		write-host "[RFLshExt_Remove] _Trying to remove entry $RegKey"
		Remove-Item $RegKey -Recurse -ErrorAction SilentlyContinue
	}
	Catch [System.Security.SecurityException]
		{ "Registry Remove-Item $RegKey" }
	Catch [System.Management.Automation.ItemNotFoundException]
		{"RegKey $RegKey is missing."}
	Catch
		{
			Write-Error "[RFLshExt_Remove] Aborted. The error was '$($_.Exception.Message)'"
			Write-host -BackgroundColor Black -ForegroundColor Red -Object "[RFLshExt_Remove] Aborted by user"
			"Aborted by user."
		}
	Finally { " _ $RegKey done"}
	EndFunc $MyInvocation.MyCommand.Name
}
#endregion: Script Functions
} #end BEGIN

PROCESS {
	try {
		$ScriptBeginTimeStamp = Get-Date
		#region: MAIN :::::

		#for downlevel Plugin V1 with parameter Check-RFL
		if ($CheckType -match "Check-RFL") { $CheckType = "Check_RFL_anchor"}
		Write-host "CheckType: $CheckType "

		### main
		$au = autoupdate-ShellExt $CheckType $ExpectedShellExtVersion		#call function
		$Script:ResultMsg = $au
		Write-verbose "[RFLshExt_Update] AutoUpdate results: $au"
		If (-not $au) {Write-host "[RFLshExt_Update] .. Consider updating the RFL Shell Explorer Plugin $Script:regFile "}
		write-host -BackgroundColor Black -ForegroundColor Green -Object "[RFLshExt_Update] ...done. New RFL ShellExt $ExpectedShellExtVersion plugin should be available in your Windows Explorer context menu for folders right now."
		write-host -ForegroundColor Gray "Note: In case of any error, you still can download to local drive and doubleclick the *.reg file on
			 $($RFLroot)\Rfl-Check_ShellExtension.reg `n"

		#endregion: MAIN :::::
	}
	catch {
		$ErrorThrown = $true
		$errorMessage = "$scriptName caught an exception on $($ENV:COMPUTERNAME):`n`n"
		$errorMessage += "Exception Type: $($_.Exception.GetType().FullName)"
		$errorMessage += "`n`n Exception Message: $($_.Exception.Message)"

		Write-Error $errorMessage -ErrorAction Continue
		Start-Sleep -Seconds 3
		Write-Debug $errorMessage
		if ($UseExitCode) {
			$error.clear()	# clear script errors
			exit 1
		}
  } #end Catch PROCESS
	Finally {
	}
} #end PROCESS

END {
	$ScriptEndTimeStamp = Get-Date
	$Duration = $(New-TimeSpan -Start $ScriptBeginTimeStamp -End $ScriptEndTimeStamp)
	$LogLevel = 0
	Write-host -BackgroundColor Gray -ForegroundColor Black -Object " Script $scriptName v$verDateScript execution finished. Duration: $Duration"
	# This resets the ErrorActionPreference to the value at script start.
	$errorActionPreference = $startErrorActionPreference
	# Stats
	If ($Stats) { #increment at start of script
	 Try {"$j; $CheckDate; $UsrOSVersion; $UserName; $Duration; $Script:ShellExtVersion; $Script:ResultMsg; v$verDateScript ; $env:computername" | Out-File $CountInvFil2 -Append -Encoding UTF8 -ErrorAction SilentlyContinue} Catch { }
	 }
	if($ErrorThrown) {Throw $error[0].Exception.Message}
} #end END

#region: comments
<#
	The top section is comment based help so the Get-Help command will work with the script.
	The [CmdletBinding()] turns on advanced options like the common parameters.
	All sub functions are in the "BEGIN" section.
	My script code goes in the "PROCESS try" block.

VERSION and AUTHOR:
    Walter Eder	- waltere@microsoft.com

HISTORY
	2015-02-02	V1.04
	2016-07-02	- add capability to remove all RFL registry settings, see remove-RFLShellExt.ps1
	2017-04-03	V1.08 (removed platform, re-added VSS in Rfl-Check_ShellExtension_FQDN.reg)
	2017-10-06	v1.11 changed [RFLshExt_Update] to [RFLshExt_Version] + output enhancements
	2017-11-19	v1.13 using PS functions
	2019-02-25	v1.16 implemented RFLShellExtV2 update
	2022-09-08 using Utils_RflShared.psm1 library
	
	ToDo: 	/known issue:
	#https://blogs.msdn.microsoft.com/virtual_pc_guy/2010/09/23/a-self-elevating-powershell-script/


	Hints:
		# Wait for User Input
		Write-host -NoNewLine "Press any key to continue ..."; $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
#-------------------------------------------------
#$error[0] |fl * -force
#Write-Host -NoNewLine "Press any key to continue ...";
#$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
#>
#endregion: comments


# SIG # Begin signature block
# MIInvwYJKoZIhvcNAQcCoIInsDCCJ6wCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCD04Iaa7eUNFCPF
# WVy/WQjQWlSTvXeE6zzqEuzgMJX3bqCCDXYwggX0MIID3KADAgECAhMzAAADTrU8
# esGEb+srAAAAAANOMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjMwMzE2MTg0MzI5WhcNMjQwMzE0MTg0MzI5WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDdCKiNI6IBFWuvJUmf6WdOJqZmIwYs5G7AJD5UbcL6tsC+EBPDbr36pFGo1bsU
# p53nRyFYnncoMg8FK0d8jLlw0lgexDDr7gicf2zOBFWqfv/nSLwzJFNP5W03DF/1
# 1oZ12rSFqGlm+O46cRjTDFBpMRCZZGddZlRBjivby0eI1VgTD1TvAdfBYQe82fhm
# WQkYR/lWmAK+vW/1+bO7jHaxXTNCxLIBW07F8PBjUcwFxxyfbe2mHB4h1L4U0Ofa
# +HX/aREQ7SqYZz59sXM2ySOfvYyIjnqSO80NGBaz5DvzIG88J0+BNhOu2jl6Dfcq
# jYQs1H/PMSQIK6E7lXDXSpXzAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUnMc7Zn/ukKBsBiWkwdNfsN5pdwAw
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzUwMDUxNjAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAD21v9pHoLdBSNlFAjmk
# mx4XxOZAPsVxxXbDyQv1+kGDe9XpgBnT1lXnx7JDpFMKBwAyIwdInmvhK9pGBa31
# TyeL3p7R2s0L8SABPPRJHAEk4NHpBXxHjm4TKjezAbSqqbgsy10Y7KApy+9UrKa2
# kGmsuASsk95PVm5vem7OmTs42vm0BJUU+JPQLg8Y/sdj3TtSfLYYZAaJwTAIgi7d
# hzn5hatLo7Dhz+4T+MrFd+6LUa2U3zr97QwzDthx+RP9/RZnur4inzSQsG5DCVIM
# pA1l2NWEA3KAca0tI2l6hQNYsaKL1kefdfHCrPxEry8onJjyGGv9YKoLv6AOO7Oh
# JEmbQlz/xksYG2N/JSOJ+QqYpGTEuYFYVWain7He6jgb41JbpOGKDdE/b+V2q/gX
# UgFe2gdwTpCDsvh8SMRoq1/BNXcr7iTAU38Vgr83iVtPYmFhZOVM0ULp/kKTVoir
# IpP2KCxT4OekOctt8grYnhJ16QMjmMv5o53hjNFXOxigkQWYzUO+6w50g0FAeFa8
# 5ugCCB6lXEk21FFB1FdIHpjSQf+LP/W2OV/HfhC3uTPgKbRtXo83TZYEudooyZ/A
# Vu08sibZ3MkGOJORLERNwKm2G7oqdOv4Qj8Z0JrGgMzj46NFKAxkLSpE5oHQYP1H
# tPx1lPfD7iNSbJsP6LiUHXH1MIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGZ8wghmbAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAANOtTx6wYRv6ysAAAAAA04wDQYJYIZIAWUDBAIB
# BQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIDBFhDs99wehdIriVPJRUc0O
# 0n5sYqpi2IKGjFarudZ0MEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEB
# BQAEggEAyKuf56GvZwN92GUBmUA8R88kXRej/WPhSCKfo9iX1Wp1knhKiWqx5K6n
# 9C/oVN4zWZJriEAblLony85NvpYs9/7Hqb7Cg11JxAh3pmC/CSkNeQqV72FsYAQt
# 5QXvlElaJV/hkeosa40zEDLxmnoG938xvBPbRrdyMX3Tbx266AzlAdYneEG/icPE
# +J0Pgkk3WEHO8l4Ut3Abae4AmPP6+Ze15NYDo+wO6F6WBkvp6JHbjB7hcnLPq0ED
# aPiRAotlNSaAaOmr9tMwX23FiR00pRAvaH5GFxkNJa6nVPFNIEbNljmxNnXtJpLG
# zVicbP8o0ASJsWjJEYigmRKBO/4lEaGCFykwghclBgorBgEEAYI3AwMBMYIXFTCC
# FxEGCSqGSIb3DQEHAqCCFwIwghb+AgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFZBgsq
# hkiG9w0BCRABBKCCAUgEggFEMIIBQAIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFl
# AwQCAQUABCCCrroPBQQjkBznrKqzAKLRgcGC4r8CkINvLLbnRKx3egIGZGzxP/5f
# GBMyMDIzMDYxNDE1NTkxOC40ODlaMASAAgH0oIHYpIHVMIHSMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJl
# bGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNO
# OjA4NDItNEJFNi1DMjlBMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNloIIReDCCBycwggUPoAMCAQICEzMAAAGybkADf26plJIAAQAAAbIwDQYJ
# KoZIhvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjIw
# OTIwMjAyMjAxWhcNMjMxMjE0MjAyMjAxWjCB0jELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IElyZWxhbmQgT3Bl
# cmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjowODQyLTRC
# RTYtQzI5QTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZTCC
# AiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAMqiZTIde/lQ4rC+Bml5f/Wu
# q/xKTxrfbG23HofmQ+qZAN4GyO73PF3y9OAfpt7Qf2jcldWOGUB+HzBuwllYyP3f
# x4MY8zvuAuB37FvoytnNC2DKnVrVlHOVcGUL9CnmhDNMA2/nskjIf2IoiG9J0qLY
# r8duvHdQJ9Li2Pq9guySb9mvUL60ogslCO9gkh6FiEDwMrwUr8Wja6jFpUTny8tg
# 0N0cnCN2w4fKkp5qZcbUYFYicLSb/6A7pHCtX6xnjqwhmJoib3vkKJyVxbuFLRhV
# XxH95b0LHeNhifn3jvo2j+/4QV10jEpXVW+iC9BsTtR69xvTjU51ZgP7BR4YDEWq
# 7JsylSOv5B5THTDXRf184URzFhTyb8OZQKY7mqMh7c8J8w1sEM4XDUF2UZNy829N
# VCzG2tfdEXZaHxF8RmxpQYBxyhZwY1rotuIS+gfN2eq+hkAT3ipGn8/KmDwDtzAb
# nfuXjApgeZqwgcYJ8pDJ+y/xU6ouzJz1Bve5TTihkiA7wQsQe6R60Zk9dPdNzw0M
# K5niRzuQZAt4GI96FhjhlUWcUZOCkv/JXM/OGu/rgSplYwdmPLzzfDtXyuy/GCU5
# I4l08g6iifXypMgoYkkceOAAz4vx1x0BOnZWfI3fSwqNUvoN7ncTT+MB4Vpvf1QB
# ppjBAQUuvui6eCG0MCVNAgMBAAGjggFJMIIBRTAdBgNVHQ4EFgQUmfIngFzZEZlP
# kjDOVluBSDDaanEwHwYDVR0jBBgwFoAUn6cVXQBeYl2D9OXSZacbUzUZ6XIwXwYD
# VR0fBFgwVjBUoFKgUIZOaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9j
# cmwvTWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3JsMGwG
# CCsGAQUFBwEBBGAwXjBcBggrBgEFBQcwAoZQaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNyb3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIw
# MjAxMCgxKS5jcnQwDAYDVR0TAQH/BAIwADAWBgNVHSUBAf8EDDAKBggrBgEFBQcD
# CDAOBgNVHQ8BAf8EBAMCB4AwDQYJKoZIhvcNAQELBQADggIBANxHtu3FzIabaDbW
# qswdKBlAhKXRCN+5CSMiv2TYa4i2QuWIm+99piwAhDhADfbqor1zyLi95Y6GQnvI
# WUgdeC7oL1ZtZye92zYK+EIfwYZmhS+CH4infAzUvscHZF3wlrJUfPUIDGVP0lCY
# Vse9mguvG0dqkY4ayQPEHOvJubgZZaOdg/N8dInd6fGeOc+0DoGzB+LieObJ2Q0A
# tEt3XN3iX8Cp6+dZTX8xwE/LvhRwPpb/+nKshO7TVuvenwdTwqB/LT6CNPaElwFe
# KxKrqRTPMbHeg+i+KnBLfwmhEXsMg2s1QX7JIxfvT96md0eiMjiMEO22LbOzmLMN
# d3LINowAnRBAJtX+3/e390B9sMGMHp+a1V+hgs62AopBl0p/00li30DN5wEQ5If3
# 5Zk7b/T6pEx6rJUDYCti7zCbikjKTanBnOc99zGMlej5X+fC/k5ExUCrOs3/VzGR
# CZt5LvVQSdWqq/QMzTEmim4sbzASK9imEkjNtZZyvC1CsUcD1voFktld4mKMjE+u
# DEV3IddD+DrRk94nVzNPSuZXewfVOnXHSeqG7xM3V7fl2aL4v1OhL2+JwO1Tx3B0
# irO1O9qbNdJk355bntd1RSVKgM22KFBHnoL7Js7pRhBiaKmVTQGoOb+j1Qa7q+ci
# xGo48Vh9k35BDsJS/DLoXFSPDl4mMIIHcTCCBVmgAwIBAgITMwAAABXF52ueAptJ
# mQAAAAAAFTANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNh
# dGUgQXV0aG9yaXR5IDIwMTAwHhcNMjEwOTMwMTgyMjI1WhcNMzAwOTMwMTgzMjI1
# WjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQD
# Ex1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCCAiIwDQYJKoZIhvcNAQEB
# BQADggIPADCCAgoCggIBAOThpkzntHIhC3miy9ckeb0O1YLT/e6cBwfSqWxOdcjK
# NVf2AX9sSuDivbk+F2Az/1xPx2b3lVNxWuJ+Slr+uDZnhUYjDLWNE893MsAQGOhg
# fWpSg0S3po5GawcU88V29YZQ3MFEyHFcUTE3oAo4bo3t1w/YJlN8OWECesSq/XJp
# rx2rrPY2vjUmZNqYO7oaezOtgFt+jBAcnVL+tuhiJdxqD89d9P6OU8/W7IVWTe/d
# vI2k45GPsjksUZzpcGkNyjYtcI4xyDUoveO0hyTD4MmPfrVUj9z6BVWYbWg7mka9
# 7aSueik3rMvrg0XnRm7KMtXAhjBcTyziYrLNueKNiOSWrAFKu75xqRdbZ2De+JKR
# Hh09/SDPc31BmkZ1zcRfNN0Sidb9pSB9fvzZnkXftnIv231fgLrbqn427DZM9itu
# qBJR6L8FA6PRc6ZNN3SUHDSCD/AQ8rdHGO2n6Jl8P0zbr17C89XYcz1DTsEzOUyO
# ArxCaC4Q6oRRRuLRvWoYWmEBc8pnol7XKHYC4jMYctenIPDC+hIK12NvDMk2ZItb
# oKaDIV1fMHSRlJTYuVD5C4lh8zYGNRiER9vcG9H9stQcxWv2XFJRXRLbJbqvUAV6
# bMURHXLvjflSxIUXk8A8FdsaN8cIFRg/eKtFtvUeh17aj54WcmnGrnu3tz5q4i6t
# AgMBAAGjggHdMIIB2TASBgkrBgEEAYI3FQEEBQIDAQABMCMGCSsGAQQBgjcVAgQW
# BBQqp1L+ZMSavoKRPEY1Kc8Q/y8E7jAdBgNVHQ4EFgQUn6cVXQBeYl2D9OXSZacb
# UzUZ6XIwXAYDVR0gBFUwUzBRBgwrBgEEAYI3TIN9AQEwQTA/BggrBgEFBQcCARYz
# aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9Eb2NzL1JlcG9zaXRvcnku
# aHRtMBMGA1UdJQQMMAoGCCsGAQUFBwMIMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIA
# QwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFNX2
# VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwu
# bWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEw
# LTA2LTIzLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93
# d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYt
# MjMuY3J0MA0GCSqGSIb3DQEBCwUAA4ICAQCdVX38Kq3hLB9nATEkW+Geckv8qW/q
# XBS2Pk5HZHixBpOXPTEztTnXwnE2P9pkbHzQdTltuw8x5MKP+2zRoZQYIu7pZmc6
# U03dmLq2HnjYNi6cqYJWAAOwBb6J6Gngugnue99qb74py27YP0h1AdkY3m2CDPVt
# I1TkeFN1JFe53Z/zjj3G82jfZfakVqr3lbYoVSfQJL1AoL8ZthISEV09J+BAljis
# 9/kpicO8F7BUhUKz/AyeixmJ5/ALaoHCgRlCGVJ1ijbCHcNhcy4sa3tuPywJeBTp
# kbKpW99Jo3QMvOyRgNI95ko+ZjtPu4b6MhrZlvSP9pEB9s7GdP32THJvEKt1MMU0
# sHrYUP4KWN1APMdUbZ1jdEgssU5HLcEUBHG/ZPkkvnNtyo4JvbMBV0lUZNlz138e
# W0QBjloZkWsNn6Qo3GcZKCS6OEuabvshVGtqRRFHqfG3rsjoiV5PndLQTHa1V1QJ
# sWkBRH58oWFsc/4Ku+xBZj1p/cvBQUl+fpO+y/g75LcVv7TOPqUxUYS8vwLBgqJ7
# Fx0ViY1w/ue10CgaiQuPNtq6TPmb/wrpNPgkNWcr4A245oyZ1uEi6vAnQj0llOZ0
# dFtq0Z4+7X6gMTN9vMvpe784cETRkPHIqzqKOghif9lwY1NNje6CbaUFEMFxBmoQ
# tB1VM1izoXBm8qGCAtQwggI9AgEBMIIBAKGB2KSB1TCB0jELMAkGA1UEBhMCVVMx
# EzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoT
# FU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IElyZWxh
# bmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjow
# ODQyLTRCRTYtQzI5QTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2Vy
# dmljZaIjCgEBMAcGBSsOAwIaAxUAjhJ+EeySRfn2KCNsjn9cF9AUSTqggYMwgYCk
# fjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQD
# Ex1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUFAAIF
# AOgzxSIwIhgPMjAyMzA2MTQxMjQ4MzRaGA8yMDIzMDYxNTEyNDgzNFowdDA6Bgor
# BgEEAYRZCgQBMSwwKjAKAgUA6DPFIgIBADAHAgEAAgIFBDAHAgEAAgI+RjAKAgUA
# 6DUWogIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAowCAIBAAID
# B6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBAAAL0VbMN4wo8kNPjOEk
# BCaPzeDRl03PzdddegZQ/E+ZsFg1evVjPTlfE5pY5apTrBwezhkwkyIQ/mKfa7j8
# 5OUhUoIdeuIvyqoKoktkvi49q11N8z1E4cR3hRztT91hPD7Q63Rs/IXHRgejWP8O
# Sv1RK1sV3OLGoofh3eHhOP+GMYIEDTCCBAkCAQEwgZMwfDELMAkGA1UEBhMCVVMx
# EzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoT
# FU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUt
# U3RhbXAgUENBIDIwMTACEzMAAAGybkADf26plJIAAQAAAbIwDQYJYIZIAWUDBAIB
# BQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0BCQQx
# IgQgv4PAKeOFabKOp2qYoJQyrfaVG9dRhsuOrLEsZTb+jJowgfoGCyqGSIb3DQEJ
# EAIvMYHqMIHnMIHkMIG9BCBTeM485+E+t4PEVieUoFKX7PVyLo/nzu+htJPCG04+
# NTCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAw
# DgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24x
# JjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAABsm5A
# A39uqZSSAAEAAAGyMCIEIB7KttD70C0Wyo/rkm3uLuHVImh+QjKIMxd/0AL+Cd+0
# MA0GCSqGSIb3DQEBCwUABIICAGqDvpY5sW2OJONejqe5Lf+jS8RVs/SZueHgo40l
# uyZdlEOFtskXMS6f6gVu5jRqN+nFXDibkoMGpmpHwFQHA4LeXr8OtISIy3GsNA7C
# 6jho4AOFA9xc+Qk3DB/cXZ01xmHS8Fzo299dv4de+hf7aZDh0X87oXj0loYm0OjU
# 9HoCCPhZEwBg8/jwyXJ8iscWk92eTTGBgtOK6YJkn6g8Imu0qBhl6AIbcf4TJnev
# djVjkTP7cI4WB55ZNIpgmSZ8rZO9ifph5uQXkuhDmjVznu0etx7CTpq/4vAIUfl/
# qg2FAhbkBfk5mMar8O4cSE6ozUUySMhSDGW4i8nMDTDKEKNQ1sJlyRkHaNwAkIWn
# z7uIeypIonf3TbAGan/AvaCj2uAVK5RcwwrpzxgpIRzTAuy0veMEqt2WIITLMHsw
# LGnc5a1QZ/s1nkX8yrz1nbjF0eOMkC0uoZqlhXR+U+sQszhflV9vSrctDIRy2HVY
# rXqqa5HjGXaO9mNODOdRuCo18M+r2HFLOofLPjSKLW93dQ7CYfzeMiibKOV6Bp1M
# aPXVumQvdqb5aHASlWkqOxQUtot/9H6RtjKinbwPF9zXhiiN7QXyLAhoePOugi7m
# qwNysfF2f6Nq9eGea79MBYuup40RSPEahrQpmXAQZ87grGNojRe909UIUaV7SCEk
# KBGa
# SIG # End signature block
