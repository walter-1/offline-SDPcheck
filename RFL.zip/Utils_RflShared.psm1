# ******************************************* RFL ***********************************************
# File: Utils_RflShared.ps1
# Version 1.0
# Date: 2023-01-07
# Description:  Utility Script to load common functions for RFL.
# last edit by: waltere 2022-09-08
# ***********************************************************************************************


##########################
## Set Variables        ##
##########################
$verDatePsm1 = "2023.01.07.0"
#$ComputerName = $Env:computername
#$UserOSVersion = [Environment]::OSVersion.Version

##########################
## Function Definitions ##
##########################

#region Logging functions
Function global:RflEnterFunc([String]$FunctionName){
	Write-Verbose "---> Enter $FunctionName"
}

Function global:RflEndFunc([String]$FunctionName){
	Write-Verbose "<--- End $FunctionName"
}

Function global:WriteLine ([string]$line,[string]$ForegroundColor, [switch]$NoNewLine){
	# SYNOPSIS: writes the actual output - used by other Logging Functions
	if($Script:ScriptMode){
	  if($NoNewLine) {
		$Script:Trace += "$line"
	  }
	  else {
		$Script:Trace += "$line`r`n"
	  }
	  Set-Content -Path $script:LogPath -Value $Script:Trace
	}
	if($Script:HostMode){
	  $Params = @{
		NoNewLine    = $NoNewLine -eq $true
		ForegroundColor = if($ForegroundColor) {$ForegroundColor} else {"White"}
	  }
	  Write-Host $line @Params
	}
}

Function global:WriteInfo([string]$message,[switch]$WaitForResult,[string[]]$AdditionalStringArray,[string]$AdditionalMultilineString){
	# SYNOPSIS: handles informational logs
	if($WaitForResult){
	  WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)$message" -NoNewline
	}
	else{
	  WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)$message"
	}
	if($AdditionalStringArray){
	  foreach ($String in $AdditionalStringArray){
		WriteLine "          $("`t" * $script:LogLevel)`t$String"
	  }
	}
	if($AdditionalMultilineString){
	  foreach ($String in ($AdditionalMultilineString -split "`r`n" | Where-Object {$_ -ne ""})){
		WriteLine "          $("`t" * $script:LogLevel)`t$String"
	  }
	}
}

Function global:WriteResult([string]$message,[switch]$Pass,[switch]$Success){
	# SYNOPSIS: writes results - should be used after -WaitForResult in WriteInfo
	if($Pass){
	  WriteLine " - Pass" -ForegroundColor Cyan
	  if($message){
		WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)`t$message" -ForegroundColor Cyan
	  }
	}
	if($Success){
	  WriteLine " - Success" -ForegroundColor Green
	  if($message){
		WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)`t$message" -ForegroundColor Green
	  }
	}
}

Function global:WriteInfoHighlighted([string]$message,[string[]]$AdditionalStringArray,[string]$AdditionalMultilineString){
	# SYNOPSIS: write highlighted info
	WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:  $("`t" * $script:LogLevel)$message" -ForegroundColor Cyan
	if($AdditionalStringArray){
	  foreach ($String in $AdditionalStringArray){
		WriteLine "[$(Get-Date -Format hh:mm:ss)]     $("`t" * $script:LogLevel)`t$String" -ForegroundColor Cyan
	  }
	}
	if($AdditionalMultilineString){
	  foreach ($String in ($AdditionalMultilineString -split "`r`n" | Where-Object {$_ -ne ""})){
		WriteLine "[$(Get-Date -Format hh:mm:ss)]     $("`t" * $script:LogLevel)`t$String" -ForegroundColor Cyan
	  }
	}
}

Function global:WriteWarning([string]$message,[string[]]$AdditionalStringArray,[string]$AdditionalMultilineString){
	# SYNOPSIS: write warning logs
	WriteLine "[$(Get-Date -Format hh:mm:ss)] WARNING: $("`t" * $script:LogLevel)$message" -ForegroundColor Yellow
	if($AdditionalStringArray){
	  foreach ($String in $AdditionalStringArray){
		WriteLine "[$(Get-Date -Format hh:mm:ss)]     $("`t" * $script:LogLevel)`t$String" -ForegroundColor Yellow
	  }
	}
	if($AdditionalMultilineString){
	  foreach ($String in ($AdditionalMultilineString -split "`r`n" | Where-Object {$_ -ne ""})){
		WriteLine "[$(Get-Date -Format hh:mm:ss)]     $("`t" * $script:LogLevel)`t$String" -ForegroundColor Yellow
	  }
	}
}

Function global:WriteError([string]$message){
	# SYNOPSIS: logs errors
	WriteLine ""
	WriteLine "[$(Get-Date -Format hh:mm:ss)] ERROR:  $("`t`t" * $script:LogLevel)$message" -ForegroundColor Red
}

Function global:WriteErrorAndExit($message){
	# SYNOPSIS: logs errors and terminates script
	WriteLine "[$(Get-Date -Format hh:mm:ss)] ERROR:  $("`t" * $script:LogLevel)$message" -ForegroundColor Red
	Write-Host "Press any key to continue ..."
	$host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") | OUT-NULL
	$HOST.UI.RawUI.Flushinputbuffer()
	Throw "Terminating Error"
}
#endregion Logging functions

#region RFL functions
function GetOSfromMSinfo32 ($SDPPath,$NodeName){
	# Return: $OSshortVer of SDP report
	RflEnterFunc ($MyInvocation.MyCommand.Name + "(NodeName: $NodeName)")
	### Validate user input of expanded SDP report and identify the number of msinfo32.txt files and the names of the computers $NodeNames (in Cluster Report)
	$msinfo32 = $SDPPath + $NodeName + '*msinfo*.txt' # Try .txt
	If (-NOT (Test-Path $msinfo32)) {
	    Write-Verbose "[GetOSfromMSinfo32]** $SDPPath without *msinfo32.txt"
	    $msinfo32 = $SDPPath + $NodeName + '*msinfo*.nfo' # Try .nfo
	}

	### Get OS version of SDP report from msinfo.txt
	If ("$msinfo32" -match ".txt"){
	    Write-Verbose "[GetOSfromMSinfo32]Node: $NodeName Using msinfo32.txt = $msinfo32 "
	    #Read-in content from Msinfo file
	    if ($msinfo32file = get-childitem $msinfo32) {
			Write-Debug "[GetOSfromMSinfo32]msinfo32file: $msinfo32file "
			$script:SDPdate = $msinfo32file.LastWriteTime
			Write-host "`n[GetOSfromMSinfo32]Node: $NodeName : SDP Date: $script:SDPdate"
			$msinfo32 = Get-Content $msinfo32 -TotalCount 13
			If ($msinfo32){
				$SdpOSbuild = 		$msinfo32[-7]
				$global:SdpOSname = 		$msinfo32[-8];$SdpOSname=$global:SdpOSname.Split(" ",3)[2]
				$global:SdpComputerName = 	$msinfo32[1].Split("")[-1]
				$Systemmodell = 	$msinfo32[-2] #.Split("")[1,2,3]
				$is_Virtual = 		$Systemmodell| Select-String -Pattern ".*Virtual.*" -ErrorAction SilentlyContinue; if ($is_Virtual) {$Virtualized="VM"} else {$Virtualized=""}
				$is_VMware = 		$Systemmodell| Select-String -Pattern ".*VMware.*" -ErrorAction SilentlyContinue; if ($is_VMware) {$Script:Virtualization="VMware"} else {$Script:Virtualization=""}
				$SystemArch = 		$msinfo32[-1] #.Split("")[-1,-2]
				$is_x64 = 			$SystemArch| Select-String -Pattern ".*x64.*" -ErrorAction SilentlyContinue; if ($is_x64) {$Architecture="x64"} else {$Architecture="x86"}
				#_#Write-Output " Node: $SdpComputerName|$SdpOSbuild|$SdpOSname|$Systemmodell|$SystemArch |-> $Virtualized|$Virtualization|$Architecture|"
				Write-Host " Node: $SdpComputerName|$SdpOSbuild|$SdpOSname|$Systemmodell|$SystemArch |-> $Virtualized|$Virtualization|$Architecture|"
			}else{$global:ErrorMsg += "No-Valid-MsI32_txt "}
		}
	}
	Else { # Get OS version of SDP report from msinfo.nfo / may not work for some localized OS
		Write-Verbose "Node: $NodeName Using msinfo32.nfo = $msinfo32 "
		if ($msinfo32file = get-childitem $msinfo32) {
			$script:SDPdate = $msinfo32file.LastWriteTime
			Write-Debug "`nNode: $NodeName : SDP Date: $script:SDPdate"
			[xml]$nfo = Get-Content $msinfo32file
			$summary = $nfo.MSInfo.Category.Data.value # German $nfo.MSInfo.Category.Data.Wert / Italian: Valore
			If ($summary.'#cdata-section') {
				$SdpOSbuild = 		$summary.'#cdata-section'[1]
				$global:SdpOSname = 		$summary.'#cdata-section'[0]
				$global:SdpComputerName = 	$summary.'#cdata-section'[4]
				$Systemmodell = 	$summary.'#cdata-section'[6]
				$is_Virtual = 		$Systemmodell| Select-String -Pattern ".*Virtual.*" -ErrorAction SilentlyContinue; if ($is_Virtual) {$Virtualized="VM"} else {$Virtualized=""}
				$is_VMware = 		$Systemmodell| Select-String -Pattern ".*VMware.*" -ErrorAction SilentlyContinue; if ($is_VMware) {$Script:Virtualization="VMware"} else {$Script:Virtualization=""}
				$SystemArch = 		$summary.'#cdata-section'[7]
				$is_x64 = 			$SystemArch| Select-String -Pattern ".*x64.*" -ErrorAction SilentlyContinue; if ($is_x64) {$Architecture="x64"} else {$Architecture="x86"}
				Write-Host " Node: $SdpOSbuild|$SdpOSname|$SdpComputerName|$Systemmodell|$SystemArch |-> $Virtualized|$Virtualization|$Architecture|"
			}else{
				$global:ErrorMsg += "No-Valid-MsI32_nfo"
				Write-Host -BackgroundColor Black -ForegroundColor Yellow -Object "WARNING: SDP with no valid MSinfo32.txt or English .nfo files"
			}
		}
	}
	if ($SdpOSname -match "Windows 1|Windows 7|Windows 8") {$isClient = $True}
	$global:ErrorMsg += "$Architecture $Virtualized $Virtualization "
	
	### match Build number in SDP report with OS short name
	if("$SdpOSbuild" -match "2600"){$OSshortVer_old="old-XP"}  		# Windows XP
	if("$SdpOSbuild" -match "3790"){$OSshortVer_old="old-2003"}  	# Windows 2003
	if("$SdpOSbuild" -match "6001"){$OSshortVer_old="old-2008-SP1"}	# Windows Vista/2008 SP1
	if("$SdpOSbuild" -match "6002|6003"){$OSshortVer="2008"}  		# Windows Vista/2008 SP2
	if("$SdpOSbuild" -match "7600"){$OSshortVer_old="old-2008R2-RTM"} # Windows 7/2008R2 RTM
	if("$SdpOSbuild" -match "7601"){$OSshortVer="2008R2"} 			# Windows 7/2008R2
	if("$SdpOSbuild" -match "9200"){$OSshortVer="2012"}  			# Windows 8
	if("$SdpOSbuild" -match "9600"){$OSshortVer="2012R2"} 			# Windows 8.1
	if("$SdpOSbuild" -match "10.0.10240"){$OSshortVer="2016"} 		# Windows 10
	if("$SdpOSbuild" -match "10.0.14393"){$OSshortVer="2016RS1"} 	# Windows 10 RS1
	if("$SdpOSbuild" -match "10.0.17763"){$OSshortVer="2016RS5"} 	# Windows 10 RS5
	if("$SdpOSbuild" -match "10.0.18363"){$OSshortVer="201619H2"}	# Windows 10 19H2
	if("$SdpOSbuild" -match "10.0.19041"){$OSshortVer="20162004"} 	# Windows 10 2004 2020 April 2020 Update
	if("$SdpOSbuild" -match "10.0.19042"){$OSshortVer="201620H2"} 	# Windows 10 20H2 October 2020 Update
	if("$SdpOSbuild" -match "10.0.19043"){$OSshortVer="201621H1"} 	# Windows 10 21H1 April 2021 Update
	if("$SdpOSbuild" -match "10.0.19044"){$OSshortVer="201621H2"} 	# Windows 10 21H2 Oct 2021 Update
	if("$SdpOSbuild" -match "10.0.19045"){$OSshortVer="201622H2"} 	# Windows 10 22H2 Oct 2022 Update
	if("$SdpOSbuild" -match "10.0.20348"){$OSshortVer="2022"} 		# Windows Srv 2022
	if("$SdpOSbuild" -match "10.0.22000"){$OSshortVer="Win11"} 		# Windows 11
	if("$SdpOSbuild" -match "10.0.22621"){$OSshortVer="Win1122H2"}	# Windows 11 22H2 Oct 2022 Update
	Write-Host " OS build: $SdpOSbuild -|OS: $OSshortVer $OSshortVer_old"
	Write-Host " SDP Date:         $($script:SDPdate) / OS-Version: $($OSshortVer) $($OSshortVer_old)" #Write-Verbose
	Write-Host " SDP ComputerName: $SdpComputerName |Build: $SdpOSbuild |OS: $SdpOSname"
	
	$OSshortVer	# return
	RflEndFunc ($MyInvocation.MyCommand.Name + "(OS build: $SdpOSbuild - $OSVersion $OSVersion_old)")
}

#endregion RFL functions

Export-ModuleMember -Function * -Cmdlet * -Variable * -Alias *


