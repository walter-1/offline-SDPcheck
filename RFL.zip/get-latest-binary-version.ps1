# Name: get-latest-binary-version.ps1
<# Script to find latest binary version in released OS
Help: get-help \\emeacssdfs\netpod\rfl\get-latest-binary-version.ps1 -detailed
last edit by: waltere 2023-04-15
File Name: get-latest-binary-version.ps1

VERSION and AUTHORs:
    Ver 1.00 - 23.09.2016
	Walter Eder	- waltere@microsoft.com

### show Events from all providers (data in Eventlog folder) in a specifix time-range

HISTORY
	2016-09-23 v1.00
	2016-10-01 v1.01 better wildcard search
	2016-10-01 v1.02 allow multiple Binaries in Search
	2016-10-15 v1.03 correct csv Delimiter in import-csv for 208R2,2012* rollup KBs; correct Cnt: for single binaries
		Note: monthly Rollup csv files for 2012 and 2012R2 have two Space delimiter, need to globally replace ' ' with ' ' in Text-Editor first
	2017-10-06 v1.04 adding 2016RS3
	2018-04-05 adding 2016RS4
#>

<#
.SYNOPSIS
File Name: get-latest-binary-version.ps1
The script helps to find latest x64 binary version in released OS updates, where optional parameter2 OSversion can be [2008|2008R2|2012|2012R2|2016|2016RS1|2016RS2|2016RS3|2016RS4|2016RS5|201619H1|201619H2|20162004|201620H2|201621H1|201621H2|201622H2|2022|Win11|Win1122H2|Win1123H1|all]
The abbreviations stand for Server OS or corresponding Client OS (Vista, Windows 7, Windows 8.1, Windows 10 1507 RTM /1511 /1607 Anniversary Update.
For non-RFL fixes, please use optional parameter3 'Rollup'.
Older lookup tools on: http://silverseekkb.cloudapp.net/ and http://HotfixSearch/ are outdated.
For complete list of fixes, please see also Search or Advanced Search on http://WinSEqfe/
2018-12: New binary Search: http://aka.ms/trackitbinarysearch

.DESCRIPTION
This script helps to find latest binary version in released OS (listed in RFL or latest update rollup KBs), including usage of wildcards or regular expression, i.e. '*.sys'
Output file versions correspond to
Version Prefix	| Operating system Srv	| Client
6.0.6002.*		| Windows Server 2008 	| Windows Vista
6.1.7601.*		| Windows Server 2008-R2| Windows 7
6.2.9200.*		| Windows Server 2012	| Windows 8
6.3.9600.*		| Windows Server 2012-R2| Windows 8.1
6.2.10240.*		| Windows Server 2016	| Windows 10 RTM
6.2.10586.*		| Windows Server 2016TH2| Windows 10 Version 1511 TH2
6.2.14393.*		| Windows Server 2016RS1| Windows 10 Version 1607 Anniversary Update
6.2.17763.*		| Windows Server 2016RS5| Windows 10 Version 1809 October 2018 Update
6.2.18363.*		| Windows Server 201619H2| Windows 10 1909 19H2 October 2019 Update
6.2.19041.*		| Windows Server 20162004| Windows 10 2004 2020 April 2020 Update
6.2.19042.*		| Windows Server 201620H2| Windows 10 20H2 October 2020 Update
6.2.19043.*		| Windows Server 201621H1| Windows 10 21H1 April 2020 Update
6.2.19044.*		| Windows Server 201621H2| Windows 10 21H2 October 2021 Update
6.2.19045.*		| Windows Server 201622H2| Windows 10 22H2 October 2022 Update
6.2.20348.*		| Windows Server 2022| Windows Srv2022
6.2.20349.*		| Windows Server 2022| Windows Srv2022AZ HCI
6.2.22000.*		| Windows 11 
6.2.22621.*		| Windows 11		| Windows 11 22H1 May 2022 Update

.EXAMPLE
Usage:
Example 1, find a specific x64 binary in [all] Operating Systems
\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\get-latest-binary-version.ps1 [binary-name.ext] [OSversion] [RFL|Rollup]

Example 2, find all latest binaries for OS Windows 8.1 or Server 2012-R2 in RFL
\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\get-latest-binary-version.ps1 *.* 2012R2

Example 3, find multiple binaries by name, comma separated list, for OS Windows 8.1 or Server 2012-R2 in RFL
\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\get-latest-binary-version.ps1 srv2.sys,mrxsmb2 2012R2

Example 4, find all latest '*.sys' binaries for OS Windows 8.1 or Server 2012-R2 in latest Update Rollup KB
\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\get-latest-binary-version.ps1 *.sys 2012R2 Rollup

.LINK
email: waltere@microsoft.com
#>

[CmdletBinding()]
PARAM (
	#[ValidateSet("binary.dll","binary*",".*")]
	[Parameter(Mandatory=$True,Position=0,HelpMessage='Input binary name or part of name or regular expression, i.e. srv*.*')]
	[string[]]$BinSearchList
,
	[ValidateSet("2008","2008R2","2012","2012R2","2016","2016RS1","2016RS2","2016RS3","2016RS4","2016RS5","201619H1","201619H2","20162004","201620H2","201621H1","201621H2","201622H2","2022","Win11","Win1122H2","Win1123H1","all")]
	[Parameter(Mandatory=$False,Position=1,HelpMessage='optional: Choose one OS from list: [2008|2008R2|2012|2012R2|2016|2016RS1|2016RS2|2016RS3|2016RS4|2016RS5|201619H1|201619H2|20162004|201620H2|201621H1|201621H2|201622H2|2022|Win11|Win1122H2|Win1123H1|all]')]
	[string[]]$OSshortList = "all"
,
	[ValidateSet("RFL","Rollup")]
	[Parameter(Mandatory=$False,Position=2,HelpMessage='Want to search in downloaded latest update rollup csv [RFL|Rollup]')]
	[string]$RollupSearch = "RFL"
	)

$UsrOSVersion = [Environment]::OSVersion.Version.ToString(3)
$CheckDate = (Get-Date).ToUniversalTime().ToString("yy-MM-dd_HH-mm-ss")

#region: ###### customization section of script, logging configuration ########################
	$verDateScript = "2023.04.15.0"
	$ScriptFolder = Split-Path $MyInvocation.MyCommand.Path -Parent
	$SDPcheckINI = (Get-content -Path "$ScriptFolder\_SDPcheck.ini")
	$InOfflineMode 	= (($SDPcheckINI[1] -split " ")[2]).trim("""")	# set $True for outsourcer or when not connected to MS network - offline-SDPcheck
	$RFLroot = (($SDPcheckINI[2] -split " ")[2]).trim("""")	# "\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\" -or- "\\localhost\ToolsShare\rfl\"
	if ($InOfflineMode -match "False") {
			$StatsServer = (($SDPcheckINI[5] -split " ")[2]).trim("""")
			if (Test-Connection -ComputerName $StatsServer -Quiet -Count 1) {[bool]$Stats=$True} else {[bool]$Stats=$False}
	} else { 
		$Stats = $False
	}
	$RFLdbRoot = $RFLroot + "\RflLists"
#endregion: ###### customization section

if ($Stats) {
	$StatsServerPath="\\$StatsServer\RFLstats$\RFL\scripts\Stats\"
	$CountInvFil 		= $StatsServerPath +'count_getVer.dat'
	$CountInvFil2 		= $CountInvFil +'.us'
}


$start = Get-Date

 Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force
 Unblock-File -Path $RFLroot\get-latest-binary-version.ps1 -ErrorAction SilentlyContinue
 Write-Verbose "in case you see any red error messages regarding signing, open an Admin Powershell CMD and run this command first:
 	 Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force

 	 "

### Enable parameter 'all' for user input (Tech and OS)
if ($OSshortList -ieq 'all'){
	[string[]]$OSshortList = "2008","2008R2","2012","2012R2","2016","2016RS1","2016RS2","2016RS3","2016RS4","2016RS5","201619H1","201619H2","20162004","201620H2","201621H1","201621H2","201622H2","2022","Win11","Win1122H2","Win1123H1"
	"`n__OS: $OSshortList / Find: '$BinSearchList' in [RFL|Rollup] = $RollupSearch"
	}
else {"`n__OS [2008|2008R2|2012|2012R2|2016|2016RS1|2016RS2|2016RS3|2016RS4|2016RS5|201619H1|201619H2|20162004|201620H2|201621H1|201621H2|201622H2|2022|Win11|Win1122H2|Win1123H1] = $OSshortList / Find: '$BinSearchList' in [RFL|Rollup] = $RollupSearch"}

### walk through each OS in inputlist
$CntAll = 0
foreach ($OSshort in $OSshortList){
### walk through each binary in $BinSearchList
foreach ($BinSearch in $BinSearchList){
	#if ($BinSearch.StartsWith("*")) { [regex] $BinSearch = '.' +$BinSearch } ## included for regex search
	if ($BinSearch.Contains("*")){ $BinSearch = $BinSearch.Replace("*",".*") }
	Write-verbose "...Found in $OSshort"
	$DBfileName = $RFLdbRoot +"\ref__Master_"+ $OSshort +"_latest.csv"
	### Search in Rollup KB
	if ($RollupSearch -ieq 'Rollup') {
		if (($OSshort -match '2016') -or ($OSshort -match '2012') -or ($OSshort -match '2008R2')) {
			### Extracting KB and Title from current KBOnlyRollup_*.csv
			$KBOnlyRollupFileName	= $RFLdbRoot + '\KBOnlyRollup_' +$OSshort+ '.csv'
			Write-Verbose "... looking up cumulative KB-nr and Title in last line of file $KBOnlyRollupFileName "
			$KBOnlyRollupFile = Import-Csv -Path $KBOnlyRollupFileName -Header Binary,Component,Version,Prio,Published,Branch,Article,Title,Link,LDROnlyKB,LDROnlyTitle,LDROnlyLink,Comment,RollupInfo | Select-Object -last 1
			$CumKB 	= $($KBOnlyRollupFile.Binary) 	#$CumKB 	= "3124266"
			$CumKBTitle = $($KBOnlyRollupFile.Title)
			Write-Host "... looking up '$BinSearch' version in KB $CumKB $CumKBTitle"
			$DBfileName = $RFLdbRoot+ "\" +$OSshort+ "*" +$CumKB+ ".csv"
			Write-Host "... $OSshort _Fetch 'x64 Windows $OSshort' - $DBfileName"
			if ($OSshort -match '2016') {
				#Format 2016: 		File name,File version,File size,Date,Time,Platform,SP requirement,Service branch,
			    $DBfile = import-csv -Path $DBfileName -Header "Binary","Version","size","Published","Time","Platform","SP_requirement","Service branch"}
			if (($OSshort -match '2012') -or ($OSshort -match '2008R2')) {
				#Format 2008R2: 	File_name File_version File_size Date Time Platform SP_requirement Service_branch
			    $DBfile = import-csv -Delimiter ' ' -Path $DBfileName -Header "Binary","Version","size","Published","Time","Platform","SP_requirement","Service branch"}
			$Result = $DBfile |?{(($_.Binary -match $BinSearch) -and ($_.Binary.Contains(".")) -and ($_.Version -Notmatch 'Not applicable') -and ($_.Platform.Contains("x64")))} | Select-Object Binary,Version,Published,Platform | Sort-Object -Unique Binary #| Format-Table -auto
			#(import-csv -Path $DBfileName -Header "Binary","Version","size","Published","Time","Platform","SP_requirement","Service branch") |?{($_.Binary -match $BinSearch) -and ($_.Version -Notmatch 'Not applicable')} | Select-Object Binary,Version,Published | Sort-Object -Unique Binary | Format-Table -auto
			Write-verbose "...Searching in $DBfileName"
			}
		else { Write-host "..sorry, no Update Rollup fixes for this OS $OSshort"
		 	Write-host "..using DBfileName: $DBfileName"}
	}
 	### Search in RFL database
 	else {$Result =(import-csv $DBfileName ) |?{$_.Binary -match $BinSearch} | Select-Object Binary,Version,Published,Component,Branch,RollupInfo,Article,Title | Sort-Object -Unique Binary #}# | Format-Table -auto
 		#$ResM1=$Result|measure; $Cnt = $($ResM1.count); Write-Host "$OSshort Cnt: $Cnt"
 	   }
	if ($Result) { #$Cnt = $($Result.count); Write-Host "$OSshort Cnt: $($Result.count)"}
			$ResM1=$Result|measure; $Cnt = $($ResM1.count); Write-Host "$OSshort Cnt: $Cnt"
			}
	else {$Cnt = 0; Write-Host "$OSshort $Cnt results; you may try Advanced Search on http://WinSEqfe/" }
	$Result | Format-Table -auto
	$CntAll = $CntAll+$Cnt
} #end of loop: # walk through each binary in $BinSearchList
} #end of loop: # walk through each OS in inputlist

#set-location -path $CurrentPath
Write-Verbose "... done."

$end = Get-Date
$Duration = $end - $start
Write-Host -BackgroundColor Gray -ForegroundColor Black -Object "$(Get-Date -UFormat "%R") Found $CntAll '$($BinSearchList)' in '$OSshortList'; script version v$verDateScript  took $($Duration)"

### Stats
If ($Stats) {
 ($j=[int32](Get-Content $CountInvFil -TotalCount 1)) |Out-Null
 Try {(++$j) | Set-Content $CountInvFil -ErrorAction SilentlyContinue} Catch { }
 Try {([string]$j + "; $CheckDate; $UsrOSVersion; " + [System.Security.Principal.WindowsIdentity]::GetCurrent().Name) + "; $($Duration)" + "; $BinSearchList; $OSshortList; $RollupSearch; $CntAll;" | Out-File $CountInvFil2 -Append -Encoding UTF8} Catch { }
 }


# SIG # Begin signature block
# MIInlQYJKoZIhvcNAQcCoIInhjCCJ4ICAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDLSK1xB5r6QdEW
# isMzBB7MsPcuvmbXRALpkKAEG726u6CCDXYwggX0MIID3KADAgECAhMzAAADTrU8
# esGEb+srAAAAAANOMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjMwMzE2MTg0MzI5WhcNMjQwMzE0MTg0MzI5WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDdCKiNI6IBFWuvJUmf6WdOJqZmIwYs5G7AJD5UbcL6tsC+EBPDbr36pFGo1bsU
# p53nRyFYnncoMg8FK0d8jLlw0lgexDDr7gicf2zOBFWqfv/nSLwzJFNP5W03DF/1
# 1oZ12rSFqGlm+O46cRjTDFBpMRCZZGddZlRBjivby0eI1VgTD1TvAdfBYQe82fhm
# WQkYR/lWmAK+vW/1+bO7jHaxXTNCxLIBW07F8PBjUcwFxxyfbe2mHB4h1L4U0Ofa
# +HX/aREQ7SqYZz59sXM2ySOfvYyIjnqSO80NGBaz5DvzIG88J0+BNhOu2jl6Dfcq
# jYQs1H/PMSQIK6E7lXDXSpXzAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUnMc7Zn/ukKBsBiWkwdNfsN5pdwAw
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzUwMDUxNjAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAD21v9pHoLdBSNlFAjmk
# mx4XxOZAPsVxxXbDyQv1+kGDe9XpgBnT1lXnx7JDpFMKBwAyIwdInmvhK9pGBa31
# TyeL3p7R2s0L8SABPPRJHAEk4NHpBXxHjm4TKjezAbSqqbgsy10Y7KApy+9UrKa2
# kGmsuASsk95PVm5vem7OmTs42vm0BJUU+JPQLg8Y/sdj3TtSfLYYZAaJwTAIgi7d
# hzn5hatLo7Dhz+4T+MrFd+6LUa2U3zr97QwzDthx+RP9/RZnur4inzSQsG5DCVIM
# pA1l2NWEA3KAca0tI2l6hQNYsaKL1kefdfHCrPxEry8onJjyGGv9YKoLv6AOO7Oh
# JEmbQlz/xksYG2N/JSOJ+QqYpGTEuYFYVWain7He6jgb41JbpOGKDdE/b+V2q/gX
# UgFe2gdwTpCDsvh8SMRoq1/BNXcr7iTAU38Vgr83iVtPYmFhZOVM0ULp/kKTVoir
# IpP2KCxT4OekOctt8grYnhJ16QMjmMv5o53hjNFXOxigkQWYzUO+6w50g0FAeFa8
# 5ugCCB6lXEk21FFB1FdIHpjSQf+LP/W2OV/HfhC3uTPgKbRtXo83TZYEudooyZ/A
# Vu08sibZ3MkGOJORLERNwKm2G7oqdOv4Qj8Z0JrGgMzj46NFKAxkLSpE5oHQYP1H
# tPx1lPfD7iNSbJsP6LiUHXH1MIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGXUwghlxAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAANOtTx6wYRv6ysAAAAAA04wDQYJYIZIAWUDBAIB
# BQCggbAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIDPGQ+3qXDtH5Jswqm0ui0g+
# Dt8V0NZA6/hu/6HogwKcMEQGCisGAQQBgjcCAQwxNjA0oBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEcgBpodHRwczovL3d3dy5taWNyb3NvZnQuY29tIDANBgkqhkiG9w0B
# AQEFAASCAQCZYdn9hIWNrd137X7kutHS8m5qzt2Nk9EmkhFEbmnZOw3Ps+BEN5eG
# 2b0GCivqEseaH8eFYPmGW5sPba824+FNFRKYNLN3QelIWk3wieekyKdeZj77KM6o
# baAVyPkhNC6CTVVNREC43y0w2h22I095ASVBMfdi+aN5qoeWGBk1CaETHq270prZ
# SUQ+vuFm0ONn3B09pN+k0kdrUsNmZQ7Gh46sRYD8fSHJ5XCazicVCnrmygQscSuh
# BGkXadlyvK+7b8E4bbfM0KKb/0qs46li7xXhuoLrmdlOQlgzJRc/m5T3y2gVdPAo
# GqpeKmqk+J8grrRYTqH5dg6QnEFhgUSyoYIW/TCCFvkGCisGAQQBgjcDAwExghbp
# MIIW5QYJKoZIhvcNAQcCoIIW1jCCFtICAQMxDzANBglghkgBZQMEAgEFADCCAVEG
# CyqGSIb3DQEJEAEEoIIBQASCATwwggE4AgEBBgorBgEEAYRZCgMBMDEwDQYJYIZI
# AWUDBAIBBQAEICG8EZs5oA1nlJ9kDuiCuPWvCd+Sx+kzRY3nskaLnJzyAgZkbNi4
# cXgYEzIwMjMwNjA1MTgyNTQwLjk4N1owBIACAfSggdCkgc0wgcoxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBB
# bWVyaWNhIE9wZXJhdGlvbnMxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjIyNjQt
# RTMzRS03ODBDMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNl
# oIIRVDCCBwwwggT0oAMCAQICEzMAAAHBPqCDnOAJr8UAAQAAAcEwDQYJKoZIhvcN
# AQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQG
# A1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjIxMTA0MTkw
# MTI3WhcNMjQwMjAyMTkwMTI3WjCByjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldh
# c2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBD
# b3Jwb3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0aW9u
# czEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046MjI2NC1FMzNFLTc4MEMxJTAjBgNV
# BAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQDksdczJ3DaFQLiklTQjm48mcx5GbwsoLjFogO7cXHH
# ciln9Z7apcuPg06ajD9Y8V5ji9pPj9LhP3GgOwUaDnAQkzo4tlV9rsFQ27S0O3iu
# SXtAFg0fPPqlyv1vBqraqbvHo/3KLlbRjyyOiP5BOC2aZejEKg1eEnWgboZuoANB
# cNmRNwOMgCK14TpPGuEGkhvt7q6mJ9MZk19wKE9+7MerrUVIjAnRcLFxpHUHACVI
# qFv81Q65AY+v1nN3o6chwD5Fy3HAqB84oH1pYQQeW3SOEoqCkQG9wmcww/5ZpPCY
# yGhvV76GgIQXH+cjRge6mLrTzaQV00WtoTvaaw5hCvCtTJYJ5KY3bTYtkOlPPFlW
# 3LpCsE6T5/4ESuxH4zl6+Qq5RNZUkcje+02Bvorn6CToS5DDShywN2ymI+n6qXEF
# pbnTJRuvrCd/NiMmHtCQ9x8EhlskCFZAdpXS5LdPs6Q5t0KywJExYftVZQB5Jt6a
# 5So5cJHut2kVN9j9Jco72UIhAEBBKH7DPCHlm/Vv6NPbNbBWXzYHLdgeZJPxvwIq
# dFdIKMu2CjLLsREvCRvM8iQJ8FdzJWd4LXDb/BSeo+ICMrTBB/O19cV+gxCvxhRw
# secC16Tw5U0+5EhXptwRFsXqu0VeaeOMPhnBXEhn8czhyN5UawTCQUD1dPOpf1bU
# /wIDAQABo4IBNjCCATIwHQYDVR0OBBYEFF+vYwnrHvIT6A/m5f3FYZPClEL6MB8G
# A1UdIwQYMBaAFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMF8GA1UdHwRYMFYwVKBSoFCG
# Tmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY3Jvc29mdCUy
# MFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEpLmNybDBsBggrBgEFBQcBAQRgMF4w
# XAYIKwYBBQUHMAKGUGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY2Vy
# dHMvTWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3J0MAwG
# A1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZIhvcNAQELBQAD
# ggIBAF+6JoGCx5we8z3RFmJMOV8duUvT2v1f7mr1yS4xHQGzVKvkHYwAuFPljRHe
# CAu59FfpFBBtJztbFFcgyvm0USAHnPL/tiDzUKfZ2FN/UbOMJvv+ffC0lIa2vZDA
# exrV6FhZ0x+L4RMugRfUbv1U8WuzS3oaLCmvvi2/4IsTezqbXRU7B7zTA/jK5Pd6
# IV+pFXymhQVJ0vbByWBAqhLBsKlsmU0L8RJoNBttAWWL247mPZ/8btLhMwb+DLLG
# 8xDlAm6L0XDazuqSWajNChfYCHhoq5sp739Vm96IRM1iXUBk+PSSPWDnVU3JaO8f
# D4fPXFl6RYil8xdASLTCsZ1Z6JbiLyX3atjdlt0ewSsVirOHoVEU55eBrM2x+Qub
# DL5MrXuYDsJMRTNoBYyrn5/0rhj/eaEHivpSuKy2Ral2Q9YSjxv21uR0pJjTQT4V
# LkNS2OAB0JpEE1oG7xwVgJsSuH2uhYPFz4iy/zIxABQO4TBdLLQTGcgCVxUiuHMv
# jQ6wbZxrlHkGAB68Y/UeP16PiX/L5KHQdVw303ouY8OYj8xpTasRntj6NF8JnV36
# XkMRJ0tcjENPKxheRP7dUz/XOHrLazRmxv/e89oaenbN6PB/ZiUZaXVekKE1lN6U
# Xl44IJ9LNRSfeod7sjLIMqFqGBucqmbBwSQxUGz5EdtWQ1aoMIIHcTCCBVmgAwIB
# AgITMwAAABXF52ueAptJmQAAAAAAFTANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0
# IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTAwHhcNMjEwOTMwMTgyMjI1
# WhcNMzAwOTMwMTgzMjI1WjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGlu
# Z3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBv
# cmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCC
# AiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAOThpkzntHIhC3miy9ckeb0O
# 1YLT/e6cBwfSqWxOdcjKNVf2AX9sSuDivbk+F2Az/1xPx2b3lVNxWuJ+Slr+uDZn
# hUYjDLWNE893MsAQGOhgfWpSg0S3po5GawcU88V29YZQ3MFEyHFcUTE3oAo4bo3t
# 1w/YJlN8OWECesSq/XJprx2rrPY2vjUmZNqYO7oaezOtgFt+jBAcnVL+tuhiJdxq
# D89d9P6OU8/W7IVWTe/dvI2k45GPsjksUZzpcGkNyjYtcI4xyDUoveO0hyTD4MmP
# frVUj9z6BVWYbWg7mka97aSueik3rMvrg0XnRm7KMtXAhjBcTyziYrLNueKNiOSW
# rAFKu75xqRdbZ2De+JKRHh09/SDPc31BmkZ1zcRfNN0Sidb9pSB9fvzZnkXftnIv
# 231fgLrbqn427DZM9ituqBJR6L8FA6PRc6ZNN3SUHDSCD/AQ8rdHGO2n6Jl8P0zb
# r17C89XYcz1DTsEzOUyOArxCaC4Q6oRRRuLRvWoYWmEBc8pnol7XKHYC4jMYcten
# IPDC+hIK12NvDMk2ZItboKaDIV1fMHSRlJTYuVD5C4lh8zYGNRiER9vcG9H9stQc
# xWv2XFJRXRLbJbqvUAV6bMURHXLvjflSxIUXk8A8FdsaN8cIFRg/eKtFtvUeh17a
# j54WcmnGrnu3tz5q4i6tAgMBAAGjggHdMIIB2TASBgkrBgEEAYI3FQEEBQIDAQAB
# MCMGCSsGAQQBgjcVAgQWBBQqp1L+ZMSavoKRPEY1Kc8Q/y8E7jAdBgNVHQ4EFgQU
# n6cVXQBeYl2D9OXSZacbUzUZ6XIwXAYDVR0gBFUwUzBRBgwrBgEEAYI3TIN9AQEw
# QTA/BggrBgEFBQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9E
# b2NzL1JlcG9zaXRvcnkuaHRtMBMGA1UdJQQMMAoGCCsGAQUFBwMIMBkGCSsGAQQB
# gjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/
# MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1UdHwRPME0wS6BJ
# oEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01p
# Y1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYB
# BQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljUm9v
# Q2VyQXV0XzIwMTAtMDYtMjMuY3J0MA0GCSqGSIb3DQEBCwUAA4ICAQCdVX38Kq3h
# LB9nATEkW+Geckv8qW/qXBS2Pk5HZHixBpOXPTEztTnXwnE2P9pkbHzQdTltuw8x
# 5MKP+2zRoZQYIu7pZmc6U03dmLq2HnjYNi6cqYJWAAOwBb6J6Gngugnue99qb74p
# y27YP0h1AdkY3m2CDPVtI1TkeFN1JFe53Z/zjj3G82jfZfakVqr3lbYoVSfQJL1A
# oL8ZthISEV09J+BAljis9/kpicO8F7BUhUKz/AyeixmJ5/ALaoHCgRlCGVJ1ijbC
# HcNhcy4sa3tuPywJeBTpkbKpW99Jo3QMvOyRgNI95ko+ZjtPu4b6MhrZlvSP9pEB
# 9s7GdP32THJvEKt1MMU0sHrYUP4KWN1APMdUbZ1jdEgssU5HLcEUBHG/ZPkkvnNt
# yo4JvbMBV0lUZNlz138eW0QBjloZkWsNn6Qo3GcZKCS6OEuabvshVGtqRRFHqfG3
# rsjoiV5PndLQTHa1V1QJsWkBRH58oWFsc/4Ku+xBZj1p/cvBQUl+fpO+y/g75LcV
# v7TOPqUxUYS8vwLBgqJ7Fx0ViY1w/ue10CgaiQuPNtq6TPmb/wrpNPgkNWcr4A24
# 5oyZ1uEi6vAnQj0llOZ0dFtq0Z4+7X6gMTN9vMvpe784cETRkPHIqzqKOghif9lw
# Y1NNje6CbaUFEMFxBmoQtB1VM1izoXBm8qGCAsswggI0AgEBMIH4oYHQpIHNMIHK
# MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQLExxN
# aWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25zMSYwJAYDVQQLEx1UaGFsZXMgVFNT
# IEVTTjoyMjY0LUUzM0UtNzgwQzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3Rh
# bXAgU2VydmljZaIjCgEBMAcGBSsOAwIaAxUARIo61IrtFVUr5KL5qoV3RhJj5U+g
# gYMwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYw
# JAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0B
# AQUFAAIFAOgoek0wIhgPMjAyMzA2MDUyMzE0MjFaGA8yMDIzMDYwNjIzMTQyMVow
# dDA6BgorBgEEAYRZCgQBMSwwKjAKAgUA6Ch6TQIBADAHAgEAAgIQnjAHAgEAAgIR
# yDAKAgUA6CnLzQIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAow
# CAIBAAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBACoc29M/C2EK
# agwUOuCCyQLVTaOvjbOB37p0pf0uvILAaZheqIfmOdA88a/DCXgpszrhPGJmIlGz
# ZZkZVJOXexLQ2TL5DCg0zwZaRNIBOccIgbnIVfoaRG05KGsqHDBobc60EUgLIBiW
# YHzaMyaAB4w74ly/z9uQcp8+abyqNxzDMYIEDTCCBAkCAQEwgZMwfDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAHBPqCDnOAJr8UAAQAAAcEwDQYJYIZI
# AWUDBAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG
# 9w0BCQQxIgQgXe9/uyAEO2x4iNlxPq5t6q7keQEL3/JAu1JuGUGPh7swgfoGCyqG
# SIb3DQEJEAIvMYHqMIHnMIHkMIG9BCAKuSDq2Bgd5KAiw3eilHbPsQTFYDRiSKuS
# 9VhJMGB21DCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMz
# AAABwT6gg5zgCa/FAAEAAAHBMCIEIOJvRHrCtF07jvvABQZhhmOnDvQHRgRB16xn
# mEWE3bvkMA0GCSqGSIb3DQEBCwUABIICABr6NhOdC+eT4DG/iJBk+sFueOQTLsDp
# 5du9WCpQz66uMJbAQK2YwgeIpU46NtAfITkdCJLzXd7mi0w5ZS7ATZg4BK/QKL5I
# 9rFZ2WrZa9Zn1Gv3VoEBkVS3wubbtgbR6D2wXgIhteKEMMgxPk1JcbDTGvtctQL0
# KgiAFakOsRv1d2s+9lTWAUCswGPG9jVjnCnAZqk256VfAteCUhTlfhpnsL9AuY22
# wCTvYZmNocvgqeZVCFfrsv+gYf5Plrh2IwKtOOqFG9je8al99CgszTwmZSYxpkiM
# wZwqMdEIQelObsGkFmEEQ6ASSGVQQzsldDi1S0U4FlGeAQmIfVClmj8fDkLOkN89
# zJNVSJKJsbD+F60D9/J1dv2Y1VzOEMPqcv2CEnNMF2he2mjwbYy/zrPFghgFTOWk
# 5To0iKkHeCatOQQW5HAckdNWbyfpPihsbxdSRFlBXFKl8GRBRQVd+K+X2UUSopoL
# aZQm06tGKsN5ibsg/F9wEvndk0g+q10yZqDIlBlfa1eXG1TTBuJI5N8wL+bgQkDb
# 3USMZaun0fHPLdNiTA2K65ljBGepdfa7I5k40jZukFiI4BNASGXo4qscZpORVpCh
# z5Q2JhDarH2skkTBzP+HwJXEVxr9k8Xj9dVK8J57B27WGMiS3lCZdSB61uKwA21I
# Y6xQOG3jl8Z9
# SIG # End signature block
