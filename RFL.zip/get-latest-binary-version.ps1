# Name: get-latest-binary-version.ps1
<# Script to find latest binary version in released OS
Help: get-help \\emeacssdfs\netpod\rfl\get-latest-binary-version.ps1 -detailed
last edit by: waltere 2022-10-13
File Name: get-latest-binary-version.ps1

VERSION and AUTHORs:
    Ver 1.00 - 23.09.2016
	Walter Eder	- waltere@microsoft.com

### show Events from all providers (data in Eventlog folder) in a specifix time-range

HISTORY
	2016-09-23 v1.00
	2016-10-01 v1.01 better wildcard search
	2016-10-01 v1.02 allow multiple Binaries in Search
	2016-10-15 v1.03 correct csv Delimiter in import-csv for 208R2,2012* rollup KBs; correct Cnt: for single binaries
		Note: monthly Rollup csv files for 2012 and 2012R2 have two Space delimiter, need to globally replace ' ' with ' ' in Text-Editor first
	2017-10-06 v1.04 adding 2016RS3
	2018-04-05 adding 2016RS4
#>

<#
.SYNOPSIS
File Name: get-latest-binary-version.ps1
The script helps to find latest x64 binary version in released OS updates, where optional parameter2 OSversion can be [2008|2008R2|2012|2012R2|2016|2016RS1|2016RS2|2016RS3|2016RS4|2016RS5|201619H1|201619H2|20162004|201620H2|201621H1|201621H2|201622H2|2022|Win11|Win1122H2|all]
The abbreviations stand for Server OS or corresponding Client OS (Vista, Windows 7, Windows 8.1, Windows 10 1507 RTM /1511 /1607 Anniversary Update.
For non-RFL fixes, please use optional parameter3 'Rollup'.
Older lookup tools on: http://silverseekkb.cloudapp.net/ and http://HotfixSearch/ are outdated.
For complete list of fixes, please see also Search or Advanced Search on http://WinSEqfe/
2018-12: New binary Search: http://aka.ms/trackitbinarysearch

.DESCRIPTION
This script helps to find latest binary version in released OS (listed in RFL or latest update rollup KBs), including usage of wildcards or regular expression, i.e. '*.sys'
Output file versions correspond to
Version Prefix	| Operating system Srv	| Client
6.0.6002.*		| Windows Server 2008 	| Windows Vista
6.1.7601.*		| Windows Server 2008-R2| Windows 7
6.2.9200.*		| Windows Server 2012	| Windows 8
6.3.9600.*		| Windows Server 2012-R2| Windows 8.1
6.2.10240.*		| Windows Server 2016	| Windows 10 RTM
6.2.10586.*		| Windows Server 2016TH2| Windows 10 Version 1511 TH2
6.2.14393.*		| Windows Server 2016RS1| Windows 10 Version 1607 Anniversary Update
6.2.17763.*		| Windows Server 2016RS5| Windows 10 Version 1809 October 2018 Update
6.2.18363.*		| Windows Server 201619H2| Windows 10 1909 19H2 October 2019 Update
6.2.19041.*		| Windows Server 20162004| Windows 10 2004 2020 April 2020 Update
6.2.19042.*		| Windows Server 201620H2| Windows 10 20H2 October 2020 Update
6.2.19043.*		| Windows Server 201621H1| Windows 10 21H1 April 2020 Update
6.2.19044.*		| Windows Server 201621H2| Windows 10 21H2 October 2021 Update
6.2.19045.*		| Windows Server 201622H2| Windows 10 22H2 October 2022 Update
6.2.20348.*		| Windows Server 2022| Windows Srv2022
6.2.22000.*		| Windows 11 
6.2.22621.*		| Windows 11		| Windows 11 22H1 May 2022 Update

.EXAMPLE
Usage:
Example 1, find a specific x64 binary in [all] Operating Systems
\\emeacssdfs.europe.corp.microsoft.com\netpod\rfl\get-latest-binary-version.ps1 [binary-name.ext] [OSversion] [RFL|Rollup]

Example 2, find all latest binaries for OS Windows 8.1 or Server 2012-R2 in RFL
\\emeacssdfs.europe.corp.microsoft.com\netpod\rfl\get-latest-binary-version.ps1 *.* 2012R2

Example 3, find multiple binaries by name, comma separated list, for OS Windows 8.1 or Server 2012-R2 in RFL
\\emeacssdfs.europe.corp.microsoft.com\netpod\rfl\get-latest-binary-version.ps1 srv2.sys,mrxsmb2 2012R2

Example 4, find all latest '*.sys' binaries for OS Windows 8.1 or Server 2012-R2 in latest Update Rollup KB
\\emeacssdfs.europe.corp.microsoft.com\netpod\rfl\get-latest-binary-version.ps1 *.sys 2012R2 Rollup

.LINK
email: waltere@microsoft.com
#>

Param(
	#[ValidateSet("binary.dll","binary*",".*")]
	[Parameter(Mandatory=$True,Position=0,HelpMessage='Input binary name or part of name or regular expression, i.e. srv*.*')]
	[string[]]$BinSearchList
,
	[ValidateSet("2008","2008R2","2012","2012R2","2016","2016RS1","2016RS2","2016RS3","2016RS4","2016RS5","201619H1","201619H2","20162004","201620H2","201621H1","201621H2","201622H2","2022","Win11","Win1122H2","all")]
	[Parameter(Mandatory=$False,Position=1,HelpMessage='optional: Choose one OS from list: [2008|2008R2|2012|2012R2|2016|2016RS1|2016RS2|2016RS3|2016RS4|2016RS5|201619H1|201619H2|20162004|201620H2|201621H1|201621H2|201622H2|2022|Win11|Win1122H2|all]')]
	[string[]]$OSshortList = "all"
,
	[ValidateSet("RFL","Rollup")]
	[Parameter(Mandatory=$False,Position=2,HelpMessage='Want to search in downloaded latest update rollup csv [RFL|Rollup]')]
	[string]$RollupSearch = "RFL"
	)

$UsrOSVersion = [Environment]::OSVersion.Version.ToString(3)
$CheckDate = (Get-Date).ToUniversalTime().ToString("yy-MM-dd_HH-mm-ss")

#region: ###### customization section of script, logging configuration ########################
	$ScriptFolder = Split-Path $MyInvocation.MyCommand.Path -Parent
	$SDPcheckINI = (Get-content -Path "$ScriptFolder\_SDPcheck.ini")
	$InOfflineMode 	= (($SDPcheckINI[1] -split " ")[2]).trim("""")	# set $True for outsourcer or when not connected to MS network - offline-SDPcheck
	$RFLroot = (($SDPcheckINI[2] -split " ")[2]).trim("""")	# "\\emeacssdfs.europe.corp.microsoft.com\netpod\rfl\" -or- "\\localhost\ToolsShare\rfl\"
	if ($InOfflineMode -match "False") {
			$StatsServer = (($SDPcheckINI[4] -split " ")[2]).trim("""")
			if (Test-Connection -ComputerName $StatsServer -Quiet -Count 1) {[bool]$Stats=$True} else {[bool]$Stats=$False}
	} else { 
		$Stats = $False
	}
	$RFLdbRoot = $RFLroot + "\RflLists"
#endregion: ###### customization section

if ($Stats) {
	$StatsServerPath="\\$StatsServer\RFLstats$\RFL\scripts\Stats\"
	$CountInvFil 		= $StatsServerPath +'count_getVer.dat'
	$CountInvFil2 		= $CountInvFil +'.us'
}
$verDateScript = "2022.10.13.0"
$start = Get-Date

 Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force
 Unblock-File -Path $RFLroot\get-latest-binary-version.ps1 -ErrorAction SilentlyContinue
 Write-Verbose "in case you see any red error messages regarding signing, open an Admin Powershell CMD and run this command first:
 	 Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force

 	 "

### Enable parameter 'all' for user input (Tech and OS)
if ($OSshortList -ieq 'all'){
	[string[]]$OSshortList = "2008","2008R2","2012","2012R2","2016","2016RS1","2016RS2","2016RS3","2016RS4","2016RS5","201619H1","201619H2","20162004","201620H2","201621H1","201621H2","201622H2","2022","Win11","Win1122H2"
	"`n__OS: $OSshortList / Find: '$BinSearchList' in [RFL|Rollup] = $RollupSearch"
	}
else {"`n__OS [2008|2008R2|2012|2012R2|2016|2016RS1|2016RS2|2016RS3|2016RS4|2016RS5|201619H1|201619H2|20162004|201620H2|201621H1|201621H2|201622H2|2022|Win11|Win1122H2] = $OSshortList / Find: '$BinSearchList' in [RFL|Rollup] = $RollupSearch"}

### walk through each OS in inputlist
$CntAll = 0
foreach ($OSshort in $OSshortList){
### walk through each binary in $BinSearchList
foreach ($BinSearch in $BinSearchList){
	#if ($BinSearch.StartsWith("*")) { [regex] $BinSearch = '.' +$BinSearch } ## included for regex search
	if ($BinSearch.Contains("*")){ $BinSearch = $BinSearch.Replace("*",".*") }
	Write-verbose "...Found in $OSshort"
	$DBfileName = $RFLdbRoot +"\ref__Master_"+ $OSshort +"_latest.csv"
	### Search in Rollup KB
	if ($RollupSearch -ieq 'Rollup') {
		if (($OSshort -match '2016') -or ($OSshort -match '2012') -or ($OSshort -match '2008R2')) {
			### Extracting KB and Title from current KBOnlyRollup_*.csv
			$KBOnlyRollupFileName	= $RFLdbRoot + '\KBOnlyRollup_' +$OSshort+ '.csv'
			Write-Verbose "... looking up cumulative KB-nr and Title in last line of file $KBOnlyRollupFileName "
			$KBOnlyRollupFile = Import-Csv -Path $KBOnlyRollupFileName -Header Binary,Component,Version,Prio,Published,Branch,Article,Title,Link,LDROnlyKB,LDROnlyTitle,LDROnlyLink,Comment,RollupInfo | Select-Object -last 1
			$CumKB 	= $($KBOnlyRollupFile.Binary) 	#$CumKB 	= "3124266"
			$CumKBTitle = $($KBOnlyRollupFile.Title)
			Write-Host "... looking up '$BinSearch' version in KB $CumKB $CumKBTitle"
			$DBfileName = $RFLdbRoot+ "\" +$OSshort+ "*" +$CumKB+ ".csv"
			Write-Host "... $OSshort _Fetch 'x64 Windows $OSshort' - $DBfileName"
			if ($OSshort -match '2016') {
				#Format 2016: 		File name,File version,File size,Date,Time,Platform,SP requirement,Service branch,
			    $DBfile = import-csv -Path $DBfileName -Header "Binary","Version","size","Published","Time","Platform","SP_requirement","Service branch"}
			if (($OSshort -match '2012') -or ($OSshort -match '2008R2')) {
				#Format 2008R2: 	File_name File_version File_size Date Time Platform SP_requirement Service_branch
			    $DBfile = import-csv -Delimiter ' ' -Path $DBfileName -Header "Binary","Version","size","Published","Time","Platform","SP_requirement","Service branch"}
			$Result = $DBfile |?{(($_.Binary -match $BinSearch) -and ($_.Binary.Contains(".")) -and ($_.Version -Notmatch 'Not applicable') -and ($_.Platform.Contains("x64")))} | Select-Object Binary,Version,Published,Platform | Sort-Object -Unique Binary #| Format-Table -auto
			#(import-csv -Path $DBfileName -Header "Binary","Version","size","Published","Time","Platform","SP_requirement","Service branch") |?{($_.Binary -match $BinSearch) -and ($_.Version -Notmatch 'Not applicable')} | Select-Object Binary,Version,Published | Sort-Object -Unique Binary | Format-Table -auto
			Write-verbose "...Searching in $DBfileName"
			}
		else { Write-host "..sorry, no Update Rollup fixes for this OS $OSshort"
		 	Write-host "..using DBfileName: $DBfileName"}
	}
 	### Search in RFL database
 	else {$Result =(import-csv $DBfileName ) |?{$_.Binary -match $BinSearch} | Select-Object Binary,Version,Published,Component,Branch,RollupInfo,Article,Title | Sort-Object -Unique Binary #}# | Format-Table -auto
 		#$ResM1=$Result|measure; $Cnt = $($ResM1.count); Write-Host "$OSshort Cnt: $Cnt"
 	   }
	if ($Result) { #$Cnt = $($Result.count); Write-Host "$OSshort Cnt: $($Result.count)"}
			$ResM1=$Result|measure; $Cnt = $($ResM1.count); Write-Host "$OSshort Cnt: $Cnt"
			}
	else {$Cnt = 0; Write-Host "$OSshort $Cnt results; you may try Advanced Search on http://WinSEqfe/" }
	$Result | Format-Table -auto
	$CntAll = $CntAll+$Cnt
} #end of loop: # walk through each binary in $BinSearchList
} #end of loop: # walk through each OS in inputlist

#set-location -path $CurrentPath
Write-Verbose "... done."

$end = Get-Date
$Duration = $end - $start
Write-Host -BackgroundColor Gray -ForegroundColor Black -Object "$(Get-Date -UFormat "%R") Found $CntAll '$($BinSearchList)' in '$OSshortList'; script version v$verDateScript  took $($Duration)"

### Stats
If ($Stats) {
 ($j=[int32](Get-Content $CountInvFil -TotalCount 1)) |Out-Null
 (++$j) | Set-Content $CountInvFil -ErrorAction SilentlyContinue
 ([string]$j + "; $CheckDate; $UsrOSVersion; " + [System.Security.Principal.WindowsIdentity]::GetCurrent().Name) + "; $($Duration)" + "; $BinSearchList; $OSshortList; $RollupSearch; $CntAll;" | Out-File $CountInvFil2 -Append -Encoding UTF8
 }


# SIG # Begin signature block
# MIInmAYJKoZIhvcNAQcCoIIniTCCJ4UCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAYmXnhVQ7SNlH/
# iM7mYSAXgn+4W03HSB4OgsFHCiG9uKCCDXYwggX0MIID3KADAgECAhMzAAACy7d1
# OfsCcUI2AAAAAALLMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjIwNTEyMjA0NTU5WhcNMjMwNTExMjA0NTU5WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC3sN0WcdGpGXPZIb5iNfFB0xZ8rnJvYnxD6Uf2BHXglpbTEfoe+mO//oLWkRxA
# wppditsSVOD0oglKbtnh9Wp2DARLcxbGaW4YanOWSB1LyLRpHnnQ5POlh2U5trg4
# 3gQjvlNZlQB3lL+zrPtbNvMA7E0Wkmo+Z6YFnsf7aek+KGzaGboAeFO4uKZjQXY5
# RmMzE70Bwaz7hvA05jDURdRKH0i/1yK96TDuP7JyRFLOvA3UXNWz00R9w7ppMDcN
# lXtrmbPigv3xE9FfpfmJRtiOZQKd73K72Wujmj6/Su3+DBTpOq7NgdntW2lJfX3X
# a6oe4F9Pk9xRhkwHsk7Ju9E/AgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUrg/nt/gj+BBLd1jZWYhok7v5/w4w
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzQ3MDUyODAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAJL5t6pVjIRlQ8j4dAFJ
# ZnMke3rRHeQDOPFxswM47HRvgQa2E1jea2aYiMk1WmdqWnYw1bal4IzRlSVf4czf
# zx2vjOIOiaGllW2ByHkfKApngOzJmAQ8F15xSHPRvNMmvpC3PFLvKMf3y5SyPJxh
# 922TTq0q5epJv1SgZDWlUlHL/Ex1nX8kzBRhHvc6D6F5la+oAO4A3o/ZC05OOgm4
# EJxZP9MqUi5iid2dw4Jg/HvtDpCcLj1GLIhCDaebKegajCJlMhhxnDXrGFLJfX8j
# 7k7LUvrZDsQniJZ3D66K+3SZTLhvwK7dMGVFuUUJUfDifrlCTjKG9mxsPDllfyck
# 4zGnRZv8Jw9RgE1zAghnU14L0vVUNOzi/4bE7wIsiRyIcCcVoXRneBA3n/frLXvd
# jDsbb2lpGu78+s1zbO5N0bhHWq4j5WMutrspBxEhqG2PSBjC5Ypi+jhtfu3+x76N
# mBvsyKuxx9+Hm/ALnlzKxr4KyMR3/z4IRMzA1QyppNk65Ui+jB14g+w4vole33M1
# pVqVckrmSebUkmjnCshCiH12IFgHZF7gRwE4YZrJ7QjxZeoZqHaKsQLRMp653beB
# fHfeva9zJPhBSdVcCW7x9q0c2HVPLJHX9YCUU714I+qtLpDGrdbZxD9mikPqL/To
# /1lDZ0ch8FtePhME7houuoPcMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGXgwghl0AgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAALLt3U5+wJxQjYAAAAAAsswDQYJYIZIAWUDBAIB
# BQCggbAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIJzx89BXPqzg+u7Rvy9Mdvsj
# aD+RaLYee1yTSJU/negDMEQGCisGAQQBgjcCAQwxNjA0oBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEcgBpodHRwczovL3d3dy5taWNyb3NvZnQuY29tIDANBgkqhkiG9w0B
# AQEFAASCAQARwIrvOaGY4Zy7JQgu1dnf6StFNGUeOweApaqBKiZZTC+XUJErG1pz
# 5TEa8CswDdza3fZKnfiO2kybkTf9OPPX2YSViCTni+szMoP19nHRL48LUv1JyJNC
# D0L7GHQIp56DhdnuOD1A6SjrQ8QS7pUc7ji8LqXSvjSL+gP1eimT68Rtow7vG7lM
# 1KwdI6HpmcdBqdD5H+P6PgfSNAspsr4lVxeHQfNt8T/6q+0tVG9Ynb9meaW+Q9KZ
# szaX/3XB5u9AfhJRn6LQoCdgZId5S+6D5u1Cm1EMZBXYkQTybc+NMwHCZdMIoHPk
# tRTVgirOLERJKBOWEEzZNKcbJu0yQVScoYIXADCCFvwGCisGAQQBgjcDAwExghbs
# MIIW6AYJKoZIhvcNAQcCoIIW2TCCFtUCAQMxDzANBglghkgBZQMEAgEFADCCAVEG
# CyqGSIb3DQEJEAEEoIIBQASCATwwggE4AgEBBgorBgEEAYRZCgMBMDEwDQYJYIZI
# AWUDBAIBBQAEIGNP1m6hdl/GwN9Rz7RPWncOw1WTGU7HV2D4QQZhe9sLAgZjETyM
# rtkYEzIwMjIwOTE0MTAyNTQwLjg4OFowBIACAfSggdCkgc0wgcoxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBB
# bWVyaWNhIE9wZXJhdGlvbnMxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjdCRjEt
# RTNFQS1CODA4MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNl
# oIIRVzCCBwwwggT0oAMCAQICEzMAAAGfK0U1FQguS10AAQAAAZ8wDQYJKoZIhvcN
# AQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQG
# A1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjExMjAyMTkw
# NTIyWhcNMjMwMjI4MTkwNTIyWjCByjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldh
# c2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBD
# b3Jwb3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0aW9u
# czEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046N0JGMS1FM0VBLUI4MDgxJTAjBgNV
# BAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCk9Xl8TVGyiZAvzm8tB4fLP0znL883YDIG03js1/Wz
# CaICXDs0kXlJ39OUZweBFa/V8l27mlBjyLZDtTg3W8dQORDunfn7SzZEoFmlXaSY
# cQhyDMV5ghxi6lh8y3NV1TNHGYLzaoQmtBeuFSlEH9wp6rC/sRK7GPrOn17XAGzo
# +/yFy7DfWgIQ43X35ut20TShUeYDrs5GOVpHp7ouqQYRTpu+lAaCHfq8tr+LFqIy
# jpkvxxb3Hcx6Vjte0NPH6GnICT84PxWYK7eoa5AxbsTUqWQyiWtrGoyQyXP4yIKf
# TUYPtsTFCi14iuJNr3yRGjo4U1OHZU2yGmWeCrdccJgkby6k2N5AhRYvKHrePPh5
# oWHY01g8TckxV4h4iloqvaaYGh3HDPWPw4KoKyEy7QHGuZK1qAkheWiKX2qE0eNR
# WummCKPhdcF3dcViVI9aKXhty4zM76tsUjcdCtnG5VII6eU6dzcL6YFp0vMl7JPI
# 3y9Irx9sBEiVmSigM2TDZU4RUIbFItD60DJYzNH0rGu2Dv39P/0Owox37P3ZfvB5
# jAeg6B+SBSD0awi+f61JFrVc/UZ83W+5tgI/0xcLGWHBNdEibSF1NFfrV0KPCKfi
# 9iD2BkQgMYi02CY8E3us+UyYA4NFYcWJpjacBKABeDBdkY1BPfGgzskaKhIGhdox
# 9QIDAQABo4IBNjCCATIwHQYDVR0OBBYEFGI08tUeExYrSA4u6N/ZasfWHchhMB8G
# A1UdIwQYMBaAFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMF8GA1UdHwRYMFYwVKBSoFCG
# Tmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY3Jvc29mdCUy
# MFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEpLmNybDBsBggrBgEFBQcBAQRgMF4w
# XAYIKwYBBQUHMAKGUGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY2Vy
# dHMvTWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3J0MAwG
# A1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZIhvcNAQELBQAD
# ggIBAB2KKCk8O+kZ8+m9bPXQIAmo+6xbKDaKkMR3/82A8XVAMa9RpItYJkdkta+C
# 6ZIVBsZEARJkKnWpYJiiyGBV3PmPoIMP5zFbr0BYLMolDJZMtH3MifVBD9NknYNK
# g+GbWyaAPs8VZ6UD3CRzjoVZ2PbHRH+UOl2Yc/cm1IR3BlvjlcNwykpzBGUndARe
# fuzjfRSfB+dBzmlFY+dME8+J3OvveMraIcznSrlr46GXMoWGJt0hBJNf4G5JZqyX
# e8n8z2yR5poL2uiMRzqIXX1rwCIXhcLPFgSKN/vJxrxHiF9ByViouf4jCcD8O2mO
# 94toCSqLERuodSe9dQ7qrKVBonDoYWAx+W0XGAX2qaoZmqEun7Qb8hnyNyVrJ2C2
# fZwAY2yiX3ZMgLGUrpDRoJWdP+tc5SS6KZ1fwyhL/KAgjiNPvUBiu7PF4LHx5TRF
# U7HZXvgpZDn5xktkXZidA4S26NZsMSygx0R1nXV3ybY3JdlNfRETt6SIfQdCxRX5
# YUbI5NdvuVMiy5oB3blfhPgNJyo0qdmkHKE2pN4c8iw9SrajnWcM0bUExrDkNqcw
# aq11Dzwc0lDGX14gnjGRbghl6HLsD7jxx0+buzJHKZPzGdTLMFKoSdJeV4pU/t3d
# PbdU21HS60Ex2Ip2TdGfgtS9POzVaTA4UucuklbjZkQihfg2MIIHcTCCBVmgAwIB
# AgITMwAAABXF52ueAptJmQAAAAAAFTANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0
# IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTAwHhcNMjEwOTMwMTgyMjI1
# WhcNMzAwOTMwMTgzMjI1WjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGlu
# Z3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBv
# cmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCC
# AiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAOThpkzntHIhC3miy9ckeb0O
# 1YLT/e6cBwfSqWxOdcjKNVf2AX9sSuDivbk+F2Az/1xPx2b3lVNxWuJ+Slr+uDZn
# hUYjDLWNE893MsAQGOhgfWpSg0S3po5GawcU88V29YZQ3MFEyHFcUTE3oAo4bo3t
# 1w/YJlN8OWECesSq/XJprx2rrPY2vjUmZNqYO7oaezOtgFt+jBAcnVL+tuhiJdxq
# D89d9P6OU8/W7IVWTe/dvI2k45GPsjksUZzpcGkNyjYtcI4xyDUoveO0hyTD4MmP
# frVUj9z6BVWYbWg7mka97aSueik3rMvrg0XnRm7KMtXAhjBcTyziYrLNueKNiOSW
# rAFKu75xqRdbZ2De+JKRHh09/SDPc31BmkZ1zcRfNN0Sidb9pSB9fvzZnkXftnIv
# 231fgLrbqn427DZM9ituqBJR6L8FA6PRc6ZNN3SUHDSCD/AQ8rdHGO2n6Jl8P0zb
# r17C89XYcz1DTsEzOUyOArxCaC4Q6oRRRuLRvWoYWmEBc8pnol7XKHYC4jMYcten
# IPDC+hIK12NvDMk2ZItboKaDIV1fMHSRlJTYuVD5C4lh8zYGNRiER9vcG9H9stQc
# xWv2XFJRXRLbJbqvUAV6bMURHXLvjflSxIUXk8A8FdsaN8cIFRg/eKtFtvUeh17a
# j54WcmnGrnu3tz5q4i6tAgMBAAGjggHdMIIB2TASBgkrBgEEAYI3FQEEBQIDAQAB
# MCMGCSsGAQQBgjcVAgQWBBQqp1L+ZMSavoKRPEY1Kc8Q/y8E7jAdBgNVHQ4EFgQU
# n6cVXQBeYl2D9OXSZacbUzUZ6XIwXAYDVR0gBFUwUzBRBgwrBgEEAYI3TIN9AQEw
# QTA/BggrBgEFBQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9E
# b2NzL1JlcG9zaXRvcnkuaHRtMBMGA1UdJQQMMAoGCCsGAQUFBwMIMBkGCSsGAQQB
# gjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/
# MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1UdHwRPME0wS6BJ
# oEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01p
# Y1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYB
# BQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljUm9v
# Q2VyQXV0XzIwMTAtMDYtMjMuY3J0MA0GCSqGSIb3DQEBCwUAA4ICAQCdVX38Kq3h
# LB9nATEkW+Geckv8qW/qXBS2Pk5HZHixBpOXPTEztTnXwnE2P9pkbHzQdTltuw8x
# 5MKP+2zRoZQYIu7pZmc6U03dmLq2HnjYNi6cqYJWAAOwBb6J6Gngugnue99qb74p
# y27YP0h1AdkY3m2CDPVtI1TkeFN1JFe53Z/zjj3G82jfZfakVqr3lbYoVSfQJL1A
# oL8ZthISEV09J+BAljis9/kpicO8F7BUhUKz/AyeixmJ5/ALaoHCgRlCGVJ1ijbC
# HcNhcy4sa3tuPywJeBTpkbKpW99Jo3QMvOyRgNI95ko+ZjtPu4b6MhrZlvSP9pEB
# 9s7GdP32THJvEKt1MMU0sHrYUP4KWN1APMdUbZ1jdEgssU5HLcEUBHG/ZPkkvnNt
# yo4JvbMBV0lUZNlz138eW0QBjloZkWsNn6Qo3GcZKCS6OEuabvshVGtqRRFHqfG3
# rsjoiV5PndLQTHa1V1QJsWkBRH58oWFsc/4Ku+xBZj1p/cvBQUl+fpO+y/g75LcV
# v7TOPqUxUYS8vwLBgqJ7Fx0ViY1w/ue10CgaiQuPNtq6TPmb/wrpNPgkNWcr4A24
# 5oyZ1uEi6vAnQj0llOZ0dFtq0Z4+7X6gMTN9vMvpe784cETRkPHIqzqKOghif9lw
# Y1NNje6CbaUFEMFxBmoQtB1VM1izoXBm8qGCAs4wggI3AgEBMIH4oYHQpIHNMIHK
# MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQLExxN
# aWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25zMSYwJAYDVQQLEx1UaGFsZXMgVFNT
# IEVTTjo3QkYxLUUzRUEtQjgwODElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3Rh
# bXAgU2VydmljZaIjCgEBMAcGBSsOAwIaAxUAdF2umB/yywxFLFTC8rJ9Fv9c9reg
# gYMwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYw
# JAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0B
# AQUFAAIFAObLjCgwIhgPMjAyMjA5MTQwNzA5MjhaGA8yMDIyMDkxNTA3MDkyOFow
# dzA9BgorBgEEAYRZCgQBMS8wLTAKAgUA5suMKAIBADAKAgEAAgIjPwIB/zAHAgEA
# AgISSDAKAgUA5szdqAIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMC
# oAowCAIBAAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBAK9LMOWn
# uOacl+c0Sel1B8RcFgpbAtbe09hSm7R/KF0I79yP9V6ieq5ahA8YcNGIFmDotIRF
# 3rTJf2j3be6Rol+YZV7A5Qtx5UlOA3v5t7I4Vsd1zjD7XQtDtQ5biG33Gj8GUXZZ
# eBLTxjoq7HrnwWKgbqCKnJ7bOydB94Jx5edzMYIEDTCCBAkCAQEwgZMwfDELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9z
# b2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAGfK0U1FQguS10AAQAAAZ8wDQYJ
# YIZIAWUDBAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkq
# hkiG9w0BCQQxIgQghoRx2AqxYh8GXH1tu1tdqT4XRvpZO1pghoJ+TZnHfXswgfoG
# CyqGSIb3DQEJEAIvMYHqMIHnMIHkMIG9BCCG8V4poieJnqXnVzwNUejeKgLJfEH7
# P+jspyw3S3xc2jCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEw
# AhMzAAABnytFNRUILktdAAEAAAGfMCIEIP5n82VNQJghcFyGLlBMB5zg+EJEW2e2
# rMd0Fd2gZSd8MA0GCSqGSIb3DQEBCwUABIICAFL7Bjrs1NdiwbmYyI2o8aAR0Y16
# 3K6vbOYy2qQVh1vrc6RZ2KBrzxdLQJwTk5ar2KooT24ZfjZi4wUM+3yytJRBrE87
# 2GOYfdf44kouCLeG4XjK1Z+9mLfvGQsVHCafhkQD7nXlEEPAgoI0ET4Dq9Mft8A2
# md380l06e1ZQMTNMq4ohYrIlr1aa4qkZfgYA1CVi6DnhM1hjbX1w4ni5aqL+KHcM
# k7jGjFUY/7ySXcuzEPHUoFjdN11M2Qlbo+L8dez1EQvEY6PVzSXAcWTdUEeDVaxQ
# Ha8aKZOUZpC2CgS1rT5qza9haS5bPP9/PQFWnz3NLkcV39EFbHnfLXbJplfg8LuO
# HnnVTZTbUt0XXGkSaQIH921etaPx21Ygw6Zc8+38gnNfzQPjqdBD7HwZ0PM0nUe8
# LAsHJlDm3jKMjrDpNzZf1F1HW2LhhsYx8O/yzQoLQi5TeiW9JttNAv0oP3GnUNYH
# C7YqcGQrRHZwfCcFiy3/CGSFb1atACwBC73yZ6PpdvR20OTe58744a7lW/eJhLew
# k0cHyZq8zAR8zPur84pjzoji7xNEfGJRVCZLvHX4085B7NWIGoZbhdCyk/h8lB9G
# lD2GG8ohyAo34bc+oN2yYa8dCGOzLm9chkurntKExbMgCGQgZXtRdLTwyhFzZPD4
# fzn3eMVHffFkDr3w
# SIG # End signature block
