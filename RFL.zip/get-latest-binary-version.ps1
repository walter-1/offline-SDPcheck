# Name: get-latest-binary-version.ps1
<# Script to find latest binary version in released OS
Help: get-help \\emeacssdfs\netpod\rfl\get-latest-binary-version.ps1 -detailed
last edit by: waltere 2023-04-15
File Name: get-latest-binary-version.ps1

VERSION and AUTHORs:
    Ver 1.00 - 23.09.2016
	Walter Eder	- waltere@microsoft.com

### show Events from all providers (data in Eventlog folder) in a specifix time-range

HISTORY
	2016-09-23 v1.00
	2016-10-01 v1.01 better wildcard search
	2016-10-01 v1.02 allow multiple Binaries in Search
	2016-10-15 v1.03 correct csv Delimiter in import-csv for 208R2,2012* rollup KBs; correct Cnt: for single binaries
		Note: monthly Rollup csv files for 2012 and 2012R2 have two Space delimiter, need to globally replace ' ' with ' ' in Text-Editor first
	2017-10-06 v1.04 adding 2016RS3
	2018-04-05 adding 2016RS4
#>

<#
.SYNOPSIS
File Name: get-latest-binary-version.ps1
The script helps to find latest x64 binary version in released OS updates, where optional parameter2 OSversion can be [2008|2008R2|2012|2012R2|2016|2016RS1|2016RS2|2016RS3|2016RS4|2016RS5|201619H1|201619H2|20162004|201620H2|201621H1|201621H2|201622H2|2022|Win11|Win1122H2|Win1123H1|all]
The abbreviations stand for Server OS or corresponding Client OS (Vista, Windows 7, Windows 8.1, Windows 10 1507 RTM /1511 /1607 Anniversary Update.
For non-RFL fixes, please use optional parameter3 'Rollup'.
Older lookup tools on: http://silverseekkb.cloudapp.net/ and http://HotfixSearch/ are outdated.
For complete list of fixes, please see also Search or Advanced Search on http://WinSEqfe/
2018-12: New binary Search: http://aka.ms/trackitbinarysearch

.DESCRIPTION
This script helps to find latest binary version in released OS (listed in RFL or latest update rollup KBs), including usage of wildcards or regular expression, i.e. '*.sys'
Output file versions correspond to
Version Prefix	| Operating system Srv	| Client
6.0.6002.*		| Windows Server 2008 	| Windows Vista
6.1.7601.*		| Windows Server 2008-R2| Windows 7
6.2.9200.*		| Windows Server 2012	| Windows 8
6.3.9600.*		| Windows Server 2012-R2| Windows 8.1
6.2.10240.*		| Windows Server 2016	| Windows 10 RTM
6.2.10586.*		| Windows Server 2016TH2| Windows 10 Version 1511 TH2
6.2.14393.*		| Windows Server 2016RS1| Windows 10 Version 1607 Anniversary Update
6.2.17763.*		| Windows Server 2016RS5| Windows 10 Version 1809 October 2018 Update
6.2.18363.*		| Windows Server 201619H2| Windows 10 1909 19H2 October 2019 Update
6.2.19041.*		| Windows Server 20162004| Windows 10 2004 2020 April 2020 Update
6.2.19042.*		| Windows Server 201620H2| Windows 10 20H2 October 2020 Update
6.2.19043.*		| Windows Server 201621H1| Windows 10 21H1 April 2020 Update
6.2.19044.*		| Windows Server 201621H2| Windows 10 21H2 October 2021 Update
6.2.19045.*		| Windows Server 201622H2| Windows 10 22H2 October 2022 Update
6.2.20348.*		| Windows Server 2022| Windows Srv2022
6.2.20349.*		| Windows Server 2022| Windows Srv2022AZ HCI
6.2.22000.*		| Windows 11 
6.2.22621.*		| Windows 11		| Windows 11 22H1 May 2022 Update

.EXAMPLE
Usage:
Example 1, find a specific x64 binary in [all] Operating Systems
\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\get-latest-binary-version.ps1 [binary-name.ext] [OSversion] [RFL|Rollup]

Example 2, find all latest binaries for OS Windows 8.1 or Server 2012-R2 in RFL
\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\get-latest-binary-version.ps1 *.* 2012R2

Example 3, find multiple binaries by name, comma separated list, for OS Windows 8.1 or Server 2012-R2 in RFL
\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\get-latest-binary-version.ps1 srv2.sys,mrxsmb2 2012R2

Example 4, find all latest '*.sys' binaries for OS Windows 8.1 or Server 2012-R2 in latest Update Rollup KB
\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\get-latest-binary-version.ps1 *.sys 2012R2 Rollup

.LINK
email: waltere@microsoft.com
#>

[CmdletBinding()]
PARAM (
	#[ValidateSet("binary.dll","binary*",".*")]
	[Parameter(Mandatory=$True,Position=0,HelpMessage='Input binary name or part of name or regular expression, i.e. srv*.*')]
	[string[]]$BinSearchList
,
	[ValidateSet("2008","2008R2","2012","2012R2","2016","2016RS1","2016RS2","2016RS3","2016RS4","2016RS5","201619H1","201619H2","20162004","201620H2","201621H1","201621H2","201622H2","2022","Win11","Win1122H2","Win1123H1","all")]
	[Parameter(Mandatory=$False,Position=1,HelpMessage='optional: Choose one OS from list: [2008|2008R2|2012|2012R2|2016|2016RS1|2016RS2|2016RS3|2016RS4|2016RS5|201619H1|201619H2|20162004|201620H2|201621H1|201621H2|201622H2|2022|Win11|Win1122H2|Win1123H1|all]')]
	[string[]]$OSshortList = "all"
,
	[ValidateSet("RFL","Rollup")]
	[Parameter(Mandatory=$False,Position=2,HelpMessage='Want to search in downloaded latest update rollup csv [RFL|Rollup]')]
	[string]$RollupSearch = "RFL"
	)

$UsrOSVersion = [Environment]::OSVersion.Version.ToString(3)
$CheckDate = (Get-Date).ToUniversalTime().ToString("yy-MM-dd_HH-mm-ss")

#region: ###### customization section of script, logging configuration ########################
	$verDateScript = "2023.04.15.0"
	$ScriptFolder = Split-Path $MyInvocation.MyCommand.Path -Parent
	$SDPcheckINI = (Get-content -Path "$ScriptFolder\_SDPcheck.ini")
	$InOfflineMode 	= (($SDPcheckINI[1] -split " ")[2]).trim("""")	# set $True for outsourcer or when not connected to MS network - offline-SDPcheck
	$RFLroot = (($SDPcheckINI[2] -split " ")[2]).trim("""")	# "\\emea.europe.corp.microsoft.com\Shares\SDP-Check\RFL\" -or- "\\localhost\ToolsShare\rfl\"
	if ($InOfflineMode -match "False") {
			$StatsServer = (($SDPcheckINI[5] -split " ")[2]).trim("""")
			if (Test-Connection -ComputerName $StatsServer -Quiet -Count 1) {[bool]$Stats=$True} else {[bool]$Stats=$False}
	} else { 
		$Stats = $False
	}
	$RFLdbRoot = $RFLroot + "\RflLists"
#endregion: ###### customization section

if ($Stats) {
	$StatsServerPath="\\$StatsServer\RFLstats$\RFL\scripts\Stats\"
	$CountInvFil 		= $StatsServerPath +'count_getVer.dat'
	$CountInvFil2 		= $CountInvFil +'.us'
}


$start = Get-Date

 Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force
 Unblock-File -Path $RFLroot\get-latest-binary-version.ps1 -ErrorAction SilentlyContinue
 Write-Verbose "in case you see any red error messages regarding signing, open an Admin Powershell CMD and run this command first:
 	 Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force

 	 "

### Enable parameter 'all' for user input (Tech and OS)
if ($OSshortList -ieq 'all'){
	[string[]]$OSshortList = "2008","2008R2","2012","2012R2","2016","2016RS1","2016RS2","2016RS3","2016RS4","2016RS5","201619H1","201619H2","20162004","201620H2","201621H1","201621H2","201622H2","2022","Win11","Win1122H2","Win1123H1"
	"`n__OS: $OSshortList / Find: '$BinSearchList' in [RFL|Rollup] = $RollupSearch"
	}
else {"`n__OS [2008|2008R2|2012|2012R2|2016|2016RS1|2016RS2|2016RS3|2016RS4|2016RS5|201619H1|201619H2|20162004|201620H2|201621H1|201621H2|201622H2|2022|Win11|Win1122H2|Win1123H1] = $OSshortList / Find: '$BinSearchList' in [RFL|Rollup] = $RollupSearch"}

### walk through each OS in inputlist
$CntAll = 0
foreach ($OSshort in $OSshortList){
### walk through each binary in $BinSearchList
foreach ($BinSearch in $BinSearchList){
	#if ($BinSearch.StartsWith("*")) { [regex] $BinSearch = '.' +$BinSearch } ## included for regex search
	if ($BinSearch.Contains("*")){ $BinSearch = $BinSearch.Replace("*",".*") }
	Write-verbose "...Found in $OSshort"
	$DBfileName = $RFLdbRoot +"\ref__Master_"+ $OSshort +"_latest.csv"
	### Search in Rollup KB
	if ($RollupSearch -ieq 'Rollup') {
		if (($OSshort -match '2016') -or ($OSshort -match '2012') -or ($OSshort -match '2008R2')) {
			### Extracting KB and Title from current KBOnlyRollup_*.csv
			$KBOnlyRollupFileName	= $RFLdbRoot + '\KBOnlyRollup_' +$OSshort+ '.csv'
			Write-Verbose "... looking up cumulative KB-nr and Title in last line of file $KBOnlyRollupFileName "
			$KBOnlyRollupFile = Import-Csv -Path $KBOnlyRollupFileName -Header Binary,Component,Version,Prio,Published,Branch,Article,Title,Link,LDROnlyKB,LDROnlyTitle,LDROnlyLink,Comment,RollupInfo | Select-Object -last 1
			$CumKB 	= $($KBOnlyRollupFile.Binary) 	#$CumKB 	= "3124266"
			$CumKBTitle = $($KBOnlyRollupFile.Title)
			Write-Host "... looking up '$BinSearch' version in KB $CumKB $CumKBTitle"
			$DBfileName = $RFLdbRoot+ "\" +$OSshort+ "*" +$CumKB+ ".csv"
			Write-Host "... $OSshort _Fetch 'x64 Windows $OSshort' - $DBfileName"
			if ($OSshort -match '2016') {
				#Format 2016: 		File name,File version,File size,Date,Time,Platform,SP requirement,Service branch,
			    $DBfile = import-csv -Path $DBfileName -Header "Binary","Version","size","Published","Time","Platform","SP_requirement","Service branch"}
			if (($OSshort -match '2012') -or ($OSshort -match '2008R2')) {
				#Format 2008R2: 	File_name File_version File_size Date Time Platform SP_requirement Service_branch
			    $DBfile = import-csv -Delimiter ' ' -Path $DBfileName -Header "Binary","Version","size","Published","Time","Platform","SP_requirement","Service branch"}
			$Result = $DBfile |?{(($_.Binary -match $BinSearch) -and ($_.Binary.Contains(".")) -and ($_.Version -Notmatch 'Not applicable') -and ($_.Platform.Contains("x64")))} | Select-Object Binary,Version,Published,Platform | Sort-Object -Unique Binary #| Format-Table -auto
			#(import-csv -Path $DBfileName -Header "Binary","Version","size","Published","Time","Platform","SP_requirement","Service branch") |?{($_.Binary -match $BinSearch) -and ($_.Version -Notmatch 'Not applicable')} | Select-Object Binary,Version,Published | Sort-Object -Unique Binary | Format-Table -auto
			Write-verbose "...Searching in $DBfileName"
			}
		else { Write-host "..sorry, no Update Rollup fixes for this OS $OSshort"
		 	Write-host "..using DBfileName: $DBfileName"}
	}
 	### Search in RFL database
 	else {$Result =(import-csv $DBfileName ) |?{$_.Binary -match $BinSearch} | Select-Object Binary,Version,Published,Component,Branch,RollupInfo,Article,Title | Sort-Object -Unique Binary #}# | Format-Table -auto
 		#$ResM1=$Result|measure; $Cnt = $($ResM1.count); Write-Host "$OSshort Cnt: $Cnt"
 	   }
	if ($Result) { #$Cnt = $($Result.count); Write-Host "$OSshort Cnt: $($Result.count)"}
			$ResM1=$Result|measure; $Cnt = $($ResM1.count); Write-Host "$OSshort Cnt: $Cnt"
			}
	else {$Cnt = 0; Write-Host "$OSshort $Cnt results; you may try Advanced Search on http://WinSEqfe/" }
	$Result | Format-Table -auto
	$CntAll = $CntAll+$Cnt
} #end of loop: # walk through each binary in $BinSearchList
} #end of loop: # walk through each OS in inputlist

#set-location -path $CurrentPath
Write-Verbose "... done."

$end = Get-Date
$Duration = $end - $start
Write-Host -BackgroundColor Gray -ForegroundColor Black -Object "$(Get-Date -UFormat "%R") Found $CntAll '$($BinSearchList)' in '$OSshortList'; script version v$verDateScript  took $($Duration)"

### Stats
If ($Stats) {
 ($j=[int32](Get-Content $CountInvFil -TotalCount 1)) |Out-Null
 Try {(++$j) | Set-Content $CountInvFil -ErrorAction SilentlyContinue} Catch { }
 Try {([string]$j + "; $CheckDate; $UsrOSVersion; " + [System.Security.Principal.WindowsIdentity]::GetCurrent().Name) + "; $($Duration)" + "; $BinSearchList; $OSshortList; $RollupSearch; $CntAll;" | Out-File $CountInvFil2 -Append -Encoding UTF8} Catch { }
 }


# SIG # Begin signature block
# MIInwQYJKoZIhvcNAQcCoIInsjCCJ64CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDAGA3KYY3RzX/F
# H+oFCVK4C5uoH5BdM8XxYQFfclUq6KCCDXYwggX0MIID3KADAgECAhMzAAACy7d1
# OfsCcUI2AAAAAALLMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjIwNTEyMjA0NTU5WhcNMjMwNTExMjA0NTU5WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC3sN0WcdGpGXPZIb5iNfFB0xZ8rnJvYnxD6Uf2BHXglpbTEfoe+mO//oLWkRxA
# wppditsSVOD0oglKbtnh9Wp2DARLcxbGaW4YanOWSB1LyLRpHnnQ5POlh2U5trg4
# 3gQjvlNZlQB3lL+zrPtbNvMA7E0Wkmo+Z6YFnsf7aek+KGzaGboAeFO4uKZjQXY5
# RmMzE70Bwaz7hvA05jDURdRKH0i/1yK96TDuP7JyRFLOvA3UXNWz00R9w7ppMDcN
# lXtrmbPigv3xE9FfpfmJRtiOZQKd73K72Wujmj6/Su3+DBTpOq7NgdntW2lJfX3X
# a6oe4F9Pk9xRhkwHsk7Ju9E/AgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUrg/nt/gj+BBLd1jZWYhok7v5/w4w
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzQ3MDUyODAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAJL5t6pVjIRlQ8j4dAFJ
# ZnMke3rRHeQDOPFxswM47HRvgQa2E1jea2aYiMk1WmdqWnYw1bal4IzRlSVf4czf
# zx2vjOIOiaGllW2ByHkfKApngOzJmAQ8F15xSHPRvNMmvpC3PFLvKMf3y5SyPJxh
# 922TTq0q5epJv1SgZDWlUlHL/Ex1nX8kzBRhHvc6D6F5la+oAO4A3o/ZC05OOgm4
# EJxZP9MqUi5iid2dw4Jg/HvtDpCcLj1GLIhCDaebKegajCJlMhhxnDXrGFLJfX8j
# 7k7LUvrZDsQniJZ3D66K+3SZTLhvwK7dMGVFuUUJUfDifrlCTjKG9mxsPDllfyck
# 4zGnRZv8Jw9RgE1zAghnU14L0vVUNOzi/4bE7wIsiRyIcCcVoXRneBA3n/frLXvd
# jDsbb2lpGu78+s1zbO5N0bhHWq4j5WMutrspBxEhqG2PSBjC5Ypi+jhtfu3+x76N
# mBvsyKuxx9+Hm/ALnlzKxr4KyMR3/z4IRMzA1QyppNk65Ui+jB14g+w4vole33M1
# pVqVckrmSebUkmjnCshCiH12IFgHZF7gRwE4YZrJ7QjxZeoZqHaKsQLRMp653beB
# fHfeva9zJPhBSdVcCW7x9q0c2HVPLJHX9YCUU714I+qtLpDGrdbZxD9mikPqL/To
# /1lDZ0ch8FtePhME7houuoPcMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGaEwghmdAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAALLt3U5+wJxQjYAAAAAAsswDQYJYIZIAWUDBAIB
# BQCggbAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIPjzxw8bcgDc3u3+dbLY3AcU
# cdcEVxWEcomsMaRW5pSMMEQGCisGAQQBgjcCAQwxNjA0oBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEcgBpodHRwczovL3d3dy5taWNyb3NvZnQuY29tIDANBgkqhkiG9w0B
# AQEFAASCAQAVlzTaZY3ETFiNIFKb5DjrcXEcIXeSTc16KwfQB5cOEG1VhJqFiHU6
# QCnoyHbq6hhkAanUxoz1w4Iz0Hh/4+2IlVyNDepjwLUXr91/7hEUqPjhGeU9n8rX
# MI9WFUouiDu4UKULu5/OM+3IrDUVt0pXi/MIowfCfXlOtAy7VPYXpiVCEpCgQ6NI
# alxB8OnvYX0BO4yi2DHVU8WH698qRg8Fbi+6Vdakpg0iJsTQY0m00GkLyPXR9qeg
# tbN2E/QwJLaKxaYLQ39XEqYK3Eyj72kbBEzeVwaatOOSqrphSaZRmQRVTEb23Enz
# OnfsXX9BbWqMbpQ4W/9VogNFVOHGex2voYIXKTCCFyUGCisGAQQBgjcDAwExghcV
# MIIXEQYJKoZIhvcNAQcCoIIXAjCCFv4CAQMxDzANBglghkgBZQMEAgEFADCCAVkG
# CyqGSIb3DQEJEAEEoIIBSASCAUQwggFAAgEBBgorBgEEAYRZCgMBMDEwDQYJYIZI
# AWUDBAIBBQAEIJ6nAi2xfpwuO84qhsgN61HDje9M4ElnI587l0dNIAQbAgZkGwHt
# orcYEzIwMjMwNDE3MDY0NTE0LjY4NVowBIACAfSggdikgdUwgdIxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJ
# cmVsYW5kIE9wZXJhdGlvbnMgTGltaXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBF
# U046OEQ0MS00QkY3LUIzQjcxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1w
# IFNlcnZpY2WgghF4MIIHJzCCBQ+gAwIBAgITMwAAAbP+Jc4pGxuKHAABAAABszAN
# BgkqhkiG9w0BAQsFADB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3Rv
# bjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0
# aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0y
# MjA5MjAyMDIyMDNaFw0yMzEyMTQyMDIyMDNaMIHSMQswCQYDVQQGEwJVUzETMBEG
# A1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWlj
# cm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJlbGFuZCBP
# cGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjhENDEt
# NEJGNy1CM0I3MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNl
# MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAtHwPuuYYgK4ssGCCsr2N
# 7eElKlz0JPButr/gpvZ67kNlHqgKAW0JuKAy4xxjfVCUev/eS5aEcnTmfj63fvs8
# eid0MNvP91T6r819dIqvWnBTY4vKVjSzDnfVVnWxYB3IPYRAITNN0sPgolsLrCYA
# KieIkECq+EPJfEnQ26+WTvit1US+uJuwNnHMKVYRri/rYQ2P8fKIJRfcxkadj8CE
# PJrN+lyENag/pwmA0JJeYdX1ewmBcniX4BgCBqoC83w34Sk37RMSsKAU5/BlXbVy
# Du+B6c5XjyCYb8Qx/Qu9EB6KvE9S76M0HclIVtbVZTxnnGwsSg2V7fmJx0RP4bfA
# M2ZxJeVBizi33ghZHnjX4+xROSrSSZ0/j/U7gYPnhmwnl5SctprBc7HFPV+BtZv1
# VGDVnhqylam4vmAXAdrxQ0xHGwp9+ivqqtdVVDU50k5LUmV6+GlmWyxIJUOh0xzf
# Qjd9Z7OfLq006h+l9o+u3AnS6RdwsPXJP7z27i5AH+upQronsemQ27R9HkznEa05
# yH2fKdw71qWivEN+IR1vrN6q0J9xujjq77+t+yyVwZK4kXOXAQ2dT69D4knqMlFS
# sH6avnXNZQyJZMsNWaEt3rr/8Nr9gGMDQGLSFxi479Zy19aT/fHzsAtu2ocBuTqL
# VwnxrZyiJ66P70EBJKO5eQECAwEAAaOCAUkwggFFMB0GA1UdDgQWBBTQGl3CUWdS
# DBiLOEgh/14F3J/DjTAfBgNVHSMEGDAWgBSfpxVdAF5iXYP05dJlpxtTNRnpcjBf
# BgNVHR8EWDBWMFSgUqBQhk5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3Bz
# L2NybC9NaWNyb3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIwMjAxMCgxKS5jcmww
# bAYIKwYBBQUHAQEEYDBeMFwGCCsGAQUFBzAChlBodHRwOi8vd3d3Lm1pY3Jvc29m
# dC5jb20vcGtpb3BzL2NlcnRzL01pY3Jvc29mdCUyMFRpbWUtU3RhbXAlMjBQQ0El
# MjAyMDEwKDEpLmNydDAMBgNVHRMBAf8EAjAAMBYGA1UdJQEB/wQMMAoGCCsGAQUF
# BwMIMA4GA1UdDwEB/wQEAwIHgDANBgkqhkiG9w0BAQsFAAOCAgEAWoa7N86wCbjA
# Al8RGYmBZbS00ss+TpViPnf6EGZQgKyoaCP2hc01q2AKr6Me3TcSJPNWHG14pY4u
# hMzHf1wJxQmAM5Agf4aO7KNhVV04Jr0XHqUjr3T84FkWXPYMO4ulQG6j/+/d7gqe
# zjXaY7cDqYNCSd3F4lKx0FJuQqpxwHtML+a4U6HODf2Z+KMYgJzWRnOIkT/od0oI
# Xyn36+zXIZRHm7OQij7ryr+fmQ23feF1pDbfhUSHTA9IT50KCkpGp/GBiwFP/m1d
# rd7xNfImVWgb2PBcGsqdJBvj6TX2MdUHfBVR+We4A0lEj1rNbCpgUoNtlaR9Dy2k
# 2gV8ooVEdtaiZyh0/VtWfuQpZQJMDxgbZGVMG2+uzcKpjeYANMlSKDhyQ38wboAi
# vxD4AKYoESbg4Wk5xkxfRzFqyil2DEz1pJ0G6xol9nci2Xe8LkLdET3u5RGxUHam
# 8L4KeMW238+RjvWX1RMfNQI774ziFIZLOR+77IGFcwZ4FmoteX1x9+Bg9ydEWNBP
# 3sZv9uDiywsgW40k00Am5v4i/GGiZGu1a4HhI33fmgx+8blwR5nt7JikFngNuS83
# jhm8RHQQdFqQvbFvWuuyPtzwj5q4SpjO1SkOe6roHGkEhQCUXdQMnRIwbnGpb/2E
# sxadokK8h6sRZMWbriO2ECLQEMzCcLAwggdxMIIFWaADAgECAhMzAAAAFcXna54C
# m0mZAAAAAAAVMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZp
# Y2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0yMTA5MzAxODIyMjVaFw0zMDA5MzAxODMy
# MjVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIICIjANBgkqhkiG9w0B
# AQEFAAOCAg8AMIICCgKCAgEA5OGmTOe0ciELeaLL1yR5vQ7VgtP97pwHB9KpbE51
# yMo1V/YBf2xK4OK9uT4XYDP/XE/HZveVU3Fa4n5KWv64NmeFRiMMtY0Tz3cywBAY
# 6GB9alKDRLemjkZrBxTzxXb1hlDcwUTIcVxRMTegCjhuje3XD9gmU3w5YQJ6xKr9
# cmmvHaus9ja+NSZk2pg7uhp7M62AW36MEBydUv626GIl3GoPz130/o5Tz9bshVZN
# 7928jaTjkY+yOSxRnOlwaQ3KNi1wjjHINSi947SHJMPgyY9+tVSP3PoFVZhtaDua
# Rr3tpK56KTesy+uDRedGbsoy1cCGMFxPLOJiss254o2I5JasAUq7vnGpF1tnYN74
# kpEeHT39IM9zfUGaRnXNxF803RKJ1v2lIH1+/NmeRd+2ci/bfV+AutuqfjbsNkz2
# K26oElHovwUDo9Fzpk03dJQcNIIP8BDyt0cY7afomXw/TNuvXsLz1dhzPUNOwTM5
# TI4CvEJoLhDqhFFG4tG9ahhaYQFzymeiXtcodgLiMxhy16cg8ML6EgrXY28MyTZk
# i1ugpoMhXV8wdJGUlNi5UPkLiWHzNgY1GIRH29wb0f2y1BzFa/ZcUlFdEtsluq9Q
# BXpsxREdcu+N+VLEhReTwDwV2xo3xwgVGD94q0W29R6HXtqPnhZyacaue7e3Pmri
# Lq0CAwEAAaOCAd0wggHZMBIGCSsGAQQBgjcVAQQFAgMBAAEwIwYJKwYBBAGCNxUC
# BBYEFCqnUv5kxJq+gpE8RjUpzxD/LwTuMB0GA1UdDgQWBBSfpxVdAF5iXYP05dJl
# pxtTNRnpcjBcBgNVHSAEVTBTMFEGDCsGAQQBgjdMg30BATBBMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL0RvY3MvUmVwb3NpdG9y
# eS5odG0wEwYDVR0lBAwwCgYIKwYBBQUHAwgwGQYJKwYBBAGCNxQCBAweCgBTAHUA
# YgBDAEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB/wQFMAMBAf8wHwYDVR0jBBgwFoAU
# 1fZWy4/oolxiaNE9lJBb186aGMQwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2Ny
# bC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljUm9vQ2VyQXV0XzIw
# MTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXRfMjAxMC0w
# Ni0yMy5jcnQwDQYJKoZIhvcNAQELBQADggIBAJ1VffwqreEsH2cBMSRb4Z5yS/yp
# b+pcFLY+TkdkeLEGk5c9MTO1OdfCcTY/2mRsfNB1OW27DzHkwo/7bNGhlBgi7ulm
# ZzpTTd2YurYeeNg2LpypglYAA7AFvonoaeC6Ce5732pvvinLbtg/SHUB2RjebYIM
# 9W0jVOR4U3UkV7ndn/OOPcbzaN9l9qRWqveVtihVJ9AkvUCgvxm2EhIRXT0n4ECW
# OKz3+SmJw7wXsFSFQrP8DJ6LGYnn8AtqgcKBGUIZUnWKNsIdw2FzLixre24/LAl4
# FOmRsqlb30mjdAy87JGA0j3mSj5mO0+7hvoyGtmW9I/2kQH2zsZ0/fZMcm8Qq3Uw
# xTSwethQ/gpY3UA8x1RtnWN0SCyxTkctwRQEcb9k+SS+c23Kjgm9swFXSVRk2XPX
# fx5bRAGOWhmRaw2fpCjcZxkoJLo4S5pu+yFUa2pFEUep8beuyOiJXk+d0tBMdrVX
# VAmxaQFEfnyhYWxz/gq77EFmPWn9y8FBSX5+k77L+DvktxW/tM4+pTFRhLy/AsGC
# onsXHRWJjXD+57XQKBqJC4822rpM+Zv/Cuk0+CQ1ZyvgDbjmjJnW4SLq8CdCPSWU
# 5nR0W2rRnj7tfqAxM328y+l7vzhwRNGQ8cirOoo6CGJ/2XBjU02N7oJtpQUQwXEG
# ahC0HVUzWLOhcGbyoYIC1DCCAj0CAQEwggEAoYHYpIHVMIHSMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJl
# bGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNO
# OjhENDEtNEJGNy1CM0I3MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQBxi0Tolt0eEqXCQl4qgJXUkiQOYaCBgzCB
# gKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0GCSqGSIb3DQEBBQUA
# AgUA5+cbmzAiGA8yMDIzMDQxNzA5MTI1OVoYDzIwMjMwNDE4MDkxMjU5WjB0MDoG
# CisGAQQBhFkKBAExLDAqMAoCBQDn5xubAgEAMAcCAQACAheuMAcCAQACAhJbMAoC
# BQDn6G0bAgEAMDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEA
# AgMHoSChCjAIAgEAAgMBhqAwDQYJKoZIhvcNAQEFBQADgYEAT6QNzpFXvC0Zi4FD
# JFf6itndVReMk47imnBnC2nZf4513BWP8fhBdYmwwIb+qgjQlzfTLuK/T+nfKePJ
# teSJOA0V4SE1yy1EDqWKzWovrgwkM4SSLf7zu6Smfn3qqQYpt3e8TFaXiFhnrblx
# Q5t0KmVdvu0snAH95l/nrT7zUyMxggQNMIIECQIBATCBkzB8MQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGlt
# ZS1TdGFtcCBQQ0EgMjAxMAITMwAAAbP+Jc4pGxuKHAABAAABszANBglghkgBZQME
# AgEFAKCCAUowGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJ
# BDEiBCBON2CYBhBZp51dDzHJ2RF5eXIvaiPgP6wOkhOXc5WO9TCB+gYLKoZIhvcN
# AQkQAi8xgeowgecwgeQwgb0EIIahM9UqENIHtkbTMlBlQzaOT+WXXMkaHoo6Gfvq
# T79CMIGYMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAGz
# /iXOKRsbihwAAQAAAbMwIgQgo/if/09SoIaXpTAgAKfyWNsw7nno7Is/w20oDLAo
# U1IwDQYJKoZIhvcNAQELBQAEggIAkbdhB2Y91I70YdbPtNCzp1OR/dVIkznnr/mp
# TwW7KTc+4iMPzujLgTX7HyWQuzDoWL+lFykNpA0qInw8BkZuMAH+QReGJBtkcMN5
# GCqwrEzwn+9I5m5/R5L8ZhiOfwLXqjIqd5JgRBGwDlf/r9vJUw6iKem31ptasToP
# VCY6ti7OHH/Nxnyu/skJZAi9sMaCKF705z4a+LvSTBaWd/tiIqELsKvlcfFHRleD
# lzCtRBhb81XP4/yfdoPGs/mQItA+d9Rr/ZGJeIEJs1qP7Ft9CF8u9119jPYbrwwD
# rD6NzN3IcG+rGUscGwOwHQyR5sbQ/Khq9Bui3q1TLXvtlV8k5h/faa+mkn5NzMdN
# W4zoOwGC+qg95Vi3jZ0/h5hViIF32BUiJKFcIvXGa8Eg4591uNwPrhmG7lAOOxT4
# 4AXVFT205EMh8HCTaVfv01b2jbv+cuX9tA3+VLKZrCHNoZb1C03PxKXgga4DBdMX
# QBlZ3OTtNj7F65iyeyko+it23UMzj7VjmB41f7uWrxZk/C+xq+hB9UFQQQYXGntn
# 4doM9ulyELxGAmMueoJor4zXBbK1x9PcITpzgcNmbLS0Do5JJDd3TOXOOpRRyXiq
# 4uqcMIlkOrbXTl24AdzKxC/T2E77pgfJqqWrZotaf/ksf45xwKIQVBcC+uEAh2oS
# KIDepbY=
# SIG # End signature block
