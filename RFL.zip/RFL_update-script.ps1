# Name: RFL_update-script.ps1 forSDPcheck
# last edit by: waltere 2022-09-12

<# 
.SYNOPSIS
	Script to [auto-]update RFL to latest version or download latest zip from CesdiagTools/GitHub.

.DESCRIPTION
	Script will search on "https://microsoft.githubenterprise.com/css-windows/WindowsCSSToolsDevRep/releases/tag" / GitHub for latest RFL version
	If local version does not match the remote CesdiagTools/GitHub version, it will download and replace RFL with latest version
	Script gets the current version from version_SDPcheck.dat and compares to version on 'https://cesdiagtools.blob.core.windows.net/windows/RFL.ver' /GitHub.

.PARAMETER RFL_action
	choose action from allowed values: "Download" or "Update" or "Version"
		Download	= download latest CesdiagTools/GitHub version
		Update		= update current local version
		Version		= decide based on local version, try AutoUpdate if local version is lower than CesdiagTools/GitHub version
	Ex: -RFL_action "Download"

.PARAMETER RFL_file
	Specify filename from allowed values: "RFL.zip" or "RFL_DB.zip"
	Ex: .\RFL_update-script.ps1 -RFL_file "RFL.zip"

.PARAMETER RFL_path
	Specify the local path where check-rfl-csv_Tech_Path.ps1 is located.
	Ex: .\RFL_update-script.ps1 -RFL_path "C:\RFL"

.PARAMETER UpdMode
	Specify the mode: 
		Online  = complete package (RFL.zip) from aka.ms/getRFL
		Full    = complete package (RFL.zip) from CesdiagTools/GitHub
		Quick   = differential package only (RFL_DB.zip): replace only database files
		Force   = run a Full update, regardless of current installed version

.PARAMETER RFL_arch
	Specify the System Architecture.
	Allowed values:
		x64 - For 64-bit systems
		x86 - For 32-bit systems
	Ex: .\RFL_update-script.ps1 -RFL_arch "x64"

.EXAMPLE
	Example 1: Update RFL in folder C:\RFL
	.\RFL_update-script.ps1 -RFL_action "Update" -RFL_path "C:\RFL" -RFL_file "RFL.zip"

.LINK
	https://microsoft.githubenterprise.com/css-windows/WindowsCSSToolsDevRep/releases/tag
	Public Download: RFL:    https://cesdiagtools.blob.core.windows.net/windows/RFL.zip -or- https://aka.ms/getRFL or aka.ms/getRFL
#>


param(
	[ValidateSet("download","update","version")]
	[Parameter(Mandatory=$False,Position=0,HelpMessage='Choose from: download|update|version')]
	[string]$RFL_action 	= "update",
	[string]$RFL_path 		= (Split-Path $MyInvocation.MyCommand.Path -Parent),
	[ValidateSet("Online","Full","Quick","Force")]
	[string]$UpdMode 		= "Full",
	[ValidateSet("RFL.zip","RFL_DB.zip")]
	[string]$RFL_file 		= "RFL.zip",
	[ValidateSet("x64","x86")]
	[string]$RFL_arch 		= "x64",
	[switch]$AutoUpd		= $False,							# 
	[switch]$UseExitCode 	= $true								# This will cause the script to bail out after the error is logged if an error occurs.
)

#region  ::::: [Variables] -----------------------------------------------------------#
$verDateScript	= "2022.09.12.0"
$ScriptFolder = Split-Path $MyInvocation.MyCommand.Path -Parent
$RflUpdLogfile 		= $RFL_path + "\_RFL_Update-Log.txt"
$script:ChkFailed	= $FALSE
$invocation 		= (Get-Variable MyInvocation).Value
$ScriptParentPath 	= $MyInvocation.MyCommand.Path | Split-Path -Parent
$scriptName 		= $invocation.MyCommand.Name
if ($UpdMode -match 'Online') {
	$RFLReleaseServer = "cesdiagtools.blob.core.windows.net"
	$RFL_release_url  = "https://cesdiagtools.blob.core.windows.net/windows"
} else {
	$RFLReleaseServer = "api.Github.com"
	$RFL_release_url  = "https://api.github.com/repos/walter-1/offline-SDPcheck/releases"
}
#endregion  ::::: [Variables] --------------------------------------------------------#
# Load Common Library /module
	Remove-Module Utils_RflUpd -ErrorAction Ignore
	Import-Module $ScriptFolder\Utils_RflUpd.psm1 -DisableNameChecking
	  
$Script:BeginTimeStamp = Get-Date

#region Logging functions
# Check if trailing "\" was provided in $RFL_path, if it was not, add it
if (-not $RFL_path.EndsWith("\")){
	$RFL_path = $RFL_path + "\"
}

Function global:RflEnterFunc([String]$FunctionName){
	Write-Verbose "---> Enter $FunctionName"
}

Function global:RflEndFunc([String]$FunctionName){
	Write-Verbose "<--- End $FunctionName"
}
#endregion Logging functions

#region  ::::: [MAIN] ----------------------------------------------------------------#
# detect OS version and SKU # Note: gwmi / Get-WmiObject is no more supportd in PS v7 -> use Get-CimInstance
If($Host.Version.Major -ge 7){
	[Reflection.Assembly]::LoadWithPartialName("System.ServiceProcess.servicecontroller") | Out-Null
	$wmiOSVersion = Get-CimInstance -Namespace "root\cimv2" -Class Win32_OperatingSystem
} else {$wmiOSVersion = Get-WmiObject -Namespace "root\cimv2" -Class Win32_OperatingSystem}
[int]$bn = [int]$wmiOSVersion.BuildNumber
#Write-verbose "installed-version: $(get_local_RFL_version current) - Build: $bn"
$installedRFLver = New-Object System.Version([version]$(get_local_RFL_version "current"))
Write-verbose "installedRFLver: $installedRFLver"

## :: Criteria to use Quick (DB only) vs. Online update: Quick if UpdMode = Quick; Online = if full package is needed, ...
# Choose download file based on $UpdMode (and current installed RFL build)
$RFL_file = "RFL.zip"
switch ($UpdMode) {
        "Quick"	{ 	$RFL_file = "RFL_DB.zip"
					$UpdateSource= "GitHub"}
		"Online"{ 	$RFL_file = "RFL.zip"
					$UpdateSource= "CesdiagTools"}
        default	{ 	$RFL_file = "RFL.zip"
					$UpdateSource= "GitHub"}
}
		
# Check for Internet connectivity // Test-NetConnection does not work for Win7
$isReachable = FwTestConnWebSite $RFLReleaseServer -ErrorAction SilentlyContinue
if ( $isReachable -eq "True") {
	if ($UpdMode -Notmatch "Online") {
		$script:expectedVersion = New-Object System.Version(get_latest_RFL_version $RFL_release_url)
	}
	if ("$($script:expectedVersion)" -eq "0.0") { Write-Verbose "Bail out: $script:expectedVersion"; ExitWithCode 20}
	# Check if RFL exists in $RFL_path
	if (-not (Test-Path ($RFL_path + "check-rfl-csv_Tech_Path.ps1"))){
		Write-Host -ForegroundColor Red "[Warning] check-rfl-csv_Tech_Path.ps1 could not be located in $RFL_path"
		DownloadFileFromGitHubRelease "update" $RFL_file $installedRFLver
	}

	if (Test-Path ($RFL_path + "check-rfl-csv_Tech_Path.ps1")){
		if ($UpdMode -match "Online") {
			DownloadRFLZipFromCesdiagRelease -File "RFL.zip"
		}
		elseif ($UpdMode -match "Force") {	# update regardless of current local version
		Write-Host -ForegroundColor Cyan "[Forced update:] to latest version $script:expectedVersion from $UpdateSource`n"
		 if (Test-Path ($RFL_path + "x64\TTTracer.exe")) { Write-Host -ForegroundColor Yellow "[note:] This procedure will not refresh iDNA part"}
									DownloadFileFromGitHubRelease "update" $RFL_file $installedRFLver
		} else {
			Write-Host "[Info] checking current version $installedRFLver in $RFL_path against latest released $UpdateSource version $script:expectedVersion."
			if ($($installedRFLver.CompareTo($script:expectedVersion)) -eq 0) { 		# If versions match, display message
				"`n [Info] Latest RFL version $script:expectedVersion is installed. " | Out-File $RflUpdLogfile -Append
				Write-Host -ForegroundColor Cyan "[Info] Latest RFL version $script:expectedVersion is installed.`n"}
			elseif ($($installedRFLver.CompareTo($script:expectedVersion)) -lt 0) {	# if installed current version is lower than latest $UpdateSource Release version
				"`n [Action: $RFL_action -[Warning] Actually installed RFL version $installedRFLver is outdated] " | Out-File $RflUpdLogfile -Append
				Write-Host -ForegroundColor red "[Warning] Actually installed RFL version $installedRFLver is outdated"
				Write-Host "[Info] Expected latest RFL version on $($UpdateSource) = $script:expectedVersion"
				Write-Host -ForegroundColor yellow "[Warning] ** Update will overwrite customized Shell script, latest Rfl-Check_ShellExtension.reg is preserved in Rfl-Check_ShellExtension.reg_backup. ** "
				switch($RFL_action)
					{
					"download"		{ 	Write-Host "[download:] latest $RFL_file"
										DownloadFileFromGitHubRelease "download" $RFL_file $installedRFLver
									}
					"update"		{ 	Write-Host "[update:] to latest version $script:expectedVersion from $UpdateSource " 
										DownloadFileFromGitHubRelease "update" $RFL_file $installedRFLver
									}
					"version"		{ 	Write-Host -background darkRed "[version:] installed RFL version is outdated, please run 'RFL Update', trying AutoUpate" # or answer next question with 'Yes'"
										Write-Host -ForegroundColor Cyan "[Info] running AutoUpdate now... (to avoid updates, append RFL switch 'noUpdate')"
										DownloadFileFromGitHubRelease "update" $RFL_file $installedRFLver
									}
					}
					"`n [Action: $RFL_action - OK] " | Out-File $RflUpdLogfile -Append
			}
			else {	# if installed current version is greater than latest CesdiagTools/GitHub Release version
				if ($script:ChkFailed) {Write-Host -ForegroundColor Gray "[Info] Version check failed! Expected version on $($UpdateSource) = $script:expectedVersion. Please download https://aka.ms/getRFL `n"}
				Write-Verbose "Match: Current installed RFL version:  $installedRFLver"
				Write-Verbose "Expected latest RFL version on $($UpdateSource) = $script:expectedVersion"
			}
		}
	}
} else {
	Write-Host -ForegroundColor Red "[failed update] Missing secure internet connection to $RFLReleaseServer. Please download https://aka.ms/getRFL `n"
								 "`n [failed update] Missing secure internet connection to $RFLReleaseServer. Please download https://aka.ms/getRFL `n" | Out-File $RflUpdLogfile -Append
}

$ScriptEndTimeStamp = Get-Date
$Duration = $(New-TimeSpan -Start $Script:BeginTimeStamp -End $ScriptEndTimeStamp)

Write-Host -ForegroundColor Black -background gray "[Info] Script $scriptName v$verDateScript execution finished. Duration: $Duration"
if ($AutoUpd) { Write-Host -ForegroundColor Yellow  "[AutoUpdate done] .. Please repeat your RFL command now."}
#endregion  ::::: [MAIN] -------------------------------------------------------------#

#region  ::::: [ToDo] ----------------------------------------------------------------#
<# 
 ToDo: 

- Implement a scheduled task for periodic update check
Example one-line command: schtasks.exe /Create /SC DAILY /MO 1 /TN "RFL Updater" /TR "powershell \path\to\script\get-latest-check-rfl-csv_Tech_Path.ps1 -RFL_path 'path\to\where\RFL\is' -RFL_arch 'x64'" /ST 12:00 /F
	[/SC DAILY]: Run daily
	[/MO 1]: Every Day
	[/TN "RFL Updater"]: Task Name
	[/TR "powershell \path\to\script\get-latest-check-rfl-csv_Tech_Path.ps1 -RFL_path 'path\to\where\RFL\is' -RFL_arch 'x64'"]: Command to run
	[/ST 12:00]: Run at 12 PM
	[/F]: Force update
#>
#endregion  ::::: [ToDo] ----------------------------------------------------------------#

