# Name: RFL_update-script.ps1 forSDPcheck in OfflineMode
# last edit by: waltere

<# 
.SYNOPSIS
	For offline-SDPcheck: Script to [auto-]update RFL to latest version or download latest RFL.zip from CesdiagTools/GitHub.

.DESCRIPTION
	For offline-SDPcheck: Script will search on "https://microsoft.githubenterprise.com/css-windows/WindowsCSSToolsDevRep/releases/tag" / GitHub for latest RFL version
	If local version does not match the remote CesdiagTools/GitHub version, it will download and replace RFL with latest version
	Script gets the current version from _SDPcheck.ini and compares to version on 'https://cesdiagtools.blob.core.windows.net/windows/RFL.ver' /GitHub.

.PARAMETER RFL_action
	choose action from allowed values: "Download" or "Update" or "Version"
		Download	= download latest CesdiagTools/GitHub version
		Update		= update current local version
		Version		= decide based on local version, try AutoUpdate if local version is lower than CesdiagTools/GitHub version
	Ex: -RFL_action "Download"

.PARAMETER RFL_file
	Specify filename from allowed values: "RFL.zip" or "RFL_DB.zip"
	Ex: .\RFL_update-script.ps1 -RFL_file "RFL.zip"

.PARAMETER RFL_path
	Specify the local path where check-rfl-csv_Tech_Path.ps1 is located.
	Ex: .\RFL_update-script.ps1 -RFL_path "C:\RFL"

.PARAMETER UpdMode
	Specify the mode: 
		Online  = complete package (RFL.zip) from aka.ms/getRFL
		Full    = complete package (RFL.zip) from CesdiagTools/GitHub
		Quick   = differential package only (RFL_DB.zip): replace only database files
		Force   = run a Full update, regardless of current installed version

.PARAMETER RFL_arch
	Specify the System Architecture.
	Allowed values:
		x64 - For 64-bit systems
		x86 - For 32-bit systems
	Ex: .\RFL_update-script.ps1 -RFL_arch "x64"

.EXAMPLE
	Example 1: Update RFL in folder C:\RFL
	.\RFL_update-script.ps1 -RFL_action "Update" -RFL_path "C:\RFL" -RFL_file "RFL.zip"

.LINK
	https://microsoft.githubenterprise.com/css-windows/WindowsCSSToolsDevRep/releases/tag
	Public Download: RFL:    https://cesdiagtools.blob.core.windows.net/windows/RFL.zip -or- https://aka.ms/getRFL or aka.ms/getRFL
#>


[CmdletBinding()]
PARAM (
	[ValidateSet("download","update","version")]
	[Parameter(Mandatory=$False,Position=0,HelpMessage='Choose from: download|update|version')]
	[string]$RFL_action 	= "update",
	[string]$RFL_path 		= (Split-Path $MyInvocation.MyCommand.Path -Parent),
	[ValidateSet("Online","Full","Quick","Force")]
	[string]$UpdMode 		= "Online",
	[ValidateSet("RFL.zip","RFL_DB.zip")]
	[string]$RFL_file 		= "RFL.zip",
	[ValidateSet("x64","x86")]
	[string]$RFL_arch 		= "x64",
	[switch]$AutoUpd		= $False,							# 
	[switch]$UseExitCode 	= $true								# This will cause the script to bail out after the error is logged if an error occurs.
)

#region  ::::: [Variables] -----------------------------------------------------------#
$verDateScript	= "2023.06.07.0"
$ScriptFolder = Split-Path $MyInvocation.MyCommand.Path -Parent

$script:ChkFailed	= $FALSE
$invocation 		= (Get-Variable MyInvocation).Value
$ScriptParentPath 	= $MyInvocation.MyCommand.Path | Split-Path -Parent
$scriptName 		= $invocation.MyCommand.Name
if ($UpdMode -match 'Online') {
	$RflUpdLogfile 		= $env:TEMP + "\_RFL_Update-Log.txt"
	$RFLReleaseServer = "cesdiagtools.blob.core.windows.net"
	$RFL_release_url  = "https://cesdiagtools.blob.core.windows.net/windows"
} else {
	$RflUpdLogfile 		= $ScriptFolder + "\_RFL_Update-Log.txt"
	$RFLReleaseServer = "api.Github.com"
	$RFL_release_url  = "https://api.github.com/repos/walter-1/offline-SDPcheck/releases"
}
#endregion  ::::: [Variables] --------------------------------------------------------#
	# Load Common Library:
	. $ScriptFolder\Utils_RflShared.ps1
	. $ScriptFolder\Utils_RflUpd.ps1
	  
$Script:BeginTimeStamp = Get-Date


# Check if trailing "\" was provided in $RFL_path, if it was not, add it
if (-not $RFL_path.EndsWith("\")){
	$RFL_path = $RFL_path + "\"
}

#region  ::::: [MAIN] ----------------------------------------------------------------#
	# detect OS version and SKU # Note: gwmi / Get-WmiObject is no more supportd in PS v7 -> use Get-CimInstance
	If($Host.Version.Major -ge 7){
		[Reflection.Assembly]::LoadWithPartialName("System.ServiceProcess.servicecontroller") | Out-Null
		$wmiOSVersion = Get-CimInstance -Namespace "root\cimv2" -Class Win32_OperatingSystem
	} else {$wmiOSVersion = Get-WmiObject -Namespace "root\cimv2" -Class Win32_OperatingSystem}
	[int]$bn = [int]$wmiOSVersion.BuildNumber
	#Write-verbose "installed-version: $(get_local_RFL_version current) - Build: $bn"
	$installedRFLver = New-Object System.Version([version]$(get_local_RFL_version "current"))
	Write-verbose "installedRFLver: $installedRFLver"

	## :: Criteria to use Quick (DB only) vs. Online update: Quick if UpdMode = Quick; Online = if full package is needed, ...
	# Choose download file based on $UpdMode (and current installed RFL build)
	$RFL_file = "RFL.zip"
	switch ($UpdMode) {
			"Quick"	{ 	$RFL_file = "RFL_DB.zip"
						$UpdateSource= "GitHub"}
			"Online"{ 	$RFL_file = "RFL.zip"
						$UpdateSource= "CesdiagTools"}
			default	{ 	$RFL_file = "RFL.zip"
						$UpdateSource= "CesdiagTools"}
	}
			
	# Check for Internet connectivity // Test-NetConnection does not work for Win7
	$isReachable = FwTestConnWebSite $RFLReleaseServer -ErrorAction SilentlyContinue
	if ( $isReachable -eq "True") {
		if ($UpdMode -Notmatch "Online") {
			$script:expectedVersion = New-Object System.Version(get_latest_RFL_version $RFL_release_url)
		}
		if ("$($script:expectedVersion)" -eq "0.0") { Write-Verbose "Bail out: $script:expectedVersion"; ExitWithCode 20}
		# Check if RFL exists in $RFL_path
		if (-not (Test-Path ($RFL_path + "check-rfl-csv_Tech_Path.ps1"))){
			Write-Host -ForegroundColor Red "[Warning] check-rfl-csv_Tech_Path.ps1 could not be located in $RFL_path"
			DownloadFileFromGitHubRelease "update" $RFL_file $installedRFLver -RFL_Path $ScriptFolder
		}

		if (Test-Path ($RFL_path + "check-rfl-csv_Tech_Path.ps1")){
			if ($UpdMode -match "Online") {
				DownloadRFLZipFromCesdiagRelease -File "RFL.zip"
			}
			elseif ($UpdMode -match "Force") {	# update regardless of current local version
			Write-Host -ForegroundColor Cyan "[Forced update:] to latest version $script:expectedVersion from $UpdateSource`n"
			DownloadFileFromGitHubRelease "update" $RFL_file $installedRFLver -RFL_Path $ScriptFolder
			} else {
				Write-Host "[Info] checking current version $installedRFLver in $RFL_path against latest released $UpdateSource version $script:expectedVersion."
				if ($($installedRFLver.CompareTo($script:expectedVersion)) -eq 0) { 		# If versions match, display message
					"`n [Info] Latest RFL version $script:expectedVersion is installed. " | Out-File $RflUpdLogfile -Append
					Write-Host -ForegroundColor Cyan "[Info] Latest RFL version $script:expectedVersion is installed.`n"}
				elseif ($($installedRFLver.CompareTo($script:expectedVersion)) -lt 0) {	# if installed current version is lower than latest $UpdateSource Release version
					"`n [Action: $RFL_action -[Warning] Actually installed RFL version $installedRFLver is outdated] " | Out-File $RflUpdLogfile -Append
					Write-Host -ForegroundColor red "[Warning] Actually installed RFL version $installedRFLver is outdated"
					Write-Host "[Info] Expected latest RFL version on $($UpdateSource) = $script:expectedVersion"
					Write-Host -ForegroundColor yellow "[Warning] ** Update will overwrite customized Shell script, latest Rfl-Check_ShellExtension.reg is preserved in Rfl-Check_ShellExtension.reg_backup. ** "
					switch($RFL_action)
						{
						"download"		{ 	Write-Host "[download:] latest $RFL_file"
											DownloadFileFromGitHubRelease "download" $RFL_file $installedRFLver -RFL_Path $ScriptFolder
										}
						"update"		{ 	Write-Host "[update:] to latest version $script:expectedVersion from $UpdateSource " 
											DownloadFileFromGitHubRelease "update" $RFL_file $installedRFLver -RFL_Path $ScriptFolder
										}
						"version"		{ 	Write-Host -background darkRed "[version:] installed RFL version is outdated, please run 'RFL Update', trying AutoUpate" # or answer next question with 'Yes'"
											Write-Host -ForegroundColor Cyan "[Info] running AutoUpdate now... (to avoid updates, append RFL switch 'noUpdate')"
											DownloadFileFromGitHubRelease "update" $RFL_file $installedRFLver -RFL_Path $ScriptFolder
										}
						}
					"`n [Action: $RFL_action - OK] " | Out-File $RflUpdLogfile -Append
				}
				else {	# if installed current version is greater than latest CesdiagTools/GitHub Release version
					if ($script:ChkFailed) {Write-Host -ForegroundColor Gray "[Info] Version check failed! Expected version on $($UpdateSource) = $script:expectedVersion. Please download https://aka.ms/getRFL `n"}
					Write-Verbose "Match: Current installed RFL version:  $installedRFLver"
					Write-Verbose "Expected latest RFL version on $($UpdateSource) = $script:expectedVersion"
				}
			}
		}
	} else {
		Write-Host -ForegroundColor Red "[failed update] Missing secure internet connection to $RFLReleaseServer. Please download https://aka.ms/getRFL `n"
									 "`n [failed update] Missing secure internet connection to $RFLReleaseServer. Please download https://aka.ms/getRFL `n" | Out-File $RflUpdLogfile -Append
	}

	$ScriptEndTimeStamp = Get-Date
	$Duration = $(New-TimeSpan -Start $Script:BeginTimeStamp -End $ScriptEndTimeStamp)

	Write-Host -ForegroundColor Black -background gray "[Info] Script $scriptName v$verDateScript execution finished. Duration: $Duration"
	if ($AutoUpd) { Write-Host -ForegroundColor Yellow  "[AutoUpdate done] .. Please repeat your RFL command now."}
#endregion  ::::: [MAIN] -------------------------------------------------------------#

#region  ::::: [ToDo] ----------------------------------------------------------------#
<# 
 ToDo: 

- Implement a scheduled task for periodic update check
Example one-line command: schtasks.exe /Create /SC DAILY /MO 1 /TN "RFL Updater" /TR "powershell \path\to\script\get-latest-check-rfl-csv_Tech_Path.ps1 -RFL_path 'path\to\where\RFL\is' -RFL_arch 'x64'" /ST 12:00 /F
	[/SC DAILY]: Run daily
	[/MO 1]: Every Day
	[/TN "RFL Updater"]: Task Name
	[/TR "powershell \path\to\script\get-latest-check-rfl-csv_Tech_Path.ps1 -RFL_path 'path\to\where\RFL\is' -RFL_arch 'x64'"]: Command to run
	[/ST 12:00]: Run at 12 PM
	[/F]: Force update
#>
#endregion  ::::: [ToDo] ----------------------------------------------------------------#


# SIG # Begin signature block
# MIInvwYJKoZIhvcNAQcCoIInsDCCJ6wCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCRnggvfLYJcRm/
# mUO8s5RBIaMAMYg6h4h2Vs1jsam8eqCCDXYwggX0MIID3KADAgECAhMzAAADTrU8
# esGEb+srAAAAAANOMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjMwMzE2MTg0MzI5WhcNMjQwMzE0MTg0MzI5WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDdCKiNI6IBFWuvJUmf6WdOJqZmIwYs5G7AJD5UbcL6tsC+EBPDbr36pFGo1bsU
# p53nRyFYnncoMg8FK0d8jLlw0lgexDDr7gicf2zOBFWqfv/nSLwzJFNP5W03DF/1
# 1oZ12rSFqGlm+O46cRjTDFBpMRCZZGddZlRBjivby0eI1VgTD1TvAdfBYQe82fhm
# WQkYR/lWmAK+vW/1+bO7jHaxXTNCxLIBW07F8PBjUcwFxxyfbe2mHB4h1L4U0Ofa
# +HX/aREQ7SqYZz59sXM2ySOfvYyIjnqSO80NGBaz5DvzIG88J0+BNhOu2jl6Dfcq
# jYQs1H/PMSQIK6E7lXDXSpXzAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUnMc7Zn/ukKBsBiWkwdNfsN5pdwAw
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzUwMDUxNjAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAD21v9pHoLdBSNlFAjmk
# mx4XxOZAPsVxxXbDyQv1+kGDe9XpgBnT1lXnx7JDpFMKBwAyIwdInmvhK9pGBa31
# TyeL3p7R2s0L8SABPPRJHAEk4NHpBXxHjm4TKjezAbSqqbgsy10Y7KApy+9UrKa2
# kGmsuASsk95PVm5vem7OmTs42vm0BJUU+JPQLg8Y/sdj3TtSfLYYZAaJwTAIgi7d
# hzn5hatLo7Dhz+4T+MrFd+6LUa2U3zr97QwzDthx+RP9/RZnur4inzSQsG5DCVIM
# pA1l2NWEA3KAca0tI2l6hQNYsaKL1kefdfHCrPxEry8onJjyGGv9YKoLv6AOO7Oh
# JEmbQlz/xksYG2N/JSOJ+QqYpGTEuYFYVWain7He6jgb41JbpOGKDdE/b+V2q/gX
# UgFe2gdwTpCDsvh8SMRoq1/BNXcr7iTAU38Vgr83iVtPYmFhZOVM0ULp/kKTVoir
# IpP2KCxT4OekOctt8grYnhJ16QMjmMv5o53hjNFXOxigkQWYzUO+6w50g0FAeFa8
# 5ugCCB6lXEk21FFB1FdIHpjSQf+LP/W2OV/HfhC3uTPgKbRtXo83TZYEudooyZ/A
# Vu08sibZ3MkGOJORLERNwKm2G7oqdOv4Qj8Z0JrGgMzj46NFKAxkLSpE5oHQYP1H
# tPx1lPfD7iNSbJsP6LiUHXH1MIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGZ8wghmbAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAANOtTx6wYRv6ysAAAAAA04wDQYJYIZIAWUDBAIB
# BQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIGITV4myScq++dTUp4EiUZ/D
# FWO4Oef356eZ3pErVL4nMEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEB
# BQAEggEAubML2ugYguSipW6QfEkMLmTjEOi9BIGG0lpkEITL2RNKxBjBB6hJl1zC
# 7BrCJtWd9SdY/Vf6QAsxvvqdpO0G35K/AQtwZy6ReWQjuszecsSLY5m8XQcwrqCz
# AkzNfAoeQ/Fo3sUHQk7MkDrYEArxOZeWQVtiRwr6LGkk3VICv8TCky9DCR8N0qPp
# jvxWMMIpcZG2FVJ1XOsiravvy1QZRPcieYwlkI+8CgvzFAi0DPa9esE+kQ+G/8Dc
# LBD6zq4G0e5zjo0ozTnYXVbLctMjTu2utyn2f7QlurUiCKl+ueZfOeCZ+7sYlrlI
# JH9H2a2WNqvGL6m8T2uYETAaSJocBKGCFykwghclBgorBgEEAYI3AwMBMYIXFTCC
# FxEGCSqGSIb3DQEHAqCCFwIwghb+AgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFZBgsq
# hkiG9w0BCRABBKCCAUgEggFEMIIBQAIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFl
# AwQCAQUABCBUo9Sf9QEiQDAmpCsuNbKWjzI6t4U1VH/6n+k1JiGRgwIGZGzzs7dL
# GBMyMDIzMDYxNDE1NTkxOC43MThaMASAAgH0oIHYpIHVMIHSMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJl
# bGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNO
# OkZDNDEtNEJENC1EMjIwMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNloIIReDCCBycwggUPoAMCAQICEzMAAAG59gANZVRPvAMAAQAAAbkwDQYJ
# KoZIhvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjIw
# OTIwMjAyMjE3WhcNMjMxMjE0MjAyMjE3WjCB0jELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IElyZWxhbmQgT3Bl
# cmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjpGQzQxLTRC
# RDQtRDIyMDElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZTCC
# AiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAONJPslh9RbHyQECbUIINxMF
# 5uQkyN07VIShITXubLpWnANgBCLvCcJl7o/2HHORnsRcmSINJ/qclAmLIrOjnYnr
# bocAnixiMEXC+a1sZ84qxYWtEVY7VYw0LCczY+86U/8shgxqsaezKpWriPOcpV1S
# h8SsOxf30yO7jvld/IBA3T6lHM2pT/HRjWk/r9uyx0Q4atx0mkLVYS9y55/oTlKL
# E00h792S+maadAdy3VgTweiwoEOXD785wv3h+fwH/wTQtC9lhAxhMO4p+OP9888W
# xkbl6BqRWXud54RTzqp2Vr+yen1Q1A6umyMB7Xq0snIYG5B1Acc4UgJlPQ/ZiMkq
# gxQNFCWQvz0G9oLgSPD8Ky0AkX22PcDOboPuNT4RceWPX0UVZUsX9IUgs7QF41Hi
# QSwEeOOHGyrfQdmSslATrbmH/18M5QrsTM5JINjct9G42xqN8VF9Z8WOiGMjNbvl
# pcEmmysYl5QyhrEDoFnQTU7bFrD3JX0fIfu1sbLWeBqXwbp4Z8yACTtphK2VbzOv
# i4vc0RCmRNzvYQQ2PjZ7NaTXE4Gu3vggAJ+rtzUTAfJotvOSqcMgNwLZa1Y+ET/l
# b0VyjrYwFuHtg0QWyQjP5350LTpv086pyVUh4A3w/Os5hTGFZgFe5bCyMnpY09M0
# yPdHaQ/56oYUsSIcyKyVAgMBAAGjggFJMIIBRTAdBgNVHQ4EFgQUt7A4cdtYQ5oJ
# jE1ZqrSonp41RFIwHwYDVR0jBBgwFoAUn6cVXQBeYl2D9OXSZacbUzUZ6XIwXwYD
# VR0fBFgwVjBUoFKgUIZOaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9j
# cmwvTWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3JsMGwG
# CCsGAQUFBwEBBGAwXjBcBggrBgEFBQcwAoZQaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNyb3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIw
# MjAxMCgxKS5jcnQwDAYDVR0TAQH/BAIwADAWBgNVHSUBAf8EDDAKBggrBgEFBQcD
# CDAOBgNVHQ8BAf8EBAMCB4AwDQYJKoZIhvcNAQELBQADggIBAM3cZ7NFUHRMsLKz
# jl7rJPIkv7oJ+s9kkut0hZif9WSt60SzYGULp1zmdPqc+w8eHTkhqX0GKCp2TTqS
# zBXBhwHOm8+p6hUxNlDewGMZUos952aTXblAT3OKBnfVBLQyUavrSjuJGZAW30cN
# Y3rjVDUlGD+VygQHySaDaviJQbK6/6fQvUUFoqIk3ldGfjnAtnebsVlqh6WWamVc
# 5AZdpWR1jSzN/oxKYqc1BG4SxxlPtcfrAdBz/cU4bxVXqAAf02NZscvJNpRnOALf
# 5kVo2HupJXCsk9TzP5PNW2sTS3TmwhIQmPxr0E0UqOojUrBJUOhbITAxcnSa/IMl
# uL1HXRtLQZI+xs2eRtuPOUsKUW71/1YeqsYCLHLvu82ceDVQQvP7GHEEkp2kEjio
# fbjYErBo2iCEaxxeX4Z9HvAgA4MsQkbn6e4EFQf13sP+Kn3XgMIvJbqLJeFcQja+
# SUeOXu5cfkxe0GzTNojdyIwzaHlhOflVRZNrxee3B+yZwd3JHDIvv71uSI/SIzzt
# 9cU2GyHQVqxBSrRtKW6W8Vw7zpVvoVsIv3ljxg+7NiGSlXX1s7zbBNDMUj9OnzOl
# HK/3mrOU8YEuRf6RwakW5UCeGamy5MiKu2YuyKiGBCv4OGhPstNe7ALkEOh8BX12
# t4ntuYu+gw9L6yCPY0jWYaQtzAP9MIIHcTCCBVmgAwIBAgITMwAAABXF52ueAptJ
# mQAAAAAAFTANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNh
# dGUgQXV0aG9yaXR5IDIwMTAwHhcNMjEwOTMwMTgyMjI1WhcNMzAwOTMwMTgzMjI1
# WjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQD
# Ex1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCCAiIwDQYJKoZIhvcNAQEB
# BQADggIPADCCAgoCggIBAOThpkzntHIhC3miy9ckeb0O1YLT/e6cBwfSqWxOdcjK
# NVf2AX9sSuDivbk+F2Az/1xPx2b3lVNxWuJ+Slr+uDZnhUYjDLWNE893MsAQGOhg
# fWpSg0S3po5GawcU88V29YZQ3MFEyHFcUTE3oAo4bo3t1w/YJlN8OWECesSq/XJp
# rx2rrPY2vjUmZNqYO7oaezOtgFt+jBAcnVL+tuhiJdxqD89d9P6OU8/W7IVWTe/d
# vI2k45GPsjksUZzpcGkNyjYtcI4xyDUoveO0hyTD4MmPfrVUj9z6BVWYbWg7mka9
# 7aSueik3rMvrg0XnRm7KMtXAhjBcTyziYrLNueKNiOSWrAFKu75xqRdbZ2De+JKR
# Hh09/SDPc31BmkZ1zcRfNN0Sidb9pSB9fvzZnkXftnIv231fgLrbqn427DZM9itu
# qBJR6L8FA6PRc6ZNN3SUHDSCD/AQ8rdHGO2n6Jl8P0zbr17C89XYcz1DTsEzOUyO
# ArxCaC4Q6oRRRuLRvWoYWmEBc8pnol7XKHYC4jMYctenIPDC+hIK12NvDMk2ZItb
# oKaDIV1fMHSRlJTYuVD5C4lh8zYGNRiER9vcG9H9stQcxWv2XFJRXRLbJbqvUAV6
# bMURHXLvjflSxIUXk8A8FdsaN8cIFRg/eKtFtvUeh17aj54WcmnGrnu3tz5q4i6t
# AgMBAAGjggHdMIIB2TASBgkrBgEEAYI3FQEEBQIDAQABMCMGCSsGAQQBgjcVAgQW
# BBQqp1L+ZMSavoKRPEY1Kc8Q/y8E7jAdBgNVHQ4EFgQUn6cVXQBeYl2D9OXSZacb
# UzUZ6XIwXAYDVR0gBFUwUzBRBgwrBgEEAYI3TIN9AQEwQTA/BggrBgEFBQcCARYz
# aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9Eb2NzL1JlcG9zaXRvcnku
# aHRtMBMGA1UdJQQMMAoGCCsGAQUFBwMIMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIA
# QwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFNX2
# VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwu
# bWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEw
# LTA2LTIzLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93
# d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYt
# MjMuY3J0MA0GCSqGSIb3DQEBCwUAA4ICAQCdVX38Kq3hLB9nATEkW+Geckv8qW/q
# XBS2Pk5HZHixBpOXPTEztTnXwnE2P9pkbHzQdTltuw8x5MKP+2zRoZQYIu7pZmc6
# U03dmLq2HnjYNi6cqYJWAAOwBb6J6Gngugnue99qb74py27YP0h1AdkY3m2CDPVt
# I1TkeFN1JFe53Z/zjj3G82jfZfakVqr3lbYoVSfQJL1AoL8ZthISEV09J+BAljis
# 9/kpicO8F7BUhUKz/AyeixmJ5/ALaoHCgRlCGVJ1ijbCHcNhcy4sa3tuPywJeBTp
# kbKpW99Jo3QMvOyRgNI95ko+ZjtPu4b6MhrZlvSP9pEB9s7GdP32THJvEKt1MMU0
# sHrYUP4KWN1APMdUbZ1jdEgssU5HLcEUBHG/ZPkkvnNtyo4JvbMBV0lUZNlz138e
# W0QBjloZkWsNn6Qo3GcZKCS6OEuabvshVGtqRRFHqfG3rsjoiV5PndLQTHa1V1QJ
# sWkBRH58oWFsc/4Ku+xBZj1p/cvBQUl+fpO+y/g75LcVv7TOPqUxUYS8vwLBgqJ7
# Fx0ViY1w/ue10CgaiQuPNtq6TPmb/wrpNPgkNWcr4A245oyZ1uEi6vAnQj0llOZ0
# dFtq0Z4+7X6gMTN9vMvpe784cETRkPHIqzqKOghif9lwY1NNje6CbaUFEMFxBmoQ
# tB1VM1izoXBm8qGCAtQwggI9AgEBMIIBAKGB2KSB1TCB0jELMAkGA1UEBhMCVVMx
# EzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoT
# FU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IElyZWxh
# bmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjpG
# QzQxLTRCRDQtRDIyMDElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2Vy
# dmljZaIjCgEBMAcGBSsOAwIaAxUAx2IeGHhk58MQkzzSWknGcLjfgTqggYMwgYCk
# fjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQD
# Ex1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUFAAIF
# AOgzyGEwIhgPMjAyMzA2MTQxMzAyMjVaGA8yMDIzMDYxNTEzMDIyNVowdDA6Bgor
# BgEEAYRZCgQBMSwwKjAKAgUA6DPIYQIBADAHAgEAAgICBDAHAgEAAgIRbjAKAgUA
# 6DUZ4QIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAowCAIBAAID
# B6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBALgF+WmCllw6hBjlQvM6
# hPk82NmmBzM1GrhZ3EMhzOj/Q4HA7hUU6iEKsvMOORhYIZq3YjdrWz0VTRVCM22t
# FMQ9jUuMulTytBGxtZrbgkvOfkMOsMQZZFyvXyr5E7bGEcgOacusIu+G6h5O5Q1H
# EuPB1oj0Mlr5Gh9ZPPnegrsnMYIEDTCCBAkCAQEwgZMwfDELMAkGA1UEBhMCVVMx
# EzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoT
# FU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUt
# U3RhbXAgUENBIDIwMTACEzMAAAG59gANZVRPvAMAAQAAAbkwDQYJYIZIAWUDBAIB
# BQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0BCQQx
# IgQgIzeAszxnV5ffNzkq9NNYMjBWN1KrfGFU+5hpoqSLdWQwgfoGCyqGSIb3DQEJ
# EAIvMYHqMIHnMIHkMIG9BCBk60bO8W85uTAfJVEO3vX2aLaQFcgcGpdwsOoi+foP
# 9DCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAw
# DgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24x
# JjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAABufYA
# DWVUT7wDAAEAAAG5MCIEIEhpscsb1gzWTVZ7a6nJAuxkj1u8Eeqmy4k1AM99JHUU
# MA0GCSqGSIb3DQEBCwUABIICAAP8iH98Oj2SZjBM2NoPEN4pMRW2KN1UpBZq8AmA
# 1mFKkNW74fB7B19Pw6ivaXL4uPM6RVBBm2jasDtUegfujpLr+Juis4SsWboOhahU
# Wod0DuAXVapRRP9YOdCHcyCBN/jPlmjDfNv7TNqpH07Qiy3QYIjAJqmcaRbDUTjU
# h+L4medH/5vYBEwcxIQl6AVLtaCgmzq1CXkO0JxxE+SCnSaColQiVBheL2z39qPk
# UJWOi2lVoJfjTPkpqgIIbwIRbgqzcp0/PYgRcMt1cfKkrrLiawobXbUMpZqDAT01
# +04dBZxbvEiLzQHRV3tyrJA9NP3wOu0F3/n+Tsz8TZnDh78q0A4gBkRIE2C7FQ3y
# zqaZ9s0rh4QwW5BRQ2VrInLrSa2MGg9coUeqPC8oJ9VnCirEvhxvQ8Kt+N6UGxcd
# rgFGVEcFytCQzUXv9+0i0/EB/CPM0URuMZeIwe4Ea9ntHeWYC732u1dp479Xm/Pp
# L4JZ1sEsA1wyZZA8rtrmEKKUXtEoJfcCS/SgLOQhBZMHR9OZ4odP7KTd9buWxDx7
# f40yd4gzTX9hjnhwGuBp+ynLcoRVYcLbsyc1+cUUDErsYbKOVYhProqHQB9Ed17x
# 5aYt/BsdckqNpCgXVuDbCoMeRQDBObWhYe8LDSUdgVY2szie2geQTkNhWzQYU9yK
# PApY
# SIG # End signature block
