# Name: RFL_update-script.ps1 forSDPcheck
# last edit by: waltere 2022-09-14

<# 
.SYNOPSIS
	Script to [auto-]update RFL to latest version or download latest zip from CesdiagTools/GitHub.

.DESCRIPTION
	Script will search on "https://microsoft.githubenterprise.com/css-windows/WindowsCSSToolsDevRep/releases/tag" / GitHub for latest RFL version
	If local version does not match the remote CesdiagTools/GitHub version, it will download and replace RFL with latest version
	Script gets the current version from version_SDPcheck.dat and compares to version on 'https://cesdiagtools.blob.core.windows.net/windows/RFL.ver' /GitHub.

.PARAMETER RFL_action
	choose action from allowed values: "Download" or "Update" or "Version"
		Download	= download latest CesdiagTools/GitHub version
		Update		= update current local version
		Version		= decide based on local version, try AutoUpdate if local version is lower than CesdiagTools/GitHub version
	Ex: -RFL_action "Download"

.PARAMETER RFL_file
	Specify filename from allowed values: "RFL.zip" or "RFL_DB.zip"
	Ex: .\RFL_update-script.ps1 -RFL_file "RFL.zip"

.PARAMETER RFL_path
	Specify the local path where check-rfl-csv_Tech_Path.ps1 is located.
	Ex: .\RFL_update-script.ps1 -RFL_path "C:\RFL"

.PARAMETER UpdMode
	Specify the mode: 
		Online  = complete package (RFL.zip) from aka.ms/getRFL
		Full    = complete package (RFL.zip) from CesdiagTools/GitHub
		Quick   = differential package only (RFL_DB.zip): replace only database files
		Force   = run a Full update, regardless of current installed version

.PARAMETER RFL_arch
	Specify the System Architecture.
	Allowed values:
		x64 - For 64-bit systems
		x86 - For 32-bit systems
	Ex: .\RFL_update-script.ps1 -RFL_arch "x64"

.EXAMPLE
	Example 1: Update RFL in folder C:\RFL
	.\RFL_update-script.ps1 -RFL_action "Update" -RFL_path "C:\RFL" -RFL_file "RFL.zip"

.LINK
	https://microsoft.githubenterprise.com/css-windows/WindowsCSSToolsDevRep/releases/tag
	Public Download: RFL:    https://cesdiagtools.blob.core.windows.net/windows/RFL.zip -or- https://aka.ms/getRFL or aka.ms/getRFL
#>


param(
	[ValidateSet("download","update","version")]
	[Parameter(Mandatory=$False,Position=0,HelpMessage='Choose from: download|update|version')]
	[string]$RFL_action 	= "update",
	[string]$RFL_path 		= (Split-Path $MyInvocation.MyCommand.Path -Parent),
	[ValidateSet("Online","Full","Quick","Force")]
	[string]$UpdMode 		= "Full",
	[ValidateSet("RFL.zip","RFL_DB.zip")]
	[string]$RFL_file 		= "RFL.zip",
	[ValidateSet("x64","x86")]
	[string]$RFL_arch 		= "x64",
	[switch]$AutoUpd		= $False,							# 
	[switch]$UseExitCode 	= $true								# This will cause the script to bail out after the error is logged if an error occurs.
)

#region  ::::: [Variables] -----------------------------------------------------------#
$verDateScript	= "2022.09.14.1"
$ScriptFolder = Split-Path $MyInvocation.MyCommand.Path -Parent
$RflUpdLogfile 		= $ScriptFolder + "\_RFL_Update-Log.txt"
$script:ChkFailed	= $FALSE
$invocation 		= (Get-Variable MyInvocation).Value
$ScriptParentPath 	= $MyInvocation.MyCommand.Path | Split-Path -Parent
$scriptName 		= $invocation.MyCommand.Name
if ($UpdMode -match 'Online') {
	$RFLReleaseServer = "cesdiagtools.blob.core.windows.net"
	$RFL_release_url  = "https://cesdiagtools.blob.core.windows.net/windows"
} else {
	$RFLReleaseServer = "api.Github.com"
	$RFL_release_url  = "https://api.github.com/repos/walter-1/offline-SDPcheck/releases"
}
#endregion  ::::: [Variables] --------------------------------------------------------#
# Load Common Library /module
	Remove-Module Utils_RflUpd -ErrorAction Ignore
	Import-Module $ScriptFolder\Utils_RflUpd.psm1 -DisableNameChecking
	  
$Script:BeginTimeStamp = Get-Date


# Check if trailing "\" was provided in $RFL_path, if it was not, add it
if (-not $RFL_path.EndsWith("\")){
	$RFL_path = $RFL_path + "\"
}

#region Logging functions
Function global:RflEnterFunc([String]$FunctionName){
	Write-Verbose "---> Enter $FunctionName"
}
Function global:RflEndFunc([String]$FunctionName){
	Write-Verbose "<--- End $FunctionName"
}
#endregion Logging functions

#region  ::::: [MAIN] ----------------------------------------------------------------#
	# detect OS version and SKU # Note: gwmi / Get-WmiObject is no more supportd in PS v7 -> use Get-CimInstance
	If($Host.Version.Major -ge 7){
		[Reflection.Assembly]::LoadWithPartialName("System.ServiceProcess.servicecontroller") | Out-Null
		$wmiOSVersion = Get-CimInstance -Namespace "root\cimv2" -Class Win32_OperatingSystem
	} else {$wmiOSVersion = Get-WmiObject -Namespace "root\cimv2" -Class Win32_OperatingSystem}
	[int]$bn = [int]$wmiOSVersion.BuildNumber
	#Write-verbose "installed-version: $(get_local_RFL_version current) - Build: $bn"
	$installedRFLver = New-Object System.Version([version]$(get_local_RFL_version "current"))
	Write-verbose "installedRFLver: $installedRFLver"

	## :: Criteria to use Quick (DB only) vs. Online update: Quick if UpdMode = Quick; Online = if full package is needed, ...
	# Choose download file based on $UpdMode (and current installed RFL build)
	$RFL_file = "RFL.zip"
	switch ($UpdMode) {
			"Quick"	{ 	$RFL_file = "RFL_DB.zip"
						$UpdateSource= "GitHub"}
			"Online"{ 	$RFL_file = "RFL.zip"
						$UpdateSource= "CesdiagTools"}
			default	{ 	$RFL_file = "RFL.zip"
						$UpdateSource= "GitHub"}
	}
			
	# Check for Internet connectivity // Test-NetConnection does not work for Win7
	$isReachable = FwTestConnWebSite $RFLReleaseServer -ErrorAction SilentlyContinue
	if ( $isReachable -eq "True") {
		if ($UpdMode -Notmatch "Online") {
			$script:expectedVersion = New-Object System.Version(get_latest_RFL_version $RFL_release_url)
		}
		if ("$($script:expectedVersion)" -eq "0.0") { Write-Verbose "Bail out: $script:expectedVersion"; ExitWithCode 20}
		# Check if RFL exists in $RFL_path
		if (-not (Test-Path ($RFL_path + "check-rfl-csv_Tech_Path.ps1"))){
			Write-Host -ForegroundColor Red "[Warning] check-rfl-csv_Tech_Path.ps1 could not be located in $RFL_path"
			DownloadFileFromGitHubRelease "update" $RFL_file $installedRFLver -RFL_Path $ScriptFolder
		}

		if (Test-Path ($RFL_path + "check-rfl-csv_Tech_Path.ps1")){
			if ($UpdMode -match "Online") {
				DownloadRFLZipFromCesdiagRelease -File "RFL.zip"
			}
			elseif ($UpdMode -match "Force") {	# update regardless of current local version
			Write-Host -ForegroundColor Cyan "[Forced update:] to latest version $script:expectedVersion from $UpdateSource`n"
			 if (Test-Path ($RFL_path + "x64\TTTracer.exe")) { Write-Host -ForegroundColor Yellow "[note:] This procedure will not refresh iDNA part"}
										DownloadFileFromGitHubRelease "update" $RFL_file $installedRFLver -RFL_Path $ScriptFolder
			} else {
				Write-Host "[Info] checking current version $installedRFLver in $RFL_path against latest released $UpdateSource version $script:expectedVersion."
				if ($($installedRFLver.CompareTo($script:expectedVersion)) -eq 0) { 		# If versions match, display message
					"`n [Info] Latest RFL version $script:expectedVersion is installed. " | Out-File $RflUpdLogfile -Append
					Write-Host -ForegroundColor Cyan "[Info] Latest RFL version $script:expectedVersion is installed.`n"}
				elseif ($($installedRFLver.CompareTo($script:expectedVersion)) -lt 0) {	# if installed current version is lower than latest $UpdateSource Release version
					"`n [Action: $RFL_action -[Warning] Actually installed RFL version $installedRFLver is outdated] " | Out-File $RflUpdLogfile -Append
					Write-Host -ForegroundColor red "[Warning] Actually installed RFL version $installedRFLver is outdated"
					Write-Host "[Info] Expected latest RFL version on $($UpdateSource) = $script:expectedVersion"
					Write-Host -ForegroundColor yellow "[Warning] ** Update will overwrite customized Shell script, latest Rfl-Check_ShellExtension.reg is preserved in Rfl-Check_ShellExtension.reg_backup. ** "
					switch($RFL_action)
						{
						"download"		{ 	Write-Host "[download:] latest $RFL_file"
											DownloadFileFromGitHubRelease "download" $RFL_file $installedRFLver -RFL_Path $ScriptFolder
										}
						"update"		{ 	Write-Host "[update:] to latest version $script:expectedVersion from $UpdateSource " 
											DownloadFileFromGitHubRelease "update" $RFL_file $installedRFLver -RFL_Path $ScriptFolder
										}
						"version"		{ 	Write-Host -background darkRed "[version:] installed RFL version is outdated, please run 'RFL Update', trying AutoUpate" # or answer next question with 'Yes'"
											Write-Host -ForegroundColor Cyan "[Info] running AutoUpdate now... (to avoid updates, append RFL switch 'noUpdate')"
											DownloadFileFromGitHubRelease "update" $RFL_file $installedRFLver -RFL_Path $ScriptFolder
										}
						}
						"`n [Action: $RFL_action - OK] " | Out-File $RflUpdLogfile -Append
				}
				else {	# if installed current version is greater than latest CesdiagTools/GitHub Release version
					if ($script:ChkFailed) {Write-Host -ForegroundColor Gray "[Info] Version check failed! Expected version on $($UpdateSource) = $script:expectedVersion. Please download https://aka.ms/getRFL `n"}
					Write-Verbose "Match: Current installed RFL version:  $installedRFLver"
					Write-Verbose "Expected latest RFL version on $($UpdateSource) = $script:expectedVersion"
				}
			}
		}
	} else {
		Write-Host -ForegroundColor Red "[failed update] Missing secure internet connection to $RFLReleaseServer. Please download https://aka.ms/getRFL `n"
									 "`n [failed update] Missing secure internet connection to $RFLReleaseServer. Please download https://aka.ms/getRFL `n" | Out-File $RflUpdLogfile -Append
	}

	$ScriptEndTimeStamp = Get-Date
	$Duration = $(New-TimeSpan -Start $Script:BeginTimeStamp -End $ScriptEndTimeStamp)

	Write-Host -ForegroundColor Black -background gray "[Info] Script $scriptName v$verDateScript execution finished. Duration: $Duration"
	if ($AutoUpd) { Write-Host -ForegroundColor Yellow  "[AutoUpdate done] .. Please repeat your RFL command now."}
#endregion  ::::: [MAIN] -------------------------------------------------------------#

#region  ::::: [ToDo] ----------------------------------------------------------------#
<# 
 ToDo: 

- Implement a scheduled task for periodic update check
Example one-line command: schtasks.exe /Create /SC DAILY /MO 1 /TN "RFL Updater" /TR "powershell \path\to\script\get-latest-check-rfl-csv_Tech_Path.ps1 -RFL_path 'path\to\where\RFL\is' -RFL_arch 'x64'" /ST 12:00 /F
	[/SC DAILY]: Run daily
	[/MO 1]: Every Day
	[/TN "RFL Updater"]: Task Name
	[/TR "powershell \path\to\script\get-latest-check-rfl-csv_Tech_Path.ps1 -RFL_path 'path\to\where\RFL\is' -RFL_arch 'x64'"]: Command to run
	[/ST 12:00]: Run at 12 PM
	[/F]: Force update
#>
#endregion  ::::: [ToDo] ----------------------------------------------------------------#


# SIG # Begin signature block
# MIInsQYJKoZIhvcNAQcCoIInojCCJ54CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDsnI3LEc/GUwFM
# trsFTDEH5EZbHoAQDwPm0IDEIyhk0aCCDXYwggX0MIID3KADAgECAhMzAAACy7d1
# OfsCcUI2AAAAAALLMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjIwNTEyMjA0NTU5WhcNMjMwNTExMjA0NTU5WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC3sN0WcdGpGXPZIb5iNfFB0xZ8rnJvYnxD6Uf2BHXglpbTEfoe+mO//oLWkRxA
# wppditsSVOD0oglKbtnh9Wp2DARLcxbGaW4YanOWSB1LyLRpHnnQ5POlh2U5trg4
# 3gQjvlNZlQB3lL+zrPtbNvMA7E0Wkmo+Z6YFnsf7aek+KGzaGboAeFO4uKZjQXY5
# RmMzE70Bwaz7hvA05jDURdRKH0i/1yK96TDuP7JyRFLOvA3UXNWz00R9w7ppMDcN
# lXtrmbPigv3xE9FfpfmJRtiOZQKd73K72Wujmj6/Su3+DBTpOq7NgdntW2lJfX3X
# a6oe4F9Pk9xRhkwHsk7Ju9E/AgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUrg/nt/gj+BBLd1jZWYhok7v5/w4w
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzQ3MDUyODAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAJL5t6pVjIRlQ8j4dAFJ
# ZnMke3rRHeQDOPFxswM47HRvgQa2E1jea2aYiMk1WmdqWnYw1bal4IzRlSVf4czf
# zx2vjOIOiaGllW2ByHkfKApngOzJmAQ8F15xSHPRvNMmvpC3PFLvKMf3y5SyPJxh
# 922TTq0q5epJv1SgZDWlUlHL/Ex1nX8kzBRhHvc6D6F5la+oAO4A3o/ZC05OOgm4
# EJxZP9MqUi5iid2dw4Jg/HvtDpCcLj1GLIhCDaebKegajCJlMhhxnDXrGFLJfX8j
# 7k7LUvrZDsQniJZ3D66K+3SZTLhvwK7dMGVFuUUJUfDifrlCTjKG9mxsPDllfyck
# 4zGnRZv8Jw9RgE1zAghnU14L0vVUNOzi/4bE7wIsiRyIcCcVoXRneBA3n/frLXvd
# jDsbb2lpGu78+s1zbO5N0bhHWq4j5WMutrspBxEhqG2PSBjC5Ypi+jhtfu3+x76N
# mBvsyKuxx9+Hm/ALnlzKxr4KyMR3/z4IRMzA1QyppNk65Ui+jB14g+w4vole33M1
# pVqVckrmSebUkmjnCshCiH12IFgHZF7gRwE4YZrJ7QjxZeoZqHaKsQLRMp653beB
# fHfeva9zJPhBSdVcCW7x9q0c2HVPLJHX9YCUU714I+qtLpDGrdbZxD9mikPqL/To
# /1lDZ0ch8FtePhME7houuoPcMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGZEwghmNAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAALLt3U5+wJxQjYAAAAAAsswDQYJYIZIAWUDBAIB
# BQCggbAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIOwhn64V7falrpmzga1E9vuq
# t+YqbZqsUt3TJ8JnikArMEQGCisGAQQBgjcCAQwxNjA0oBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEcgBpodHRwczovL3d3dy5taWNyb3NvZnQuY29tIDANBgkqhkiG9w0B
# AQEFAASCAQBpAd7W4Izysl5ZEvFmdiAg3YD3siCIs2iA7IzBjCPhFsPezzJkin59
# 7LX0ZFHgv/dl6KGAuOI5DYLDVmbdThq+sgyXPwoDZNl4uM2P5e+AFeZa/jgWbexD
# 1IpTxZ8Okb+DACeM/CvyunuULaxBCcbe/zpkgu4PPJ0xBgqlZXG0a7O5BRixjBwX
# 9UCTNPUJJ/6CGLCEzGxwQ4vjESnDmgfWK/q2Vs2mMnTYcLjw4o5+OnLqdbGYdYQs
# Nv6Fb7X/BzY942GKcfZuBcl7z0zoniSGfjacVLRRAVHJtqmixqJiRAMKSXH3TNcp
# tsWer3MGWzs68yS56BXgzBIm/zuA7fOQoYIXGTCCFxUGCisGAQQBgjcDAwExghcF
# MIIXAQYJKoZIhvcNAQcCoIIW8jCCFu4CAQMxDzANBglghkgBZQMEAgEFADCCAVkG
# CyqGSIb3DQEJEAEEoIIBSASCAUQwggFAAgEBBgorBgEEAYRZCgMBMDEwDQYJYIZI
# AWUDBAIBBQAEIFsU3L3CYNg0S6kHPcOZn1UaW7pXSSIXgwiX9PwApJIxAgZjEhDc
# E2cYEzIwMjIwOTE2MTMwNTE1Ljc0NlowBIACAfSggdikgdUwgdIxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJ
# cmVsYW5kIE9wZXJhdGlvbnMgTGltaXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBF
# U046QTI0MC00QjgyLTEzMEUxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1w
# IFNlcnZpY2WgghFoMIIHFDCCBPygAwIBAgITMwAAAY16VS54dJkqtwABAAABjTAN
# BgkqhkiG9w0BAQsFADB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3Rv
# bjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0
# aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0y
# MTEwMjgxOTI3NDVaFw0yMzAxMjYxOTI3NDVaMIHSMQswCQYDVQQGEwJVUzETMBEG
# A1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWlj
# cm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJlbGFuZCBP
# cGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkEyNDAt
# NEI4Mi0xMzBFMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNl
# MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA2jRILZg+O6U7dLcuwBPM
# B+0tJUz0wHLqJ5f7KJXQsTzWToADUMYV4xVZnp9mPTWojUJ/l3O4XqegLDNduFAO
# bcitrLyY5HDsxAfUG1/2YilcSkSP6CcMqWfsSwULGX5zlsVKHJ7tvwg26y6eLklU
# dFMpiq294T4uJQdXd5O7mFy0vVkaGPGxNWLbZxKNzqKtFnWQ7jMtZ05XvafkIWZr
# NTFv8GGpAlHtRsZ1A8KDo6IDSGVNZZXbQs+fOwMOGp/Bzod8f1YI8Gb2oN/mx2cc
# vdGr9la55QZeVsM7LfTaEPQxbgAcLgWDlIPcmTzcBksEzLOQsSpBzsqPaWI9ykVw
# 5ofmrkFKMbpQT5EMki2suJoVM5xGgdZWnt/tz00xubPSKFi4B4IMFUB9mcANUq9c
# HaLsHbDJ+AUsVO0qnVjwzXPYJeR7C/B8X0Ul6UkIdplZmncQZSBK3yZQy+oGsuJK
# XFAq3BlxT6kDuhYYvO7itLrPeY0knut1rKkxom+ui6vCdthCfnAiyknyRC2lknqz
# z8x1mDkQ5Q6Ox9p6/lduFupSJMtgsCPN9fIvrfppMDFIvRoULsHOdLJjrRli8co5
# M+vZmf20oTxYuXzM0tbRurEJycB5ZMbwznsFHymOkgyx8OeFnXV3car45uejI1B1
# iqUDbeSNxnvczuOhcpzwackCAwEAAaOCATYwggEyMB0GA1UdDgQWBBR4zJFuh59G
# wpTuSju4STcflihmkzAfBgNVHSMEGDAWgBSfpxVdAF5iXYP05dJlpxtTNRnpcjBf
# BgNVHR8EWDBWMFSgUqBQhk5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3Bz
# L2NybC9NaWNyb3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIwMjAxMCgxKS5jcmww
# bAYIKwYBBQUHAQEEYDBeMFwGCCsGAQUFBzAChlBodHRwOi8vd3d3Lm1pY3Jvc29m
# dC5jb20vcGtpb3BzL2NlcnRzL01pY3Jvc29mdCUyMFRpbWUtU3RhbXAlMjBQQ0El
# MjAyMDEwKDEpLmNydDAMBgNVHRMBAf8EAjAAMBMGA1UdJQQMMAoGCCsGAQUFBwMI
# MA0GCSqGSIb3DQEBCwUAA4ICAQA1r3Oz0lEq3VvpdFlh3YBxc4hnYkALyYPDa9FO
# 4XgqwkBm8Lsb+lK3tbGGgpi6QJbK3iM3BK0ObBcwRaJVCxGLGtr6Jz9hRumRyF8o
# 4n2y3YiKv4olBxNjFShSGc9E29JmVjBmLgmfjRqPc/2rD25q4ow4uA3rc9ekiauf
# gGhcSAdek/l+kASbzohOt/5z2+IlgT4e3auSUzt2GAKfKZB02ZDGWKKeCY3pELj1
# tuh6yfrOJPPInO4ZZLW3vgKavtL8e6FJZyJoDFMewJ59oEL+AK3e2M2I4IFE9n6L
# VS8bS9UbMUMvrAlXN5ZM2I8GdHB9TbfI17Wm/9Uf4qu588PJN7vCJj9s+KxZqXc5
# sGScLgqiPqIbbNTE+/AEZ/eTixc9YLgTyMqakZI59wGqjrONQSY7u0VEDkEE6ikz
# +FSFRKKzpySb0WTgMvWxsLvbnN8ACmISPnBHYZoGssPAL7foGGKFLdABTQC2PX19
# WjrfyrshHdiqSlCspqIGBTxRaHtyPMro3B/26gPfCl3MC3rC3NGq4xGnIHDZGSiz
# UmGg8TkQAloVdU5dJ1v910gjxaxaUraGhP8IttE0RWnU5XRp/sGaNmDcMwbyHuSp
# aFsn3Q21OzitP4BnN5tprHangAC7joe4zmLnmRnAiUc9sRqQ2bmsMAvUpsO8nlOF
# miM1LzCCB3EwggVZoAMCAQICEzMAAAAVxedrngKbSZkAAAAAABUwDQYJKoZIhvcN
# AQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xMjAw
# BgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmljYXRlIEF1dGhvcml0eSAyMDEw
# MB4XDTIxMDkzMDE4MjIyNVoXDTMwMDkzMDE4MzIyNVowfDELMAkGA1UEBhMCVVMx
# EzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoT
# FU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUt
# U3RhbXAgUENBIDIwMTAwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDk
# 4aZM57RyIQt5osvXJHm9DtWC0/3unAcH0qlsTnXIyjVX9gF/bErg4r25PhdgM/9c
# T8dm95VTcVrifkpa/rg2Z4VGIwy1jRPPdzLAEBjoYH1qUoNEt6aORmsHFPPFdvWG
# UNzBRMhxXFExN6AKOG6N7dcP2CZTfDlhAnrEqv1yaa8dq6z2Nr41JmTamDu6Gnsz
# rYBbfowQHJ1S/rboYiXcag/PXfT+jlPP1uyFVk3v3byNpOORj7I5LFGc6XBpDco2
# LXCOMcg1KL3jtIckw+DJj361VI/c+gVVmG1oO5pGve2krnopN6zL64NF50ZuyjLV
# wIYwXE8s4mKyzbnijYjklqwBSru+cakXW2dg3viSkR4dPf0gz3N9QZpGdc3EXzTd
# EonW/aUgfX782Z5F37ZyL9t9X4C626p+Nuw2TPYrbqgSUei/BQOj0XOmTTd0lBw0
# gg/wEPK3Rxjtp+iZfD9M269ewvPV2HM9Q07BMzlMjgK8QmguEOqEUUbi0b1qGFph
# AXPKZ6Je1yh2AuIzGHLXpyDwwvoSCtdjbwzJNmSLW6CmgyFdXzB0kZSU2LlQ+QuJ
# YfM2BjUYhEfb3BvR/bLUHMVr9lxSUV0S2yW6r1AFemzFER1y7435UsSFF5PAPBXb
# GjfHCBUYP3irRbb1Hode2o+eFnJpxq57t7c+auIurQIDAQABo4IB3TCCAdkwEgYJ
# KwYBBAGCNxUBBAUCAwEAATAjBgkrBgEEAYI3FQIEFgQUKqdS/mTEmr6CkTxGNSnP
# EP8vBO4wHQYDVR0OBBYEFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMFwGA1UdIARVMFMw
# UQYMKwYBBAGCN0yDfQEBMEEwPwYIKwYBBQUHAgEWM2h0dHA6Ly93d3cubWljcm9z
# b2Z0LmNvbS9wa2lvcHMvRG9jcy9SZXBvc2l0b3J5Lmh0bTATBgNVHSUEDDAKBggr
# BgEFBQcDCDAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYw
# DwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvXzpoY
# xDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtp
# L2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYIKwYB
# BQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20v
# cGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNydDANBgkqhkiG9w0B
# AQsFAAOCAgEAnVV9/Cqt4SwfZwExJFvhnnJL/Klv6lwUtj5OR2R4sQaTlz0xM7U5
# 18JxNj/aZGx80HU5bbsPMeTCj/ts0aGUGCLu6WZnOlNN3Zi6th542DYunKmCVgAD
# sAW+iehp4LoJ7nvfam++Kctu2D9IdQHZGN5tggz1bSNU5HhTdSRXud2f8449xvNo
# 32X2pFaq95W2KFUn0CS9QKC/GbYSEhFdPSfgQJY4rPf5KYnDvBewVIVCs/wMnosZ
# iefwC2qBwoEZQhlSdYo2wh3DYXMuLGt7bj8sCXgU6ZGyqVvfSaN0DLzskYDSPeZK
# PmY7T7uG+jIa2Zb0j/aRAfbOxnT99kxybxCrdTDFNLB62FD+CljdQDzHVG2dY3RI
# LLFORy3BFARxv2T5JL5zbcqOCb2zAVdJVGTZc9d/HltEAY5aGZFrDZ+kKNxnGSgk
# ujhLmm77IVRrakURR6nxt67I6IleT53S0Ex2tVdUCbFpAUR+fKFhbHP+CrvsQWY9
# af3LwUFJfn6Tvsv4O+S3Fb+0zj6lMVGEvL8CwYKiexcdFYmNcP7ntdAoGokLjzba
# ukz5m/8K6TT4JDVnK+ANuOaMmdbhIurwJ0I9JZTmdHRbatGePu1+oDEzfbzL6Xu/
# OHBE0ZDxyKs6ijoIYn/ZcGNTTY3ugm2lBRDBcQZqELQdVTNYs6FwZvKhggLXMIIC
# QAIBATCCAQChgdikgdUwgdIxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJhdGlvbnMgTGlt
# aXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046QTI0MC00QjgyLTEzMEUxJTAj
# BgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2WiIwoBATAHBgUrDgMC
# GgMVAIBzlZM9TRND4PgtpLWQZkSPYVcJoIGDMIGApH4wfDELMAkGA1UEBhMCVVMx
# EzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoT
# FU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUt
# U3RhbXAgUENBIDIwMTAwDQYJKoZIhvcNAQEFBQACBQDmzlqeMCIYDzIwMjIwOTE2
# MTAxNDU0WhgPMjAyMjA5MTcxMDE0NTRaMHcwPQYKKwYBBAGEWQoEATEvMC0wCgIF
# AObOWp4CAQAwCgIBAAICBS8CAf8wBwIBAAICE1IwCgIFAObPrB4CAQAwNgYKKwYB
# BAGEWQoEAjEoMCYwDAYKKwYBBAGEWQoDAqAKMAgCAQACAwehIKEKMAgCAQACAwGG
# oDANBgkqhkiG9w0BAQUFAAOBgQAF6PhrgTswQKzWqPTyW7GgQ7G3PY+Zi7z+IMwY
# hb85kFYD9BtnnKO4G4PMkZd5znEvK7LfsHzwXPJ62fEhflWI6YmSynUinncdMdk3
# HqgcBJrAC5fF+sBDPM+GpSO4oeO0G008FLoowjLsorfaTJufWdHm90I9Ya/iMi8O
# 7Ri7wTGCBA0wggQJAgEBMIGTMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEw
# AhMzAAABjXpVLnh0mSq3AAEAAAGNMA0GCWCGSAFlAwQCAQUAoIIBSjAaBgkqhkiG
# 9w0BCQMxDQYLKoZIhvcNAQkQAQQwLwYJKoZIhvcNAQkEMSIEIOgFTqRUGecBd8h8
# U+8koUBpimF3uJPkRyoILBUFNP70MIH6BgsqhkiG9w0BCRACLzGB6jCB5zCB5DCB
# vQQgnpYRM/odXkDAnzf2udL569W8cfGTgwVuenQ8ttIYzX8wgZgwgYCkfjB8MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNy
# b3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAAY16VS54dJkqtwABAAABjTAi
# BCB6cNGw8Js04M/uRXIyviOxJCeMOsh/Xc4hNfb3Y3ZRxDANBgkqhkiG9w0BAQsF
# AASCAgDGGawR7g1mHYht0vnUBwP55a9pFbyI2VnmeP0KVOKX4FONCf0FkYYuAykh
# mVJvEb/6hpzeFiTMM7MFe3JZ3dmrLDYe1P4wP6XNc0PxhnBnySP6tkBX/Uy9eu0e
# E7xf6RDbCIcvNi3VbX/SE15QuV2Cui9WtUHflMCddkRvh3iGejbuN5quoXJKW9mv
# ZqL+mHJX2i2ZjPwNYPaiWce5895iFT7qExPUghXWhTbUEvm+A6H2bUiO0VvwEDy5
# mzLBZQ6nxPC7KZKBE+5wGwM+YXR7LNLcEDrvmI6eEQ53SU3jRAxLJr7ccd8LvgNi
# tJgH8HIG6Ajnp0cQFXQvuvfLOTlhmXLFVPhs15NTg5fzEnz0ixz73vFaqneNkXsy
# BLyNHc339gp4cTfo9KEWH4xvUc81Yg2kFb/BzSNlDzgF/fu9iyEGh6kbSpYKcUlT
# +Xu1GZomrTFHOH/+HlptitDqvwDvdcht4jsgss6h6SDrJFJUj6e597rAOawwbv7f
# dPFEcOhu5b0vQ8uz+mi0McmBKfOOPK0J+wdmQkqBnhZtLQki+gg/F7KDbKjTimva
# pR+5m3+eVeceOezOkewrI9M7GCm1RmoKXyHz0YVdOeZAVD3TXeCTgIaO0jiwdk0I
# rpKvDjQk/EMVie3q7ajw2/KONcXRo3E45iAn0e0CC8QCyN76JA==
# SIG # End signature block
